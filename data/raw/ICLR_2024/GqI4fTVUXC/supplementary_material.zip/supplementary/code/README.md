# On the Disconnect Between Theory and Practice of Overparametrized Neural Networks

This supplementary material contains the code to reproduce all experiments shown in the paper. 

## Dependencies

To install the dependencies into a virtual environment with `conda`, run
```sh
conda env create --file .conda_env.yml
```
which sets up an environment named `ntk`.

Enable it with
```sh
conda activate ntk
```

### Verify installed dependencies

To check that everything works, try running the tests with
```sh
pytest -vx test
```
