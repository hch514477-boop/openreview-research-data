# Memory-efficient implementation of WideResNet
# https://github.com/xternalz/WideResNet-pytorch/

import torch
import torch.nn as nn
import torch.nn.functional as F
from avalanche.models.dynamic_modules import MultiHeadClassifier, MultiTaskModule

__all__ = ["WideResNet", "MTWideResNet"]


class BasicBlock(nn.Module):
    def __init__(self, in_planes, out_planes, stride, dropRate=0.0):
        super(BasicBlock, self).__init__()
        self.bn1 = nn.BatchNorm2d(in_planes)
        self.relu1 = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(
            in_planes, out_planes, kernel_size=3, stride=stride, padding=1, bias=False
        )
        self.bn2 = nn.BatchNorm2d(out_planes)
        self.relu2 = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(
            out_planes, out_planes, kernel_size=3, stride=1, padding=1, bias=False
        )
        self.droprate = dropRate
        self.equalInOut = in_planes == out_planes
        self.convShortcut = (
            (not self.equalInOut)
            and nn.Conv2d(
                in_planes,
                out_planes,
                kernel_size=1,
                stride=stride,
                padding=0,
                bias=False,
            )
            or None
        )

    def forward(self, x):
        if not self.equalInOut:
            x = self.relu1(self.bn1(x))
        else:
            out = self.relu1(self.bn1(x))
        out = self.relu2(self.bn2(self.conv1(out if self.equalInOut else x)))
        if self.droprate > 0:
            out = F.dropout(out, p=self.droprate, training=self.training)
        out = self.conv2(out)
        return torch.add(x if self.equalInOut else self.convShortcut(x), out)


class NetworkBlock(nn.Module):
    def __init__(self, nb_layers, in_planes, out_planes, block, stride, dropRate=0.0):
        super(NetworkBlock, self).__init__()
        self.layer = self._make_layer(
            block, in_planes, out_planes, nb_layers, stride, dropRate
        )

    def _make_layer(self, block, in_planes, out_planes, nb_layers, stride, dropRate):
        layers = []
        for i in range(int(nb_layers)):
            layers.append(
                block(
                    i == 0 and in_planes or out_planes,
                    out_planes,
                    i == 0 and stride or 1,
                    dropRate,
                )
            )
        return nn.Sequential(*layers)

    def forward(self, x):
        return self.layer(x)


class WideResNet(nn.Module):
    def __init__(self, depth, num_classes, widen_factor=1, drop_rate=0.0):
        super(WideResNet, self).__init__()

        # Channels
        num_channels_list = [
            16,
            16 * widen_factor,
            32 * widen_factor,
            64 * widen_factor,
        ]
        assert (depth - 4) % 6 == 0
        n = (depth - 4) / 6

        # 1st conv before any network block
        self.conv1 = nn.Conv2d(
            3, num_channels_list[0], kernel_size=3, stride=1, padding=1, bias=False
        )
        # 1st block
        self.block1 = NetworkBlock(
            n, num_channels_list[0], num_channels_list[1], BasicBlock, 1, drop_rate
        )
        # 2nd block
        self.block2 = NetworkBlock(
            n, num_channels_list[1], num_channels_list[2], BasicBlock, 2, drop_rate
        )
        # 3rd block
        self.block3 = NetworkBlock(
            n, num_channels_list[2], num_channels_list[3], BasicBlock, 2, drop_rate
        )
        # global average pooling and classifier
        self.bn1 = nn.BatchNorm2d(num_channels_list[3])
        self.relu = nn.ReLU(inplace=True)
        self.fc = nn.Linear(num_channels_list[3], num_classes)
        self.num_channels = num_channels_list[3]

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.bias.data.zero_()

        # Features
        self.features = nn.Sequential(
            self.conv1,
            self.block1,
            self.block2,
            self.block3,
            self.bn1,
            self.relu,
            nn.AvgPool2d(kernel_size=8),
        )

        # Classifier
        self.classifier = self.fc

    def forward(self, x):
        out = self.features(x)
        out = out.view(-1, self.num_channels)
        return self.classifier(out)


class MTWideResNet(WideResNet, MultiTaskModule):
    """WideResNet with multi-head classifier with separate heads for each task.

    Implementation modeled after: https://avalanche-api.continualai.org/en/v0.1.0/_modules/avalanche/models/simple_cnn.html#MTSimpleCNN
    """

    def __init__(self, depth, num_classes, widen_factor=1, drop_rate=0):
        super().__init__(depth, num_classes, widen_factor, drop_rate)
        self.classifier = MultiHeadClassifier(self.num_channels)

    def forward(self, x, task_labels):
        out = self.features(x)
        out = out.view(-1, self.num_channels)
        return self.classifier(out, task_labels)
