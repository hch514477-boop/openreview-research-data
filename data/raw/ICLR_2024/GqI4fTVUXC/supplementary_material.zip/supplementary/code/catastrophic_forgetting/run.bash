#!/bin/bash

# # MLP - RotatedMNIST
# nn_widths='16 32 64 128 256 512 1024 2048 4096 8192 16384 32768 65536 131072 262144 524288'
# seeds='276 478 150 463 121'
# # seeds='70 59 493 412 526'

# for nn_width in $nn_widths
# do
#     for seed in $seeds
#     do
#         python experiment.py \
#         --dataset rotatedmnist \
#         --nn_width $nn_width \
#         --nn_depth 2 \
#         --train_mb_size 32 \
#         --train_epochs 5 \
#         --lr 0.001 \
#         --momentum 0.9 \
#         --weight_decay 0.0001 \
#         --seed $seed
#     done
# done

# WideResNet - SplitCifar10
width_scaling_factors='1 2 4 8 16 32'
train_epochs_list='5 50'
seeds='107 613 778 626 844'

for width_scaling in $width_scaling_factors
do
    for seed in $seeds
    do
        for train_epochs in $train_epochs_list
        do
            python experiment.py \
            --dataset splitcifar10 \
            --nn_width $width_scaling \
            --nn_depth 10 \
            --train_mb_size 128 \
            --train_epochs $train_epochs \
            --lr 0.1 \
            --momentum 0.9 \
            --weight_decay 0.0001 \
            --seed $seed
        done
    done
done

# WideResNet - SplitCifar100
# seeds='107 613 778 626 844'
# seeds='828 790 617 770 623'

# for width_scaling in $width_scaling_factors
# do
#     for seed in $seeds
#     do
#         python experiment.py \
#         --dataset splitcifar100 \
#         --nn_width $width_scaling \
#         --nn_depth 10 \
#         --train_mb_size 128 \
#         --train_epochs 50 \
#         --lr 0.1 \
#         --momentum 0.9 \
#         --weight_decay 0.0001 \
#         --seed $seed
#     done
# done

# # WideResNet - TinyImageNet
# train_epochs_list='5'

# for width_scaling in $width_scaling_factors
# do
#     for seed in $seeds
#     do
#         for train_epochs in $train_epochs_list
#         do
#             python experiment.py \
#             --dataset splittinyimagenet \
#             --nn_width $width_scaling \
#             --nn_depth 10 \
#             --train_mb_size 128 \
#             --train_epochs $train_epochs \
#             --lr 0.1 \
#             --momentum 0.9 \
#             --weight_decay 0.0001 \
#             --seed $seed
#         done
#     done
# done
