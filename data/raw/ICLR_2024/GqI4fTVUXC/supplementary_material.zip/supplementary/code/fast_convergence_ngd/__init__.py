"""Evaluates the conditions for fast convergence of NGD from Zhang et al."""
