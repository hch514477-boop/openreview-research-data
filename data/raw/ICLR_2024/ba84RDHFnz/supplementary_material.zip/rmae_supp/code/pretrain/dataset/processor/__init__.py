from pretrain.dataset.processor.processors import build_processor

__all__ = ["build_processor"]
