# RETSim: Resilient and Efficient Text Similarity

RETSim training scripts are located under the training/ folder. Pre-trained RETSim models are provided under the models/ folder.