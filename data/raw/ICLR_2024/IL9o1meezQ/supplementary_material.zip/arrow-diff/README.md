# Random Walk Diffusion For Graph Generation

## Set Up Conda Environment

- `conda create -n arrow_diff python=3.9`
- `conda install pytorch torchvision torchaudio pytorch-cuda=11.6 -c pytorch -c nvidia`
- `conda install pyg -c pyg -c conda-forge`
- `conda install -c conda-forge matplotlib`
- `conda install -c conda-forge umap-learn`
- `conda install -c conda-forge jupyterlab`
- `conda install -c conda-forge ipywidgets`
- `conda install nb_conda_kernels -c conda-forge`
- `conda install numpy=1.22` # Downgrade numpy
- `pip install pyyaml`
- `pip install powerlaw`
- `pip install igraph`

## Training

### Run Training of ARROW-Diff on Single Graph Datasets

Please change the name of the dataset in `configs/config_single_graph.yaml` and `python main_arrow_diff_single_graph_training.py`.

### Run Training of ARROW-Diff on Multi Graph Datasets

Please change the name of the dataset in `configs/config_multi_graph.yaml` and `python main_arrow_diff_multi_graph_training.py`.

## Graph Generation

### Run Training of ARROW-Diff on Single Graph Datasets

Please change the name of the dataset in `configs/config_single_graph.yaml` and `python main_arrow_diff_single_graph_generation.py`.

### Run Training of ARROW-Diff on Multi Graph Datasets

Please change the name of the dataset in `configs/config_multi_graph.yaml` and `python main_arrow_diff_multi_graph_generation.py`.