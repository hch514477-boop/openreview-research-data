#!/usr/bin/env bash

export NUM_FOLDS=8
export NUM_FOLDS_VAL=1
# Training
cd ../data
mkdir -p logs

# if [ $(hostname) == "shoob" ]; then
parallel -j $(nproc --all) --will-cite --lb "python3 process.py -fold {1} -num_folds ${NUM_FOLDS} " ::: $(seq 0 $((${NUM_FOLDS}-1)))
# fi
