# Supplementary Code for Our Paper

This README provides detailed instructions on how to run the code provided in the supplementary material.

## Prerequisites

### Dataset and Environment Configuration

Refer to the details in PatchTST [repository](https://github.com/yuqinie98/PatchTST#supervised-learning-1).


## Running the Code

We provide a variety of training scripts located in the `scripts` directory. The scripts are organized based on two look-back window lengths: 336 and 720.

For each dataset, a dedicated shell script is available to predict with different output lengths.

### Multivariate Time Series Forecasting

For example, to train the model on the ETTh2 dataset with a 336-length input for multivariate time series prediction, run:

```bash
sh ./scripts/336/etth2.sh
```

### Univariate Time Series Forecasting
Scripts for univariate prediction are located within the `univariate` subdirectory. To train the model on the ETTh2 dataset with a 336-length input for univariate time series prediction, use:

```bash
sh ./scripts/336/univariate/etth2.sh
```

## Citation of PatchTST
```
@inproceedings{Yuqietal-2023-PatchTST,
  title     = {A Time Series is Worth 64 Words: Long-term Forecasting with Transformers},
  author    = {Nie, Yuqi and
               H. Nguyen, Nam and
               Sinthong, Phanwadee and 
               Kalagnanam, Jayant},
  booktitle = {International Conference on Learning Representations},
  year      = {2023}
}
```