from .serverFedAvg import ServerFedAvg
from .serverSimpFedIncen import ServerSimpFedIncen

__api__ = [
    'ServerFedAvg',
    'ServerSimpFedIncen'
]