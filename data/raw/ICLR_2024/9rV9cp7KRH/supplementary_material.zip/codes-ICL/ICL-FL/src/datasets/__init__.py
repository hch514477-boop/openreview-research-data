from .mnist import MNIST, FashionMNIST
from .cifar import CIFAR10, CIFAR100
from .svhn import SVHN
from .cinic import CINIC10
from .utils import *

__all__ = [
    'MNIST', 
    'FashionMNIST', 
    'CIFAR10', 
    'CIFAR100', 
    'SVHN',
    'CINIC10',

]
