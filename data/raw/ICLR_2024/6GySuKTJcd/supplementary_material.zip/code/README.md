# Averaging with Energy!A Generic Algorithm for Continuous Entropic Barycenter Estimation
Energy-guided continuous Entropic Wasserstein Barycenter Estimation 

## Repository structure:

### folders

```src``` - The implementation of our method and auxiliary code for experiments: plotting, logging, etc.

```notebooks``` - The code for running of experiments of the paper.

```stylegan2``` - The code for stylegan2 model.

### running experiments

```notebooks/toy_2d_twister.ipynb``` - The code for Barycenter of 2D distributions.


```notebooks/MNIST_01_barycenter_in_data_space.ipynb``` - The code for Barycenter of MNIST classes 0 and 1 in data space.


```notebooks/MNIST_01_barycenter_in_latent_space.ipynb``` - The code for Barycenter of MNIST classes 0 and 1 in maniflod constrained.


```notebooks/Ave_celeba_in_latent_space.ipynb``` -  The code for Barycenter of the Ave,CELEBA! dataset.

