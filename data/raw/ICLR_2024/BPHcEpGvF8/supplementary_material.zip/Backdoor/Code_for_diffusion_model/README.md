# Demystifying Poisoning Backdoor Attacks from a Statistical Perspective 

## Introduction

We develop a theoretic understanding of the factors contributing to effective poisoning backdoor attacks. This code conducts a simulated data experiment to demonstrate the developed theory.



## Files

- `train.py`: Run the experiments on backdooring diffusion models with MNIST dataset.

## Note

- Change `save_dir` in line 346 of `train.py` to the directory where you want to save the results.