# Demystifying Poisoning Backdoor Attacks from a Statistical Perspective 

## Introduction

We develop a theoretic understanding of the factors contributing to effective poisoning backdoor attacks. This code conducts a simulated data experiment to demonstrate the developed theory.

## Prerequisites

See `requirements.txt`.

## Files

Main files:
- `experiment.py`: Run the experiments on synthetic two-dimensional Gaussian datasets.

