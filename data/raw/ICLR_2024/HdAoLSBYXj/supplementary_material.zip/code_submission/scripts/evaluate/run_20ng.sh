python compute_npmi.py ./outputs/scholar/20ng_50/topics.txt ./data/20ng/processed/train.npz ./data/20ng/processed/train.vocab.json
