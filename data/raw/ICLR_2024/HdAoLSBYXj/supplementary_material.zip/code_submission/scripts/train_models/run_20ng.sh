python run.py data/20ng/processed/ -l 0.002 --batch-size 200 -k 50 --K 32 --n_perm 2 --test-prefix test --device 0 --o ./outputs/scholar/20ng_50 --epochs 500 --model trueContrastiveScholar
