## Requirements
- python3
- pandas
- gensim
- numpy
- torchvision
- pytorch 1.7.0
- scipy

## How to Run
1. Download and put the dataset in the ```data``` folder: bit.ly/3Zrg0ht
2. Train the model by running ```./scripts/train_models/run_{dataset}_{topk}.sh```
3. Evaluate the model via executing ```./scripts/evaluate/run_{dataset}_npmi_{topk}.sh```

