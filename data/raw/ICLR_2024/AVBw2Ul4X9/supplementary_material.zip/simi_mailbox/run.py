import argparse
import subprocess
import numpy as np

parser = argparse.ArgumentParser(description="run")
parser.add_argument("--device", type=str)
parser.add_argument("--run", type=int)

args = parser.parse_args()
