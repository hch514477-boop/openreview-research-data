
# The Role of Forgetting in Fine-Tuning Reinforcement Learning Models

## Overview

Based on [Decision Transformer: Reinforcement Learning via Sequence Modeling](https://sites.google.com/berkeley.edu/decision-transformer).

## Installation

First, you'll need [MuJoCo](http://www.mujoco.org/) simulator. Please follow
the [instructions](https://github.com/openai/mujoco-py#install-mujoco)
from `mujoco_py` package. As MuJoCo has been made freely available, you can obtain a free
license [here](https://www.roboti.us/license.html).


Next, go to the main directory of this repo and run

```sh
pip install -e .[dev] --extra-index-url https://download.pytorch.org/whl/cu116
```

Then setup pre-commit 
```sh
pre-commit install
```

## Example usage

Experiments can be reproduced with the following:

```
python -m run_single_experiment --env hopper --dataset medium --model_type dt --use_actions True --use_returns True
```

Adding `-w True` will log results to Weights and Biases.
