#!/bin/bash
#SBATCH --job-name=train_with_models
#SBATCH --cpus-per-task=32
#SBATCH --mem=500GB
#SBATCH --time=48:00:00
#SBATCH --array=1-1   # Adjust the array range based on the number of models

# Load Conda environment
eval "$(conda shell.bash hook)"
conda activate acer

# Get the current array task ID
current_task_id=${SLURM_ARRAY_TASK_ID}
SEED=$((current_task_id - 1))


python behavioral_cloning/train.py -c ./config_bc.conf -d ./trajectories_mini2/ \
  --runname dataset_1500

# Deactivate Conda environment
conda deactivate
