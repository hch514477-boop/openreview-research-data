import gym
from gym.utils.play import play

play(gym.make("MontezumaRevengeNoFrameskip-v4"))