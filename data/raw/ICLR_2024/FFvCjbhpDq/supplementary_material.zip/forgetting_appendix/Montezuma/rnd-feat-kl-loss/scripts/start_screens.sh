#!/bin/bash

conda_environment="atari"
GPU=1
# Define the kl_coef values to check
kl_coef_values=(0.05 0.1 0.5 1)

# Loop through each kl_coef value
for kl_coef in "${kl_coef_values[@]}"; do
    # Define the experiment command
#    experiment="CUDA_VISIBLE_DEVICES=${GPU} python train.py -c ./configs/config.conf --usekl True \
#    --kltrajectoriespath trajectories_kl_mini --klcoef $kl_coef \
#    --runname kl_coef_${kl_coef} --rungroup kl_test \
#    --loadmodel True --loadmodelfolder pretrained_10_11 --loadmodelsuffix 686_ \
#    --savemodelnamesuffix ft_with_kl_${kl_coef} \
#    --usestateloading False --roomsaving False"

     screen -dmS "kl_coef_$kl_coef" bash -c "sleep 2;exec bash; eval '"$(conda shell.bash hook)"';  conda activate $conda_environment"

done

echo "All screen sessions started."
