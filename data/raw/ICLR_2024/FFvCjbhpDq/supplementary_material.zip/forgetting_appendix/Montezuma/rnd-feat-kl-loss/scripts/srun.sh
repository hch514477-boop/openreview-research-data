#!/bin/bash
#SBATCH --job-name=train_with_models
#SBATCH --cpus-per-task=32
#SBATCH --mem=20GB
#SBATCH --time=48:00:00
#SBATCH --array=1-4   # Adjust the array range based on the number of models

# Load Conda environment
eval "$(conda shell.bash hook)"
conda activate acer

# Define an array of different <load_model> values
load_models=(
    "pretrained_6_1" "pretrained_6_11" "pretrained_6_22" "pretrained_6_31"
)

# Get the current array task ID
current_task_id=${SLURM_ARRAY_TASK_ID}
ROOM=6
SEED=$((current_task_id - 1))

# Use the task ID to select a <load_model> value
load_model=${load_models[current_task_id - 1]}

echo "Training with load_model=$load_model"
python -m train -c ./config.conf --loadmodelfolder "$load_model" --zerointrinsic False \
  --usestateloading False --roomsaving False \
  --loadmodel True --savemodelnamesuffix ft_${ROOM}_${SEED}  \
  --loadmodelsuffix find \
  --runname finetune_${ROOM}_from_${load_model}  --rungroup finetune_${ROOM}

# Deactivate Conda environment
conda deactivate
