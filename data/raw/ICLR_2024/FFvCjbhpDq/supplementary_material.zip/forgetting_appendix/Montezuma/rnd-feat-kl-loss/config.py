import configparser

config = configparser.ConfigParser()
config.read('./configs/config.conf')

# ---------------------------------
default = 'DEFAULT'
# ---------------------------------
default_config = config[default]
