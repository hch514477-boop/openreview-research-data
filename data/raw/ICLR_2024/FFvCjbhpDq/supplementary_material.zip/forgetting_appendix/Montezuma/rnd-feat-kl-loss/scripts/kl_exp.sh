conda_environment="atari"
GPU=3
kl_coef=0.025
SEED=1
#LOAD_MODEL_FOLDERS=("pretrained_10_1" "pretrained_10_11" "pretrained_10_7")
LOAD_MODEL_FOLDER="pretrained_10_7"
LOAD_MODEL_SUFFIX=find
ROOM=10




CUDA_VISIBLE_DEVICES=${GPU} python train.py -c ./configs/config.conf --usekl True \
--kltrajectoriespath trajectories_kl_mini --klcoef $kl_coef \
--zerointrinsicrooms 0 --zerointrinsic False \
--runname kl_coef_${kl_coef}_${LOAD_MODEL_FOLDER} --rungroup kl_final \
--loadmodel True --loadmodelfolder ${LOAD_MODEL_FOLDER} --loadmodelsuffix ${LOAD_MODEL_SUFFIX} \
--savemodelnamesuffix ft_with_kl_${kl_coef}_r${ROOM}_s${SEED} \
--usestateloading False --roomsaving False --resume False