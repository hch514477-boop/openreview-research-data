GPU=1
ROOMS_TO_ZERO="0"
SEED=3

CUDA_VISIBLE_DEVICES=${GPU} python -m train -c ./configs/config.conf --zerointrinsic False \
  --roomsaving False --zerointrinsicrooms ${ROOMS_TO_ZERO}  --usestateloading False \
  --loadmodel False --savemodelnamesuffix from_scratch_checkpoints_${SEED} \
  --runname from_scratch  --rungroup from_scratch_dense --usekl False