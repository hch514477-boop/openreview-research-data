ROOM=0
GPU=2
LOAD_MODEL_SUFFIX=find
#LOAD_MODEL_FOLDERS=("pretrained_10_1" "pretrained_10_11" "pretrained_10_7")
LOAD_MODEL_FOLDER="pretrained_0_21"
SEED=1

CUDA_VISIBLE_DEVICES=${GPU} python -m train -c ./configs/config.conf --zerointrinsic False \
  --usestateloading False --roomsaving False --usekl False \
  --loadmodel True --savemodelnamesuffix finetune_${ROOM}_${SEED}  \
  --loadmodelfolder ${LOAD_MODEL_FOLDER} --loadmodelsuffix ${LOAD_MODEL_SUFFIX} \
  --runname finetune_${ROOM}_${LOAD_MODEL_FOLDER}  --rungroup finetune_${ROOM}_eval \
  --maxglobalupdate 10000 --resume False --runid hnwkf7pm

