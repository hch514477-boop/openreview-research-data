ROOM=1
GPU=4
ROOMS_TO_ZERO="1,2"

for SEED in 1;
do CUDA_VISIBLE_DEVICES=${GPU} python -m train -c ./config.conf --zerointrinsic True --usestateloading True \
  --loadroom ${ROOM} --roomsaving True --zerointrinsicrooms ${ROOMS_TO_ZERO} \
  --loadmodel False --savemodelnamesuffix pretrained_${ROOM}_${SEED} \
  --runname pretrain_${ROOM}  --rungroup pretrain_from_${ROOM}
done