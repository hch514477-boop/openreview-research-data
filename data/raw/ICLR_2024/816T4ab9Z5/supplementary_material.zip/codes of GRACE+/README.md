# Dependencies
- numpy==1.25.2
- ogb==1.3.6
- PyYAML==6.0.1
- scikit_learn==1.3.0
- scipy==1.11.3
- torch==1.12.1+cu113
- torch_geometric==2.3.1
- torch_scatter==2.0.9
- torch_sparse==0.6.14

Install all dependencies using
```
pip install -r requirements.txt
```

Train and evaluate the model by executing
```
python train.py --algorithm GRACE+I --dataset Cora
```
The `--dataset` argument should be one of [ Cora, CiteSeer, PubMed, DBLP, Amazon-Photo, Amazon-Computers ]. and the `--algorithm` argument should be one of [ GRACE+I, GRACE+S ], pure GRACE could be GRACE+I with retain rate of 0%
