# -*- coding:utf-8 _*-
# @License: MIT Licence

# @Time: 14/7/2023

import os, sys
import time
import random
import warnings
import numpy as np
from pathlib import Path
import argparse
import json

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Process some arguments.')
    parser.add_argument('--file', type=str, required=True, help='the path to the input file')
    parser.add_argument('--value', type=int, required=True, help='the value to be subtracted')
    args = parser.parse_args()

    with open(args.file, 'r') as f:
        lines = f.readlines()
    with open(args.file, 'w') as f:
        for line in lines:
            if line.strip() == '':
                continue
            else:
                content = json.loads(line.strip())
                content['id'] -= args.value
                f.write(json.dumps(content) + '\n')
