

# Create a Conda Environment
conda create -n torch python=3.11

pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# For replay buffers
mkdir deps
git clone https://github.com/pytorch/rl torchrl
cd torchrl
pip install -e .

pip install -U tensordict-nightly

pip install gym==0.23.0
pip install cpprb
pip install tensorboard
cd join-optimization
pip install -e .
pip install wandb
pip install Cython
pip install d3rlpy
