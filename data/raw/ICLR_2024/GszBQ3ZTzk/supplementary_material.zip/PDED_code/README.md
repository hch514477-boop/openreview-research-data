# PDED

This repo is for source code of paper "PDED: Revitalize physics laws submerged in data information for Traffic State Estimation".

## Environment

- python == 3.7.10
- pytorch == 1.8.1
- numpy == 1.19.2
- pandas == 1.2.2
- scipy == 1.7.3

## Main Methods

Here we provide an implementation of PDED in PyTorch, along with an execution example on US-80 datasets.  
```python
python main.py
```




