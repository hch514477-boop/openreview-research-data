config_path="config/thumos_i3d_eval.yaml"

CUDA_VISIBLE_DEVICES=0 python -W ignore ./main_eval.py --config ${config_path}