config_path="config/thumos_i3d_train.yaml"

CUDA_VISIBLE_DEVICES=0 python -W ignore ./main.py --config ${config_path}