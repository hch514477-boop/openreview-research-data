
from abc import ABC, abstractmethod
class Reward(ABC):
    def __init__(self, logits_to_soft_pred,
                 logits_to_hard_pred):

        self.logits_to_soft_pred = logits_to_soft_pred
        self.logits_to_hard_pred = logits_to_hard_pred
