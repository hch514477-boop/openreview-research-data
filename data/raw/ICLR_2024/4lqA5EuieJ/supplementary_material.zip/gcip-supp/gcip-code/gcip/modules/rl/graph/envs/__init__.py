from .node_env_one import GraphEnvOne
from .node_env import GraphEnv

from gcip.modules.rl import env_dict

env_dict_graph = {}
env_dict_graph['graph_one'] = GraphEnvOne
env_dict_graph['graph_many'] = GraphEnv

env_dict.update(env_dict_graph)
