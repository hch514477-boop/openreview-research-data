from gcip.utils.kernels.exp import ExponentialKernel

kernels_dict = {
    'exp': ExponentialKernel
}