import gcip.utils.io as playbook_io


def assert_between(tensor, name='', between=(0.0, 1.0)):
    assert tensor.max() <= between[1] and tensor.min() >= between[0], playbook_io.print_debug_tensor(tensor, name)
