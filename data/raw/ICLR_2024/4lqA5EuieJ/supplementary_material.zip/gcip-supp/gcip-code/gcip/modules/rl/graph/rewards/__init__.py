from .gcip import RewardGCIP

from gcip.modules.rl import reward_dict

reward_dict_graph = {}
reward_dict_graph['gcip'] = RewardGCIP
reward_dict.update(reward_dict_graph)
