import os


class Cte:

    DEFAULT_CONFIG_FILE = 'gcip/configs/default_config.yaml'

    DEFAULT = 'default'
    # Losses
    MSE = 'mse'
    BCELOGITS = 'bcelogits'
    CE = 'ce'
    FORWARD = 'forward'