# iNat2018
# ----------------------------------------------------------------------------------------------
python3 prune_ViT_iNat.py \
        --dist_url 'tcp://localhost:50012' \
        --multiprocessing-distributed \
        --world_size 1 \
        --local_rank 0 \
        --batch_size 512 \
        --epochs 200 \
        --lr 0.02 \
        --min_lr 0.0 \
        --warmup_epochs 5 \
        --weight_decay 1e-4 \
        --setting D \
        --prune_rule 'DepGraph' \
        --prune_rate 0.4 \
        --save_dir "./run/ViT/iNat2018/DepGraph/prune63.0/D"