# Residual Denoising Diffusion Models
This paper was submitted to ICLR 2023 (Peer review...).

This repository is the official implementation of Residual Denoising Diffusion Models.

## Requirements

To install requirements:

```
conda env create -f diffuion.yaml
```
## Training

To train the model(s) in the paper, run this command:

```train
python train.py
```
or
```train
accelerate launch train.py
```

## Evaluation

To evaluate image generation, run:

```eval
cd eval/image_generation_eval/
python fid_and_inception_score.py path_of_gen_img
```

For image restoration, MATLAB evaluation codes in `./eval`.

## Pre-trained Models

Due to the limited size of supplementary material (<100M) and the risk of anonymity violations when uploading to cloud drives, pre-trained models (1G) will be provided later.

## Results

See Table 3 in main paper.

