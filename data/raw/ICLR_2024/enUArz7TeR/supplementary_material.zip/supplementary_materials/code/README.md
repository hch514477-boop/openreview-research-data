Here is the code of OPER. **We will provide detailed uasge book** once our work is accepted. Following our uasge book, all results in our paper can be reproduced by this repo.

The script to generate priroirty weights is located at `TD3_BC-bandit/eval_bc_iter.py`.

The script for bandit experiments is located at `TD3_BC-bandit/bandit.ipynb` and `TD3_BC-bandit/main_bandit.py`.

The resampling and reweighting implemntations for OPER-A and OPER-R are integrated into the original code of algorithms (TD3+BC, IQL, CQL, OnestepRL). Behavior cloning is intergrated into the code of OnestepRL.

