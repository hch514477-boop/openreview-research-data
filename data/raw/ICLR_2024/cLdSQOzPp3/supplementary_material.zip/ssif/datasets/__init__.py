from .datasets import register, make
from . import image_folder
from . import wrappers

from . import cave_image_folder
from . import cave_wrappers

from . import pavia_centre_image_folder
from . import pavia_centre_wrappers