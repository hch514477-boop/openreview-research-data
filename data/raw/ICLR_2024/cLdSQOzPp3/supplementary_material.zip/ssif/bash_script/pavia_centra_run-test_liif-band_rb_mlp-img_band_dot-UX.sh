#!/bin/bash
BN=60
RF=gaussian
ST=gaussian
RFS=g
STS=g

python3 test_batch.py \
    --config ./configs/test-pavia_centra/test_rdn-liif_band_rb_mlp.yaml  \
    --model ./save/pavia_centra/train_rdn-liif_band_rb_mlp/PAVIA_CENTRA-TSM8-MD-BANDMIN13-MAX102-SAM13-liif-rdn-256-banddec-mlp-H512_512_512-512-bandposenc-band_rb_mlp-32-1.00-0.000100-H512-bandnerf-img_band_dot1--identity-${BN}-${RF}-invsum-${ST}-LR0.000100-L1/epoch-best.pth \
    --gpu 0  \
    --scale_list 2 3 4 8 10 12 14 16    \
    --num_band_list  102

python3 test_batch.py \
    --config ./configs/test-pavia_centra/test_rdn-liif_band_rb_mlp.yaml  \
    --model ./save/pavia_centra/train_rdn-liif_band_rb_mlp/PAVIA_CENTRA-TSM8-MD-BANDMIN13-MAX102-SAM13-liif-rdn-256-banddec-mlp-H512_512_512-512-bandposenc-band_rb_mlp-32-1.00-0.000100-H512-bandnerf-img_band_dot1--identity-${BN}-${RF}-invsum-${ST}-LR0.000100-L1/epoch-best.pth \
    --gpu 0  \
    --scale_list 2 3 4 8   \
    --num_band_list  2 3 4 8 10 12 14 16 53 58 63 68 73 78 83 88 93 98 102 110 120 130 140 150 
    
