#!/bin/bash
BN=16
RF=uniform
ST=uniform
RFS=u
STS=u

python3 test_batch.py \
    --config ./configs/test-cave/test_rdn-liif-band_rb_mlp.yaml  \
    --model ./save/cave/train_rdn-liif_band_rb_mlp/CAVE-TSM8-BANDMIN8-MAX31-SAM8-liif-rdn-64-banddec-mlp-H256_256_256-256-bandposenc-band_rb_mlp-32-1.00-0.000100-H512-bandnerf-img_band_dot--identity-${BN}-${RF}-invsum-${ST}-LR0.000100-L1/epoch-best.pth   \
    --gpu 0  \
    --scale_list 2 4 8 10 12 14    \
    --num_band_list  31


python3 test_batch.py \
    --config ./configs/test-cave/test_rdn-liif-band_rb_mlp.yaml  \
    --model ./save/cave/train_rdn-liif_band_rb_mlp/CAVE-TSM8-BANDMIN8-MAX31-SAM8-liif-rdn-64-banddec-mlp-H256_256_256-256-bandposenc-band_rb_mlp-32-1.00-0.000100-H512-bandnerf-img_band_dot--identity-${BN}-${RF}-invsum-${ST}-LR0.000100-L1/epoch-best.pth   \
    --gpu 0  \
    --scale_list 2 4 8     \
    --num_band_list  3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40


    
