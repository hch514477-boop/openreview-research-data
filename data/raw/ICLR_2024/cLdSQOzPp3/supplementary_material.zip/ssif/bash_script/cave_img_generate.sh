
#!/bin/bash
BN=32
RF=uniform
ST=uniform
RFS=u
STS=u

ACT=identity

# band_sre_mlp, SSIF-SRE
python3 img_generate.py \
    --config ./configs/test-cave/test_rdn-liif-band_rb_mlp.yaml  \
    --model ./save/cave/train_rdn-liif_band_rb_mlp/CAVE-TSM8-BANDMIN8-MAX31-SAM8-liif-rdn-64-banddec-mlp-H256_256_256-256-bandposenc-band_rb_mlp-32-1.00-0.000100-H512-bandnerf-img_band_cat-256_256_256-${ACT}-${BN}-${RF}-invsum-${ST}-LR0.000100-L1/epoch-best.pth   \
    --gpu 0  \
    --scale_list 2 4 8    \
    --num_band_list  8 16 31

