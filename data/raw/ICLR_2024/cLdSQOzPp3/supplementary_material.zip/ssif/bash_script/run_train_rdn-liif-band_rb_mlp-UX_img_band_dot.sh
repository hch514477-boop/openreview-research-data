   
#!/bin/bash
BN=16
RF=uniform
ST=fix
RFS=u
STS=f

DIM=256

python3 train_liif.py \
    --config ./configs/train-cave/train_rdn-liif-band_rb_mlp-U${BN}_${RF}_${ST}_img_band_dot.yaml  \
    --name  cave/train_rdn-liif_band_rb_mlp \
    --ni

