#!/bin/bash
SS=4000
JOBNAME="a2s${SS}"
#source your_virtua_env_dir


python3 test_a2s2k.py \
--dataset pavia_centra \
--save_data_dir  ./res_data \
--epoch 200 \
--iter 3  \
--patch 5  \
--valid_split 0.9 \
--optimizer adam \
--sample_size ${SS} \
--test_prop 0.01 \
--num_band 102 \
--lr 0.00001  \
--batch_size  600 \
--epoch_save 10