# About the Dataset
This folder is mainly used to show what some of our data sets look like in the training pose estimation phase. Note that this is only a subset of the data set and not the entire due to the file size limitation.
