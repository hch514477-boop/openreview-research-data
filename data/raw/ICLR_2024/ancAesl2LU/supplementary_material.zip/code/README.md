# DomainStudio

DomainStudio is the proposed few-shot domain-driven generation method for diffusion models. It is compatible with unconditional DDPMs and conditional text-to-image models (Stable Diffusion). The code are provided in the two files separately.