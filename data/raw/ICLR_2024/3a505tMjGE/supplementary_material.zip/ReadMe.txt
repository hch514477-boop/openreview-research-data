We provide the implemention code in this folder, which contains two parts:
1) "analysis_code": the code for the analysis in Section 3, containing the single-modal and multi-modal case
                    with linear VAE and non-linear deep VAE;

2) "exps_code": the code for the experiments in Section 4, which is largely based on the official source code
                repository for the ICML 2021 paper "Hierarchical VAEs Know What They Don't Know"
                (https://github.com/JakobHavtorn/hvae-oodd), containing the data preparation, training and testing,
                calculating the metrics, etc.

===================================================================================================================
#  ----------------------------- Instruction for the 1) "analysis_code" ----------------------------------------- #
1. the "analysis_linear_vae.py" is the implementation for single-modal and multi-modal case with linear VAE.
    1) Environment: this code is under python 3.9 environment, with package requirement of: numpy, matplotlib and scipy.
    2) Run: you could directly run "python analysis_linear_vae.py".
    3) Hyper-parameters: as shown in Line 63-66, you could choose parameters "single-mode" or "multi-mode" and other
       parameters about plotting selections.

2. the "analysis_deep_vae.py" is the implementation for multi-modal case with non-linear deep VAE.
    1) Environment: this code is under python 3.9 and PyTorch 1.12.1 environment, with package requirement of: numpy, matplotlib.
    2) Run: you could directly run "python analysis_deep_vae.py".
    3) Hyper-parameters: as shown in Line 149-156, you could choose parameters like hidden_dim and learning rate.

We provide necessary comments for some important parts of the code, e.g., the purpose of each section, expression of the
distribution, and how to modify the code. Since these two cases are helpful for gaining insights of unsupervised OOD detection,
you could modify some parts of them to evaluate your own ideas, like simulation of some OOD data.
===================================================================================================================


===================================================================================================================
#  ----------------------------- Instruction for the 2) "exps_code" ----------------------------------------- #
1) Environment: We thanks for the great effort of Jakob D. Havtorn et al. for developing the code base for VAE-based unsupervised OOD
detection. Since our method is largely based on this public code, a detailed setup for these codes could follow the
guidance in https://github.com/JakobHavtorn/hvae-oodd.
2) Run: you could directly run "python train_vae.py".
3) Hyper-parameters: the parameters could be tunned in the "args" at the begining of the code.
A more detailed guidance would be prepared when this paper is public.
===================================================================================================================




