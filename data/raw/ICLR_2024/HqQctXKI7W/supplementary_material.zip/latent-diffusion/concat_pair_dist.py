import os

import numpy as np
from tqdm import tqdm

print('add directory')
#directory = 

uncs = []
for i in tqdm(range(1000)):
    file_path = os.path.join(directory, f'pair_dist_class{i}.npy')
    data = np.load(file_path) 
    uncs.append(data)

uncs = np.stack(uncs)
np.save(os.path.join(directory, 'pair_dist_mat.npy'), uncs)
