import os

from omegaconf import OmegaConf
import pandas as pd


if __name__ == '__main__':
    print('add train path')
    #train_path = 

    data_path = os.path.join(train_path, 'data') 
    data_dirs = os.listdir(data_path)
    #data_dirs = [d[:-4] for d in data_dirs if '.tar' in d]
    data_dirs = [d for d in data_dirs if os.path.isdir(os.path.join(data_path, d))]
    idx2synset = OmegaConf.load(os.path.join(train_path, 'index_synset.yaml'))
    human_synset = {}
    with open(os.path.join(train_path, 'synset_human.txt')) as f:
        for line in f:
            items = line.split()
            key, values = items[0], ' '.join(items[1:])
            human_synset[key] = values
    df = pd.DataFrame(human_synset.items(), columns=['synset', 'text'])
    wtf = ['n02012849', 'n03126707']
    i = 0
    ch = {}
    for k, v in idx2synset.items():
        ch[k] = df.loc[df['synset']==v].text.iloc[0]
        if not v in data_dirs:
            dbl_synsets = df.loc[df.text==df.loc[df['synset']==v].text.iloc[0]].synset
            right_synset = dbl_synsets.loc[dbl_synsets.isin(data_dirs)]
            if right_synset.shape[0] == 1:
                idx2synset[k] = right_synset.iloc[0]
        if v=='n03126707':
            # note crane double indexed for mechanical and bird
            # also someon fucked up, not me someone else
            # double cranes n02012849, n03126707
            print(k)
            idx2synset[k] = wtf[i]
            i+=1
    OmegaConf.save(idx2synset, os.path.join(train_path, 'index_synset.yaml'))
    check_mofo ={}
    with open(os.path.join(train_path, 'imagenet1000_clsidx_to_labels.txt')) as f:
        for line in f:
            items = line.split(':')
            key, value = int(items[0]), items[1]
            value = value.replace(',\n','').strip(" '")
            check_mofo[key] = value
