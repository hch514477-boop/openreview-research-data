Sampling script:
```shell
python -m akgr.sampling.sample_parallel
```

Main script:
```shell
python -m akgr.abduction_model.main
```
- Use the `mode` argument to choose modes from training / testing / optimizing.

---



Transformer models are implemented in `transformer.py` and `t5.py` under `akgr/abduction_model`.

Utilities for searching queries and anwers in given graphs are implemented in `kgclass.py` under `akgr/kgdata`.

Utilities for conversion between different representations of queries are implemented in `parsing_util.py` under `akgr/utils`.

Training and PPO scripts are implemented in `main.py` under `akgr/abduction_model`.

Evaluation metrics are implemented in `evaluation.py` under the root directory.