from pcrl_dqn import Agent as PCRLAgent

ATARI_AGENTS = {
    "pcrl": PCRLQAgent,
}
