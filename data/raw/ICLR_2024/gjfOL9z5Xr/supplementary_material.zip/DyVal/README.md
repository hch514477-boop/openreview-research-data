# DyVal

## Environment
Run the following command:

```
conda env create -f env.yaml
conda activate dynamic
```

## Sample running commands
### Running Llama2-13b-chat (modify the --model_path)
```
python main.py --model llama2-13b-chat --dataset arithmetic --token_ratio 5 --shot 0 --depth 2 --num_children_per_node 2 --extra_links_per_node 0 --add_rand_desc 0 --delete_desc 0 --add_cycles 0 ---model_path /your/model/path --num_samples 500

python main.py --model llama2-13b-chat --dataset bool_logic --token_ratio 5 --shot 0 --depth 2 --num_children_per_node 2 --extra_links_per_node 0 --add_rand_desc 0 --delete_desc 0 --add_cycles 0 ---model_path /your/model/path --num_samples 500

python main.py --model llama2-13b-chat --dataset reachability --num_nodes_per_sample 7 --max_links_per_node 3  --token_ratio 5 --shot 0 --model_path /your/model/path --num_samples 500
```
