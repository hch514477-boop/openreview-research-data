"""Utilities of tensorflow."""
