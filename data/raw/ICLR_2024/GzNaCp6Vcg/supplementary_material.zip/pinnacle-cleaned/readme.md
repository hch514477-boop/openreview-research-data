## Instructions:

requirement.txt has the dependencies of the file.

To run experiment:
`deepxde_al_patch/al_pinn.sh {exp_num} {alg_num} {other flags}`
For the full expeirment number and algorithm number, see al_pinn.sh

The othe al_pinn*.sh files are structured in the same way
- `al_pinn` : forward and inverse expeirments
- `al_pinn_change_ic` : fine tuning experiments
- `al_pinn_timing` : to measure computation time

`test_al.ipynb` contains a loop that can be ran independently in a notebook

`plot*.ipynb` contains scripts used to generate the plotted graph