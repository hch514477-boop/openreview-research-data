## ICLR

python train.py --learner RBMLE --T 500 --Episodes 20 --S 5 --A 4 --eta 1 --env normal --solving_approach exact --seed 1
python train.py --learner RBMLE --T 500 --Episodes 20 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 1

python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 1
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 2
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 3
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 4
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 5
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 6
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 7
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 8
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 9
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 10
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 11
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 12
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 13
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 14
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 15
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 16
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 17
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 18
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 19
python train.py --learner UCB --T 500 --Episodes 1 --S 5 --A 4 --eta 1 --env normal --seed 20


python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 1
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 2
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 3
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 4
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 5
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 6
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 7
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 8
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 9
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 10
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 11
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 12
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 13
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 14
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 15
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 16
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 17
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 18
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 19
python train.py --learner UCB --T 500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 20



# diff_theta
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 1
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 2
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 3
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 4
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 5
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 6
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 7
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 8
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 9
python train.py --learner UCB --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --seed 10
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 1
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 2
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 3
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 4
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 5
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 6
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 7
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 8
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 9
python train.py --learner RBMLE --T 2500 --Episodes 1 --S 3 --A 2 --eta 1 --env normal --solving_approach exact --seed 10