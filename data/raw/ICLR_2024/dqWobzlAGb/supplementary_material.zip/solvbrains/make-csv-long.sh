#!/bin/sh

function list {
  geomname=$1
  log1=embeddings-long/log-$who-$geomname
  grep CSV $log1 | cut -c 14- | sed -e "s/^/$who;$geomname/;"
  }

echo "who;geom;iteration;places;n;m;req_r;req_t;opt_r;opt_t;loglik;mAP;meanrank;success;stretch;saiter"

for who in Macaque4 Cat3 Cat1 Macaque2 Macaque1 Cat2 Human7 Human6 Macaque3 Human8 CElegans Drosophila1 Human1 Rat3 Human2 Rat2 Rat1 ZebraFinch2 Mouse2   Mouse3 Drosophila2
do for geo in g711 g435 sol3 e3b subsol3 g435b2 h2r twist
  do list $geo
  done
done

for who in Macaque4 Cat3 Cat1 Macaque2 Macaque1 Cat2 Human7 Human6 Macaque3 Human8 CElegans Drosophila1 Human1 Rat3 Human2 Rat2 Rat1 ZebraFinch2 Mouse2   Mouse3 Drosophila2
do for geo in BIG-sol3 BIG-g435 BIG-twist BIG-h2r BIG-g435b2
  do list $geo
  done
done
