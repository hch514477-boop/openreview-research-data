#!/bin/sh

function list {
  geomname=$1
  log1=embeddings/log-$who-$geomname
  grep CSV $log1 | cut -c 14- | sed -e "s/^/$who;$geomname/;"
  }

echo "who;geom;iteration;places;n;m;req_r;req_t;opt_r;opt_t;loglik;mAP;meanrank;success;stretch;saiter"

for who in Macaque4 Cat3 Cat1 Macaque2 Macaque1 Cat2 Human7 Human6 Macaque3 Human8 CElegans Drosophila1 Human1 Rat3 Human2 Rat2 Rat1 ZebraFinch2 Mouse2   Mouse3 Drosophila2
do for geo in g711 g435 g435b2 nil e3b h2r subnil h2ra g711d g435d tree treed s3 t3 h3m h2m g435ch g711ch sol3 subsol3 twist BIG-g435 BIG-sol3 BIG-twist BIG-h2r BIG-g435b2
  do list $geo
  done
done
