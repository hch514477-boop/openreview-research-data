#!/bin/sh

EXEC=hyperrogue/hyper
mkdir -p tes/log-big
rm -rf /tmp/graph-*

SIZE=100000

function solve {
  geomname=$1
  shift
  geostat=tes/log-big/log-$geomname-$SIZE
  if [ true = true ] # ! -f x$geostat
  then

  echo doing $geomname-$SIZE `date`
  GRAPH=/tmp/graph-$geomname

  unbuffer $EXEC -nogui -fixx 0 -s nul -g -canvas 0 stamplen=9 -sag-creq $SIZE -threads 8 -sag_gdist 20 $* -sag-geo-stats -sag_gdist_save $GRAPH -exit > $geostat
  fi
  }

solve BIG-$1 `cat tes/settings/$1`
echo $1 > tes/current-big
