#!/bin/sh

echo -n "name;"
grep "maxsagdist;" tes/log/log-g711 | cut -c 13-
for x in tes/log/log-*
do
  echo -n `echo $x | cut -c 13- | tr "\r" ";"`
  echo -n ";"
  grep "maxsagdist;" $x -A 1 | tail -n 1 | cut -c 13-
done
