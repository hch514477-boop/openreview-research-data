#!/bin/sh

who=$1
geomname=$2
id=$3
EXEC=hyperrogue/hyper
size=`cat tes/sizes/$geomname`
graph=tes/graph/$geomname

#cat embeddings/log-$who-$geomname | grep "CSV;$3" -B 1 | head -n 1 | sed "s/^.*(//" | sed "s/)//" | sed "s/,/ /g" > emb
$EXEC -fixx 0 -s nul -canvas 400000 -g -dftcolor ffd500ff -sag-creq $size `cat tes/settings/$geomname` -sag_gdist_load $graph -sagformat 1 -sag navigable_brain_maps_data/maps/$who/$who.edge -sag-load-solution <(cat embeddings/log-$who-$geomname | grep "CSV;$3" -B 1 | head -n 1 | sed "s/^.*(//" | sed "s/)//" | sed "s/,/ /g") -PM 0 -lab -csc 2
