cd hyperrogue
make mymake
./mymake -O3 -rv
mv *.ttf ..
mv *-geodesics.dat ..
mv honeycombs ..
cd ..
