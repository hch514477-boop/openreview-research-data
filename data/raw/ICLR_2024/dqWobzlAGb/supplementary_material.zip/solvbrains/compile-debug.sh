cd hyperrogue
make mymake
./mymake -rv
mv *.ttf ..
mv *-geodesics.dat ..
mv honeycombs ..
cd ..
