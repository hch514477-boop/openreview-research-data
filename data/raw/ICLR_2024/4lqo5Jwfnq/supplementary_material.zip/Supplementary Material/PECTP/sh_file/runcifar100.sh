#!/bin/bash


if [ ! -d "/logs/adam_vpt/fetch_hyper_para/" ]; then
  mkdir -p /logs/adam_vpt/fetch_hyper_para/
  echo "mkdir done"
fi


# cifar上测试no fusion

nohup python main.py --gpu_used 1 --task_num 10 --file_name fetch_hyper_para --lamda_for_featureformer 350000 --lamda_for_featurelower 0 --lamda_for_pool3 350000 --lamda_for_prompt 400 --fc_inittype type8 --task_id 0  > ./logs/cifar224/in21k/adam_vpt/fetch_hyper_para/out1.out &






