# Predicated Diffusion: Predicate Logic-Based Attention Guidance for Text-to-Image Diffusion Models

This code was built by modifying the official implementation of [Chefer et al., "Attend-and-Excite: Attention-Based Semantic Guidance for Text-to-Image Diffusion Models," SIGGRAPH, 2023.](https://github.com/yuval-alaluf/Attend-and-Excite)

## Usage

For Experiment (i), to generate the image of "a dog and a bowl," run

```sh
python run.py --prompt "A dog and a bowl" --attention_corr_indices [] --attention_exist_indices [2,5] --attention_leak_indices [] --attention_possession_indices []
```

For Experiment (ii), to generate the image of "a brown dog and a yellow bowl," run

```sh
python run.py --prompt "A brown dog and a yellow bowl" --attention_corr_indices [[2,3],[6,7]] --attention_exist_indices [3,7] --attention_leak_indices [[2,7],[6,3]] --attention_possession_indices []
```

For Experiment (iii), to generate the image of "a frog wearing a hat," run

```sh
python run.py --prompt "A frog wearing a hat" --attention_corr_indices [] --attention_exist_indices [2,5] --attention_leak_indices [] --attention_possession_indices [2,5]
```
