def prompt_without_history(question):
    prompt=f"""
    Solve the given arithmetic problem step-by-step and arrive at the final answer.

    Problem 1:
    Brenda invested $300 into a scheme that accumulates simple interest at the rate of three-quarters of the original amount per year. How much in total will she have after 3 years?

    Solution for Problem 1:
    step 1: Three-quarters of $300 is (3/4)*$300 = $225
    step 2: After 3 years, interest of $225*3 = $675 has been accumulated
    step 3: She now has a total of $300+$675 = $975
    final answer: 975

    Problem 2:
    An airport has only 2 planes that fly multiple times a day. Each day, the first plane goes to Greece for three-quarters of its flights, and the remaining flights are split equally between flights to France and flights to Germany. The other plane flies exclusively to Poland, and its 44 trips only amount to half the number of trips the first plane makes throughout each day. How many flights to France does the first plane take in one day?

    Solution for Problem 2:
    step 1: The second plane flies half as much as the first, so the first plane makes 44 flights * 2 = 88 flights a day
    step 2: If 3/4 of the first plane’s flights are to Greece, then flights to France or Germany make up 1 – 3/4 = 1/4 of the total daily flights
    step 3: Therefore, 88 daily flights / 4 = 22 flights to France or Germany
    step 4: Splitting these flights equally means the first plane makes 22 flights / 2 = 11 flights to France in one day
    final answer: 11

    Problem 3:
    200 pounds of carrots are to be distributed to 40 restaurants in a certain city. Each restaurant is to receive 2 pounds of carrots. How many pounds of carrots will not be used?

    Solution for Problem 3:
    step 1: The restaurants need 40 * 2 = 80 lbs. of carrots
    step 2: So 200 - 80 = 120 lbs. of carrots will not be used
    final answer: 120

    Based on the Problem, Solution, and the final answer provided above. Predict the step by step solution for Problem 4 and arrive at final answer-

    Problem 4:
    {question}"""

        
    return prompt


def prompt_with_history(question, history):
    prompt=f"""
    Solve the given arithmetic problem step-by-step and arrive at the final answer.

    Problem 1:
    Brenda invested $300 into a scheme that accumulates simple interest at the rate of three-quarters of the original amount per year. How much in total will she have after 3 years?

    Solution for Problem 1:
    step 1: Three-quarters of $300 is (3/4)*$300 = $225 
    step 2: After 3 years, interest of $225*3 = $675 has been accumulated 
    step 3: She now has a total of $300+$675 = $975 
    final answer: 975 

    Problem 2:
    An airport has only 2 planes that fly multiple times a day. Each day, the first plane goes to Greece for three-quarters of its flights, and the remaining flights are split equally between flights to France and flights to Germany. The other plane flies exclusively to Poland, and its 44 trips only amount to half the number of trips the first plane makes throughout each day. How many flights to France does the first plane take in one day?

    Solution for Problem 2:
    step 1: The second plane flies half as much as the first, so the first plane makes 44 flights * 2 = 88 flights a day. 
    step 2: If 3/4 of the first plane’s flights are to Greece, then flights to France or Germany make up 1 – 3/4 = 1/4 of the total daily flights. 
    step 3: Therefore, 88 daily flights / 4 = 22 flights to France or Germany. 
    step 4: Splitting these flights equally means the first plane makes 22 flights / 2 = 11 flights to France in one day. 
    final answer: 11 

    Problem 3:
    200 pounds of carrots are to be distributed to 40 restaurants in a certain city. Each restaurant is to receive 2 pounds of carrots. How many pounds of carrots will not be used?

    Solution for Problem 3:
    step 1: The restaurants need 40 * 2 = 80 lbs. of carrots. 
    step 2: So 200 - 80 = 120 lbs. of carrots will not be used. 
    final answer: 120 

    Based on the example Problem, Solution, and the final answer provided above. Predict the Solution and final answer for the below Problem 4. 

    Note: For each step in Solution for Problem 4, select the step from OPTIONS provided between the symbols '$$$'. Choose a step only if the reward is HIGH. If the reward is LOW, DO NOT output the respective step.
    
    OPTIONS
    $$$
    {history}
    $$$
    
    Problem 4:
    {question}"""
    
    return prompt

def prompt_without_history_ucl(question, flag):
    prompt=f"""
    Solve the given arithmetic problem step-by-step and arrive at the final answer.

    Problem 1:
    Brenda invested $300 into a scheme that accumulates simple interest at the rate of three-quarters of the original amount per year. How much in total will she have after 3 years?

    Solution for Problem 1:
    step 1: Three-quarters of $300 is (3/4)*$300 = $225
    step 2: After 3 years, interest of $225*3 = $675 has been accumulated
    step 3: She now has a total of $300+$675 = $975
    final answer: 975

    Problem 2:
    An airport has only 2 planes that fly multiple times a day. Each day, the first plane goes to Greece for three-quarters of its flights, and the remaining flights are split equally between flights to France and flights to Germany. The other plane flies exclusively to Poland, and its 44 trips only amount to half the number of trips the first plane makes throughout each day. How many flights to France does the first plane take in one day?

    Solution for Problem 2:
    step 1: The second plane flies half as much as the first, so the first plane makes 44 flights * 2 = 88 flights a day
    step 2: If 3/4 of the first plane’s flights are to Greece, then flights to France or Germany make up 1 – 3/4 = 1/4 of the total daily flights
    step 3: Therefore, 88 daily flights / 4 = 22 flights to France or Germany
    step 4: Splitting these flights equally means the first plane makes 22 flights / 2 = 11 flights to France in one day
    final answer: 11

    Problem 3:
    200 pounds of carrots are to be distributed to 40 restaurants in a certain city. Each restaurant is to receive 2 pounds of carrots. How many pounds of carrots will not be used?

    Solution for Problem 3:
    step 1: The restaurants need 40 * 2 = 80 lbs. of carrots
    step 2: So 200 - 80 = 120 lbs. of carrots will not be used
    final answer: 120

    Based on the Problem, Solution, and the final answer provided above. Predict the step by step solution for Problem 4 and arrive at final answer-

    Problem 4:
    {question}"""

    if flag:
        prompt += f"""\n\nSolution for Problem 4:\nstep 1:"""
        
    return prompt


def prompt_with_history_ucl(question, history):
    prompt=f"""
    Solve the given arithmetic problem step-by-step and arrive at the final answer.

    Problem 1:
    Brenda invested $300 into a scheme that accumulates simple interest at the rate of three-quarters of the original amount per year. How much in total will she have after 3 years?

    Solution for Problem 1:
    step 1: Three-quarters of $300 is (3/4)*$300 = $225 %%%%
    step 2: After 3 years, interest of $225*3 = $675 has been accumulated %%%%
    step 3: She now has a total of $300+$675 = $975 %%%%
    final answer: 975 %%%%

    Problem 2:
    An airport has only 2 planes that fly multiple times a day. Each day, the first plane goes to Greece for three-quarters of its flights, and the remaining flights are split equally between flights to France and flights to Germany. The other plane flies exclusively to Poland, and its 44 trips only amount to half the number of trips the first plane makes throughout each day. How many flights to France does the first plane take in one day?

    Solution for Problem 2:
    step 1: The second plane flies half as much as the first, so the first plane makes 44 flights * 2 = 88 flights a day. %%%%
    step 2: If 3/4 of the first plane’s flights are to Greece, then flights to France or Germany make up 1 – 3/4 = 1/4 of the total daily flights. %%%%
    step 3: Therefore, 88 daily flights / 4 = 22 flights to France or Germany. %%%%
    step 4: Splitting these flights equally means the first plane makes 22 flights / 2 = 11 flights to France in one day. %%%%
    final answer: 11 %%%%

    Problem 3:
    200 pounds of carrots are to be distributed to 40 restaurants in a certain city. Each restaurant is to receive 2 pounds of carrots. How many pounds of carrots will not be used?

    Solution for Problem 3:
    step 1: The restaurants need 40 * 2 = 80 lbs. of carrots. %%%%
    step 2: So 200 - 80 = 120 lbs. of carrots will not be used. %%%%
    final answer: 120 %%%%

    Based on the example Problem, Solution, and the final answer provided above. Predict the Solution and final answer for the below Problem 4. 

    Note: For each step in Solution for Problem 4, select the step from OPTIONS provided between the symbols '$$$'. Choose a step only if the reward is HIGH. If the reward is LOW, DO NOT output the respective step.
    
    OPTIONS
    $$$
    {history}
    $$$
    
    Problem 4:
    {question}

    Solution for Problem 4:
    """
    return prompt
