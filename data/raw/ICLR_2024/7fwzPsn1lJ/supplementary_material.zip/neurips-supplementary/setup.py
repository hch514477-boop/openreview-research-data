from distutils.core import setup


extra_deps = {}

extra_deps["gpu"] = [
    "flash-attn==v1.0.3.post0",
    "triton==2.0.0.dev20221202",
    "xentropy-cuda-lib@git+https://github.com/HazyResearch/flash-attention.git@v0.2.8#subdirectory=csrc/xentropy",
]

setup(
    name="music2text",
    version="0.1",
    description="Experiments in music-text modeling.",
    author="anonymized for review",
    author_email="anonymized for review",
    url="anonymized for review",
    packages=[
        "m2t",
    ],
    extras_require=extra_deps,
)
