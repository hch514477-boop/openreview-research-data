import os
import shutil

representations_dir = "datasets/fsl10k/representations/jukebox/f10"

for f in os.listdir(representations_dir):
    newfile = f.replace("_", "")
    src = os.path.join(representations_dir, f)
    dest = os.path.join(representations_dir, newfile)
    print(f"moving file from {src} to {dest}")
    shutil.move(src, dest)
