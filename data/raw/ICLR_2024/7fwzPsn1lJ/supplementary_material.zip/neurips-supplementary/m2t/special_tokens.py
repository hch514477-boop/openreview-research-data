"""
Shared special token values used throughout modules.
"""
IGNORE_INDEX = -100
DEFAULT_PAD_TOKEN = "[PAD]"
DEFAULT_EOS_TOKEN = "</s>"
DEFAULT_BOS_TOKEN = "<s>"
DEFAULT_UNK_TOKEN = "<unk>"
DEFAULT_AUDIO_TOKEN = "<audio>"
DEFAULT_AUDIO_PATCH_TOKEN = "<audio_patch>"
DEFAULT_AUDIO_START_TOKEN = "<audio_start>"
DEFAULT_AUDIO_END_TOKEN = "<audio_end>"