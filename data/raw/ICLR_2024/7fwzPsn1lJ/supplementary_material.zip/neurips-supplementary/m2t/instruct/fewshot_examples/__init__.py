from dataclasses import dataclass
from typing import List, Dict, Any


@dataclass
class FewShotExample:
    user: Any
    assistant: List[Dict[str, str]]