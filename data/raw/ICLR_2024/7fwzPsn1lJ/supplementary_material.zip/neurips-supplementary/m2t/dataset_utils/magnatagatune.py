import os

MAGNATAGATUNE_TRAIN_CHUNKS = [
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "a",
]
MAGNATAGATUNE_VALIDATION_CHUNKS = [
    "b",
    "c",
]
MAGNATAGATUNE_TEST_CHUNKS = ["d", "e", "f"]


def extract_id_from_mp3_path(path) -> str:
    fname = os.path.basename(path)
    return fname.replace(".mp3", "")
