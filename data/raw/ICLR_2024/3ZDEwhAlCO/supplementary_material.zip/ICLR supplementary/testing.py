import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--gpu", required=True, type=int)
args, unparsed = parser.parse_known_args()
assert args.gpu in [0,1,2,3]

os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)


cath_calls = [
    "python3 ./se3cnn/experiments/scripts/cath/cath.py --data-filename ./se3cnn/data/cath_10arch_ca.npz --model ILPOResNet34hardmax --training-epochs 100 --batch-size 4 --batchsize-multiplier 1 --randomize-orientation --kernel-size 3 --initial_lr=0.0005 --lr_decay_start=40 --burnin-epochs 40 --lr_decay_base=.94 --downsample-by-pooling --p-drop-conv 0.01 --report-frequency 1 --lamb_conv_weight_L1 1e-7 --lamb_conv_weight_L2 1e-7 --lamb_bn_weight_L1 1e-7 --lamb_bn_weight_L2 1e-7 --report-on-test-set --mode test --restore-checkpoint-filename  2023-09-02_14:34:52_best_window_avg.ckpt",
    "python3 ./se3cnn/experiments/scripts/cath/cath.py --data-filename ./se3cnn/data/cath_10arch_ca.npz --model ILPOResNet34softmax --training-epochs 100 --batch-size 4 --batchsize-multiplier 1 --randomize-orientation --kernel-size 3 --initial_lr=0.0005 --lr_decay_start=40 --burnin-epochs 40 --lr_decay_base=.94 --downsample-by-pooling --p-drop-conv 0.01 --report-frequency 1 --lamb_conv_weight_L1 1e-7 --lamb_conv_weight_L2 1e-7 --lamb_bn_weight_L1 1e-7 --lamb_bn_weight_L2 1e-7 --report-on-test-set --mode test --restore-checkpoint-filename  2023-09-02_15:01:57_best_window_avg.ckpt",
    "python3 ./se3cnn/experiments/scripts/cath/cath.py --data-filename ./se3cnn/data/cath_10arch_ca.npz --model ILPOResNet34Smallhardmax --training-epochs 100 --batch-size 4 --batchsize-multiplier 1 --randomize-orientation --kernel-size 3 --initial_lr=0.0005 --lr_decay_start=40 --burnin-epochs 40 --lr_decay_base=.94 --downsample-by-pooling --p-drop-conv 0.01 --report-frequency 1 --lamb_conv_weight_L1 1e-7 --lamb_conv_weight_L2 1e-7 --lamb_bn_weight_L1 1e-7 --lamb_bn_weight_L2 1e-7 --report-on-test-set --mode test --restore-checkpoint-filename  2023-09-02_14:34:57_best_window_avg.ckpt",
    "python3 ./se3cnn/experiments/scripts/cath/cath.py --data-filename ./se3cnn/data/cath_10arch_ca.npz --model ILPOResNet34Smallsoftmax --training-epochs 100 --batch-size 4 --batchsize-multiplier 1 --randomize-orientation --kernel-size 3 --initial_lr=0.0005 --lr_decay_start=40 --burnin-epochs 40 --lr_decay_base=.94 --downsample-by-pooling --p-drop-conv 0.01 --report-frequency 1 --lamb_conv_weight_L1 1e-7 --lamb_conv_weight_L2 1e-7 --lamb_bn_weight_L1 1e-7 --lamb_bn_weight_L2 1e-7 --report-on-test-set --mode test --restore-checkpoint-filename  2023-09-02_14:37:23_best_window_avg.ckpt",
    "python3 ./se3cnn/experiments/scripts/cath/cath.py --data-filename ./se3cnn/data/cath_10arch_ca.npz --model ILPOResNet34Tinyhardmax --training-epochs 100 --batch-size 4 --batchsize-multiplier 1 --randomize-orientation --kernel-size 3 --initial_lr=0.0005 --lr_decay_start=40 --burnin-epochs 40 --lr_decay_base=.94 --downsample-by-pooling --p-drop-conv 0.01 --report-frequency 1 --lamb_conv_weight_L1 1e-7 --lamb_conv_weight_L2 1e-7 --lamb_bn_weight_L1 1e-7 --lamb_bn_weight_L2 1e-7 --report-on-test-set --mode test --restore-checkpoint-filename  2023-09-02_14:35:15_best_window_avg.ckpt",
    "python3 ./se3cnn/experiments/scripts/cath/cath.py --data-filename ./se3cnn/data/cath_10arch_ca.npz --model ILPOResNet34Tinysoftmax --training-epochs 100 --batch-size 4 --batchsize-multiplier 1 --randomize-orientation --kernel-size 3 --initial_lr=0.0005 --lr_decay_start=40 --burnin-epochs 40 --lr_decay_base=.94 --downsample-by-pooling --p-drop-conv 0.01 --report-frequency 1 --lamb_conv_weight_L1 1e-7 --lamb_conv_weight_L2 1e-7 --lamb_bn_weight_L1 1e-7 --lamb_bn_weight_L2 1e-7 --report-on-test-set --mode test --restore-checkpoint-filename  2023-09-02_14:35:07_best_window_avg.ckpt",
]
         
for cath_call in cath_calls:
    os.system(cath_call)

medmnist_calls = [
    ""
]

for medmnist_call in medmnist_calls:
    os.system(medmnist_call)