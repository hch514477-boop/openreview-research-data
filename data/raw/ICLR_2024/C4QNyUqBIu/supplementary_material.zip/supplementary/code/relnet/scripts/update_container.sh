#! /bin/bash

echo "<<UPDATING DOCKER IMAGE...>>"
docker build -f $RN_SOURCE_DIR/docker/base/Dockerfile -t relnet/base --rm $RN_SOURCE_DIR && docker image prune -f
docker build -f $RN_SOURCE_DIR/docker/manager/Dockerfile -t relnet/manager --rm $RN_SOURCE_DIR && docker image prune -f