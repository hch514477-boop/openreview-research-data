#! /bin/bash
source activate relnet-cenv
jupyter notebook --no-browser --notebook-dir=/relnet --ip=0.0.0.0 --NotebookApp.token='' --NotebookApp.password='' --allow-root &

tail -f /dev/null