#! /bin/bash
expWhich=$1

suffixes=("final0d05" "final0d1" "final0d25" "final0d5" "final1d")
dmsMults=("0.05" "0.10" "0.25" "0.5" "1.0")

for i in ${!dmsMults[@]};
do
  dmsMult=${dmsMults[$i]}
  suffix=${suffixes[$i]}

  bash data_gen.sh $expWhich ssp $suffix $dmsMult
  bash data_gen.sh $expWhich ecmp $suffix $dmsMult

done

