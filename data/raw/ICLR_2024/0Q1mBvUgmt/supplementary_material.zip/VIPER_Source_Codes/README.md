# This is the experimental source code for the paper: "VIPER: Vibrant Period Representation for Robust and Efficient Time Series Forecasting."



## After downloading the corresponding eight datasets, create a folder named 'dataset' in two subdirectories-viper and backbone, and then place the downloaded datasets into it. 

## ----One thing notable here is that I've packaged the dataset in viper, so you can directly copy and paste it to the 'backbone folder',so you don't need to download the data from else where.



## Next, use 'requirements.txt' to install the environment dependencies by:

 ```pip install -r requirements.txt```

## Once you are prepared:

### 1. You can enter the 'viper' subdirectory and directly use:

```python run_script.py```

to replicate the benchmark results of VIPER from the paper on the eight datasets. 

Alternatively, you can use bash commands to individually run scripts in the 'scripts' folder from the command line to obtain results for individual datasets, take Traffic for example：

```bash scripts/Traffic/VIPER.sh ```

you can find the training result under 'test_dict' folder

### 2. To obtain results for the enhancement effects of VIPER on different models mentioned in the paper, you can enter the 'backbone' folder and similarly use:

```python run_script.py```

to obtain results on ETTh2 and ETTm2 as mentioned in the paper. 
Alternatively, you can use bash commands to individually run scripts in the 'scripts' folder from the command line to obtain results of other datasets for further exploration, take Informer on Traffic for example:

```bash scripts/Traffic_script/Informer.sh ```

you can find the training result under 'test_dict' folder