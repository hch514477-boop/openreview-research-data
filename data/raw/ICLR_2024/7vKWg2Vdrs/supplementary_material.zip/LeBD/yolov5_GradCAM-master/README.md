This is an official implementation of the paper "This is the official implementation of the paper".

## train backdoor model

Before running the backdoor detector, you need to train a backdoor YOLO network.

1. Poisoning the training set and the Validation set.

```bash
python poison_person.py
```
After runnig the code, you need to create a  txt file "dataset/coco/train2017_poison_person2cup_dataset.txt", then copy the  contents in "dataset/coco/train2017_poison_person2cup.txt" and "dataset/coco/train2017.txt" into it.

2. Train the backdoor YOLO network.

```bash
python train.py
```

## visualize CAM

After training, you obtain a backdoor model. You can visualize the salinecy map in differen layers of different CAM methods by running the following commands:

```bash
python main_cam.py
```

## run backdoor detector

You can run the real-time backdoor detector LeBD by:

```bash
python detect_trigger.py --trigger_detect
```

Morever, you can run CA-LeBD by:

```bash
python detect_trigger.py --trigger_detect --CA
```