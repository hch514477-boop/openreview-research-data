import sys
sys.path.append("./")  # change this path to your current work directory
from LFAE.modules import AutoEncoder