import sys
sys.path.append("./") 
from LFAE.modules.AE import AutoEncoder