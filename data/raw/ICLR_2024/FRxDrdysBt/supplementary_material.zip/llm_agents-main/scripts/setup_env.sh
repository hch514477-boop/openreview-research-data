pip install torch torchvision torchaudio
pip install transformers[torch] datasets
pip install scipy
pip install einops
pip install accelerate bitsandbytes
pip install langchain wikipedia google-search-results
pip install ibm-generative-ai openai python-dotenv faiss-cpu
pip install ipykernel rouge
pip install peft dateparser sentence-transformers chromadb ibm-generative-ai
pip install -U tensorflow
