cd data
git clone git@github.com:openai/grade-school-math.git
cd grade-school-math

# get data from ReACT repo