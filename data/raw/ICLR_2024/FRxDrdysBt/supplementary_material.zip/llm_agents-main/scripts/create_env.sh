mkdir logs
mkdir data
mkdir experiments
conda create --prefix ./llm_agents_env python=3.9