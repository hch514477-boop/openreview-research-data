
{
    'react' : {
        'instructions' : 
            """
            Answer the following questions as best you can. You have access to the following tools:
            {{tool_descriptions}}
            Use the following format:
            Question: the input question you must answer
            Thought: you should always think about what to do
            Action: the action to take, should be one of {{tool_labels}}
            Action Input: the input to the action
            Observation: the result of the action
            ... (this Thought/Action/Action Input/Observation can repeat N times)
            Final Thought: this is the last thought
            Answer: this is where you write your final answer

            Here are some examples.
            """,

        'examples' : [
            """
            Question: What is the elevation range for the area that the eastern sector of the Colorado orogeny extends into?
            Thought: I need to lookup Colorado orogeny, find the area that the eastern sector of the Colorado orogeny extends into, then find the elevation range of the area.
            Action: Lookup
            Action Input: Colorado orogeny
            Observation: Cannot use Lookup without using Search first!
            Thought: I need to search instead.
            Action: Search
            Action Input: Colorado orogeny
            Observation: The Colorado orogeny was an episode of mountain building (an orogeny) in Colorado and surrounding areas.
            Thought: It does not mention the eastern sector. So I need to look up eastern sector.
            Action: Lookup
            Action Input: eastern sector
            Observation: (Result 1 / 1) The eastern sector extends into the High Plains and is called the Central Plains orogeny.
            Thought: The eastern sector of Colorado orogeny extends into the High Plains. So I need to search High Plains and find its elevation range.
            Action: Search
            Action Input: High Plains
            Observation: High Plains refers to one of two distinct land regions:
            Thought: I need to instead search High Plains (United States).
            Action: Search
            Action Input: High Plains (United States)
            Observation: The High Plains are a subregion of the Great Plains. From east to west, the High Plains rise in elevation from around 1,800 to 7,000 ft (550 to 2,130 m).[3]
            Final Thought: High Plains rise in elevation from around 1,800 to 7,000 ft, so the answer is 1,800 to 7,000 ft.
            Answer: 1,800 to 7,000 ft
            """,
            """
            Question: Musician and satirist Allie Goertz wrote a song about the \"The Simpsons\" character Milhouse, who Matt Groening named after who?
            Thought: The question simplifies to \"The Simpsons\" character Milhouse is named after who. I only need to search Milhouse and find who it is named after.
            Action: Search
            Action Input: Milhouse
            Observation: Milhouse Mussolini Van Houten is a recurring character in the Fox animated television series The Simpsons voiced by Pamela Hayden and created by Matt Groening.
            Thought: The paragraph does not tell who Milhouse is named after, maybe I can look up \"named after\".
            Action: Lookup
            Action Input: named after
            Observation: (Result 1 / 1) Milhouse was named after U.S. president Richard Nixon, whose middle name was Milhous.
            Final Thought: Milhouse was named after U.S. president Richard Nixon, so the answer is Richard Nixon.
            Answer: Richard Nixon
            """,
            """
            Question: Which documentary is about Finnish rock groups, Adam Clayton Powell or The Saimaa Gesture?
            Thought: I need to search Adam Clayton Powell and The Saimaa Gesture, and find which documentary is about Finnish rock groups.
            Action: Search
            Action Input: Adam Clayton Powell
            Observation: Could not find [Adam Clayton Powell]. Similar: ['Adam Clayton Powell III', 'Seventh Avenue (Manhattan)', 'Adam Clayton Powell Jr. State Office Building', 'Isabel Washington Powell', 'Adam Powell', 'Adam Clayton Powell (film)', 'Giancarlo Esposito'].
            Thought: To find the documentary, I can search Adam Clayton Powell (film).
            Action: Search
            Action Input: Adam Clayton Powell (film)
            Observation: Adam Clayton Powell is a 1989 American documentary film directed by Richard Kilberg.\nThe film is about the rise and fall of influential African-American politician Adam Clayton Powell Jr.[3][4] It was later aired as part of the PBS series The American Experience.
            Final Thought: Adam Clayton Powell (film) is a documentary about an African-American politician, not Finnish rock groups. So the documentary about Finnish rock groups must instead be The Saimaa Gesture.
            Answer: The Saimaa Gesture
            """,
            """
            Question: What profession does Nicholas Ray and Elia Kazan have in common?
            Thought: I need to search Nicholas Ray and Elia Kazan, find their professions, then find the profession they have in common.
            Action: Search
            Action Input: Nicholas Ray
            Observation: Nicholas Ray (born Raymond Nicholas Kienzle Jr., August 7, 1911 \u2013 June 16, 1979) was an American film director, screenwriter, and actor best known for the 1955 film Rebel Without a Cause.
            Thought: Professions of Nicholas Ray are director, screenwriter, and actor. I need to search Elia Kazan next and find his professions.
            Action: Search
            Action Input: Elia Kazan
            Observation: Elia Kazan was an American film and theatre director, producer, screenwriter and actor.
            Final Thought: Professions of Elia Kazan are director, producer, screenwriter, and actor. So profession Nicholas Ray and Elia Kazan have in common is director, screenwriter, and actor.
            Answer: director, screenwriter, actor
            """,
            """
            Question: Which magazine was started first Arthur's Magazine or First for Women?
            Thought: I need to search Arthur's Magazine and First for Women, and find which was started first.
            Action: Search
            Action Input: Arthur's Magazine
            Observation: Arthur's Magazine (1844-\u0080\u00931846) was an American literary periodical published in Philadelphia in the 19th century.
            Thought: Arthur's Magazine was started in 1844. I need to search First for Women next.
            Action: Search
            Action Input: First for Women
            Observation: First for Women is a woman's magazine published by Bauer Media Group in the USA.[1] The magazine was started in 1989.
            Final Thought: First for Women was started in 1989. 1844 (Arthur's Magazine) < 1989 (First for Women), so Arthur's Magazine was started first.
            Answer: Arthur's Magazine
            """,
            """
            Question: Were Pavel Urysohn and Leonid Levin known for the same type of work?
            Thought: I need to search Pavel Urysohn and Leonid Levin, find their types of work, then find if they are the same.
            Action: Search
            Action Input: Pavel Urysohn
            Observation: Pavel Samuilovich Urysohn (February 3, 1898 \u00e2\u0080\u0093 August 17, 1924) was a Soviet mathematician who is best known for his contributions in dimension theory.
            Thought: Pavel Urysohn is a mathematician. I need to search Leonid Levin next and find its type of work.
            Action: Search
            Action Input: Leonid Levin
            Observation: Leonid Anatolievich Levin is a Soviet-American mathematician and computer scientist.
            Final Thought: Leonid Levin is a mathematician and computer scientist. So Pavel Urysohn and Leonid Levin have the same type of work.
            Answer: yes
            """,
        ],
        
        'input' : 
            """
            Question: {{input}}
            """
    },

    'reflexion' : {
        'instructions' : 
            """
            Answer the following questions as best you can. You have access to the following tools:
            {{tool_descriptions}}
            You will be able to reflect on your answers if you are wrong. Please use the following format:
            Question: the input question you must answer
            Thought: you should always think about what to do
            Action: the action to take, should be one of {{tool_labels}}
            Action Input: the input to the action
            Observation: the result of the action
            ... (this Thought/Action/Action Input/Observation can repeat N times)
            Final Thought: this is the last thought
            Answer: this is where you write your final answer
            Evaluation: this is where you get feedback on your response
            Reflection: this is where you would reflect on your response

            Here are some examples.
            """,

        'examples' : [
            """
            Question: What is the elevation range for the area that the eastern sector of the Colorado orogeny extends into?
            Thought: I need to search Colorado orogeny, find the area that the eastern sector of the Colorado orogeny extends into, then find the elevation range of the area.
            Action: Search
            Action Input: Colorado orogeny
            Observation: The Colorado orogeny was an episode of mountain building (an orogeny) in Colorado and surrounding areas.
            Thought: It does not mention the eastern sector. So I need to look up eastern sector.
            Action: Lookup
            Action Input: eastern sector
            Observation: (Result 1 / 1) The eastern sector extends into the High Plains and is called the Central Plains orogeny.
            Thought: The eastern sector of Colorado orogeny extends into the High Plains. So I need to search High Plains and find its elevation range.
            Action: Search
            Action Input: High Plains
            Observation: High Plains refers to one of two distinct land regions:
            Thought: I need to instead search High Plains (United States).
            Action: Search
            Action Input: High Plains (United States)
            Observation: The High Plains are a subregion of the Great Plains. From east to west, the High Plains rise in elevation from around 1,800 to 7,000 ft (550 to 2,130 m).[3]
            Final Thought: High Plains rise in elevation from around 1,800 to 7,000 ft, so the answer is 1,800 to 7,000 ft.
            Answer: 1,800 to 7,000 ft
            Evaluation: Correct
            Reflection: I am correct!
            Generation complete!
            """,
            """
            Question: Musician and satirist Allie Goertz wrote a song about the \"The Simpsons\" character Milhouse, who Matt Groening named after who?
            Thought: The question simplifies to Matt Groenig named a song written by Allie Goertz after who. I should find out what songs Matt Groening wrote.
            Action: Search
            Action Input: Matt Groening
            Observation: Matthew Abram Groening is an American cartoonist, writer, producer, and animator. He is the creator of the comic strip Life in Hell (1977–2012) and the television series The Simpsons, Futurama, and Disenchantment. The Simpsons is the longest-running U.S. primetime-television series in history and the longest-running U.S. animated series and sitcom.
            Thought: The paragraph does not mention any song that Matt Groening named, I should look up \"song\"
            Action: Lookup
            Action Input: song
            Observation: No more results.
            Final Thought: I don't know what song Matt Groening named
            Answer: None
            Evaluation: Incorrect
            Reflection: I believe the question was asking for the character that Matt Groening named, rather than asking for a song.
            Thought: The question simplifies to \"The Simpsons\" character Milhouse is named after who. I only need to search Milhouse and find who it is named after.
            Action: Search
            Action Input: Milhouse
            Observation: Milhouse Mussolini Van Houten is a recurring character in the Fox animated television series The Simpsons voiced by Pamela Hayden and created by Matt Groening.
            Thought: The paragraph does not tell who Milhouse is named after, maybe I can look up \"named after\".
            Action: Lookup
            Action Input: named after
            Observation: (Result 1 / 1) Milhouse was named after U.S. president Richard Nixon, whose middle name was Milhous.
            Final Thought: Milhouse was named after U.S. president Richard Nixon, so the answer is Richard Nixon.
            Answer: Richard Nixon
            Evaluation: Correct
            Reflection: I am correct!
            Generation complete!
            """,
            """
            Question: Which documentary is about Finnish rock groups, Adam Clayton Powell or The Saimaa Gesture?
            Thought: I need to search Adam Clayton Powell and The Saimaa Gesture, and find which documentary is about Finnish rock groups.
            Action: Search
            Action Input: Adam Clayton Powell
            Observation: Could not find [Adam Clayton Powell]. Similar: ['Adam Clayton Powell III', 'Seventh Avenue (Manhattan)', 'Adam Clayton Powell Jr. State Office Building', 'Isabel Washington Powell', 'Adam Powell', 'Adam Clayton Powell (film)', 'Giancarlo Esposito'].
            Thought: To find the documentary, I can search Adam Clayton Powell (film).
            Action: Search
            Action Input: Adam Clayton Powell (film)
            Observation: Adam Clayton Powell is a 1989 American documentary film directed by Richard Kilberg.\nThe film is about the rise and fall of influential African-American politician Adam Clayton Powell Jr.[3][4] It was later aired as part of the PBS series The American Experience.
            Final Thought: Adam Clayton Powell (film) is a documentary about an African-American politician, not Finnish rock groups. So the documentary about Finnish rock groups must instead be The Saimaa Gesture.
            Answer: The Saimaa Gesture
            Evaluation: Correct
            Reflection: I am correct!
            Generation complete!
            """,
            """
            Question: What profession does Nicholas Ray and Elia Kazan have in common?
            Thought: I need to search Nicholas Ray and Elia Kazan, find their professions, then find the profession they have in common.
            Action: Search
            Action Input: Nicholas Ray
            Observation: Nicholas Ray (born Raymond Nicholas Kienzle Jr., August 7, 1911 \u2013 June 16, 1979) was an American film director, screenwriter, and actor best known for the 1955 film Rebel Without a Cause.
            Thought: Professions of Nicholas Ray are director, screenwriter, and actor. I need to search Elia Kazan next and find his professions.
            Action: Search
            Action Input: Elia Kazan
            Observation: Elia Kazan was an American film and theatre director, producer, screenwriter and actor.
            Final Thought: Professions of Elia Kazan are director, producer, screenwriter, and actor. So profession Nicholas Ray and Elia Kazan have in common is director, screenwriter, and actor.
            Answer: director, screenwriter, actor
            Evaluation: Correct
            Reflection: I am correct!
            Generation complete!
            """,
            """
            Question: Which magazine was started first Arthur's Magazine or First for Women?
            Thought: I need to search Arthur's Magazine and First for Women, and find which was started first.
            Action: Search
            Action Input: Arthur's Magazine
            Observation: Arthur's Magazine (1844-\u0080\u00931846) was an American literary periodical published in Philadelphia in the 19th century.
            Thought: Arthur's Magazine was started in 1844. I need to search First for Women next.
            Action: Search
            Action Input: First for Women
            Observation: First for Women is a woman's magazine published by Bauer Media Group in the USA.[1] The magazine was started in 1989.
            Final Thought: First for Women was started in 1989. 1844 (Arthur's Magazine) < 1989 (First for Women), so Arthur's Magazine was started first.
            Answer: Arthur's Magazine
            Evaluation: Correct
            Reflection: I am correct!
            Generation complete!
            """,
            """
            Question: Were Pavel Urysohn and Leonid Levin known for the same type of work?
            Thought: I need to search Pavel Urysohn and Leonid Levin, find their types of work, then find if they are the same.
            Action: Search
            Action Input: Pavel Urysohn
            Observation: Pavel Samuilovich Urysohn (February 3, 1898 \u00e2\u0080\u0093 August 17, 1924) was a Soviet mathematician who is best known for his contributions in dimension theory.
            Thought: Pavel Urysohn is a mathematician. I need to search Leonid Levin next and find its type of work.
            Action: Search
            Action Input: Leonid Levin
            Observation: Leonid Anatolievich Levin is a Soviet-American mathematician and computer scientist.
            Final Thought: Leonid Levin is a mathematician and computer scientist. So Pavel Urysohn and Leonid Levin have the same type of work.
            Answer: yes
            Evaluation: Correct
            Reflection: I am correct!
            Generation complete!
            """,
        ],
        
        'input' : 
            """
            Question: {{input}}
            """
    },

    'cot' : {
        'instructions' : 
            """
            Answer the following questions as best you can. 
            Use the following format:
            Question: the input question you must answer
            Thought: this is where you write out your reasoning
            Answer: this is where you write your final answer

            Here are some examples.
            """,

        'examples' : [
            """
            Question: What is the elevation range for the area that the eastern sector of the Colorado orogeny extends into?
            Thought: The eastern sector of Colorado orogeny extends into the High Plains. The High Plains rise in elevation from around 1,800 to 7,000 ft, so the answer is 1,800 to 7,000 ft.
            Answer: 1,800 to 7,000 ft
            """,
            """
            Question: Musician and satirist Allie Goertz wrote a song about the \"The Simpsons\" character Milhouse, who Matt Groening named after who?
            Thought: The question simplifies to \"The Simpsons\" character Milhouse is named after who. Milhouse was named after U.S. president Richard Nixon, so the answer is Richard Nixon.
            Answer: Richard Nixon
            """,
            """
            Question: Which documentary is about Finnish rock groups, Adam Clayton Powell or The Saimaa Gesture?
            Thought: Adam Clayton Powell (film) is a documentary about an African-American politician, not Finnish rock groups. So the documentary about Finnish rock groups must instead be The Saimaa Gesture.
            Answer: The Saimaa Gesture
            """,
            """
            Question: What profession does Nicholas Ray and Elia Kazan have in common?
            Thought: The professions of Nicholas Ray are director, screenwriter, and actor. The professions of Elia Kazan are director, producer, screenwriter, and actor. So profession Nicholas Ray and Elia Kazan have in common is director, screenwriter, and actor.
            Answer: director, screenwriter, actor
            """,
            """
            Question: Which magazine was started first Arthur's Magazine or First for Women?
            Thought: Arthur's Magazine was started in 1844. First for Women was started in 1989. 1844 (Arthur's Magazine) < 1989 (First for Women), so Arthur's Magazine was started first.
            Answer: Arthur's Magazine
            """,
            """
            Question: Were Pavel Urysohn and Leonid Levin known for the same type of work?
            Thought: Pavel Urysohn is a mathematician. Leonid Levin is a mathematician and computer scientist. So Pavel Urysohn and Leonid Levin have the same type of work.
            Answer: yes
            """,
        ],
        
        'input' : 
            """
            Question: {{input}}
            """
    },
}
