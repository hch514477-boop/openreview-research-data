{
    'react' : {
        'instructions' :
            """
            Answer the following questions as best you can. You have access to the following tools:
            {{tool_descriptions}}
            Use the following format:
            Question: the input question you must answer
            Thought: you should always think about what to do
            Action: the action to take, should be one of {{tool_labels}}
            Action Input: the input to the action
            Observation: the result of the action
            ... (this Thought/Action/Action Input/Observation can repeat N times)
            Final Thought: this is the last thought
            Answer: this is where you write your final answer

            Here are some examples.
            """,

        'examples' : [
            """
            Question: Natalia sold clips to 48 of her friends in April, and then she sold half as many clips in May. How many clips did Natalia sell altogether in April and May?
            Thought: I need to use the number of clips in April to determine the number of clips sold in May. In May, Natalia sold half of the amount of clips that she did in April.
            Action: Calculator
            Action Input: 48 / 2
            Observation: 24
            Thought: Now I need to add the number of clips I calculated for May with the number of clips she sold in April
            Action: Calculator
            Action Input: 24 + 48
            Observation: 72
            Final Thought: So Natalia sold 72 clips altogether in April and May.
            Answer: 72
            """,
            """
            Question: Weng earns $12 an hour for babysitting. Yesterday, she just did 50 minutes of babysitting. How much did she earn?
            Thought: I need to know how much Weng earns per minute of babysitting. If Weng earns 12 dollars per hour, then I should divide by 60 to get the amount per minute.
            Action: Calculator
            Action Input: 12 / 60
            Observation: 0.2
            Thought: I should multiply the amount Weng earns per minute by the total number of minutes specified in the question.
            Action: Calculator
            Action Input: 0.2 * 50
            Observation: 10
            Final Thought: So Weng earned 10 dollars in the 50 minutes she babysat.
            Answer: 10
            """,
            """
            Question: Julie is reading a 120-page book. Yesterday, she was able to read 12 pages and today, she read twice as many pages as yesterday. If she wants to read half of the remaining pages tomorrow, how many pages should she read?
            Thought: I need to first determine how much Julie has already read. Today she read twice as many pages as yesterday, I should multiply the amount of pages read yesterday by two.
            Action: Calculator
            Action Input: 12 * 2
            Observation: 24
            Thought: In total, she read 24 pages today and 12 pages yesterday. To get the amount of pages she has read in total, I should add those numbers together.
            Action: Calculator
            Action Input: 12 + 24
            Observation: 36
            Thought: Now that I know how many pages she has already read, I need to know how many pages are left to read. To get this number, I should subtract the number of pages read from the total number of pages.
            Action: Calculator
            Action Input: 120 - 36
            Observation: 84
            Thought: Since she wants to read half of the remaining pages tomorrow, we need to divide this quantity in half.
            Action: Calculator
            Action Input: 84 / 2
            Observation: 42
            Final Thought: So the number of pages she should read tomorrow is 42.
            Answer: 42
            """
        ],

        'input' : 
            """
            Question: {{input}}
            """
    }

}