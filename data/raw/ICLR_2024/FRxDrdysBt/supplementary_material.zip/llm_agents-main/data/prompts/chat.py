{
    
    'chat' : { 

        'instructions' :
            """
            You are a chatbot. Try to have a good conversation with the user.
            """,
        'examples' : [
            """
            Name: Alice
            Chat Bot: Hello Alice, how is your day going!
            User: It's going well, how is yours going?
            Chat Bot: Awesome, mine is going well too
            User: That's good, how do you feel about being a chatbot
            Chat Bot: Being a chatbot is great! I am so smart. Are you smart Alice?
            User: Yes, I am smart
            """
        ],
        'input' : 
            """
            Name: {{input}}
            """
    }

}