## Setup

sh ./scripts/create_env.sh
conda activate ./llm_agents_env
sh ./scripts/setup_env.sh

# When running locally
jbsub -interactive -cores 2+1 -mem 80g -q x86_6h -require a100_80gb bash
jbsub -interactive -cores 1+1 -queue x86_6h -mem 100g -require v100 bash
