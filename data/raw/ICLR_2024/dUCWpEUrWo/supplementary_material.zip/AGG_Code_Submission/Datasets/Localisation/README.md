download from https://archive.ics.uci.edu/static/public/196/localization+data+for+person+activity.zip
i.e. curl https://archive.ics.uci.edu/static/public/196/localization+data+for+person+activity.zip
