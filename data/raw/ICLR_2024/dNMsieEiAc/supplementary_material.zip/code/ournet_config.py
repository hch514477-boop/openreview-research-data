
from datetime import datetime
import torch




class Config:

    experiment_day = datetime.today().strftime("%m%d")

    # ------------ default config ------------
    

    device = torch.device("cpu")
    # device = torch.device("cuda:0")
    
    train_epochs = 2       
    batch_size = 128         
    learning_rate = 0.002    
    l2_regularization = 1e-6 
    learning_rate_decay = 0.99  
    patience_limit = 15

    word_dim = 50
    kernel_count = 100
    kernel_size = 1    
    feature_dim = 50
    dropout_prob = 0.5
    
    vocab_category_u = 'vocab_1'   # set vocab data : vocab_1 or vocab_2 
    vocab_category_i = 'vocab_1'
    top_k = 10     

    # DM : 5541 users, 3568 items
    # GG : 14681 users, 8713 items
    # AM : 2928 users, 1835 items
    # OP : 4905 users, 2420 items
    # PG : 1686 users, 962 items
    # id_emb parameters

    user_num   = 2928
    item_num   = 1835
    fusion_method = 'sum'  # default : sum


    # dataset & word2vec
    word2vec_file = './data/preprocessing/glove.6B.50d.txt'  
    train_file = './prompt/dataset_vocab/roberta_AM_train.pkl'
    valid_file = './prompt/dataset_vocab/roberta_AM_valid.pkl'
    test_file  = './prompt/dataset_vocab/roberta_AM_test.pkl'
    


