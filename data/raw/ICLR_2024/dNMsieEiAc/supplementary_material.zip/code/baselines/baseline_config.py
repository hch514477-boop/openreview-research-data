from datetime import datetime
import torch
from model.DeepCoNN import DeepCoNN
from model.Dattn import Dattn 
from model.DAML import DAML


class Config:


    baseline = Dattn   # DeepCoNN, Dattn, DAML : * Not used on Transent

    

    # ------------ default config ------------

    experiment_day = datetime.today().strftime("%m%d")

    # device = torch.device("cpu")
    device = torch.device("cuda:0")
    
    train_epochs = 100       
    batch_size = 32         
    learning_rate = 0.002    
    l2_regularization = 1e-6 
    learning_rate_decay = 0.99  
    patience_limit = 15

    word_dim = 50
    kernel_count = 100
    kernel_size = 3    
    feature_dim = 50
    dropout_prob = 0.5
    

    # DM : 5541 users, 3568 items
    # GG : 14681 users, 8713 items
    # AM : 2928 users, 1835 items
    # OP : 4905 users, 2420 items
    # PG : 1686 users, 962 items
    # id_emb parameters : only the model using idemb (DAML)

    with_idemb = False
    user_num   = 2928
    item_num   = 1835


    # dataset & word2vec
    word2vec_file = './data/preprocessing/glove.6B.50d.txt'  
    train_file = './prompt/dataset_vocab/roberta_AM_train.pkl'
    valid_file = './prompt/dataset_vocab/roberta_AM_valid.pkl'
    test_file  = './prompt/dataset_vocab/roberta_AM_test.pkl'
    


