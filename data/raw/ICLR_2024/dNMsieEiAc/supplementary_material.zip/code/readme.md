## Prompt2Rec code

#### Environments settings

```
pip install -r requirements.txt

```


- Download Word Embedding file(embedding/glove.6B.50d.txt)
  - Download from https://nlp.stanford.edu/projects/glove
  - Save to the path (./data/preprocessing/glove.6B.50d.txt)



### (part 1) Prompt-based user & item Key factor generation

- Example : (Amazon reviews 5-core) "Automotive" category


#### 1. Preprocessing

```
python3 data/dataset.py --json_path ./data/raw/Automotive_5.json --save_dir ./data/dataset/AM --data_category AM
```


#### 2. Generating (user & item) Key factors 

- Check prompt/prompt_config.py file, before Generating Key factors

```
python3 prompt/prompting.py
```

### (part 2) Recommendation model learning

#### Our model : Train & Test
- Check ournet_config.py file, before training the model
```
python3 main_ournet.py
```

#### baselines : Train & Test
- Check baseline_config.py file, before training the model
- DeepCoNN, Dattn, DAML  
  - (DAML model) need "with_idemb = True" for training
```
python3 baselines/main_reviews.py
```

- TransNet : ※ Learning structure is different from the other baselines
```
python3 baselines/transnet.py
```