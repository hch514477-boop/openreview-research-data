import torch

class Prompt_Config:
    
    # device
    # device = torch.device("cuda:0")
    device = torch.device("cpu")

    # model_path="bert-base-uncased"
    model_path="roberta-base"
    top_k = 20

    # for Roberta 
    user_patterns = {
               "user_vocab_1" : "</s> I think the <mask> is important.",
               "user_vocab_2":  "</s> I am a consumer who values the <mask>.",              
                         }

    item_patterns = {
               "item_vocab_1":  "</s> The <mask> of this item is important.", 
               "item_vocab_2":  "</s> The point of this product is the <mask>."
                         }
    

    train_file = './data/dataset/AM/AM_train.csv'
    valid_file = './data/dataset/AM/AM_valid.csv'
    test_file =  './data/dataset/AM/AM_test.csv'

    pickle_path = './prompt/dataset_vocab/'
    pickle_file_name = 'roberta_AM_test'
