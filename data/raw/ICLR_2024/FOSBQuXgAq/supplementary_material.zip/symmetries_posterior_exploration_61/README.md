# 61 - A Symmetry-aware Exploration of Bayesian Posterior - Supp

This folder contains:

- two files containing the data and the models used to generate the toy example of Figure 1,
- three notebooks to: 1. visualize the data, 2. train custom models, 3. create your
    own version of the Figure with your models,
- samples of code with the logic of the scaling and permutation operators for very simple fully-connected networks.

Thank you!
