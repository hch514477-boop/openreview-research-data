## ⚙️ Setup

### Install Environment via Anaconda (Recommended)
```bash
conda create -n freenoise python=3.8.5
conda activate freenoise
pip install -r requirements.txt
```


## 💫 Inference 

1) Download pretrained 256x256 T2V models via [VideoCrafter](https://huggingface.co/VideoCrafter), and put the `model.ckpt` in `checkpoints/base_256_v1/model.ckpt`.
2) Input the following commands in terminal.
```bash
  sh scripts/run_text2video_freenoise_256.sh
```
