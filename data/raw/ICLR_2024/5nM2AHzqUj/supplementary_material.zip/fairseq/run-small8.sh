export PYTHONPATH=/home/yury/projects/laila/
export CUDA_VISIBLE_DEVICES=0
export USE_KERNEL_ATTENTION=True
export KERNEL_TYPE="exp"

. ./../../venvyr/bin/activate
python /home/yury/projects/fairseq/fairseq_cli/hydra_train.py -m --config-dir examples/roberta/config/pretraining --config-name small8-64 task.data=/opt/share/dataset/wikitext-103-fairseq/data-bin/wikitext-103/
deactivate