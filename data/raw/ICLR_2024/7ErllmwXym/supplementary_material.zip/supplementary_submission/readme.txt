Environment setup
-----------------
1. Install requirements
     pip install -r requirements.txt

2. Download model checkpoints and FID from https://github.com/luping-liu/PNDM/
   Requires following files before running the code:
     models/ddim_celeba.ckpt
     models/ddim_cifar10.ckpt
     fid/fid_celeba_train.npz
     fid/fid_cifar10_train.npz

3. Download COCO dataset and modify constants in `coco_experiment.py` to point to dataset

To reproduce results
--------------------

1. For FID evaluations and plots, run
     python run_experiments.py
   Plots will be generated in `figures`
   FID scores will be logged in `results` (viewable with tensorboard)
   Images will be generated in `images`

2. For Stable Diffusion comparison, run `sd_new_sampler.ipynb`

3. For MS-COCO experiments, run
     python coco_experiment.py
