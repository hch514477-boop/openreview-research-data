# Installation
- Follow the instructions in `trlx_lora` and install the dependencies
- `pip install sentence-transformers torchmetrics fast-bleu`

# Run IMDb experiments
```
bash run_imdb_rl.sh
bash run_imdb_rl_tdiv.sh
bash run_imdb_rl_curiosity.sh
```

# Run databricks experiments
```
bash run_databricks_rl.sh
bash run_databricks_rl_tdiv.sh
bash run_databricks_rl_curiosity.sh
```