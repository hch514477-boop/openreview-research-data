from .anchor_head_multi import AnchorHeadMulti
from .anchor_head_single import AnchorHeadSingle
from .anchor_head_single import ActiveAnchorHeadSingle1
from .anchor_head_single import AnchorHeadSingle_TQS
from .anchor_head_template import AnchorHeadTemplate
from .point_head_box import PointHeadBox
from .point_head_simple import PointHeadSimple
from .point_intra_part_head import PointIntraPartOffsetHead
from .center_head import CenterHead
from .center_head_dsvt import CenterHead_DSVT
from .center_head_semi import CenterHeadSemi
from .center_head_MoE import CenterHeadMoE
from .center_head import ActiveCenterHead
from .centerpoint_single import CenterPointSingle
from .IASSD_head import IASSD_Head
from .anchor_head_semi import AnchorHeadSemi
from .point_head_semi import PointHeadSemi
from .anchor_head_single import AnchorHeadSinglePretrain_v1, AnchorHeadSinglePretrain_v2, AnchorHeadSinglePretrain_v1_2
from .voxelnext_head import VoxelNeXtHead


__all__ = {
    'AnchorHeadTemplate': AnchorHeadTemplate,
    'AnchorHeadSingle': AnchorHeadSingle,
    'ActiveAnchorHeadSingle1': ActiveAnchorHeadSingle1,
    'AnchorHeadSingle_TQS': AnchorHeadSingle_TQS,
    'PointIntraPartOffsetHead': PointIntraPartOffsetHead,
    'PointHeadSimple': PointHeadSimple,
    'PointHeadBox': PointHeadBox,
    'AnchorHeadMulti': AnchorHeadMulti,
    'CenterHead': CenterHead,
    'CenterHead_DSVT': CenterHead_DSVT,
    'CenterHeadSemi': CenterHeadSemi,
    'CenterHeadMoE': CenterHeadMoE,
    'ActiveCenterHead': ActiveCenterHead,
    'CenterPointSingle': CenterPointSingle,
    'IASSD_Head': IASSD_Head,
    'ActiveAnchorHeadSingle1': ActiveAnchorHeadSingle1,
    'AnchorHeadSemi': AnchorHeadSemi,
    'PointHeadSemi': PointHeadSemi,
    'AnchorHeadSinglePretrain_v1': AnchorHeadSinglePretrain_v1,
    'AnchorHeadSinglePretrain_v2': AnchorHeadSinglePretrain_v2,
    # 'AnchorHeadSinglePretrain_v3': AnchorHeadSinglePretrain_v3,
    'AnchorHeadSinglePretrain_v1_2': AnchorHeadSinglePretrain_v1_2,
    'VoxelNeXtHead': VoxelNeXtHead,
}