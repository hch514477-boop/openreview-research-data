Example Single run,

```shell
tango run config/rest.jsonnet -i src/
```