The codes are for implementing our TDD algorithm.
Please download and unzip the datasets from BLiMP into the .\data folder first.

Steps to reproduce our results:
1. run main1_evaluate_saliency.py to cauculate token saliency for each dataset.
2. run main2_evaluate_explanation_faithfulness.py to obtain the AOPC (generate) and Suff (pruning) scores.

The "interpret" folder contains implementations of the state-of-the-art Con-GI and Con-GN. We are grateful for the efforts of the authors behind Con-GI and Con-GN. Their original code can be found at: https://github.com/kayoyin/interpret-lm