
import numpy as np
import os


if __name__ == "__main__":

    num = 20000

    a0 = np.load(os.path.join("medium", f"{0}.npz"))
    a1 = np.load(os.path.join("medium", f"{1}.npz"))
    a2 = np.load(os.path.join("medium", f"{2}.npz"))

    print(a0["observations"].shape)
    print(a1["observations"].shape)
    print(a2["observations"].shape)

    print(a0["observations"][:-10])
    print(a0["actions"][:-10])
