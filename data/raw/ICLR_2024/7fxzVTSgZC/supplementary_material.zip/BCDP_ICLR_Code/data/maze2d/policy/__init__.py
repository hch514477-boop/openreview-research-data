from .random import Random
from .sac import Sac
from .expert import Expert
def get_policy(file,env,policy_name:str):
    if(policy_name == 'random'):
        return Random(env)
    if(policy_name == 'sac'):
        return Sac(file,env)
    if(policy_name == 'expert'):
        return Expert(env)
    raise ValueError('No such policy!')