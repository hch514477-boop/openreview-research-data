

# python generator.py --dataset_name maze2d-umaze-v1 --policy expert

# python generator.py --dataset_name maze2d-medium-v1 --policy expert

# python generator.py --dataset_name maze2d-large-v1 --policy expert




# python generator.py --dataset_name maze2d-umaze-v1 --policy random --episodes 5000 --steps 200
python generator.py --dataset_name maze2d-medium-v1  --policy random --episodes 5000 --steps 200
python generator.py --dataset_name maze2d-large-v1 --policy random --episodes 5000 --steps 200


python generator.py --dataset_name maze2d-umaze-dense-v1 --policy random --episodes 5000 --steps 200
python generator.py --dataset_name maze2d-medium-dense-v1  --policy random --episodes 5000 --steps 200
python generator.py --dataset_name maze2d-large-dense-v1 --policy random --episodes 5000 --steps 200


python generator.py --dataset_name maze2d-umaze-dense-v1 --policy expert
python generator.py --dataset_name maze2d-medium-dense-v1 --policy expert
python generator.py --dataset_name maze2d-large-dense-v1 --policy expert