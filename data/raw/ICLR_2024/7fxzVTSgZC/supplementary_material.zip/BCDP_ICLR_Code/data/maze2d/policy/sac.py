import d3rlpy
import numpy as np
class Sac:
    def __init__(self,file,env):
        self.algo = d3rlpy.algos.SAC()
        self.algo.build_with_env(env)
        self.algo.load_model(file)
    def seed(self,seed):
        self.seed = seed
    def sample(self,x,target):
        xx = np.array([x])
        return self.algo.predict(xx)[0]
    def reset(self):...