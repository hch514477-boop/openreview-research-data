
from copy import deepcopy

class Random:
    def __init__(self,env):
        self.env = deepcopy(env)
    def set_seed(self,seed=None):
        if(seed != None):
            self.seed = seed
            self.env.seed(seed)
            self.env.action_space.seed(seed)
        return self.seed
    def sample(self,x,target):
        return self.env.action_space.sample()
    def reset(self):...