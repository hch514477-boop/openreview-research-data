





python oil_td3bc.py --expert-data hopper-expert-v2 --offline-data hopper-random-v2 --expert-num 5 --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5
python oil_td3bc.py --expert-data hopper-expert-v2 --offline-data hopper-random-v2 --expert-num 5 --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5
python oil_td3bc.py --expert-data hopper-expert-v2 --offline-data hopper-random-v2 --expert-num 5 --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5

python oil_td3bc.py --expert-data hopper-expert-v2 --offline-data hopper-medium-v2 --expert-num 5 --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5
python oil_td3bc.py --expert-data hopper-expert-v2 --offline-data hopper-medium-v2 --expert-num 5 --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5
python oil_td3bc.py --expert-data hopper-expert-v2 --offline-data hopper-medium-v2 --expert-num 5 --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5


python oil_td3bc.py --expert-data  halfcheetah-expert-v2 --offline-data  halfcheetah-random-v2 --expert-num 5 --offline-exp 0  --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --discount 0.3 --seed 0 
python oil_td3bc.py --expert-data  halfcheetah-expert-v2 --offline-data  halfcheetah-random-v2 --expert-num 5 --offline-exp 0  --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --discount 0.3 --seed 1 
python oil_td3bc.py --expert-data  halfcheetah-expert-v2 --offline-data  halfcheetah-random-v2 --expert-num 5 --offline-exp 0  --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --discount 0.3 --seed 2

python oil_td3bc.py --expert-data  halfcheetah-expert-v2 --offline-data  halfcheetah-medium-v2 --expert-num 5 --offline-exp 0  --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --discount 0.3 --seed 0 
python oil_td3bc.py --expert-data  halfcheetah-expert-v2 --offline-data  halfcheetah-medium-v2 --expert-num 5 --offline-exp 0  --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --discount 0.3 --seed 1 
python oil_td3bc.py --expert-data  halfcheetah-expert-v2 --offline-data  halfcheetah-medium-v2 --expert-num 5 --offline-exp 0  --mode train --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --discount 0.3 --seed 2

python oil_td3bc.py --expert-data  walker2d-expert-v2 --offline-data  walker2d-random-v2 --expert-num 5 --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5 --mode train
python oil_td3bc.py --expert-data  walker2d-expert-v2 --offline-data  walker2d-random-v2 --expert-num 5 --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5 --mode train
python oil_td3bc.py --expert-data  walker2d-expert-v2 --offline-data  walker2d-random-v2 --expert-num 5 --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5 --mode train

python oil_td3bc.py --expert-data  walker2d-expert-v2 --offline-data  walker2d-medium-v2 --expert-num 5 --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5 --mode train
python oil_td3bc.py --expert-data  walker2d-expert-v2 --offline-data  walker2d-medium-v2 --expert-num 5 --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5 --mode train
python oil_td3bc.py --expert-data  walker2d-expert-v2 --offline-data  walker2d-medium-v2 --expert-num 5 --lr 1e-4 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5 --mode train

python oil_td3bc.py --expert-data  ant-expert-v2 --offline-data  ant-random-v2 --expert-num 5  --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5 --mode train
python oil_td3bc.py --expert-data  ant-expert-v2 --offline-data  ant-random-v2 --expert-num 5  --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5 --mode train
python oil_td3bc.py --expert-data  ant-expert-v2 --offline-data  ant-random-v2 --expert-num 5  --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5 --mode train 

python oil_td3bc.py --expert-data  ant-expert-v2 --offline-data  ant-medium-v2 --expert-num 5  --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5 --mode train
python oil_td3bc.py --expert-data  ant-expert-v2 --offline-data  ant-medium-v2 --expert-num 5  --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5 --mode train
python oil_td3bc.py --expert-data  ant-expert-v2 --offline-data  ant-medium-v2 --expert-num 5  --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5 --mode train


