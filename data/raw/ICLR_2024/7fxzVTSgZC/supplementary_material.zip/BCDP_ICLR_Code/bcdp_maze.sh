

python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-random-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 0
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-random-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 1
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-random-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 2


python oil_td3bc.py --expert-data maze2d-medium-expert-v1 --offline-data maze2d-medium-random-v1 --expert-num 5 --offline-exp 0 --max_timesteps 200000 --lr 1e-5 --seed 0 --alpha 1.0 --policy_freq 2
python oil_td3bc.py --expert-data maze2d-medium-expert-v1 --offline-data maze2d-medium-random-v1 --expert-num 5 --offline-exp 0 --max_timesteps 200000 --lr 1e-5 --seed 1 --alpha 1.0 --policy_freq 2
python oil_td3bc.py --expert-data maze2d-medium-expert-v1 --offline-data maze2d-medium-random-v1 --expert-num 5 --offline-exp 0 --max_timesteps 200000 --lr 1e-5 --seed 2 --alpha 1.0 --policy_freq 2

python oil_td3bc.py --expert-data maze2d-large-expert-v1 --offline-data maze2d-large-random-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000 --lr 1e-3 --alpha 1.0 --seed 0  --policy_freq 2 --wd 0
python oil_td3bc.py --expert-data maze2d-large-expert-v1 --offline-data maze2d-large-random-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000 --lr 1e-3 --alpha 1.0 --seed 1  --policy_freq 2 --wd 0
python oil_td3bc.py --expert-data maze2d-large-expert-v1 --offline-data maze2d-large-random-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000 --lr 1e-3 --alpha 1.0 --seed 2  --policy_freq 2 --wd 0



python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-random-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 0
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-random-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 1
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-random-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 2


python oil_td3bc.py --expert-data maze2d-medium-expert-v1 --offline-data maze2d-medium-random-dense-v1 --expert-num 5 --offline-exp 0 --max_timesteps 200000 --lr 1e-5 --seed 0 --alpha 1.0 --policy_freq 2
python oil_td3bc.py --expert-data maze2d-medium-expert-v1 --offline-data maze2d-medium-random-dense-v1 --expert-num 5 --offline-exp 0 --max_timesteps 200000 --lr 1e-5 --seed 1 --alpha 1.0 --policy_freq 2
python oil_td3bc.py --expert-data maze2d-medium-expert-v1 --offline-data maze2d-medium-random-dense-v1 --expert-num 5 --offline-exp 0 --max_timesteps 200000 --lr 1e-5 --seed 2 --alpha 1.0 --policy_freq 2

python oil_td3bc.py --expert-data maze2d-large-expert-v1 --offline-data maze2d-large-random-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000 --lr 1e-3 --alpha 1.0 --seed 0  --policy_freq 2 --wd 0
python oil_td3bc.py --expert-data maze2d-large-expert-v1 --offline-data maze2d-large-random-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000 --lr 1e-3 --alpha 1.0 --seed 1  --policy_freq 2 --wd 0
python oil_td3bc.py --expert-data maze2d-large-expert-v1 --offline-data maze2d-large-random-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000 --lr 1e-3 --alpha 1.0 --seed 2  --policy_freq 2 --wd 0






python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-v1 --expert-num 10 --offline-exp 0  --max_timesteps 200000 --seed 0 --mode train 
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-v1 --expert-num 10 --offline-exp 0  --max_timesteps 200000 --seed 1 --mode train 
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-v1 --expert-num 10 --offline-exp 0  --max_timesteps 200000 --seed 2 --mode train 

python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 0
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 1
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 2

python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 0 --wd 0
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 1 --wd 0
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 2 --wd 0



python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 0
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 1
python oil_td3bc.py --expert-data maze2d-umaze-expert-v1 --offline-data maze2d-umaze-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000  --mode train --lr 1e-5 --alpha 0.1 --seed 2

python oil_td3bc.py --expert-data maze2d-medium-expert-v1 --offline-data maze2d-medium-dense-v1 --expert-num 5 --offline-exp 0 --max_timesteps 200000 --mode train --lr 1e-4 --seed 0 --alpha 1.0 --policy_freq 2
python oil_td3bc.py --expert-data maze2d-medium-expert-v1 --offline-data maze2d-medium-dense-v1 --expert-num 5 --offline-exp 0 --max_timesteps 200000 --mode train --lr 1e-4 --seed 1 --alpha 1.0 --policy_freq 2
python oil_td3bc.py --expert-data maze2d-medium-expert-v1 --offline-data maze2d-medium-dense-v1 --expert-num 5 --offline-exp 0 --max_timesteps 200000 --mode train --lr 1e-4 --seed 2 --alpha 1.0 --policy_freq 2


python oil_td3bc.py --expert-data maze2d-large-expert-v1 --offline-data maze2d-large-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000 --lr 1e-3 --alpha 1.0 --seed 0 --mode debug --policy_freq 2 --wd 0
python oil_td3bc.py --expert-data maze2d-large-expert-v1 --offline-data maze2d-large-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000 --lr 1e-3 --alpha 1.0 --seed 1 --mode debug --policy_freq 2 --wd 0
python oil_td3bc.py --expert-data maze2d-large-expert-v1 --offline-data maze2d-large-dense-v1 --expert-num 5 --offline-exp 0  --max_timesteps 200000 --lr 1e-3 --alpha 1.0 --seed 2 --mode debug --policy_freq 2 --wd 0

