



python oil_td3bc.py --expert-data pen-expert-v1 --offline-data pen-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5
python oil_td3bc.py --expert-data pen-expert-v1 --offline-data pen-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5
python oil_td3bc.py --expert-data pen-expert-v1 --offline-data pen-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5

python oil_td3bc.py --expert-data hammer-expert-v1 --offline-data hammer-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5
python oil_td3bc.py --expert-data hammer-expert-v1 --offline-data hammer-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5
python oil_td3bc.py --expert-data hammer-expert-v1 --offline-data hammer-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5

python oil_td3bc.py --expert-data door-expert-v1 --offline-data door-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5
python oil_td3bc.py --expert-data door-expert-v1 --offline-data door-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5
python oil_td3bc.py --expert-data door-expert-v1 --offline-data door-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5

python oil_td3bc.py --expert-data relocate-expert-v1 --offline-data relocate-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 0 --discount 0.5
python oil_td3bc.py --expert-data relocate-expert-v1 --offline-data relocate-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 1 --discount 0.5
python oil_td3bc.py --expert-data relocate-expert-v1 --offline-data relocate-cloned-v1 --expert-num 50 --mode train --max_timesteps 200000 --lr 1e-5 --alpha 0.1 --policy_freq 3 --bc_freq 1 --seed 2 --discount 0.5

