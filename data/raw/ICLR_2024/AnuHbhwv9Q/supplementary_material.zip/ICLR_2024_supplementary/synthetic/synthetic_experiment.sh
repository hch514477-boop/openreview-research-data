# Run the experiment with w_1
python3 synthetic_data_exper.py --num_repeats 10 --regressor_choice 1

# Run the experiment with w_2
python3 synthetic_data_exper.py --num_repeats 10 --regressor_choice 2

# Run the experiment with w_3
python3 synthetic_data_exper.py --num_repeats 10 --regressor_choice 3
