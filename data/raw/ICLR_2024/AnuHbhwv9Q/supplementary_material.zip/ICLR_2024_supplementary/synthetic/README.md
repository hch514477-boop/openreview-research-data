# Synthetic experiments
This subdirectory supplements the synthetic experiments in the SpAR paper.

synthetic_experiment.sh contains 3 commands to reproduce each of the three synthetic experiment columns in the paper.
