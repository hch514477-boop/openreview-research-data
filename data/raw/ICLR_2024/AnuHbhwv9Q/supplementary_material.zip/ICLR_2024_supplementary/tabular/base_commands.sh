
# Run the seed 0 base experiment for ERM on Skillcraft
python3 main.py --dataset SkillCraft --mixtype erm --kde_bandwidth 5e-4 --use_manifold 0 --store_model 1 --read_best_model 0 --seed 0 --spar_alpha 0.999 --search_lr 0.01 --search_artifact_base_path ./search_results/SkillCraft/base_erm_seed_0

# Run the seed 0 base experiment for Cmixup on Skillcraft
python3 main.py --dataset SkillCraft --mixtype kde --kde_bandwidth 5e-4 --use_manifold 0 --store_model 1 --read_best_model 0 --seed 0 --spar_alpha 0.999 --search_lr 0.01 --search_artifact_base_path ./search_results/SkillCraft/base_kde_seed_0

# Run the seed 0 base experiment for ERM on CommunitiesAndCrime
python3 main.py --dataset CommunitiesAndCrime --mixtype erm --kde_bandwidth 1.0 --use_manifold 1 --store_model 1 --read_best_model 0 --seed 0 --spar_alpha 0.999 --search_lr 0.001 --search_artifact_base_path ./search_results/CommunitiesAndCrime/base_erm_seed_0

# Run the seed 0 base experiment for Cmixup on CommunitiesAndCrime
python3 main.py --dataset CommunitiesAndCrime --mixtype kde --kde_bandwidth 1.0 --use_manifold 1 --store_model 1 --read_best_model 0 --seed 0 --spar_alpha 0.999 --search_lr 0.001 --search_artifact_base_path ./search_results/CommunitiesAndCrime/base_kde_seed_0