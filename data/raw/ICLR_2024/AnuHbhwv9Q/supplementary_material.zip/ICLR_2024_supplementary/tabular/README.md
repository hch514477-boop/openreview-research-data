# Tabular experiments
This subdirectory supplements the tabular experiments in the SpAR paper.

base_commands.sh contains 4 commands that can be used for running experiments with C-mixup/ERM on CommunitiesAndCrime/Skillcraft. Experiments were run on ten seeds, seeds 0-9.

This code is adapted from [the src folder of the C-Mixup codebase](https://github.com/huaxiuyao/C-Mixup/tree/main/src), which is subject to the MIT license.