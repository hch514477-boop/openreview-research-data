#!/bin/bash
#SBATCH --qos gpu
#SBATCH --chdir /home/bigi/wigner-kernels-jax-radial/
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 20
#SBATCH --gres gpu:1
#SBATCH --mem 80G
#SBATCH --time 3-0 

echo STARTING AT `date`
python -u measure_latency.py "${1}1.extxyz" > "latencies2/$1.out"
echo FINISHED at `date`
