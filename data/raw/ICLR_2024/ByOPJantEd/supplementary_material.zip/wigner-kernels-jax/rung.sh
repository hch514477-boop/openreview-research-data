#!/bin/bash
#SBATCH --qos gpu
#SBATCH --chdir /home/bigi/wigner-kernels-jax-radial/
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 20
#SBATCH --gres gpu:1
#SBATCH --mem 80G
#SBATCH --time 3-0 

echo STARTING AT `date`
python -u train_wk_forces.py "$1.extxyz" > "outputs_final/$1.out" $2 $3
echo FINISHED at `date`
