# Wigner Kernels

This folder is a collection of utilities to benchmark Wigner kernels. We provide two experimental implementations: one uses
PyTorch and the other uses JAX. The underscores/hyphens in the folder names reflect the standard way of naming folders in
the two aforementioned libraries. 
The JAX implementation has been used to generate results on rMD17, while the PyTorch one is more tested and it has been used
for all the other datasets.
