# GeneOH Diffusion

