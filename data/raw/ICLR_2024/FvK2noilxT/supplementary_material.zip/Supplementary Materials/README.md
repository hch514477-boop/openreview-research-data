# GeneOH Diffusion: Towards Generalizable Hand-Object Interaction Denoising via Denoising Diffusion -- *Supplementary Materials*

The supplementary materials accompanying this paper consist of the following resources:

- **Anonymous Website:** An anonymous website for presenting our work can be accessed at [Geneoh-Diffusion](https://geneoh-diffusion.github.io/Geneoh-Diffusion/). This website is dedicated to introducing the problem and showcasing animated experimental results.
- **Source Code:** The source code is included in the `Geneoh-Diffusion-Code/` directory.
- **Supplementary Video:** The Supplementary Video (with audio narration) titled `Supplementary Video.mp4` provides an overview of the challenging problem and presents our results and comparisons with prior art.
- **Local Webpage:** To access a *faster-loading* version of the published website, open `Geneoh-Diffusion-Webpage/index.html`. This local version is an abbreviated version of the anonymous website [Geneoh-Diffusion](https://geneoh-diffusion.github.io/Geneoh-Diffusion/).