videos are video results of our experiments.
code.zip contains codebase for our training/evaluation code.
