folder main_results are videos of Pointmass, UR5E, ShadowHand reported in main experiments in our paper.

folder pointmass_shrink_5184 are videos for model trained in pointmass env. under shrink=5184.

folder analysis contain videos for Analysis section with following sub-folders:

    shadow_default are default model trained with same tasks for reference purpose.
    shadow_mask_15 are models with static masking ratio = 15.
    shadow_mask_no are models trained with no masking.

    shadow_num_center_1 are models trained under 1 action bin.
    shadow_num_center_2 are models trained under 2 action bins.

    shadow_corrupt_0.45 are models trained with dataset corrupted with 45% proportion of skewing.

    dynamic_fire_1st refers to "fire handgun" in our paper.
    rsp refers to "rock-scissor-paper" in our paper.
    {dynamic_fire_1st|rsp}-full-mask are tasks where mask ratio is further increased.
