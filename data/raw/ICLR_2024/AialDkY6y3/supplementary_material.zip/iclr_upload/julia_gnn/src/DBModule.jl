module DBModule

include("DBNN-DBGC.jl")
export DBGCModel, DirichletEnergy

include("previousDBNN.jl")
export previousDBNN

include("DBNN.jl")
export DBGNN

end