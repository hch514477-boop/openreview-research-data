# companion paper to to test DBGNN layer

To train a model the language Julia 1.9.1 needs to be installed, afterwards the necessary packages can be automatically installed by running

```julia
using Pkg
Pkg.activate("julia_gnn/.")
Pkg.instantiate()
```
The training of the power grid task with the dataset of grids of size 20 can be started by executing:
```bash
julia run.jl
```
