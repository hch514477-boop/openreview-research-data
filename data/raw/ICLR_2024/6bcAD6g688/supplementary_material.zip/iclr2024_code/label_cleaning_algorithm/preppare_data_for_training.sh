python3 ./tools/prepare_downstream_data.py 
python3 ./tools/prepare_downstream_data_jigsaw.py 