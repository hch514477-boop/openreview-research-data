sel_labels="0 1 2 3 4 5 6"
for SEL in $sel_labels
do
    CUDA_VISIBLE_DEVICES=0 nohup python3 ./tools/diagnose_jigsaw.py --sel_label $SEL > jigsaw_$SEL.log &
    wait
done