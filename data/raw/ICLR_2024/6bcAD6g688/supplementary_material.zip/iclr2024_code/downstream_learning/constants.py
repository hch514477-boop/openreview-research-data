CLEAN_LABEL = 'clean_label'
RAW_LABEL = 'raw_label'
FILTER_LABEL = 'filter_label'
BEST_LABEL = 'chat_label'