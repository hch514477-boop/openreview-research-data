# train
cnt=0
exp_keys="PKU-SafeRLHF BeaverTails"
for EXP_KEY in $exp_keys; do
    for label_i in $labels; do
        cat ./configs/pku-bert.yml | sed -e "s/EXP_TRAIN_LABEL/${label_i}/g" -e "s/EXP_KEY/${EXP_KEY}/g" > ./configs/pku-bert_run.yml
        sleep 10s
        CUDA_VISIBLE_DEVICES=$cnt nohup python3 main.py --config ./configs/pku-bert_run.yml > pku_$EXP_KEY\_$label_i.log &
        sleep 10s
        ((cnt+=1))
        if [ "$cnt" -eq 3 ]; then
            cnt=0
            wait 
        fi
    done
done

wait

# test
test_labels="clean_label raw_label filter_label"
train_labels="clean_label raw_label"
cnt=0
for EXP_KEY in $exp_keys; do
    for train_label_i in $train_labels; do
        for test_label_i in $test_labels; do
            cat ./configs/pku-bert.yml | sed -e "s/EXP_KEY/${EXP_KEY}/g" -e "s/EXP_TRAIN_LABEL/${train_label_i}/g"  -e "s/EXP_TEST_LABEL/${test_label_i}/g" > ./configs/pku-bert_test.yml
            sleep 10s
            CUDA_VISIBLE_DEVICES=$cnt nohup python3 main.py --config ./configs/pku-bert_test.yml  --test > pku_$EXP_KEY\_$train_label_i\_$test_label_i.log &
            sleep 10s
            ((cnt+=1))
            if [ "$cnt" -eq 3 ]; then
                cnt=0
                wait 
            fi
        done
    done
done

wait 

# train
cnt=0
labels="clean_label raw_label"
for i in {0..6}; do
    for label_i in $labels; do
        cat ./configs/Jigsaw-bert.yml | sed -e "s/JIGSAW_IDX/${i}/g" -e "s/TRAIN_JIGSAW_LABEL/${label_i}/g" > ./configs/Jigsaw-bert_run.yml
        sleep 10s
        CUDA_VISIBLE_DEVICES=$cnt nohup python3 main.py --config ./configs/Jigsaw-bert_run.yml > jigsaw_$i\_$label_i.log &
        sleep 10s
        ((cnt+=1))
        if [ "$cnt" -eq 3 ]; then
            cnt=0
            wait 
        fi
    done
done

wait
# test
train_labels="clean_label raw_label"
test_labels="clean_label raw_label filter_label"

label_id="0 1 2 3 4 5 6"
cnt=0
for i in $label_id; do
    for train_label_i in $train_labels; do
        for test_label_i in $test_labels; do
            cat ./configs/Jigsaw-bert.yml | sed -e "s/JIGSAW_IDX/${i}/g" -e "s/TRAIN_JIGSAW_LABEL/${train_label_i}/g" -e "s/TEST_JIGSAW_LABEL/${test_label_i}/g"  > ./configs/Jigsaw-bert_test.yml
            sleep 10s
            CUDA_VISIBLE_DEVICES=$cnt nohup python3 main.py --config ./configs/Jigsaw-bert_test.yml --test > jigsaw_test_$i\_$train_label_i\_$test_label_i.log &
            sleep 10s
            ((cnt+=1))
        done
        if [ "$cnt" -eq 3 ]; then
            cnt=0
            wait 
        fi
    done
done
