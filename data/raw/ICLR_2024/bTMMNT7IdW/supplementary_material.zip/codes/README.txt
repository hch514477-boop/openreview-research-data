1. cd to "supp/codes" directory.
2. run the following command:
	python main.py --gpu_ids 0 --data_name RMNIST --data_path '/<path to the dataset>/dataset' --num_classes 10 --data_size '[1, 28, 28]' --source-domains 10 --intermediate-domains 3 --target-domains 6 --mode train --model-func MNIST_CNN --feature-dim 512 --epochs 50 --iterations 100 --train_batch_size 48 --eval_batch_size 48 --test_epoch -1 --algorithm SDE --seed 0 --save_path './logs/' --record --mlp-depth 2 --mlp-width 512 --dropout 0. --path_weight 1 --weight-decay 1e-4
