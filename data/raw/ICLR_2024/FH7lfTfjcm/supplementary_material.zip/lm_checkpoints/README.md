Unfortunately, we cannot upload checkpoints to softconf due to file size restrictions. You can download pre-trained PyBERT checkpoints from:

https://drive.google.com/drive/folders/1jghT7SwgU5qVbvoDQROj8M4VwGeDA3OO?usp=sharing
