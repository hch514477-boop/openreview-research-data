#!/bin/bash

PYTHONPATH='.':$PYTHONPATH \
python main.py \
--config configs/datasets/cifar10/cifar10.yml \
configs/datasets/cifar10/cifar10_ood.yml \
configs/networks/resnet18_32x32_ensemble.yml \
configs/pipelines/test/test_ood.yml \
configs/preprocessors/base_preprocessor.yml \
configs/postprocessors/deed.yml \
--network.pretrained False \
--num_workers 8 \
--mark 0 \
--postprocessor.postprocessor_args.network_name resnet18_32x32_ensemble \
--postprocessor.postprocessor_args.checkpoint_root 'results/resnet18_deed_sum_pretrained/cifar10_resnet18_32x32_ensemble_deed_e100_lr0.1_default/' \
--postprocessor.postprocessor_args.num_networks 5 \
--postprocessor.postprocessor_args.aggregation 'minmax' \
--dataset.test.batch_size 64 \
--dataset.val.batch_size 64 \
--ood_dataset.batch_size 64
