#!/bin/bash

PYTHONPATH='.':$PYTHONPATH \
python main.py \
--config configs/datasets/cifar10/cifar10.yml \
configs/datasets/cifar10/cifar10_ood.yml \
configs/networks/resnet18_32x32.yml \
configs/pipelines/test/test_ood.yml \
configs/preprocessors/base_preprocessor.yml \
configs/postprocessors/msp.yml \
--network.checkpoint 'results/resnet18_ensemble_pretrained/net1/best.ckpt' \
--num_workers 8 \
--mark 0 \
