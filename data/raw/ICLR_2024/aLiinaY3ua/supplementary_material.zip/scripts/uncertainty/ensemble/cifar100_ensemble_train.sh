#!/bin/bash

for EXP_NAME in 1 2 3 4 5
do
    PYTHONPATH='.':$PYTHONPATH CUDA_VISIBLE_DEVICES=2 \
    python main.py \
    --config configs/datasets/cifar100/cifar100.yml \
    configs/networks/resnet18_32x32.yml \
    configs/preprocessors/base_preprocessor.yml \
    configs/pipelines/train/baseline.yml \
    --optimizer.num_epochs 100 \
    --num_workers 8 \
    --output_dir ./results/resnet18_ensemble_pretrained \
    --exp_name "net$EXP_NAME"
done
