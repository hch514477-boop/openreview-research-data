#!/bin/bash

EXP_NAME='tin-gradcam-logitnorm'

for SEED in 1 2 3 4 5
do
    PYTHONPATH='.':$PYTHONPATH \
    python3 main.py \
    --config configs/datasets/tin/tin.yml \
    configs/networks/resnet18_64x64_ensemble.yml \
    configs/preprocessors/base_preprocessor.yml \
    configs/pipelines/train/train_gradcam.yml \
    --seed "$SEED" \
    --optimizer.num_epochs 100 \
    --num_workers 8 \
    --exp_name "$SEED" \
    --output_dir "/results/$EXP_NAME" \
    --loss.gradcam 0.005 \
    --loss.cls_loss "logitnorm" \
    --recorder.project ded \
    --recorder.experiment "$EXP_NAME-seed-$SEED" \
    --recorder.group "$EXP_NAME"

    PYTHONPATH='.':$PYTHONPATH \
    python3 main.py \
    --config configs/datasets/tin/tin.yml \
    configs/datasets/tin/tin_ood.yml \
    configs/networks/resnet18_64x64_ensemble.yml \
    configs/pipelines/test/test_ood.yml \
    configs/preprocessors/base_preprocessor.yml \
    configs/postprocessors/deed.yml \
    --network.pretrained False \
    --num_workers 8 \
    --exp_name "eval" \
    --output_dir "/results/$EXP_NAME/$SEED" \
    --postprocessor.postprocessor_args.network_name resnet18_64x64_ensemble \
    --postprocessor.postprocessor_args.checkpoint_root "/results/$EXP_NAME/$SEED" \
    --postprocessor.postprocessor_args.num_networks 5 \
    --postprocessor.postprocessor_args.aggregation 'minmax' \
    --dataset.test.batch_size 64 \
    --dataset.val.batch_size 64 \
    --ood_dataset.batch_size 64 \
    --recorder.project ded \
    --recorder.experiment "$EXP_NAME-eval-seed-$SEED" \
    --recorder.group "$EXP_NAME-eval"
done
