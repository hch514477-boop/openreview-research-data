#!/bin/bash

EXP_NAME='tin-gradcam-min'

for SEED in 1 2 3 4 5
do
    PYTHONPATH='.':$PYTHONPATH \
    python3 main.py \
    --config configs/datasets/tin/tin.yml \
    configs/datasets/tin/tin_ood.yml \
    configs/networks/resnet18_32x32_ensemble.yml \
    configs/pipelines/test/test_ood.yml \
    configs/preprocessors/base_preprocessor.yml \
    configs/postprocessors/deed.yml \
    --merge_option "merge" \
    --network.pretrained False \
    --num_workers 8 \
    --exp_name "eval" \
    --output_dir "./results/$EXP_NAME-eval-react/$SEED" \
    --postprocessor.postprocessor_args.network_name resnet18_32x32_ensemble \
    --postprocessor.postprocessor_args.checkpoint_root "./checkpoints/$EXP_NAME/$SEED" \
    --postprocessor.postprocessor_args.num_networks 5 \
    --postprocessor.postprocessor_args.aggregation 'logit-average' \
    --postprocessor.postprocessor_args.react_percentile 90 \
    --postprocessor.postprocessor_args.react_per_model True \
    --dataset.test.batch_size 16 \
    --dataset.val.batch_size 16 \
    --ood_dataset.batch_size 16 \
    --recorder.project ded \
    --recorder.experiment "$EXP_NAME-eval-react-seed-$SEED" \
    --recorder.group "$EXP_NAME-eval-react" \
    --pipeline.tune_temperature False
done
