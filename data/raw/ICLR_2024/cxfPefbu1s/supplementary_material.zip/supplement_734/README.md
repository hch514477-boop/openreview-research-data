# Implementation of "Procedural Fairness Through Decoupling Objectionable Data Generating Components"

### Supplement to submission 734 (ICLR 2024)

**"Procedural Fairness Through Decoupling Objectionable Data Generating Components"**

### Requirements

- `python >= 3.9.6`
- `numpy >= 1.22.0`
- `scikit-learn >= 1.0.0`
- `torch >= 1.5.0`

### To run the code

Open `uci_adult.ipynb` and click `Run All` to run the Jupyter Notebook containing the implementation of our framework.
