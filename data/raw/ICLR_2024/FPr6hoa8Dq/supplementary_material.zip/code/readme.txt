# training for perceptual performance and enhancement  # default
cd /root/autodl-tmp/projects/DEvUDP/src
python train.py --train_source /root/autodl-tmp/datasets/GoPro  --val_source1 /root/autodl-tmp/datasets/GoPro_val --val_source2 /root/autodl-tmp/datasets/LOL_val --model_mode perc --experiment test

# test for perceptual performance and enhancement  # default
cd /root/autodl-tmp/projects/DEvUDP/src
python test.py --data_source /root/autodl-tmp/datasets/LOL_val --model_name DEvUDP.pth --model_mode perc --experiment test --save_image





# training for distoriton performance
cd /root/autodl-tmp/projects/DEvUDP/src
python train.py --train_source /root/autodl-tmp/datasets/GoPro  --val_source1 /root/autodl-tmp/datasets/GoPro_val --val_source2 /root/autodl-tmp/datasets/LOL_val --model_mode dist --experiment test

# test for for distoriton performance
cd /root/autodl-tmp/projects/DEvUDP/src
python test.py --data_source /root/autodl-tmp/datasets/LOL_val --model_name DEvUDP_DT.pth --model_mode dist --experiment test --save_image