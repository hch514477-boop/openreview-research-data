import torch
from torch import nn,Tensor
from torch.utils.data import DataLoader

torch.set_printoptions(threshold=10_000)

import math
from time import time
import matplotlib.pyplot as plt
import numpy as np


DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

print(DEVICE)
if torch.cuda.is_available():
    print(torch.cuda.get_device_name(0))
    
    
    