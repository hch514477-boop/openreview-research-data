--------------------

## Dependency
We provide an environment.yaml



## Inference
```angular2html
python drag_lora_dragbench.py       # SDE-Drag
python drag_ode_lora_dragbench.py   # ODE-Drag
python diffedit.py                  # a demo for DiffEdit-SDE
python ode_diffedit.py              # a demo for DiffEdit-ODE

```

### Bash for inpainting evaluation
```angular2html
num=2500
order=2
i=0
for steps in 25
do
for algorithm in 'sde' 'ode'
do
for begin in $(seq 0 2500 35000)
do
id=$(( (i%8) ))
CUDA_VISIBLE_DEVICES=$id python inpainting_evaluation.py --num $num --begin $begin --algorithm $algorithm --steps $steps --order $order&
i=$((i+1))
done
done
done
```


