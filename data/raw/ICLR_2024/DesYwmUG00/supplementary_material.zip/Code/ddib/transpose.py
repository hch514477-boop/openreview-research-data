import os
import shutil
from PIL import Image
file_dir = '/mnt/datasets/ImageNet/train/'
file_dir2 = sorted(os.listdir(file_dir))[95]

file_dir += file_dir2
# 创建一个子文件存放文件
name = 'class'
 
file_list = sorted(os.listdir(file_dir))[:224]
 
for image in file_list:
    outdir = '/ddib_uvit/test/val2'
    image2 = Image.open(os.path.join(file_dir,image))
    image2 = image2.resize((256,256))
    image2.save(os.path.join(outdir, image))
    #shutil.copy(os.path.join(file_dir,image), os.path.join(outdir, image))


