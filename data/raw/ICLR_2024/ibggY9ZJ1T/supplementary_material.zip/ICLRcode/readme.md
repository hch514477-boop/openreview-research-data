contra_single.py->training CNNEncoder
finetune_un.py->adervatial experiments
get_mm_matix.py->extract invariant terms 
llama_cos_sim.py,transformer_cos_sim.py->extract invariant terms  and caculate cos
genarate_finger.py->genarate fingerprints
confusiontable.py->data output