# Official code for Transition-Dependent Discounting (TED)

TED_OfflineLearning: dataet creation, load reward and learn policy with TED and IQL
TED_RewardLearning: Learn reward with OPRL.