
# COMPA: ADDRESSING THE GAP IN COMPOSITIONAL REASONING IN AUDIO-LANGUAGE MODELS

1. For Vanilla Training: 

Use the following command after updating the train and val file in "/src/laion_clap/htsat-roberta-large-dataset-fusion.sh" from the "src/laion_clap/" directory

```
sh htsat-roberta-large-dataset-fusion.sh
```

2. For training with compositionally-aware hard negatives:

Use the following command after updating the resume ckpt (the ckpt from vanilla training), train and val file in "/src-ut/laion_clap/htsat-roberta-large-dataset-fusion-resume.sh" from the "src-ut/laion_clap/" directory

```
sh htsat-roberta-large-dataset-fusion-resume.sh
```

3. For training with modular contrastive learning:

Use the following command after updating the resume ckpt (the ckpt from training with compositionally-aware hard negatives), train and val file in "/src-ut-2/laion_clap/htsat-roberta-large-dataset-fusion-resume.sh" from the "src-ut-2/laion_clap/" directory

```
sh htsat-roberta-large-dataset-fusion-resume.sh
```

The audio files of both the benchmarks - CompA-order and CompA attribute can be downloaded from the below repository:

https://anonymous.4open.science/r/ICLR-Audios-8963/