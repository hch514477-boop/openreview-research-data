import torch

commands = dict()

class DLRTModule(torch.nn.Module):

    def __init__(self, fixed=False,tau = 0.1):
        super().__init__()
        self.step = 1
        self.dlrt = True
        # self.prev_case = "core"
        self.fixed = fixed
        # self.basic_number_weights = None
        self.tau = tau

    def set_step(self,new_step):

        self.step = new_step

