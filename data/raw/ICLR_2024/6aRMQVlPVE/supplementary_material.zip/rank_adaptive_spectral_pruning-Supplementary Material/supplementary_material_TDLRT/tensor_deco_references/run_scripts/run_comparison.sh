# #mnist

# python3 main.py --epochs 70 --deco cp --tau 0.9 --save_weights 1 --save_progress 1 --device cuda:2
# python3 main.py --epochs 70 --deco tucker --tau 0.05 --save_weights 1 --save_progress 1 --device cuda:2

# ## fmnist

# python3 main.py --epochs 70 --dataset_name fashion_mnist --deco cp --tau 0.5 --save_weights 1 --save_progress 1 --device cuda:2
# python3 main.py --epochs 70 --dataset_name fashion_mnist --deco tucker --tau 0.5 --save_weights 1 --save_progress 1 --device cuda:2

# ### cifar10

# python3 main.py --epochs 70 --dataset_name cifar10 --deco cp --tau 0.7 --net_name vgg16 --save_weights 1 --save_progress 1 --device cuda:2
# python3 main.py --epochs 70 --dataset_name cifar10 --deco tucker --tau 0.7 --net_name vgg16 --save_weights 1 --save_progress 1 --device cuda:2

# python3 main.py --epochs 70 --dataset_name cifar10 --deco cp --tau 0.7 --net_name alexnet --save_weights 1 --save_progress 1 --device cuda:2
# python3 main.py --epochs 70 --dataset_name cifar10 --deco tucker --tau 0.7 --net_name alexnet --save_weights 1 --save_progress 1 --device cuda:2



#### Feature basis

#mnist

python3 main.py --epochs 70 --deco mat --tau 0.9 --save_weights 1 --save_progress 1 --device cuda:2

## fmnist

python3 main.py --epochs 70 --dataset_name fashion_mnist --deco mat --tau 0.7 --save_weights 1 --save_progress 1 --device cuda:2

### cifar10

python3 main.py --epochs 70 --dataset_name cifar10 --deco mat --tau 0.8 --net_name vgg16 --save_weights 1 --save_progress 1 --device cuda:2

python3 main.py --epochs 70 --dataset_name cifar10 --deco mat --tau 0.7 --net_name alexnet --save_weights 1 --save_progress 1 --device cuda:2