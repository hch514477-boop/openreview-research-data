
for i in 1 #2 3 4 5
do
    for cr in  0.2 0.4 0.6 0.7 0.8 0.9 0.95
    do
    echo $i
    # mnist
    python3 main.py --epochs 70 --deco mat --tau $cr --save_weights 1 --save_progress 1 --device cuda:2 --cv_run $i
    ## fmnist
    python3 main.py --epochs 70 --dataset_name fashion_mnist --deco mat --tau $cr --save_weights 1 --save_progress 1 --device cuda:2 --cv_run $i
    ## cifar10
    python3 main.py --epochs 70 --dataset_name cifar10 --deco mat --tau $cr --net_name vgg16 --save_weights 1 --save_progress 1 --device cpu --cv_run $i
    python3 main.py --epochs 70 --dataset_name cifar10 --deco mat --tau $cr --net_name alexnet --save_weights 0 --save_progress 1 --device cuda --cv_run $i

    done
done
