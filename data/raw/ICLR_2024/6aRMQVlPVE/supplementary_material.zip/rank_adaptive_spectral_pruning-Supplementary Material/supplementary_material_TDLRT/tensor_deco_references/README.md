# Other Low-rank training methods. 
# Implemented with Tensorly-torch :
@article{JMLR:v20:18-277,
  author  = {Jean Kossaifi and Yannis Panagakis and Anima Anandkumar and Maja Pantic},
  title   = {TensorLy: Tensor Learning in Python},
  journal = {Journal of Machine Learning Research},
  year    = {2019},
  volume  = {20},
  number  = {26},
  pages   = {1--6},
  url     = {http://jmlr.org/papers/v20/18-277.html}
}

### Installation

1. Create a python environment (using conda for example)
2. Install pip in the environment (run ``conda install pip``)
3. Install the project requirements (example for pip):
   ``pip install -r requirements.txt``
4. Run the bash scripts example for the test cases contained in the folder "run_scripts"

### Test cases
In the folder ``run_scripts`` it is possible to find some test cases to run. In particular there are three bash scripts,
one for the cp decomposed networks, one for the tucker decomposed networks, and one for the matricization. To run them:
1. Move to the folder using ``cd run_scripts``
2. launch the desidered script with bash ``sh file.sh``