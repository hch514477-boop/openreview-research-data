import os
os.system('conda activate py3')
task_list =  ['Maze_square_random', 'Maze_square_blocked','Maze_square_blocked2']
# task_max_ep_list = [8000,6000,4000,2000]
# task_list =  ['Maze_square_random',]
task_max_ep_list = [10001,]
# for i in range(len(task_list)):
#     task = task_list[i]
#     ep_max = task_max_ep_list[0]
#
#
#     for j in range(2):
#         os.system('python ours_main2.py --env {} --ep_max {} --train_num {}'.format(task, ep_max, 15600+j*102))
#
#
# task = task_list[0]
# ep_max = task_max_ep_list[0]
# os.system('python ours_main3.py --env {} --ep_max {} --train_num {}'.format(task, ep_max, 15600 + (5+2) * 102))

task = task_list[-1]
ep_max = task_max_ep_list[0]
for j in range(2):
    os.system('python ours_main3.py --env {} --ep_max {} --train_num {}'.format(task, ep_max, 15600+(180+20+j)*102))

# for j in range(6):
#     os.system('python ours_main.py --env {} --ep_max {} --train_num {}'.format('Maze_S_shape',4000,j))