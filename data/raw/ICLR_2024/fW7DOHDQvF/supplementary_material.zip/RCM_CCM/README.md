# RCM&CCM
A simple demo for the paper "Consistent Multi-Class Classification from Multiple Unlabeled Datasets"

## Requirements
* Python 3.6.13
* Numpy 1.19.2
* PyTorch 1.7.1
* Matplotlib 3.3.4

## A Demo for MNIST dataset
You can run an example code of RCM on MNIST dataset.

'python experiment.py --loss RC'

You can run an example code of CCM on MNIST dataset.

'python experiment.py --loss CC'

