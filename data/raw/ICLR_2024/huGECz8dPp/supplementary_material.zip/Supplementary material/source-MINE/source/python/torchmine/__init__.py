"""
PyTorch implementation of mutual information neural estimation.

loss - losses for lower mutual information bounds.
"""

from . import loss

__name__ = "PyTorch mutual information neural estimation"
