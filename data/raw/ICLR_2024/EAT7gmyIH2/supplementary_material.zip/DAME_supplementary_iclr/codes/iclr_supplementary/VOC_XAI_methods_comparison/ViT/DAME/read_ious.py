import numpy as np
from pdb import set_trace as bp

with open('log_all_scores.txt') as file:
    lines = [line.rstrip() for line in file]
file.close()

cls_true = np.load('store_cls.npy')
scores_bb = np.load('store_scores.npy')

ious = []
ious_cls = []
cls_temp = []
for line in lines:
    if line[:3]!='cls':
        cls_temp.append(float(line.split(' ')[1]))
        ious.append(float(line.split(' ')[1]))
    else:
        if len(cls_temp)!=0: ious_cls.append(cls_temp)
        cls_temp = []
if len(cls_temp)!=0: ious_cls.append(cls_temp)

all_mean = scores_bb.mean()
all_sample_ious = []
store_cls_means = []
store_cls_stds = []
for i, iou_c in enumerate(ious_cls):
    iou_c = np.array(iou_c)
    scores_c = scores_bb[cls_true==i+1]
    assert iou_c.shape==scores_c.shape
    # iou_c_filter = iou_c[scores_c>1.05*all_mean]
    # iou_c_filter = iou_c[scores_c>scores_c.mean()+0.21*scores_c.std()]
    iou_c_filter = iou_c[np.argpartition(scores_c, -int(0.52*scores_c.shape[0]))[-int(0.52*scores_c.shape[0]):]]
    print(f'cls: {i+1}, n_earlier: {iou_c.shape[0]}, n_now: {iou_c_filter.shape[0]}, IoU: {iou_c_filter.mean()}')
    store_cls_means.append(iou_c_filter.mean())
    store_cls_stds.append(iou_c_filter.std())
    all_sample_ious+=list(iou_c_filter)
bp()
print(f'all cls mean: {np.mean(store_cls_means)} and std {np.mean(store_cls_stds)}, all sample mean: {np.mean(all_sample_ious)}')