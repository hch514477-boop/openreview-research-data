import numpy as np
import pickle

file = open("store_ious_cls.pkl",'rb')
object_file = pickle.load(file)
file.close()

ious = []
for cls in range(1,21):
    iou_cls = object_file[cls]
    iou_cls = [i.item() for i in iou_cls]
    
    print(f'cls: {cls}: mean- {np.round(np.mean(iou_cls), 3)} ({np.round(np.std(iou_cls), 3)})')
    ious+=iou_cls
print(f'overall mean: {np.round(np.mean(ious), 3)} ({np.round(np.std(ious), 3)})')