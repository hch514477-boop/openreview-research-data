########################################################
Code for FedHP      ICLR2024 submission          ID=9239
########################################################

1. Setup-environment with the environment.yml:

2. Download pre-trained checkpoints
  
	model_epoch_184.pth: https://mega.nz/file/Nf0BQABY#R4oNX8fkigdIJTJOVLVB2YPdkGCzvs16YWV8EojFIBM 
		put under system/results/hardware_shaking/ 
		put under system/results/manufacturing_discrepancy/
	
	model_epoch_198.pth: https://mega.nz/file/dKEznarY#RrhB9w2NFFErL_y3Cjwb4BmV1aq3hVCBcthsMekavaU
		put under system/results/manufacturing_discrepancy/

	model_epoch_181.pth: https://mega.nz/file/JfFwjKpb#0Pk-RVOQXGvHHtSgzbv6on70iv6iuUK6EPE8558rfQ0
		put under system/results/manufacturing_discrepancy/

3. Download test data:
	https://mega.nz/folder/QeNyzYRT#LljQlcgKrifSHS6PjHG7PA
	put the mat files at system/mat/

	

4. Test the pre-trained model on [hardware shaking]
	

python main.py --test_mode --debug 0  --num_clients 3 --algorithm FedMP --trn_split 1 --mask_ids 8 9 10  --mask_op rand_crop --trial_num 54 --model MST-S --workers 0  --device_id 0 --focus Generalization --CA   --last_train_clients 184 184 184 --model_save_filename_clients hardware_shaking hardware_shaking hardware_shaking --test_data_path ./system/mat/ --mask_path ./system/masks/mask_files

5. Test the pre-trained model on [manufacturing discrepancy]

python main.py --test_mode --debug 0  --num_clients 3 --algorithm FedMP --trn_split 1 --mask_ids 1 4 6  --mask_op rand_crop --trial_num 54 --model MST-S --workers 0  --device_id 0 --focus Generalization --CA   --last_train_clients 184 198 181 --model_save_filename_clients hardware_shaking hardware_shaking hardware_shaking --test_data_path ./system/mat/ --mask_path ./system/masks/mask_files

Note
* mask 8 9 10 mimics the [hardware shaking] scenario
* mask 1 4 6 mimics the [manufacturing discrepancy] scenario
* Due to the limited file size, we provide 4 256x256x28 testing data
