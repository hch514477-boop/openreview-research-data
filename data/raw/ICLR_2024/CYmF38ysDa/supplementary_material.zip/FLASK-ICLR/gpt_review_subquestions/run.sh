# python gpt4_eval.py -a ../model_output/outputs_hard/chatgpt_hard.jsonl -o outputs/chatgpt_review_hard.jsonl -e outputs/chatgpt_review_hard_error.jsonl
# python gpt4_eval.py -a ../model_output/outputs_hard/bard_hard.jsonl -o outputs/bard_review_hard.jsonl -e outputs/bard_review_hard_error.jsonl
# python gpt4_eval.py -a ../model_output/outputs_hard/claude_v1_hard.jsonl -o outputs/claude_v1_review_hard.jsonl -e outputs/claude_v1_review_hard_error.jsonl
# python gpt4_eval.py -a ../model_output/outputs_hard/davinci_003_hard.jsonl -o outputs/davinci_003_review_hard.jsonl -e outputs/davinci_003_review_hard_error.jsonl
# python gpt4_eval.py -a ../model_output/outputs_hard/gpt4_hard.jsonl -o outputs/gpt4_review_hard.jsonl -e outputs/gpt4_review_hard_error.jsonl

# python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/chatgpt_hard.jsonl -o outputs/chatgpt_hard_atomic.jsonl -e outputs/chatgpt_hard_atomic_error.jsonl

# python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/chatgpt_hard.jsonl -o outputs/chatgpt_hard_atomic_ordinal.jsonl -e outputs/chatgpt_hard_atomic_ordinal_error.jsonl -p 'src/prompt_ordinal.jsonl'

python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/bard_hard.jsonl -o outputs/bard_hard_atomic_ordinal.jsonl -e outputs/bard_hard_atomic_ordinal_error.jsonl -p 'src/prompt_ordinal.jsonl'

python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/davinci_003_hard.jsonl -o outputs/davinci_003_hard_atomic_ordinal.jsonl -e outputs/davinci_003_hard_atomic_ordinal_error.jsonl -p 'src/prompt_ordinal.jsonl'

python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/claude_v1_hard.jsonl -o outputs/claude_v1_hard_atomic_ordinal.jsonl -e outputs/claude_v1_hard_atomic_ordinal_error.jsonl -p 'src/prompt_ordinal.jsonl'

python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/gpt4_hard.jsonl -o outputs/gpt4_hard_atomic_ordinal.jsonl -e outputs/gpt4_hard_atomic_ordinal_error.jsonl -p 'src/prompt_ordinal.jsonl'

# python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/chatgpt_hard_adversarial.jsonl -o outputs/chatgpt_hard_adversarial_atomic_ordinal.jsonl -e outputs/chatgpt_hard_adversarial_atomic_ordinal_error.jsonl -p 'src/prompt_ordinal.jsonl'

# python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/bard_hard.jsonl -o outputs/bard_hard_atomic.jsonl -e outputs/bard_hard_atomic_error.jsonl

# python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/claude_v1_hard.jsonl -o outputs/claude_v1_hard_atomic.jsonl -e outputs/claude_v1_hard_atomic_error.jsonl

# python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/davinci_003_hard.jsonl -o outputs/davinci_003_hard_atomic.jsonl -e outputs/davinci_003_hard_atomic_error.jsonl

# python gpt4_eval.py -q '../metadata_annotation/subquestion_generation/outputs/flask_atomic_human_validation.jsonl' -a ../model_output/outputs_hard/gpt4_hard.jsonl -o outputs/gpt4_hard_atomic.jsonl -e outputs/gpt4_hard_atomic_error.jsonl