# AI-fairness
A logical framework for verifying AI fairness. This repository contains 5 AI models with the corresponding datasets.
# Running Locally
To run the codes, follow the instructions given below:
  1. Create a new python 3.11.2 global env.
  2. Use the command pip install "package_name" to install the necessary packages.
  3. Download the zip file and extract it to a folder.
  4. Change the directory to the new folder.
 # To run the .ipynb file
    1. Load the notebook
    2.  CD... to the folder
    3. Select the .ipynb file to execute.
    3. Run the notebook
      * Use the menu pull-down `Cell > Run All` to run the notebook, or run the cells one at a time top-down using the play button.

      * As the cells run, watch the output for results or errors. A running cell will have a label like `In [*]`. A completed cell will have a run sequence           number instead of the asterisk.

  
