1. Questionaire.pdf: the user study questionaire
2. Rand_seq.pdf: the random generated sequences of each question 
3. Results.pdf: the collected user study results for each question

