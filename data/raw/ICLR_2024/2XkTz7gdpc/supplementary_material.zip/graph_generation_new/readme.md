To run the experiments configured in `config/run/`, run the following command:
```bash
python main.py run=run_name
```
where `run_name` is the name of the run configuration file in `config/run/` without the `.yaml` extension.

