#!/bin/bash -l

conda activate graph-generation
mkdir -p nohup_logs
nohup python main.py name=$1 +slurm=default +run=$1 >nohup_logs/$1.out &
