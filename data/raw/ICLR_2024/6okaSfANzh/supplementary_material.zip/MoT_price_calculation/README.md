## Setup
```
conda create --name gentenv python=3.10
conda activate gentenv
pip install tiktoken
pip install yaml
```
You can change the config of cost in config.yaml and run the code as follows:
```
python eval_gsm.py
```
