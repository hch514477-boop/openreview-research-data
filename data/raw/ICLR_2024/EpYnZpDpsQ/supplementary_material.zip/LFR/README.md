# LFR(learning from Random projections)

### environment setup
```
conda env create -f environment.yml
conda activate ssl
pip install h5py
```

### commands
To run our method (can change the epochs and eval_epochs to 1 for a quick test to see if the script runs):
```
python main.py --method ours --dataset CIFAR10 -a resnet18\
        --num_targets 6  --target_layers 2 --random-dropout\
        --init-beta --target_sample_ratio 10\
        -j $num_workers --epochs $epochs -b 512 --lr 0.03\
        --optimizer-type sgd --momentum 0.9 --wd 5e-4\
        --fix_pred_lr --pred_lr_scale 1\
        --train-predictor-individually --pred_epochs 5 --pred_layers 2\
        --eval_epochs $eval_epochs --eval_lr 0.2 --eval_bs 512\
        --dim 2048 --pred_dim 256 --loss barlow-batch\
        --num-of-runs 1--eval_during_ssl_training

```
