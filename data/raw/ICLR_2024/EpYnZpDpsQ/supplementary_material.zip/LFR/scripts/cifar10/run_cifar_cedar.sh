#!/usr/bin/env bash
sbatch --nodes=1 --mem=50G --time=96:00:00 --gres=gpu:1 scripts/cifar10/run_cifar_diet.sh
sbatch --nodes=1 --mem=50G --time=96:00:00 --gres=gpu:1 scripts/cifar10/run_cifar_diet_aug.sh
sbatch --nodes=1 --mem=50G --time=96:00:00 --gres=gpu:1 scripts/cifar10/run_cifar_autoencoder.sh
sbatch --nodes=1 --mem=50G --time=96:00:00 --gres=gpu:1 scripts/cifar10/run_cifar_simclr.sh
sbatch --nodes=1 --mem=50G --time=96:00:00 --gres=gpu:1 scripts/cifar10/run_cifar_simsiam.sh
sbatch --nodes=1 --mem=32G --time=96:00:00 --gres=gpu:1 scripts/cifar10/run_cifar_supervised.sh
# sbatch --nodes=1 --mem=32G --time=96:00:00 --gres=gpu:1 scripts/cifar10/run_cifar_ours.sh
sbatch --nodes=1 --mem=100G --time=128:00:00 --gres=gpu:1 scripts/cifar10/tuning-scripts/run_cifar_6.sh
sbatch --nodes=1 --mem=100G --time=128:00:00 --gres=gpu:1 scripts/cifar10/tuning-scripts/run_cifar_10.sh
sbatch --nodes=1 --mem=100G --time=128:00:00 --gres=gpu:1 scripts/cifar10/tuning-scripts/run_cifar_20.sh
sbatch --nodes=1 --mem=100G --time=128:00:00 --gres=gpu:1 scripts/cifar10/tuning-scripts/run_cifar_40.sh