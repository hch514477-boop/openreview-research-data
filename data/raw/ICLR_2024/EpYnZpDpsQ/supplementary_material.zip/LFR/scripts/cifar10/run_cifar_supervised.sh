#!/usr/bin/env bash
num_workers=1
epochs=800

dim=2048
pred_dim=256

python main.py --method supervised-aug --dataset CIFAR10 -a resnet18\
        --num_targets 0 --target_layers 1 --pred_layers 2\
        --dim $dim --pred_dim $pred_dim --loss ce\
        -j $num_workers --epochs $epochs -b 512 --lr 0.03\
        --optimizer-type sgd --momentum 0.9 --wd 5e-4\
        --num-of-runs 1 --eval_freq 10 --save_freq 800


        