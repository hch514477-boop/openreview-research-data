CUDA=$1
model=$2
dataset=$3
size=$4
tau=$5
l=$6

CUDA_VISIBLE_DEVICES=${CUDA} python ./utils/main.py --nowand 1 \
    --model=${model} --dataset=${dataset} \
    --buffer_size=${size} --n_epochs 1 --lr 0.03 \
    --minibatch_size 128 --batch_size 128 --tau ${tau} --window_length ${l} \
    --distributed dp