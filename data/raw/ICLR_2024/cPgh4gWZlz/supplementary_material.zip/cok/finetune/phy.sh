# export CUDA_VISIBLE_DEVICES=3

# python sft_trainer.py \
#     --model_name model/Llama-2-7b-hf \
#     --dataset_name data/physics-scienceqa \
#     --load_in_8bit \
#     --use_peft \
#     --batch_size 32 \
#     --gradient_accumulation_steps 2 \
#     --output_dir model/llama-2-7b-8bit-physics-scienceqa \
#     --num_train_epochs 3 \
#     --push_to_hub False\
#     # --max_steps 5 \
#     # --hub_model_id AnonySub628/llama-2-7b-sparql-contrastive-8bit \


export CUDA_VISIBLE_DEVICES=3

python sft_trainer_scienceqa.py \
    --model_name model/Llama-2-7b-hf \
    --dataset_name data/physics-scienceqa \
    --load_in_8bit \
    --use_peft \
    --batch_size 32 \
    --gradient_accumulation_steps 2 \
    --output_dir model/llama-2-7b-8bit-physics-scienceqa-v2 \
    --num_train_epochs 3 \
    --push_to_hub False\
    # --max_steps 5 \
    # --hub_model_id AnonySub628/llama-2-7b-sparql-contrastive-8bit \
