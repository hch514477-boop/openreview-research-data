#!/bin/bash
#SBATCH --job-name=MNIST-DDPM-allJobs # name of the job
#SBATCH --partition=gpu-unlimited # which partition the job should be scheduled on
#SBATCH --output=./slurm_logs/MNIST-DDPM-allJobs-%j.out
#SBATCH --error=./slurm_logs/MNIST-DDPM-allJobs-%j.err
##SBATCH -w gpu[33]
#SBATCH --nodes=4
#SBATCH --tasks-per-node=4

dt=$(date '+%d/%m/%Y %H:%M:%S');
echo $dt # debugging datetime print

for i in {0..31}
do
    sbatch slurm_train_ddpm.sh $i 
    sleep 20
done

##for i in {0..149}
##do
##    sbatch slurm_generate_samples.sh $i 
##    sleep 10
##done

	
dt=$(date '+%d/%m/%Y %H:%M:%S');
echo $dt # debugging datetime print
