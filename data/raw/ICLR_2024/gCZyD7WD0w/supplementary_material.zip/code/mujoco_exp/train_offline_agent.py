import os

from absl import app, flags
from ml_collections import config_flags

from experiments import exp_train_offline

config_flags.DEFINE_config_file("config", default="configs/mujoco.py")
FLAGS = flags.FLAGS


def main(argv):
    config = FLAGS.config

    # train offline RL agent
    exp_train_offline.train_and_evaluate(config)


if __name__ == '__main__':
    app.run(main)
