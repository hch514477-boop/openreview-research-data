import os

from absl import app, flags
from ml_collections import config_flags

from experiment import *

config_flags.DEFINE_config_file("config", default="configs/mujoco.py")
FLAGS = flags.FLAGS


def main(argv):
    config = FLAGS.config

    # run gde
    exp_gde.train_and_evaluate(config)

    # # run qdagger
    # exp_qdagger.train_and_evaluate(config)

    # # run iql
    # exp_baseline.train_and_evaluate(config)

    # # run jsrl
    # exp_jsrl.train_and_evaluate(config)

    # # run off2onrl
    # exp_off2onrl.train_and_evaluate(config)

    # # run per
    # exp_per.train_and_evaluate(config)

    # # run sfp
    # exp_sfp.train_and_evaluate(config)


if __name__ == '__main__':
    app.run(main)
