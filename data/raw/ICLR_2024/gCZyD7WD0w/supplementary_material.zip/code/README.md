# On the Survival Bias in Fine-tuning Offline Reinforcement Learning Agents

In this work, we study the problem of sample-efficient fine-tuning for offline reinforcement learning (RL) agents.

Train offline RL agent:

```bash
./train_offline.sh
```

Fine-tune trained offline RL agent:

```batch
./finetune.sh
```
