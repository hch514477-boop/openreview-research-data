# GMI Dataset

## Prepare environment and data

Prepare your Python environment with "env.yml".

You can download the content of "LoRA" from https://pan.quark.cn/s/de985242cf68.

You can download the content of "Model" from https://pan.quark.cn/s/5183b223e329.

## Build dataset

```
python build.py 
```

Tips: We have built the dataset already. You can download "Images.tar.xz" from https://pan.quark.cn/s/749f9687a5cb and then unzip it to "./Images".