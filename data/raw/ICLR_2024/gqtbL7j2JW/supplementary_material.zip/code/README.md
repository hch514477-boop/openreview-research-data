# GMI Experiments

## Prepare environment and data

Prepare your Python environment with "env.yml".

We have built the dataset already. You can download "Images.tar.xz" from https://pan.quark.cn/s/749f9687a5cb and then unzip it to "./Images".

## Generate specification (Optional)

If you want to build the specification yourself, please run:
```
python specification.py
```

## Identify models
```
python evalutation.py
```
The results will be stored in "./results"