def predictive_config():
    config = {}
    config["optimizer_type"] = 'adam'

    config["encoder_lr"] = 1e-3
    config["dynamics_lr"] = 1e-3
    config["state_emb_dim"] = 512
    config["action_emb_dim"] = 128
    config["dynamics_model_type"] = 'regular'
    config["discretize"] = 1
    config["koopman_real_init_type"] = 'constant'
    config["koopman_real_init_value"] = -0.2
    config["koopman_im_init_type"] = 'increasing_freq'
    config["train_seq_length"] = 100
    config["pred_reward"] = 0
    config["use_state_prediction_loss"] = 1

    config["replay_buffer_size"] = None
    return config