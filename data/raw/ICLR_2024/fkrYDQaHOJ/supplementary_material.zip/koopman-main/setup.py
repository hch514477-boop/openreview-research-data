from setuptools import find_packages, setup

setup(
    name="koopman",
    packages=find_packages(),
    version='0.1.0',
    description='Fast koopman based dynamics modeling',
    python_requires=">=3.6.*",
    author='Anonymous',
    license='MIT'
)