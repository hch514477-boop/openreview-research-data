## Fast Jax implementation of long range state and reward prediction

## Install the koopman package using
```
pip install -e .
```

## To run training of long range dynamics model using offline dataset, run the following command:
```
python -m scripts.train_offline_test_dynamics --train_seq_length 100 --dynamics_model_type regular
```
In the current implementation you can select the length of state action sequence for training and the dynamics model type.


For now you can select the dynamics model type from the following options:
- regular (mlp)
- diagonal_koopman
- gru
- transformer
- dssm
- dense_koopman

