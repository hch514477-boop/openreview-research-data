### Command

```bash
# bulk train lr
--repeat 3

python main_bulk_lr.py --data /ssd1/dataset --dataset cifar10 --arch mlp --width 1024 --epochs 1 --gpu 0
--dag 2_01_001_0001
--dag 2_02_002_0002
--dag 2_22_222_2222
--dag 2_22_222_0001
--dag 1_02_022_0222

python main_bulk_lr.py --data /ssd1/dataset --dataset cifar10 --arch cnn --width 1024 --epochs 1 --gpu 0
--kernel_size
--img-size

python main_bulk_lr.py --data /ssd1/dataset --dataset cifar10 --epochs 1 --gpu 0
--arch resnet18
--arch resnet34
--arch resnet50
--arch resnet101
--arch resnet152


python main_bulk_lr.py --data /ssd1/dataset --gpu 0 --batch_size 256 --aug --momentum 0.9 --weight_decay 0.0005 --nesterov --decreasing_lr --width 16 --arch tinynetwork
--dataset cifar10
--dataset cifar100
--dataset imagenet16_120
# search optimal learning rate
--epochs 1
--dag 1_01_001
# train a single arch to converge
--epochs 200
--lr 0.1
--dag 1_01_001
# train bulk architectures to converge
--epochs 200
--lr 0.266788
--lr_autoscale
# MuP
python main_bulk_lr.py --data /ssd1/dataset --gpu 0 --epochs 200 --batch_size 256 --aug --momentum 0.9 --weight_decay 0.0005 --decreasing_lr --width 16 --arch tinynetwork --lr 0.1 --mup
--dataset cifar10
--dataset cifar100
--dataset imagenet16_120


# CUDA_VISIBLE_DEVICES=2 OMP_NUM_THREADS=4 python ./exps/NAS-Bench-201/main.py --mode cover --save_dir ./output/ --max_node 4 --use_less 0 --datasets cifar10 --splits 1 --xpaths /ssd1/ --channel 16 --num_cells 5 --workers 1 --srange 25 25 --arch_index 25 --seeds 0
```


```bash
# bulk train
python main_bulk.py --data /ssd1/dataset --dataset cifar100 --arch mlp --width 256 --lr 0.001 --epochs 3000 --gpu 0
python main_bulk.py --data /ssd1/dataset/tiny-imagenet-200 --dataset tinyimagenet --arch mlp --width 256 --lr 0.005 --epochs 3000 --gpu 0
```


```python
# target_lr_list_v2.npy
np.concatenate([0.003 + 0.0005 * np.arange(34), 0.02 + 0.001 * np.arange(55)])
```
