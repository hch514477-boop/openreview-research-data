# Dynamical discrepancy

Transform the deep neural networks to their dynamical representations

convert demo:

```bash
cd Deep2Flat
python convert_pipeline.py \
--n_epoch 5 \
--dyn_config ./configs/dyn/vit_b_16_IMAGENET1K_V1.yaml \
--dnn_config ./configs/dnn/vit_b_16_IMAGENET1K_V1.yaml \
--model vit_b_16 \ 
--weights IMAGENET1K_V1 \ 
--work_dirs ./work_dirs \
--ngpus 4
```



