import json
MAX_PROMPTS = 10


if __name__ == "__main__":
    gpt3json = json.load(open('action-evaluation-llava.json', 'r'))
    prompts = json.load(open('epic-kitchens-description-val.json', 'r'))
    fprompts = []
    if MAX_PROMPTS >= 0:
        prompts = prompts[:MAX_PROMPTS]
    for i, act in enumerate(prompts):
        prompt = {"id": act["id"], "conversations": [{'from': 'human', 'value': f"PREDICTION: {act['description']}\nGROUND TRUTH: {act['action']}"}]}
        fprompts.append(prompt)
    gpt3json['prompts'] = fprompts
    json.dump(gpt3json, open('epick-action-evaluation-llava.json', 'w'), indent=4)
