if __name__ == "__main__":
    lines = None
    with open('example.txt') as f:
        lines = f.readlines()
        print(lines)
    for x in lines:
        x = x.strip()
        print("{")
        print('    "from": "human",')
        print('    "value": "' + x + '"')
        print("},")
