

# Optimal Kernel choice for score function-based causal discovery 





### Install
pip install -r requirements.txt

### Project structure

```
Code 
├── README.md
├── requirements.txt
├── /GES/
│  ├── GES.py
│  └── GES_utils.py
├── /Data/
│  ├── SyntheticData.py
│  ├── utils.py
│  ├── /CHILD/
│  │  ├── child.graph.txt
│  │  ├── child.pkl
│  │  ├── CHILD.py
│  │  ├── child.txt
│  │  └── txt2graph.py
│  └── /SACHS/
│     ├── sachs.graph.txt
│     ├── sachs.pkl
│     ├── SACHS.py
│     └── sach.py
├── Main.py
├── CatScore.py
└── CatModel.py


```
### Run
python Main.py --dataset con --nums 500 --score Ours 

   ######more option
    --dataset  con/dis/mix   Synthetic Continuous/ Discrete/ Mixed Data
               sach          SACH dataset
               child         CHILD dataset
    --nums     500/1000      sample size
    --score    CV            Cross-Validated likelihood
               Marg          Marginal likelihood
               Ours          Mutual Information-based score function
    --seed     1234          Random seed
    --gd       0.5           Graph density
    --device   cuda/cpu      Training on cuda/cpu          



