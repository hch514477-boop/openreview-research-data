import json
import numpy as np
import matplotlib.pyplot as plt

jump_size = 2
output_train = open("./Distortion/distorsion_train.json", "r")
auc_tmp = json.load(output_train)
output_train.close()
auc_train = np.trapz(auc_tmp["Synthetic Cognition"], dx=jump_size)
output_test = open("./Distortion/distorsion_test.json", "r")
auc_tmp = json.load(output_test)
output_test.close()
auc_test = np.trapz(auc_tmp["Synthetic Cognition"], dx=jump_size)
print("   Area under the curve on training distorsion set = {0:.2f}".format(auc_train))
print("   Area under the curve on test distorsion set = {0:.2f}".format(auc_test))
