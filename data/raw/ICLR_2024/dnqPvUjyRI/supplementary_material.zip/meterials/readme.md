Visualization

The PDF file is a graph of iteration and accuracy for all our experiments. The naming format is "data set abbreviation - setting - comparison algorithm name". For example, "esc2pseudo" represents the second setting of the ESC-50 data set, and the Pseudo Labeling algorithm is used for comparison. 

Training logs

The Txt file is a selected number of training processes, and a representative SemiReward result is selected for each modality.

meterials
├── visualization
│   ├── ag1flex.pdf
│   ├── ...
│   ├── yp2soft.pdf
├── training_logs
│   ├── audio_SRflexmatch_log.txt
│   ├── ...
│   ├── NLP_SRpseudolabel_log.txt