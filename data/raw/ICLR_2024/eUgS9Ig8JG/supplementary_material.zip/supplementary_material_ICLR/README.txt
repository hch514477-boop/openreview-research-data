The folder contains the code and the data for reproducing the results in the paper. 

The "code" folder contains python scripts for implementing SaNN for trajectory prediction, simplicial closure prediction, and graph classification. The folder contains the following scripts:
sann_tp.py -- Implements SaNN for trajectory prediction
sann_scp.py -- Implements SaNN for simplicial closure prediction
sann_gc.py -- Implements SaNN for graph classification

The "data" folder contains preprocessed sample datasets for easy implemenatation of the scripts mentioned above.
tp -- Contains preprocessed Ocean, Planar, and Mesh datasets for testing the trajectory prediction script
scp -- Contains preprocessed Email-Enron and Contact-high-school datasets for testing the simplicial closure prediction script
gc -- Contains preprocessed Proteins dataset for testing the graph classification script