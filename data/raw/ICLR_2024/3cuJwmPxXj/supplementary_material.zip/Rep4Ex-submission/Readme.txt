Code for all experiments in the manuscript "Identifying Representations for Intervention Extrapolation"

Figure 2: aff_identifiability.py
Figure 3: extrapolation_onedim.py
Figure 4: heuristic_regularization.py
Figure 5 & 6: visualize_3d_scatter.ipynb
Figure 7: extrapolation_multidim.py