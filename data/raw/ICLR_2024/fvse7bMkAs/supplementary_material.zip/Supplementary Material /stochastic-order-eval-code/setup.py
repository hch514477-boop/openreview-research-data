from setuptools import find_packages, setup

setup(
    name="soe",
    packages=find_packages(),
)
