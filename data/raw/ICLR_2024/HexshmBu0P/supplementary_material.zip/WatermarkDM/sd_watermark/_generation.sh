#!/bin/bash

# CUDA_VISIBLE_DEVICES=0 python stable_txt2img.py --ddim_eta 0.0 \
#                                  --n_samples 8 --batch_size 8 \
#                                  --n_iter 1 \
#                                  --scale 10.0 \
#                                  --ddim_steps 100 \
#                                  --ckpt ../_model_pool/sd-v1-4-full-ema.ckpt \
#                                  --prompt 'an astronaut walking in the deep universe, photorealistic' \
#                                  --outdir ../_outputs/sd_w_reg_1k \

