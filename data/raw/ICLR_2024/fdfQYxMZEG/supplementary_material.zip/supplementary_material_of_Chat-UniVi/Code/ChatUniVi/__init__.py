from .model import ChatUniViLlamaForCausalLM
