# Post-Training Recovery from Injected Bias with Self-Influence

## How to use this code?

* Install dependencies

```shell
pip install --upgrade "jax[cuda]" -f https://storage.googleapis.com/jax-releases/jax_cuda_releases.html
pip install -r requirements.txt
pip install nvidia-cudnn-cu11==8.6.0.163
```

* To run our algorithm

```shell
sh run.sh
```
