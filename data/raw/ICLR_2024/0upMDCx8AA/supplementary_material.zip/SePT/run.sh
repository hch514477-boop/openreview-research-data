#!/usr/bin/env bash
# train model for a few epoch
CUDA_VISIBLE_DEVICES=0 python -m pretrain.train --dataset cifar10c --percent 0.5pct --seed 0 --data_dir ./dataset
CUDA_VISIBLE_DEVICES=0 python -m pretrain.train --dataset cifar10c --percent 0.5pct --seed 1 --data_dir ./dataset
CUDA_VISIBLE_DEVICES=0 python -m pretrain.train --dataset cifar10c --percent 0.5pct --seed 2 --data_dir ./dataset
# Compute self-influence
CUDA_VISIBLE_DEVICES=0 python -m compute_influence.main --dataset cifar10c --percent 0.5pct --seed 0 --data_dir ./dataset
CUDA_VISIBLE_DEVICES=0 python -m compute_influence.main --dataset cifar10c --percent 0.5pct --seed 1 --data_dir ./dataset
CUDA_VISIBLE_DEVICES=0 python -m compute_influence.main --dataset cifar10c --percent 0.5pct --seed 2 --data_dir ./dataset
CUDA_VISIBLE_DEVICES=0 python -m compute_influence.intersection --dataset cifar10c --percent 0.5pct
# Fine-tuning model
# CUDA_VISIBLE_DEVICES=0 python -m finetuning --dataset cifar10c --percent 0.5pct --cosine --data_dir ./dataset --model_path ./model.pt --inf_path 