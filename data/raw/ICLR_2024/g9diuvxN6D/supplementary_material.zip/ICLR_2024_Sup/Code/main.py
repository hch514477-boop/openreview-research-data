from experiment import Experiment


if __name__ == "__main__":
    experiment = Experiment("google/flan-t5-xl", devices=[0], precision="bf16", use_peft=False)
    experiment.add_tasks_by_name(
        task_name="Known_Unknowns",
        output_dir="./test_rlhf/",
        batch_size="16",
        instruction="NIV2/QA/8",
        shot_count="0",
        eval_metric="classification",
    )
    experiment.inference()
