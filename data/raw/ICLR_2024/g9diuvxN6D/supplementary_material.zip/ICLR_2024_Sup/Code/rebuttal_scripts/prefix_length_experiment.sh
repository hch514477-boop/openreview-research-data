python train.py --model_name "flan-t5-3b-1prefix-align" --num_virtual_tokens 1 --soft_prompt --alignment --train_set_dir "./training_data/flan_train_986_3_alignment";
python train.py --model_name "flan-t5-3b-5prefix-align" --num_virtual_tokens 5 --soft_prompt --alignment --train_set_dir "./training_data/flan_train_986_3_alignment";
python train.py --model_name "flan-t5-3b-30prefix-align" --num_virtual_tokens 30 --soft_prompt --alignment --train_set_dir "./training_data/flan_train_986_3_alignment";
python train.py --model_name "flan-t5-3b-50prefix-align" --num_virtual_tokens 50 --soft_prompt --alignment --train_set_dir "./training_data/flan_train_986_3_alignment";

python train.py --model_name "flan-t5-3b-1prefix" --num_virtual_tokens 1 --soft_prompt  --train_set_dir "./training_data/flan_train_986_3";
python train.py --model_name "flan-t5-3b-5prefix" --num_virtual_tokens 5 --soft_prompt --train_set_dir "./training_data/flan_train_986_3";
python train.py --model_name "flan-t5-3b-10prefix" --num_virtual_tokens 10 --soft_prompt --train_set_dir "./training_data/flan_train_986_3";
python train.py --model_name "flan-t5-3b-30prefix" --num_virtual_tokens 30 --soft_prompt  --train_set_dir "./training_data/flan_train_986_3";
python train.py --model_name "flan-t5-3b-50prefix" --num_virtual_tokens 50 --soft_prompt  --train_set_dir "./training_data/flan_train_986_3";

python train.py --model_name_or_path "/work/frink/models/alpaca-7b" --model_name "alpaca-7b-1prefix-align" --num_virtual_tokens 1 --soft_prompt --alignment --train_set_dir "./training_data/alpaca_train_1000_3_alignment";
python train.py --model_name_or_path "/work/frink/models/alpaca-7b" --model_name "alpaca-7b-5prefix-align" --num_virtual_tokens 5 --soft_prompt --alignment --train_set_dir "./training_data/alpaca_train_1000_3_alignment";
python train.py --model_name_or_path "/work/frink/models/alpaca-7b" --model_name "alpaca-7b-30prefix-align" --num_virtual_tokens 30 --soft_prompt --alignment --train_set_dir "./training_data/alpaca_train_1000_3_alignment";
python train.py --model_name_or_path "/work/frink/models/alpaca-7b" --model_name "alpaca-7b-50prefix-align" --num_virtual_tokens 50 --soft_prompt --alignment --train_set_dir "./training_data/alpaca_train_1000_3_alignment";

python train.py --model_name_or_path "/work/frink/models/alpaca-7b" --model_name "alpaca-7b-1prefix" --num_virtual_tokens 1 --soft_prompt --train_set_dir "./training_data/alpaca_train_1000_3";
python train.py --model_name_or_path "/work/frink/models/alpaca-7b" --model_name "alpaca-7b-5prefix" --num_virtual_tokens 5 --soft_prompt --train_set_dir "./training_data/alpaca_train_1000_3";
python train.py --model_name_or_path "/work/frink/models/alpaca-7b" --model_name "alpaca-7b-10prefix" --num_virtual_tokens 10 --soft_prompt --train_set_dir "./training_data/alpaca_train_1000_3";
python train.py --model_name_or_path "/work/frink/models/alpaca-7b" --model_name "alpaca-7b-30prefix" --num_virtual_tokens 30 --soft_prompt --train_set_dir "./training_data/alpaca_train_1000_3";
python train.py --model_name_or_path "/work/frink/models/alpaca-7b" --model_name "alpaca-7b-50prefix" --num_virtual_tokens 50 --soft_prompt --train_set_dir "./training_data/alpaca_train_1000_3";