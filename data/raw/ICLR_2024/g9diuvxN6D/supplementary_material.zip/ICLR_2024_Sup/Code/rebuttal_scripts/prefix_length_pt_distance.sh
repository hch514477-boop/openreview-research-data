python distance_stat.py --model_path_or_name "./models/prefix_length/flan-t5-3b-1prefix" --output_dir "./results_csv/Distance/Prefix_Length/Flan-1-PT";
python distance_stat.py --model_path_or_name "./models/prefix_length/flan-t5-3b-5prefix" --output_dir "./results_csv/Distance/Prefix_Length/Flan-5-PT";
python distance_stat.py --model_path_or_name "./models/prefix_length/flan-t5-3b-10prefix" --output_dir "./results_csv/Distance/Prefix_Length/Flan-10-PT";
python distance_stat.py --model_path_or_name "./models/prefix_length/flan-t5-3b-30prefix" --output_dir "./results_csv/Distance/Prefix_Length/Flan-30-PT";
python distance_stat.py --model_path_or_name "./models/prefix_length/flan-t5-3b-50prefix" --output_dir "./results_csv/Distance/Prefix_Length/Flan-50-PT";