from typing import List
from dataset import Example

class BaseConverter:
    INSTRUCTION = ""
    LABEL_MAP = {}
    def example2code(self, demos: List[Example], target: Example) -> str:
        raise NotImplementedError()

    def code2answer(self, code: str) -> str:
        raise NotImplementedError()