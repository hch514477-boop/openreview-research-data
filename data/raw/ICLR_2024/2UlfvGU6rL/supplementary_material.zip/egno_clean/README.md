# Equivariant Graph Neural Operator

Example Usage:
```
python main_simulation_simple_no.py --config_by_file
```

The config files are in `configs/` folder. Use `--config_by_file` to adopt our default config file.