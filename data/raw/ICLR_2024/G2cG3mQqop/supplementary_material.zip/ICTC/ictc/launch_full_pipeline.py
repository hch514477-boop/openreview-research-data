import os 

dataset = "stl10"

# llava
command = f"python llava/eval/model.py --dataset {dataset} --use_gpt4 True --exp_name final_prompt"
os.system(command)

# labeling
command = f"python ictc/gpt_labeling.py --dataset {dataset} --use_gpt4 False --exp_name final_prompt"
os.system(command)

# clustering
command = f"python ictc/gpt_clustering.py --dataset {dataset} --use_gpt4 False --exp_name final_prompt"
os.system(command)

# classification
command = f"python ictc/gpt_classification.py --dataset {dataset} --use_gpt4 False --exp_name final_prompt"
os.system(command)

# measuring acc
command = f"python ictc/measuring_acc.py --dataset {dataset} --use_gpt4 False --exp_name final_prompt"
os.system(command)
