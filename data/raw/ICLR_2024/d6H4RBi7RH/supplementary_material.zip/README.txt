Run the following cmd to reproduce the results in Table 1 (p=0.7)

python submit_main.py --seed 1 --id_sp 1.0 --p 0.7 --n_restarts 20 --colors 32
