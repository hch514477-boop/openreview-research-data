# Skill-Conditioned Policy Optimization with Successor Features Representations

## Launching an experiment

```bash
python main.py algo=ours task=humanoid feat=feet_contact seed=$RANDOM +mode=train
```

## Using Apptainer

To build a container using Apptainer make sure you are in the root of the repository and then run:

```bash
apptainer build --fakeroot --force apptainer/container.sif apptainer/apptainer.def
```

You can execute the container with:

```bash
apptainer -d run --cleanenv --containall --no-home --nv container.sif [EXTRA ARGUMENTS]
```

