from setuptools import find_packages, setup

setup(
    name='clipmasterprints',
    packages=find_packages(),
    version='0.0.2',
    description='Fooling Contrastive Language-Image Pre-training with CLIPMasterPrints',
    author='Anonymus',
    license='',
    install_requires=[
        "torch==2.0.1",
        "torchvision==0.15.2",
        "numpy==1.23.3",
        "pandas==1.5.0",
        "cma==3.2.2",
        "yacs",
        "matplotlib==3.6.2",
        "seaborn==0.11"

    ]
)

