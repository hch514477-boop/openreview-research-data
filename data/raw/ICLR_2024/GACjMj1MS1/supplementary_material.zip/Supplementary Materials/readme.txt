Empirical likelihood for fair classification
Our code refers to the code in Muhammad Bilal Zafar, Isabel Valera, Manuel Gomez Rogriguez, and Krishna P. Gummadi. Fairness Constraints: Mechanisms for Fair Classification, Proceedings of the 20th International Conference on Artificial Intelligence and Statistics, volume 54 of Proceedings of Machine Learning Research.

simulation.py/cp_sim(): 4.1 Coverage Probability and Confidence Interval 
simulation.py/sim(): the method EL-based fairness in 4.2 Trade-off between Accuracy and Fairness
The data used in  4.2 are in the filefolder "sim_data".
credit_experiments.ipynb: 5.2 Multiple sensitive attributes 
ACS_experiments: The ".npy" files in the filefolder "income5" and "income50" are the results using our method at alpha=0.05 and alpha=0.5. The ".npy" files in the filefolder "uncon" are the results of the method without fairness constraint.
