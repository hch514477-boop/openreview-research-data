# TimelyGPT
TimelyGPT is a large-scale pre-trained model for long sequence time-series represenetation. Here is the core code of our proposed methodology. The complete source code will be released in Github.
