python prepare.py

bash ProxAdamW_LeNet_on_FashionMNIST.sh & 
bash ProxSGD_LeNet_on_FashionMNIST.sh & 
bash RAMDA_LeNet_on_FashionMNIST.sh & 
bash RMDA_LeNet_on_FashionMNIST.sh