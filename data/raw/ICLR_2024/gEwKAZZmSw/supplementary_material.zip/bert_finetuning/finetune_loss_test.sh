# mnli qqp qnli sst2
TASK_NAME="mnli"
BATCH_SIZE=32
SEED=2
EVAL_FREQ=500

BETA=2

LOG_NAME="plot_${TASK_NAME}_large_bsz${BATCH_SIZE}_seed${SEED}_loss_beta${BETA}"

CMD="CUDA_VISIBLE_DEVICES=$1 python3 -u finetune_loss_test.py \
    --task_name $TASK_NAME \
    --batch_size $BATCH_SIZE \
    --log_name $LOG_NAME \
    --seed $SEED \
    --eval_freq $EVAL_FREQ \
    --beta $BETA \
    --wandb \
    --wandb_group sb_10"
echo $CMD >> logs/$LOG_NAME.log
eval $CMD