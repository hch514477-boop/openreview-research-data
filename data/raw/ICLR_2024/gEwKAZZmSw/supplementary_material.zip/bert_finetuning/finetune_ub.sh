# mnli qqp qnli sst2
TASK_NAME="mnli"
BATCH_SIZE=32
SEED=0
EVAL_FREQ=500

SAMPLE_RATIO=0.33

LOG_NAME="${TASK_NAME}_large_bsz${BATCH_SIZE}_seed${SEED}_ub${SAMPLE_RATIO}"

CMD="CUDA_VISIBLE_DEVICES=$1 python3 -u finetune_ub.py \
    --task_name $TASK_NAME \
    --batch_size $BATCH_SIZE \
    --log_name $LOG_NAME \
    --seed $SEED \
    --eval_freq $EVAL_FREQ \
    --sample_ratio $SAMPLE_RATIO \
    --wandb \
    --wandb_group ub"
echo $CMD >> logs/$LOG_NAME.log
eval $CMD