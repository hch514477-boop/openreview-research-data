# mnli qqp qnli sst2
TASK_NAME="mnli"
BATCH_SIZE=32
# SEED=0
EVAL_FREQ=500
CAL_VAR_FREQ=500
CAL_VAR_M=2

S=1 # initial value of S
ACT_VAR_TOLERANCE=0.025
WEIGHT_VAR_TOLERANCE=0.025
S_UPDATE_STEP=0.02
WEIGHT_RATIO_MULTIPLIER=0.8

for SEED in 0 1 2
do

LOG_NAME="plot_${TASK_NAME}_base_bsz${BATCH_SIZE}_seed${SEED}_ema0.5_freq${CAL_VAR_FREQ}_m${CAL_VAR_M}_s${S}_avt${ACT_VAR_TOLERANCE}_wvt${WEIGHT_VAR_TOLERANCE}_sus${S_UPDATE_STEP}_wrm${WEIGHT_RATIO_MULTIPLIER}"

CMD="CUDA_VISIBLE_DEVICES=$1 python3 -u finetune.py \
    --task_name $TASK_NAME \
    --batch_size $BATCH_SIZE \
    --log_name $LOG_NAME \
    --seed $SEED \
    --eval_freq $EVAL_FREQ \
    --cal_var_freq $CAL_VAR_FREQ \
    --cal_var_m $CAL_VAR_M \
    --s $S \
    --act_var_tolerance $ACT_VAR_TOLERANCE \
    --weight_var_tolerance $WEIGHT_VAR_TOLERANCE \
    --s_update_step $S_UPDATE_STEP \
    --weight_ratio_multiplier $WEIGHT_RATIO_MULTIPLIER \
    --wandb \
    --wandb_group ours"
echo $CMD >> logs/$LOG_NAME.log
eval $CMD

done