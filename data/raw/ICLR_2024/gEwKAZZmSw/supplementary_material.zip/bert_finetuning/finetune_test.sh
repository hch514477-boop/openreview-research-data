SEED=0
TIME=$(date "+%Y-%m-%d-%H-%M-%S")

CAL_VAR_FREQ=50
CAL_VAR_M=2

S=1 # initial value of S
ACT_VAR_TOLERANCE=0.1
WEIGHT_VAR_TOLERANCE=0.1
S_UPDATE_STEP=0.005
WEIGHT_RATIO_MULTIPLIER=0.9

python3 -u sst2.py --log_name "test_adaptation_large" \
    --seed $SEED \
    --cal_var_freq $CAL_VAR_FREQ \
    --cal_var_m $CAL_VAR_M \
    --s $S \
    --act_var_tolerance $ACT_VAR_TOLERANCE \
    --weight_var_tolerance $WEIGHT_VAR_TOLERANCE \
    --s_update_step $S_UPDATE_STEP \
    --weight_ratio_multiplier $WEIGHT_RATIO_MULTIPLIER