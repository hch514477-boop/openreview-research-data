# mnli qqp qnli sst2
TASK_NAME="sst2"
BATCH_SIZE=32
SEED=0
EVAL_FREQ=500000

LOG_NAME="test_${TASK_NAME}_large_bsz${BATCH_SIZE}_seed${SEED}_baseline"

CMD="CUDA_VISIBLE_DEVICES=$1 python3 -u finetune_baseline_test.py \
    --task_name $TASK_NAME \
    --batch_size $BATCH_SIZE \
    --log_name $LOG_NAME \
    --seed $SEED \
    --eval_freq $EVAL_FREQ "
    # --wandb \
    # --wandb_group baseline"
echo $CMD >> logs/$LOG_NAME.log
eval $CMD