python eval.py eval=GLUE_sane name=pretrain-ub \
    eval.checkpoint=latest \
    impl.microbatch_size=16 \
    impl.shuffle_in_dataloader=True

python eval.py eval=GLUE_sane name=pretrain-sb \
    eval.checkpoint=latest \
    impl.microbatch_size=16 \
    impl.shuffle_in_dataloader=True