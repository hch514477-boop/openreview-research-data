DATASET="cifar100"
BATCH_SIZE=32
SEED=2

OUTPUT_DIR="${DATASET}_base_seed${SEED}_baseline"

CUDA_VISIBLE_DEVICES=$1 python run_image_classification.py \
    --model_name_or_path "./vit-base-patch16-224-in21k" \
    --dataset_name ${DATASET} \
    --output_dir ${OUTPUT_DIR} \
    --learning_rate 2e-5 \
    --num_train_epochs 5 \
    --batch_size ${BATCH_SIZE} \
    --eval_batch_size ${BATCH_SIZE} \
    --cal_var_freq 9999999999 \
    --eval_freq 200 \
    --seed ${SEED} \
    --wandb