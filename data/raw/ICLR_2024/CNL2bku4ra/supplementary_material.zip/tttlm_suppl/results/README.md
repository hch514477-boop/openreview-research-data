Directory to store results.
