Place model checkpoint in this directory.
