# How Neural Networks With Derivative Labels Work: A Neural Tangent Kernel Perspective

This part of code is used to implement verification of proposition 1,2,3 in our article.

# Environment

```
# first install PyTorch 1.11
conda install pytorch torchvision torchaudio cudatoolkit=11.3 -c pytorch
 
pip install functorch
```

# Test

```
python test.py
```

in which we provide all our codes for verification. pro_num means our codes for verifying our proposition num in article. Proposition 1 need only two times computation of NTK before and after train.

Our kernel, angle, adaptive weight can be obtained from NTK_func.py