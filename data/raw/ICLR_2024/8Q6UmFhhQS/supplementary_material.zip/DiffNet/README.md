# NEURAL NETWORK DIFFUSION
This is the offical implementation of paper "NEURAL NETWORK DIFFUSION".

## How to use

```sh
# step 1: prepare your environment
pip3 install -r requirements.txt 

# step 2: Start training. Datasets will be download automatically.
bash script/partial_diff_res18_bn.sh --gpu 0 --number 200 # without AutoEncoder
bash script/partial_AE_diff_res18_bn.sh --gpu 0 --number 200 # with AutoEncoder

```
