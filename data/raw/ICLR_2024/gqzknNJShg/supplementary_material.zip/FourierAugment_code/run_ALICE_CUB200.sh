python alice_main_base.py \
--dataset cub200 \
--data_root '/home/main/datasets/cub200' \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1 \
--arch resnet18 \
--learning_rate 0.001 \
--epochs_base 100 \
--epochs_new 100 \
--weight_decay 5e-4 \
--momentum 0.9 \
--milestones 60 70 \
--gamma 0.1 \
--batch_size 256 \
--eval_freq 1 \
--save_freq 25 \
--feat_dim 2048 \
--loss_type cosface \
--loss_s 30 \
--loss_m 0.4 \
--seed 1 \
--data_transform 

# --- session 0 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 100 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/all_data_session0 \
--gpu 0 \
--current_session 0 \
--used_img 500 \
--balanced 0

# --- session 0 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 100 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session0 \
--gpu 0 \
--current_session 0 \
--used_img 5 \
--balanced 1

# --- session 1 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 110 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session1 \
--gpu 0 \
--current_session 1 \
--used_img 5 \
--balanced 1

# --- session 2 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 120 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session2 \
--gpu 0 \
--current_session 2 \
--used_img 5 \
--balanced 1

# --- session 3 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 130 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session3 \
--gpu 0 \
--current_session 3 \
--used_img 5 \
--balanced 1

# --- session 4 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 140 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session4 \
--gpu 0 \
--current_session 4 \
--used_img 5 \
--balanced 1

# --- session 5 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 150 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session5 \
--gpu 0 \
--current_session 5 \
--used_img 5 \
--balanced 1

# --- session 6 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 160 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session6 \
--gpu 0 \
--current_session 6 \
--used_img 5 \
--balanced 1

# --- session 7 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 170 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session7 \
--gpu 0 \
--current_session 7 \
--used_img 5 \
--balanced 1

# --- session 8 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 180 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session8 \
--gpu 0 \
--current_session 8 \
--used_img 5 \
--balanced 1

# --- session 9 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 190 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session9 \
--gpu 0 \
--current_session 9 \
--used_img 5 \
--balanced 1

# --- session 10 ---
python alice_main_inc_ncm.py \
--arch resnet18 \
--dataset cub200 \
--num_cls 200 \
--batch_size 32 \
--data_root '/home/main/datasets/cub200' \
--pretrained ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/trial1_session0_best.pth \
--exp_dir ./exp/CUB200_base-data-2_batch-512_epoch-100_lr-1e-3_milestones-60-70_seed-1_s-30_m-4e-1/1/ncm_classifier/balanced_5_data_session10 \
--gpu 0 \
--current_session 10 \
--used_img 5 \
--balanced 1


