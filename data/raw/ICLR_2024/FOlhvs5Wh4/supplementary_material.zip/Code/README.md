# Requisite
Python 3.6+  
Pytorch 1.8.1+cu111
Torchvision 0.9.0+cu111
numpy 1.21.4

# this file is based on code publicly available at
# base file: https://github.com/Hadisalman/smoothing-adversarial

move the scripts to the Code of the base file

# How to use

Cifar10
python -u code/train_cifar10.py cifar10 cifar_resnet110 models/resnet110_cifar10_ours --batch 256 --noise 0.12 --lr_step_size 50 --epochs 150


ImageNet: we use the pretrained model in the base file
python -u code/train_imagenet.py imagenet resnet50 models/imagenet_res50_ours --gpu 0 --batch 128 --noise 0.25 --epochs 10 --lr 0.0001 
