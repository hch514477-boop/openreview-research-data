# Recurrent Linear Transformers

1. AReLiT implementation in Jax: `./src/models/rlt/relit.py`
2. ReLiT implementation in Jax: `./src/models/rlt/rlt.py`
3. Train AReLiT: 
```
    #On T-Maze
    python trainer.py +tmaze=arelit

    #On Mystery Path
    python trainer.py +memorygym=arelit
```