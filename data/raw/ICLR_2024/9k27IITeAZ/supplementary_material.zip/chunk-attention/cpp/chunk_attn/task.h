#pragma once
#include "chunk.h"
#include <torch/torch.h>

namespace GPT {
struct Task {
    Task(Chunk* chunk, int seq_idx_begin, int seq_idx_end)
      : chunk(chunk)
      , seq_idx_begin(seq_idx_begin)
      , seq_idx_end(seq_idx_end) {}

    Chunk* chunk;
    int seq_idx_begin;
    int seq_idx_end;

    bool computed = false;
    torch::Tensor score_max;
    torch::Tensor score_sum;
    torch::Tensor qkv_result;
};
}