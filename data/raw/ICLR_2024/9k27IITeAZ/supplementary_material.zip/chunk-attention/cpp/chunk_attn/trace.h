#pragma once

#include <memory>
#include <torch/torch.h>
#include "str_utils.h"

namespace GPT {

struct Trace {
    Trace(bool record_kernel_t = false)
      : record_kernel_t(record_kernel_t)
      , chunk_kernel_t(0)
      , seq_kernel_t(0.0) {}

    bool record_kernel_t = false;
    long long chunk_kernel_t = 0;
    long long seq_kernel_t = 0;
};

}
