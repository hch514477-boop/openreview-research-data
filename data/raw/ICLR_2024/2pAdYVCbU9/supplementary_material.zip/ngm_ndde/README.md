# ngc_node

## Mackey--Glass 
To train the model, use the command, for example, with 10 delayed variables and 100 time indices gap (encoded in the code by default)

python gc_mlp_prune.py --r 0 --nunit 25

To post-process, modify the expIDs in post.py and use the command, e.g., 
python post.py --nunit 25 

In the submitted file, two pretrained models are included, with different random seeds. There expIDs are 58396 and 75355, which are encoded in the post.py 


## Tsunami
To train the model, use the command, for example, with 6 delayed variables and 10 time indices gap 

python gc_mlp_prune.py --r 0 --lMB 10 --lr 1e-3 --nep 1000 --ndelay 6 --lag 10 

To post-process, modify the expIDs in post_gc_dde.py and use the command, e.g., 
python post_gc_dde.py --ndelay 6 --lag 10 

In the submitted file, two pretrained models are included, with ndelay 6 and lag 10. There expIDs are 98657 and 54088, which are encoded in the post_gc_dde.py 
