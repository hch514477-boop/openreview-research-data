srun -c 8 -x inspur-gpu-05 --pty bash
srun -c 32 --gres=gpu:1 -p dell --pty bash
srun -c 32 --gres=gpu:1 -p dell -x dell-gpu-25 --pty bash
srun -c 32 --gres=gpu:1 -p sugon --pty bash
srun -c 16 --gres=gpu:1 -p dell --pty bash
srun -c 4 --gres=gpu:1 -p sugon --pty bash
srun -c 4 --gres=gpu:1 -p sugon -x sugon-gpu-5 --pty bash
srun -c 4 --gres=gpu:1 -p dell --pty bash
srun -c 8 --gres=gpu:2 -p sugon --pty bash
srun -c 8 --gres=gpu:2 -p dell -x dell-gpu-25 --pty bash
srun -c 8 -p inspur -x inspur-gpu-10,inspur-gpu-09 --pty bash
srun -c 32 -p inspur -w inspur-gpu-01 --gres=gpu:1 --pty bash
srun -c 32 -p inspur -w inspur-gpu-02 --gres=gpu:1 --pty bash
srun -c 32 -p inspur -w inspur-gpu-03 --gres=gpu:1 --pty bash
srun -c 32 -p inspur -w inspur-gpu-04 --gres=gpu:1 --pty bash
srun -c 32 -p inspur -w inspur-gpu-05 --gres=gpu:1 --pty bash
srun -c 32 -p inspur -w inspur-gpu-08 --gres=gpu:1 --pty bash
srun -c 16 -p inspur -w inspur-gpu-07 --pty bash
srun -c 16 -p inspur -w inspur-gpu-09 --pty bash
srun -c 32 -p inspur -w inspur-gpu-13 --pty bash
srun -c 32 -p inspur -x inspur-gpu-11,inspur-gpu-12,inspur-gpu-13 --gres=gpu:1 --pty bash

srun -c 32 -p inspur -x inspur-gpu-01,inspur-gpu-02,inspur-gpu-03,inspur-gpu-10 --pty bash
srun -c 32 -p dell --pty bash
srun -c 32 --gres=gpu:1 -x dell-gpu-21,dell-gpu-22,dell-gpu-23 -p dell --pty bash

srun -c 32 --gres=gpu:1 -x dell-gpu-09 -p dell --pty bash
srun -c 32 -p inspur --gres=gpu:1 --pty bash
#SBATCH -x dell-gpu-22,dell-gpu-31,dell-gpu-32

srun -c 32 --gres=gpu:1 -p sugon --pty bash
jupyter notebook

conda activate decision-transformer-atari
source /home/LAB/anaconda3/bin/activate decision-transformer-atari
source /home/LAB/anaconda3/bin/activate decision-transformer-atari
source /home/LAB/anaconda3/bin/activate decision-transformer-gym
source /home/LAB/zhutc/anaconda3/bin/activate decision-transformer-gym
source /home/LAB/zhutc/anaconda3/bin/activate decision-transformer-atari-A100
conda activate decision-transformer-atari-A100
conda activate DDPG_MC_hunter
source /home/LAB/anaconda3/bin/activate gird_system
source /home/LAB/anaconda3/bin/activate DDPG_MC_hunter

source /home/LAB/zhutc/anaconda3/bin/activate gird_system

source /home/LAB/anaconda3/bin/activate language_condition_MAT



tar -xvf re2c-3.0.tar.xz


./configure --prefix=/home/LAB/qiuyue/tools/ninjatest/
export PATH=/home/LAB/qiuyue/tools/ninja:$PATH

pip install Werkzeug -i https://pypi.tuna.tsinghua.edu.cn/simple


python train.py --task=ShadowHandOver --algo=happo


python train.py --task=ShadowHandDoorCloseOutward --algo=happo --num_envs=2048 --headless --seed 123


sh train_hands_offline_ShadowHandDoorCloseOutward.sh
sh train_hands_offline_ShadowHandCatchOver2Underarm.sh
sh train_hands_offline_ShadowHandDoorOpenInward.sh

sh train_hands_offline_ShadowHandDoorCloseOutward50%.sh
sh train_hands_offline_ShadowHandCatchOver2Underarm50%.sh
sh train_hands_offline_ShadowHandDoorOpenInward50%.sh

sh train_hands_offline_ShadowHandDoorCloseOutward10%.sh
sh train_hands_offline_ShadowHandCatchOver2Underarm10%.sh
sh train_hands_offline_ShadowHandDoorOpenInward10%.sh

sh train_hands_offline_ShadowHandDoorCloseOutward1%.sh
sh train_hands_offline_ShadowHandCatchOver2Underarm1%.sh
sh train_hands_offline_ShadowHandDoorOpenInward1%.sh


tensorboard --logdir="./logs"

IP地址：39.105.194.84
用户名：39.105.194.84
密码：147258369?Jiang

gym==0.12.4


python collect_demo.py \
    --cuda --env_id "Hopper-v3" \
    --weight weights/Hopper-v3.pth \
    --buffer_size 1000000 --std 0.01 --p_rand 0.0 --seed 0


python train_imitation.py \
    --algo gail --cuda --env_id Hopper-v3 \
    --buffer buffers/Hopper-v3/size1000000_std0.01_prand0.0.pth \
    --num_steps 100000000 --eval_interval 5000 --rollout_length 50000 --seed 0

pip install tensorboard==2.9.0

sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail.sh
sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_notWarmup_notFixBatch.sh
sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch.sh

sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_top50%.sh
sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_top10%.sh

sh train_hands_gail_ShadowHandCatchOver2Underarm_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch.sh
sh train_hands_gail_ShadowHandDoorCloseOutward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch.sh

sh train_hands_gail_ShadowHandDoorCloseOutward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_addActNoise.sh
sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_discUseDec.sh

sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_discUseDecDim16.sh
sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_discUseDecDim64.sh


sh train_hands_gail_ShadowHandCatchOver2Underarm_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_addActNoise1.sh
sh train_hands_gail_ShadowHandCatchOver2Underarm_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_addActNoise2.sh
sh train_hands_gail_ShadowHandCatchOver2Underarm_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_addActNoise4.sh
sh train_hands_gail_ShadowHandCatchOver2Underarm_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_addActNoise8.sh

sh train_hands_gail_ShadowHandDoorCloseOutward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_useMatData.sh
sh train_hands_gail_ShadowHandCatchOver2Underarm_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_useMatData.sh
sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_useMatData.sh

sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_discUseDecDim32_discShareValue.sh

sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_matUseHis.sh


sh train_hands_gail_ShadowHandDoorOpenInward_ppo20_plr1e-4_dlr5e-6_newDisc_notLoadEncoder_xavierInit_useWail_useMultiBatch_matUseHisCatNowLen10.sh






srun -c 32 -p inspur -x inspur-gpu-11,inspur-gpu-12,inspur-gpu-13 --gres=gpu:1 --pty bash
srun -c 32 --gres=gpu:1 -x dell-gpu-11,dell-gpu-23,dell-gpu-27 -p dell --pty bash
srun -c 32 --gres=gpu:1 -p sugon --pty bash
srun -c 32 -p dell --pty bash

source /home/LAB/anaconda3/bin/activate language_condition_MAT
source /home/LAB/anaconda3/bin/activate language_condition_MAT-A100
source ~/.profile

g++ -fopenmp Exe1_matmul.cpp -o Exe1_matmul
g++ -fopenmp Exe2_calSin.cpp -o Exe2_calSin
g++ -fopenmp Exe2_new.cpp -o Exe2_new

pip install torch==1.11.0+cu113 -f  https://download.pytorch.org/whl/cu111/torch_stable.html

nvidia-smi
1.11.0+cu113
1.10.2+cu102










sh train_smac_6h_vs_8z.sh
sh train_smac_2c_vs_64zg.sh
sh train_smac_3s5z.sh

sh train_smac_3s5z_vs_3s6z.sh
sh train_smac_1c3s5z.sh


