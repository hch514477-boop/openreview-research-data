Compute Gradient 
```sh
bash run_grad_compute.sh
```
Overview of the arguments in the bash file:  
- `--model`: The identifier or the path for the LLaMA model.
- `--llama_version`: Version of Llama model using (for LLaMA-1 use 1 and for LLaMA-2 use 2)

For Pruning the model using GBLM-Pruner:
```sh
bash run_gblm_prune.sh
```
Overview of the arguments in the bash file:  
- `--model`: The identifier or the path for the LLaMA model.
- `--gradient_path`: Path to the pre-computed gradient 
