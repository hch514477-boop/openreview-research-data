# Amortized Bayesian Inference with Hybrid Expert-in-the-Loop and Learnable Summary Statistics

This repository contains the code for running the three experiments from the paper:
1. Gaussian toy model
2. 15 joint models of neural and behavioral data
3. Lotka-Volterra dynamic model

The code requires **TensorFlow** and depends on the **BayesFlow** library for amortized Bayesian inference. However, it also adds some custom architectures to the library, included in this repository.

Note: Nwetwork checkpoints are not included due to file size limitations. However, none of the experiments requires high-end hardware and most networks can be easily trained on a single desktop PC.