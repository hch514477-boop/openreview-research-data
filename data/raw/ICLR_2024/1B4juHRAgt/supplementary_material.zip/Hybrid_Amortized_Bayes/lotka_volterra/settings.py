MODES = [
    ('expert', 'none'),
    ('learner', 'transformer'),
    ('learner', 'sequence'),
    ('direct_hybrid', 'transformer'),
    ('direct_hybrid', 'sequence'),
    ('mmd_hybrid', 'transformer'),
    ('mmd_hybrid', 'sequence'),
    ('generative_hybrid', 'transformer'),
    ('generative_hybrid', 'sequence')
]

EMBEDDING_SETTINGS = {
    'non_linear': True,
    'non_linear_kwargs': dict(
        hidden_dims=[256, 128],
        activation='relu',
        dropout=0.05
    ),
}
