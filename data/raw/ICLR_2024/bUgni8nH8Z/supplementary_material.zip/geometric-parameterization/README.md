# Neural Characteristic Activation Value Analysis for Improved ReLU Network Feature Learning (Geometric Parameterization)

This is a TensorFlow 2 Implementation of `Geometric Parameterization`, proposed in the paper *Neural Characteristic Activation Value Analysis for Improved ReLU Network Feature Learning*. Please read our submitted manuscript for detailed descriptions of the proposed neural characteristic value anaylsis and  geometric parameterization.

All scripts and notebooks have been tested with `python==3.8.12` and `tensorflow==2.8.0`.

The three illustrative experiments can be run using the notebooks `./2d_perturbation/2d_perturbation.ipynb`, `./1d_levy/1d_levy.ipynb`, and `./2d_banana/2d_banana.ipynb`.

The UCI regression experiments can be run using the scirpt `./uci_regression/uci_regression.py`.

The ImageNet32 experiment can be run by frist downloading the ImageNet32 dataset from the ImageNet official website then using the script `./imagenet32/imagenet32.py`.

The ImageNet2012 experiment  can be run by frist downloading the ImageNet data by frist downloading the ImageNet2012 dataset from the ImageNet official website and preprocessing the data with `./imagenet2012/preprocess_dataset.py` then using the script `./imagenet2012/imagenet2012.py`.
