To run experiments, simply run the command "python run_test.py".

By default, the medium-hopper case will be run.

To edit parameter values or the test case, edit the values in run_test.py

included are medium and med-expert quality extrinsic policies. To select an extrinsic policy, edit the "c_name" parameter. For example, "med_hopper", "med_expert_hopper", "med_walker2d", etc.