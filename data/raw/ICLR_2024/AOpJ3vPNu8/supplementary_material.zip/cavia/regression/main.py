import arguments
import cavia
import maml
import datetime
import wandb

if __name__ == '__main__':

    current_time = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    wandb.init(project='Sine Regression')
    wandb.run.name = current_time
    wandb.run.save()

    args = arguments.parse_args()

    wandb.config.update(args)

    if args.algo == 'maml':
        logger = maml.run(args, log_interval=100, rerun=True)
    elif args.algo in ['cavia', 'pn_cavia', 'cn_cavia']:
        logger = cavia.run(args, log_interval=100, rerun=True)
    else:
        raise NotImplementedError