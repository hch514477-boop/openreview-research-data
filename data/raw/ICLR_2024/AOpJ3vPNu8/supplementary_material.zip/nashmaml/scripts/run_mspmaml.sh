#!/bin/bash

for k_val in 5; do
    for ve_steps in 1; do
        for algo in mspmaml; do
            for norm in 2 1 3; do
                for alpha in 0.1 0.3 0.5 0.7 0.9; do
                    # create the experiment ID
                    exp_id=step_$ve_steps/K_$k_val/norm_$norm/alpha_$alpha

                    python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 0 --exp_id ${exp_id}/seed_0 &
                    python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 1 --exp_id ${exp_id}/seed_1 &
                    python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 2 --exp_id ${exp_id}/seed_2 &
                    wait
                done
            done
        done
    done
done

for k_val in 5; do
    for ve_steps in 5; do
        for algo in mspmaml; do
            for norm in 2 1 3; do
                for alpha in 0.1 0.3 0.5 0.7 0.9; do
                    # create the experiment ID
                    exp_id=step_$ve_steps/K_$k_val/norm_$norm/alpha_$alpha

                    python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 0 --exp_id ${exp_id}/seed_0 &
                    python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 1 --exp_id ${exp_id}/seed_1 &
                    python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 2 --exp_id ${exp_id}/seed_2 &
                    wait
                done
            done
        done
    done
done