#!/bin/bash

# for k_val in 5; do
#     for ve_steps in 1; do
#         for algo in cmaml; do
#             for radius in 0.5; do
#                 # create the experiment ID
#                 exp_id=step_$ve_steps/K_$k_val/radius_${radius}
#                 python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 0 --exp_id ${exp_id}/seed_0 &
#                 python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 1 --exp_id ${exp_id}/seed_1 &
#                 python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 2 --exp_id ${exp_id}/seed_2 &
#                 wait
#             done
#         done
#     done
# done
task_dist=bimodal

for k_val in 5; do
    for ve_steps in 5; do
        for algo in cmaml; do
            # for radius in 0.25 0.5 0.75 1.0; do
            for radius in 0.5; do
                # create the experiment ID
                exp_id=step_$ve_steps/K_$k_val/radius_${radius}
                python main.py --task_dist $task_dist --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 0 --exp_id ${exp_id}/seed_0 &
                python main.py --task_dist $task_dist --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 1 --exp_id ${exp_id}/seed_1 &
                python main.py --task_dist $task_dist --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 2 --exp_id ${exp_id}/seed_2 &
                wait
            done
        done
    done
done

# for k_val in 5; do
#     for ve_steps in 1; do
#         for algo in cmaml; do
#             for radius in 0.25 0.75 1.0; do
#                 # create the experiment ID
#                 exp_id=step_$ve_steps/K_$k_val/radius_${radius}
#                 python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 0 --exp_id ${exp_id}/seed_0 &
#                 python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 1 --exp_id ${exp_id}/seed_1 &
#                 python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 2 --exp_id ${exp_id}/seed_2 &
#                 wait
#             done
#         done
#     done
# done

# for k_val in 5; do
#     for ve_steps in 5; do
#         for algo in cmaml; do
#             for radius in 0.25 0.75 1.0; do
#                 # create the experiment ID
#                 exp_id=step_$ve_steps/K_$k_val/radius_${radius}
#                 python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 0 --exp_id ${exp_id}/seed_0 &
#                 python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 1 --exp_id ${exp_id}/seed_1 &
#                 python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --radius $radius --seed 2 --exp_id ${exp_id}/seed_2 &
#                 wait
#             done
#         done
#     done
# done
