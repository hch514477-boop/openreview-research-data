#!/bin/bash

# for k_val in 5; do
#     for ve_steps in 1; do
#         for algo in apmaml; do
#             for norm in 2 1 3; do
#                 for alpha in 0.04 0.0769 0.2 0.4898; do
#                     # create the experiment ID
#                     exp_id=step_$ve_steps/K_$k_val/norm_$norm/alpha_$alpha

#                     python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 0 --exp_id ${exp_id}/seed_0 &
#                     python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 1 --exp_id ${exp_id}/seed_1 &
#                     python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 2 --exp_id ${exp_id}/seed_2 &
#                     wait
#                 done
#             done
#         done
#     done
# done

for k_val in 5; do
    for ve_steps in 5; do
        for algo in apmaml; do
            for norm in 2; do
                # for lamb in 0.005 0.01 0.02; do
                for lamb in 0.01; do
                    # create the experiment ID
                    exp_id=step_$ve_steps/K_$k_val/norm_$norm/alpha_$alpha

                    python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --lamb $lamb --seed 0 --exp_id ${exp_id}/seed_0 &
                    python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --lamb $lamb --seed 1 --exp_id ${exp_id}/seed_1 &
                    python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --lamb $lamb --seed 2 --exp_id ${exp_id}/seed_2 &
                    wait
                done
            done
        done
    done
done

# for k_val in 5; do
#     for ve_steps in 5; do
#         for algo in apmaml; do
#             for norm in 1 3; do
#                 for alpha in 0.04 0.0769 0.2 0.4898; do
#                     # create the experiment ID
#                     exp_id=step_$ve_steps/K_$k_val/norm_$norm/alpha_$alpha

#                     python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 0 --exp_id ${exp_id}/seed_0 &
#                     python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 1 --exp_id ${exp_id}/seed_1 &
#                     python main.py --algo_name $algo --num_ve_iters $ve_steps --K $k_val --p_norm $norm --alpha $alpha --seed 2 --exp_id ${exp_id}/seed_2 &
#                     wait
#                 done
#             done
#         done
#     done
# done
