# MAML

### Installation
- pyyaml==6.0
- torch==1.12.1

## Scripts to run experiments at /scripts directory
At main_ver directory, call run script by

`bash scripts/run_maml.sh`

`bash scripts/run_apmaml.sh`

`bash scripts/run_cmaml.sh`

`bash scripts/run_mspmaml.sh`

`bash scripts/run_spmaml.sh`

---

### apmaml : Aggregated penalty maml
<!--
$||\theta-\alpha\phi_i - (1-\alpha)/(M-1)\sum(\phi_j)||_p$
-->
$+\lambda ||\theta-(\phi_i + \sum(\phi_j))/M||_2$
---

### cmaml : Constrained maml

---

### spmaml : Separated penalty maml 

$\alpha||\theta-\phi_i||_p+(1-\alpha)/(M-1){\sum}_j{||\phi_i-\phi_j||_p}$

---

### mspmaml : Meta Separated penalty maml (theta penalty만 분리) 

$\alpha||\theta-\phi_i||_p+(1-\alpha)||\phi_i-avg(\phi_j)||_p$

---
Experiments with the variation with coefficient($\alpha$) and 

$p$-norm will be executed in each script.

## Single experiment Running Code
`python main.py --task_name <task_name> --algo_name <algo_name> --exp_id <exp_id>`

### Ex : For the Aggregated_Penalty_MAML (Regularization with parameter average)
`python main.py --task_name="sine" --algo_name="apmaml" --exp_id <exp_id>`
