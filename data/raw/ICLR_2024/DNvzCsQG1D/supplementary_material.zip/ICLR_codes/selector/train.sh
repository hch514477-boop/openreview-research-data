#!/bin/bash

python train.py --selector_type multimodalmlp --feat_size 6 --layer_num 2 --average 1 --nhead 4 --residual 0 --lr 0.01 --dimension 32 --epoch 200