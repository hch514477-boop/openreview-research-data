#!/bin/bash

python train.py --selector_type totalmlp_att --feat_size 6 --layer_num 2 --average 1 --nhead 4 --residual 0 --epoch 20
