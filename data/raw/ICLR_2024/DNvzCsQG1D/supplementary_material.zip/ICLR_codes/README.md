# InstructionGPT-4
## Prepare MiniGPT-4 Environment
```bash
git clone https://github.com/Vision-CAIR/MiniGPT-4.git
```
Follow this [doc](https://github.com/Vision-CAIR/MiniGPT-4).

You also need to replace '/path/to' with your own path.
## Computing Indicators

### CLIP Score, Reward Score, Length Score, GPT Score
```bash
cd cc_sbu_align_test
python full_score.py
```
### Multimodal Features
```bash
cd selector
python utils_image.py
python utils_text.py
python get_all_image_features.py
python get_all_text_features.py
```

## Computing Genuine Quality Labels
### Split into 30 subsets
```bash
cd cluster/kmeans++
```
```bash
python kmeans_pp.py

python average.py

python image_show.py

python split.py

python image2cap.py
```
Follow this [doc](https://github.com/OpenGVLab/Multi-Modality-Arena) for evaluation.
## Data Selector
### Training
```bash
bash train_att.sh
```

### Testing
```bash
bash eval_clus.sh
```
