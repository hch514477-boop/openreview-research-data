function [nmse,rMSE_t] = eval_TMTL_nmse_progress_2 (Y, X, W, A, B, C, b, R, delta, CL)

time_points = length(X);
rMSE_t = zeros(time_points,1);

nmse = 0;

[S, T, d] = size(X{1});

H1=zeros(S, T);

for i = 1: S
    for j = 1: T
        if(j > i)
            H1(i, j) = 1;
        end
    end
end

total_sample = 0;
for i = 3 : time_points
    W_task = reshape(W(:,i), [S, T]);
    A_task = reshape(A(:,i), [S, R]);
    B_task = reshape(B(:,i), [T, R]);
    b_task = b(1,i);
    CL_task = reshape(CL(:,i), [S, T]);
    [TestingSize, ~] = size(Y{i});
    y_pred = squeeze(sum(double(tenmat(X{i} .* repmat(reshape((delta*(CL_task)+(1-delta)*(A_task*B_task')) .* (W_task.*H1), [S, T, 1]), [1, 1, TestingSize]), 3)), 2))+b_task;
    
    rMSE_t(i) = sum((y_pred - Y{i}).^2);                                  
    Yt_variance = var(Y{i});                                              
    nmse = nmse + (rMSE_t(i) / Yt_variance);                              
    rMSE_t(i) = sqrt(rMSE_t(i)/length(y_pred));                          
    total_sample = total_sample + length(y_pred);
end
nmse = nmse/total_sample;
end
