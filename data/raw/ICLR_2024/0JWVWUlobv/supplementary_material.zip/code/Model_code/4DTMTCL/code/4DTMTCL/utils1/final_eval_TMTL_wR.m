function [wR,Placeholder] = final_eval_TMTL_wR(Y, X, y_pred)

time_points = length(X);
wR = 0;
total_sample = 0;
Placeholder = zeros(time_points,1);


for i = 3 : time_points
    
    corr = corrcoef(Y{i},y_pred{i});
    wR = wR + corr(1,2) * length(y_pred{i});
    total_sample = total_sample + length(y_pred{i});
end
wR = wR / total_sample;
end



