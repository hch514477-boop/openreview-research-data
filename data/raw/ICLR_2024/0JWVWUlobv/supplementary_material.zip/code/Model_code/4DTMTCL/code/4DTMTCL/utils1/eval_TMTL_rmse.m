function rmse = eval_TMTL_rmse (Y, X, W, A, B, C, b, R)
%% FUNCTION eval_MTL_mse
%   computation of root mean squared error given a specific model.
%   the value is the lower the better.
%

time_points = length(X);
rmse = 0;

[S, T, ~] = size(X{1});

H1=zeros(S, T);

for i = 1: S
    for j = 1: T
        if(j > i)
            H1(i, j) = 1;
        end
    end
end

for i = 3 : time_points
    
    W_task = reshape(W(:,i), [S, T]);
    A_task = reshape(A(:,i), [S, R]);
    B_task = reshape(B(:,i), [T, R]);
    b_task = b(1,i);
    [TestingSize, ~] = size(Y{i});
    y_pred = squeeze(sum(double(tenmat(X{i} .* repmat(reshape((A_task*B_task') .* (W_task.*H1), [S, T, 1]), [1, 1, TestingSize]), 3)), 2))+b_task;
    rmse = rmse + sqrt(mean((y_pred - Y{i}).^2));
    
end


end
