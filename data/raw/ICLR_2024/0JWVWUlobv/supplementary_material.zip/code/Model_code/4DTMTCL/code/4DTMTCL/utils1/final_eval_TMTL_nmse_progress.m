function [nmse,rMSE_t] = final_eval_TMTL_nmse_progress (Y, X, y_pred)

time_points = length(X);
rMSE_t = zeros(time_points,1);

nmse = 0;

total_sample = 0;
for i = 3 : time_points
    
    
    rMSE_t(i) = sum((y_pred{i} - Y{i}).^2);                                 
    Yt_variance = var(Y{i});                                             
    nmse = nmse + (rMSE_t(i) / Yt_variance);                            
    rMSE_t(i) = sqrt(rMSE_t(i)/length(y_pred{i}));                          
    total_sample = total_sample + length(y_pred{i});
end
nmse = nmse/total_sample;
end
