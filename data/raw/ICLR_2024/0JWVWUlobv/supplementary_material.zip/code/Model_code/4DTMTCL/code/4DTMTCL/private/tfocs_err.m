function err = tfocs_err() 
%  tfocs_err : TFOCS error measurement
%
%   
% 
  global subprob_optim
  
  err = subprob_optim;
  