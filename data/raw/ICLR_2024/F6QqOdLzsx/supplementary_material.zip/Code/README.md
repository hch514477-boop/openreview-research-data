# ADVANCING TEST-TIME ADAPTATION FOR ACOUSTIC FOUNDATION MODELS IN OPEN-WORLD SHIFTS

This repository is based on [Tent](https://github.com/DequanWang/tent), [SAR](https://github.com/mr-eggplant/SAR/), and [SUTA](https://github.com/DanielLin94144/Test-time-adaptation-ASR-SUTA).

The folder `./Exp1` contains experiments on LS-C, L2-Arctic, DSing and Hansen.

The folder `./Exp2` contains experiments on LS-P.
