# Exp1

### Installation 
```
pip install -r requirements.txt
```
### Data 
- [Librispeech](https://www.openslr.org/12)/
- [L2-Arctic](https://psi.engr.tamu.edu/l2-arctic-corpus/)/
- [DSing](https://github.com/groadabike/Kaldi-Dsing-task)/


### Usage


Run our experiments using scripts from scripts / scripts_L2 / scripts_sing on different datasets.





