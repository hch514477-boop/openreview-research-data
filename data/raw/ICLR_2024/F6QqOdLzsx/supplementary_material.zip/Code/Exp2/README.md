# Exp2

### Installation 
```
pip install -r requirements.txt
```
### Data 
- [Librispeech](https://www.openslr.org/12)/
- [MS-SNSD](https://github.com/microsoft/MS-SNSD)

### Usage

Run our experiments using scripts from scripts_exp2 on LS-P datasets.
