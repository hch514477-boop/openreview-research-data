## Environments
pytorch >=1.12.1
cuda>=11.3
## Installation
To build up the environment on linux, you can run:
```
pip install -r requirements.txt
```

## Evaluation
To evaluate LMD-ViT, you can run:

```
CUDA_VISIBLE_DEVICES=0 python test.py
```

