#!/usr/bin/bash

#CKPT='geom/ckpt/pretrained_models_ckpt_zero-sho_classification_pointbert_ULIP-2.pt'
CKPT='geom/ckpt/pretrained_models-pointnext_pretrained-ULIP_2-pointnext_objaverse.pt'

#ULIP_MODEL='ULIP_PointBERT'
ULIP_MODEL='ULIP_PN_NEXT'

FOLD=0

EXEC='main.py --cfd_model=GraphSAGE --cfd_mesh --ulip_model='$ULIP_MODEL' --ulip_ckpt='$CKPT' --fold_id='$FOLD
#EXEC='main.py --cfd_model=GraphSAGE --cfd_mesh'

echo $EXEC
/home/my_usrname/anaconda3/envs/my_env/bin/python $EXEC
