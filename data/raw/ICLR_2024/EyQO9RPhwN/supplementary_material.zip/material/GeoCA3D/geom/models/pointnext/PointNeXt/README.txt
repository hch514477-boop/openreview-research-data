#NOTE: './geom/models/pointnext/PointNeXt' is the offical repository of PointNeXt and is public on Github. 
