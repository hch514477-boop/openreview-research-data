ULIP-2 pre-trained checkpoints of the Point-BERT and the PointNeXt are available from its offical implementation on Github.
