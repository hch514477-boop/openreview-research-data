# GeoCA3D

`conda create -n my_env python=3.9`

`conda activate my_env`

`pip install torch==1.11.0+cu113 torchvision==0.12.0+cu113 torchaudio==0.11.0 --extra-index-url https://download.pytorch.org/whl/cu113`

`pip install torch_geometirc==2.0.4`

install whls, including torch_scatter, torch_sparse, torch_cluster, torch_spline_conv

`pip install whls/*`

`pip install -r requirements.txt`

`pip install vtk==9.2.6`

`pip install einops==0.6.1`

`cd ./geom/models/pointnext/PointNeXt`

`bash update.sh`

`bash install.sh`

`pip install --upgrade https://github.com/unlimblue/KNN_CUDA/releases/download/0.2/KNN_CUDA-0.2-py3-none-any.whl`

`pip install ninja`

pickler.dump might fail: in serialization.py, `import dill as pickle`
