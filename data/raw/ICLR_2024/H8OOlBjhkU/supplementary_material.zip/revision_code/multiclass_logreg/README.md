# Multiclass Logistic Regression

- To generate the curves in the paper, run the following code, with the appropriate value of `k` and `D` (below is an example for `k=150` and `D=0.5`): 

    - For the comparison of the algorithms in the mixed constraints setting: 
    `python generate_tsp_curves.py 0.5 150; python plot_tsp_curves.py 0.5 150`

    - For the comparison of the algorithms in the zeroth-order setting without extra constraints: 
    `python generate_zo_curves.py 150; python plot_zo_curves.py 150`