# Index tracking

To generate the curves, run each of the notebooks from this folder. When executing them for the first time, set the flag `download=True` in the loading utilities at the beginning of the notebook, for instance, set:

`dataset = load_sp500(download=True)`
`groups = load_groups(download=True)`

This will download the dataset from the Web using `beautifulsoup` and `yfinance`, which may take about an hour. Then for the next runs you can set `download=False`.