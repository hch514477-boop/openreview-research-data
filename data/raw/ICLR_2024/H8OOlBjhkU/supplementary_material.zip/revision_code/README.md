# Optimization Over Sparse Restricted Convex Sets via Two-Step Projection

To reproduce the figures in the paper, install the corresponding conda environments (through `conda env create -f name_of_the_env.yml`, or else by installing manually the corresponding packages inside the `.yml` file), and activate it (with `conda activate name_of_the_env.yml`). Below are the corresponding necessary environment files for each folder: 

- `adversarial_attacks`: `adv.yml`
- `index_tracking` and `multiclass_logreg`: `num.yml`

Then, navigate to the following folder and execute the code/notebooks, according to the corresponding `README.md` file.