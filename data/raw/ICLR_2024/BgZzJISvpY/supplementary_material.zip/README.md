# Reinforcement Learning with Extreme Minimum Distribution 

PyTorch implementation of Reinforcement Learning with Extreme Minimum Distribution (EMD).

Method is tested on [MuJoCo](http://www.mujoco.org/) continuous control tasks in [OpenAI gym](https://github.com/openai/gym).

### Usage
Hyper-parameters can be modified with different arguments to main.py.
The environment and random number seed can be modified in run.py.

The paper results can be reproduced by running: 
```
python run.py
```
What needs to be referenced in the code will be flagged when we make it public.