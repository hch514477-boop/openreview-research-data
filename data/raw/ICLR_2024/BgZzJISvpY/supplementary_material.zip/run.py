import os

env_name = ["HalfCheetah-v3"]

'''alternative = ["HalfCheetah-v3", "Humanoid-v3", "Walker2d-v3", "Ant-v3", "Hopper-v3"]'''

seeds = [1, 2, 3, 4, 5]

# python main.py --seed 1 --env "HalfCheetah-v3"

for i in seeds:
    for env in env_name:
        os.system(
            "python main.py \
            --seed %d \
            --env \"%s\"" % (i, env))
