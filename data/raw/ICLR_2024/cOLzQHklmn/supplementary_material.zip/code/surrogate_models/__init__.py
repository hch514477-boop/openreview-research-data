from .FeatureWeighting import FeatureWeighting

def create(surrogate_type, temperature = 1.):

    surrogate_type = surrogate_type.split('+')
    
    if surrogate_type[0] == 'FeatureWeighting':
        surrogate = FeatureWeighting(base_model=surrogate_type[1], temperature = temperature)

    else:
        raise Exception('surrogate_type not implemented')


    return surrogate