#PhyloGFN Bayesian Memory Efficient Implementation

This is a memory efficient implementation of PhylGFN-Bayesian. The repository is used to train models for the repeated experiments and ablation study.

To train PhyloGFN with 32millions examples (PhyloGFN Full)

```buildoutcfg
python train.py src/configs/benchmark_dna_cfgs/common_scripts_normal/cfg_0.001binsize_50bins_temperature_anneal.yaml dataset/benchmark_datasets/DS1.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_scripts_normal/cfg_0.001binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS2.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_scripts_normal/cfg_0.004binsize_50bins_temperature_anneal.yaml dataset/benchmark_datasets/DS3.pickle  OUTPUT_PATH;
python train.py src/configs/benchmark_dna_cfgs/common_scripts_normal/cfg_0.002binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS4.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_scripts_normal/cfg_0.002binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS5.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_scripts_normal/cfg_0.001binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS6.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_scripts_normal/cfg_0.001binsize_200bins_temperature_anneal.yaml dataset/benchmark_datasets/DS7.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_scripts_normal/cfg_0.001binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS8.pickle  OUTPUT_PATH
```


To train PhyloGFN with 12.8millions examples (PhyloGFN Short)

```buildoutcfg
python train.py src/configs/benchmark_dna_cfgs/common_script_short/cfg_0.001binsize_50bins_temperature_anneal.yaml dataset/benchmark_datasets/DS1.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_script_short/cfg_0.001binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS2.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_script_short/cfg_0.004binsize_50bins_temperature_anneal.yaml dataset/benchmark_datasets/DS3.pickle  OUTPUT_PATH;
python train.py src/configs/benchmark_dna_cfgs/common_script_short/cfg_0.002binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS4.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_script_short/cfg_0.002binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS5.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_script_short/cfg_0.001binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS6.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_script_short/cfg_0.001binsize_200bins_temperature_anneal.yaml dataset/benchmark_datasets/DS7.pickle  OUTPUT_PATH
python train.py src/configs/benchmark_dna_cfgs/common_script_short/cfg_0.001binsize_100bins_temperature_anneal.yaml dataset/benchmark_datasets/DS8.pickle  OUTPUT_PATH
```

Training configurations for ablation study are in folder `src/configs/benchmark_dna_cfgs/ds1_ablation_study`
