from src.env.edges_env.categorical import EdgeEnvCategorical


def build_edge_env(cfg):
    edges_cfg = cfg.GFN.MODEL.EDGES_MODELING
    dist = edges_cfg.DISTRIBUTION
    assert dist in ['CATEGORICAL']
    edge_env = EdgeEnvCategorical(edges_cfg.CATEGORICAL)
    return edge_env
