#PhyloGFN

Code repository for PhyloGFN: Phylogenetic Inference with Generative Flow Netowrks


## Dataset
Dataasets DS1-DS8 are in the folder `benchmark_datasets`


## Train model 
Configurations files are in the folder `src/configs`. See `run.py` for training parameters. Below list example to train PhyloGFN-Bayesian script for DS1 

```buildoutcfg
CUDA_VISIBLE_DEVICES=0,1 python run.py src/configs/benchmark_datasets/bayesian/ds1.yaml dataset/benchmark_datasets/DS1.pickle test --nb_device 2 --acc_gen_sampling --random_sampling_batch_size 64
```
For memory efficient training, please refer to `phylo_gfn_bayesian_memoryefficient` in the supplementary data folder.

## Inference 

To perform evaluation on parsimony model, use `parsimony_eval.py` to plot sampling probability of best trees. 

To assess MLL or compare log sampling densitity vs log posterior density, run notebook `phylogfn_bayesian_result.ipynb`

To test conditional GFN for various temperature, see notebook `ds1_conditional.ipynb`


