#!/bin/bash
    python train.py --model resnet --depth 10 --widen_factor 1 --dataset cifar100 --num_clients 100 --schedulingsize 10 --comm_rounds 500 --learning_rate 0.1 --lr_decay 0.991 --alpha 0.1 --th_coeff 0.0003 --weight_decay 0.0001 --local_epoch 2
