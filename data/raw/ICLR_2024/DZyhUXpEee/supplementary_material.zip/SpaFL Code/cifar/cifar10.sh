#!/bin/bash
python train.py --model conv4 --dataset cifar10 --batch_size 16 --learning_rate 0.01 --alpha 0.1 --th_coeff 0.000075 --local_epoch 3