#!/bin/bash
python train.py --model Lenet5 --dataset fmnist --learning_rate 0.001 --th_coeff 0.002