import os
import random
import sys

# comment this out if you are using the pip package
sys.path.append('../')

import torch
import matplotlib.pyplot as plt
from utils import CLASS_CUB200, CLASS_NAME_FOR_PROMPT

# Dataset 1/4: generate images based on the label. Presumably 200 images per class.
data_dir = 'data/gen2000'
os.makedirs(data_dir, exist_ok=True)
from diffusers import StableDiffusionPipeline
from dataset_interface.templates import imagenet_templates_small
pipe = StableDiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5", torch_dtype=torch.float16)
pipe.to('cuda')
classes = range(200)
for i in classes:
    print('Generating image for {}-th class: {}'.format(i+1, CLASS_CUB200[i]))
    os.makedirs('data/gen2000/'+CLASS_CUB200[i], exist_ok=True)
    img_idx = 0
    while img_idx < 2000:
        prompt = random.choice(imagenet_templates_small).format(CLASS_NAME_FOR_PROMPT[i])
        output = pipe(prompt, num_inference_steps=50, num_images_per_prompt=8,  guidance_scale=3.5)
        images = output.images
        nsfw = output.nsfw_content_detected
        for j in range(8):
            if nsfw[j] is False:
                images[j].save('data/gen2000/{}/sample{}.png'.format(CLASS_CUB200[i], img_idx+1))
                img_idx += 1


