import os


# count file number

DTD_CLASS_NAMES = ['banded', 'blotchy', 'braided', 'bubbly', 'bumpy', 'chequered', 'cobwebbed', 'cracked',
                   'crosshatched', 'crystalline', 'dotted', 'fibrous', 'flecked', 'freckled', 'frilly', 'gauzy', 'grid',
                   'grooved', 'honeycombed', 'interlaced', 'knitted', 'lacelike', 'lined', 'marbled', 'matted', 'meshed',
                   'paisley', 'perforated', 'pitted', 'pleated', 'polka-dotted', 'porous', 'potholed', 'scaly', 'smeared',
                   'spiralled', 'sprinkled', 'stained', 'stratified', 'striped', 'studded', 'swirly', 'veined', 'waffled',
                   'woven', 'wrinkled', 'zigzagged']


# make few-shot dataset
# import shutil
# os.mkdir('data/fs')
# for c in DTD_CLASS_NAMES:
#     os.mkdir('data/fs/'+c)
#     # copy the first image to fs
#     source_file = os.listdir('data/dtd/train/'+c)[0]
#     shutil.copy('data/dtd/train/{}/{}'.format(c, source_file), 'data/fs/'+c)


