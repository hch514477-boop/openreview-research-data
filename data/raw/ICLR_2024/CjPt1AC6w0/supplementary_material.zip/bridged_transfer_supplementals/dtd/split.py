import os
import shutil
from pathlib import Path
file_type = ['train', 'val', 'test']
base_path = ''  #标签train等文件的父目录
images = 'images/'        #总的图像文件路径


idx = 0
for tp in file_type:
    # use partition 1
        file_idx = 1
        annotation_path = 'data/dtd/labels/{}{}.txt'.format(tp, file_idx)
        # print(annotation_path)

        for line in open(annotation_path):
            file_name = line.strip()
            class_name = line.split('/')[0]
            print(file_name)

            # check if this directory has benn created before
            dir_type = 'test' if tp == 'test' else 'train'
            if not os.path.exists('data/dtd/{}/{}'.format(dir_type, class_name)):
                os.mkdir('data/dtd/{}/{}'.format(dir_type, class_name))

            shutil.move('data/dtd/images/'+file_name,
                        'data/dtd/{}/{}'.format(dir_type, class_name))
