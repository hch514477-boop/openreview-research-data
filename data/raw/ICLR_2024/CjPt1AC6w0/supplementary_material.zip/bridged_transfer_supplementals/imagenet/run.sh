export MODEL_NAME="runwayml/stable-diffusion-v1-5"
#export DATA_DIR="/gpfs/gibbs/project/panda/shared/imagenet_2012/train"
#
#accelerate launch dataset_inversion.py \
#  --pretrained_model_name_or_path=$MODEL_NAME \
#  --train_data_dir=$DATA_DIR \
#  --learnable_property="style" \
#  --placeholder_token="<imagenet>" --initializer_token="image" \
#  --resolution=512 \
#  --train_batch_size=32 \
#  --gradient_accumulation_steps=1 \
#  --max_train_steps=50000 \
#  --lr_warmup_steps=2000 \
#  --learning_rate=5.0e-04 --scale_lr \
#  --lr_scheduler="constant" \
#  --num_vectors=20 \
#  --output_dir="dataset_inversion_imagenet" \
#  --dataloader_num_workers=8



export DATA_DIR="../dogs/data/Images"

accelerate launch coco_inversion.py \
  --mixed_precision="fp16" \
  --pretrained_model_name_or_path=$MODEL_NAME \
  --train_data_dir=$DATA_DIR \
  --learnable_property="style" \
  --placeholder_token="<coco>" --initializer_token="*" \
  --resolution=512 \
  --train_batch_size=32 \
  --gradient_accumulation_steps=1 \
  --max_train_steps=16000 \
  --lr_warmup_steps=100 \
  --learning_rate=5.0e-04 --scale_lr \
  --lr_scheduler="constant" \
  --num_vectors=10 \
  --output_dir="dataset_inversion_coco" \
  --dataloader_num_workers=8