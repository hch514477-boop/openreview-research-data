FLOWERS_LABEL_NAME = ['pink primrose', 'hard-leaved pocket orchid', 'canterbury bells', 'sweet pea', 'english marigold',
                      'tiger lily', 'moon orchid', 'bird of paradise', 'monkshood', 'globe thistle', 'snapdragon',
                      '"colts foot"', 'king protea', 'spear thistle', 'yellow iris', 'globe-flower', 'purple coneflower',
                      'peruvian lily', 'balloon flower', 'giant white arum lily', 'fire lily', 'pincushion flower',
                      'fritillary', 'red ginger', 'grape hyacinth', 'corn poppy', 'prince of wales feathers',
                      'stemless gentian', 'artichoke', 'sweet william', 'carnation', 'garden phlox', 'love in the mist',
                      'mexican aster', 'alpine sea holly', 'ruby-lipped cattleya', 'cape flower', 'great masterwort',
                      'siam tulip', 'lenten rose', 'barbeton daisy', 'daffodil', 'sword lily', 'poinsettia',
                      'bolero deep blue', 'wallflower', 'marigold', 'buttercup', 'oxeye daisy', 'common dandelion',
                      'petunia', 'wild pansy', 'primula', 'sunflower', 'pelargonium', 'bishop of llandaff', 'gaura',
                      'geranium', 'orange dahlia', 'pink-yellow dahlia?', 'cautleya spicata', 'japanese anemone',
                      'black-eyed susan', 'silverbush', 'californian poppy', 'osteospermum', 'spring crocus',
                      'bearded iris', 'windflower', 'tree poppy', 'gazania', 'azalea', 'water lily', 'rose',
                      'thorn apple', 'morning glory', 'passion flower', 'lotus', 'toad lily', 'anthurium',
                      'frangipani', 'clematis', 'hibiscus', 'columbine', 'desert-rose', 'tree mallow', 'magnolia',
                      'cyclamen', 'watercress', 'canna lily', 'hippeastrum', 'bee balm', 'ball moss', 'foxglove',
                      'bougainvillea', 'camellia', 'mallow', 'mexican petunia', 'bromelia', 'blanket flower',
                      'trumpet creeper', 'blackberry lily']


# import os
# from scipy.io import loadmat
# import shutil
#
# base_folder = 'data'
# set_ids = loadmat("data/flowers-102/setid.mat", squeeze_me=True)
# image_ids = set_ids["tstid"].tolist()
#
# labels = loadmat("data/flowers-102/imagelabels.mat", squeeze_me=True)
# image_id_to_label = dict(enumerate((labels["labels"] - 1).tolist(), 1))
#
# new_dir = 'data/flowers-102/new'
# # os.mkdir(new_dir)
# os.mkdir(new_dir + '/test')
#
# for k in image_ids:
#     v = image_id_to_label[k]
#     class_name = FLOWERS_LABEL_NAME[v]
#     if not os.path.exists(os.path.join(new_dir, 'test', class_name)):
#         os.mkdir(os.path.join(new_dir, 'test', class_name))
#     shutil.copy('data/flowers-102/jpg/'+f"image_{k:05d}.jpg", os.path.join(new_dir, 'test', class_name, f"image_{k:05d}.jpg"))
