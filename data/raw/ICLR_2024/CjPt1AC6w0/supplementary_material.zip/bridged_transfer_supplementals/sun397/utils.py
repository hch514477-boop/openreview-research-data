# from torchvision.datasets import SUN397


# dset = SUN397(root='data', download=True)
import os

CLASS_NAME_SUN397 = ['abbey', 'airplane_cabin', 'airport_terminal', 'alley', 'amphitheater', 'amusement_arcade', 'amusement_park', 'anechoic_chamber', 'apartment_building-outdoor', 'apse-indoor', 'aquarium', 'aqueduct', 'arch', 'archive', 'arrival_gate-outdoor', 'art_gallery', 'art_school', 'art_studio', 'assembly_line', 'athletic_field-outdoor', 'atrium-public', 'attic', 'auditorium', 'auto_factory', 'badlands', 'badminton_court-indoor', 'baggage_claim', 'bakery-shop', 'balcony-exterior', 'balcony-interior', 'ball_pit', 'ballroom', 'bamboo_forest', 'banquet_hall', 'bar', 'barn', 'barndoor', 'baseball_field', 'basement', 'basilica', 'basketball_court-outdoor', 'bathroom', 'batters_box', 'bayou', 'bazaar-indoor', 'bazaar-outdoor', 'beach', 'beauty_salon', 'bedroom', 'berth', 'biology_laboratory', 'bistro-indoor', 'boardwalk', 'boat_deck', 'boathouse', 'bookstore', 'booth-indoor', 'botanical_garden', 'bow_window-indoor', 'bow_window-outdoor', 'bowling_alley', 'boxing_ring', 'brewery-indoor', 'bridge', 'building_facade', 'bullring', 'burial_chamber', 'bus_interior', 'butchers_shop', 'butte', 'cabin-outdoor', 'cafeteria', 'campsite', 'campus', 'canal-natural', 'canal-urban', 'candy_store', 'canyon', 'car_interior-backseat', 'car_interior-frontseat', 'carrousel', 'casino-indoor', 'castle', 'catacomb', 'cathedral-indoor', 'cathedral-outdoor', 'cavern-indoor', 'cemetery', 'chalet', 'cheese_factory', 'chemistry_lab', 'chicken_coop-indoor', 'chicken_coop-outdoor', 'childs_room', 'church-indoor', 'church-outdoor', 'classroom', 'clean_room', 'cliff', 'cloister-indoor', 'closet', 'clothing_store', 'coast', 'cockpit', 'coffee_shop', 'computer_room', 'conference_center', 'conference_room', 'construction_site', 'control_room', 'control_tower-outdoor', 'corn_field', 'corral', 'corridor', 'cottage_garden', 'courthouse', 'courtroom', 'courtyard', 'covered_bridge-exterior', 'creek', 'crevasse', 'crosswalk', 'cubicle-office', 'dam', 'delicatessen', 'dentists_office', 'desert-sand', 'desert-vegetation', 'diner-indoor', 'diner-outdoor', 'dinette-home', 'dinette-vehicle', 'dining_car', 'dining_room', 'discotheque', 'dock', 'doorway-outdoor', 'dorm_room', 'driveway', 'driving_range-outdoor', 'drugstore', 'electrical_substation', 'elevator-door', 'elevator-interior', 'elevator_shaft', 'engine_room', 'escalator-indoor', 'excavation', 'factory-indoor', 'fairway', 'fastfood_restaurant', 'field-cultivated', 'field-wild', 'fire_escape', 'fire_station', 'firing_range-indoor', 'fishpond', 'florist_shop-indoor', 'food_court', 'forest-broadleaf', 'forest-needleleaf', 'forest_path', 'forest_road', 'formal_garden', 'fountain', 'galley', 'game_room', 'garage-indoor', 'garbage_dump', 'gas_station', 'gazebo-exterior', 'general_store-indoor', 'general_store-outdoor', 'gift_shop', 'golf_course', 'greenhouse-indoor', 'greenhouse-outdoor', 'gymnasium-indoor', 'hangar-indoor', 'hangar-outdoor', 'harbor', 'hayfield', 'heliport', 'herb_garden', 'highway', 'hill', 'home_office', 'hospital', 'hospital_room', 'hot_spring', 'hot_tub-outdoor', 'hotel-outdoor', 'hotel_room', 'house', 'hunting_lodge-outdoor', 'ice_cream_parlor', 'ice_floe', 'ice_shelf', 'ice_skating_rink-indoor', 'ice_skating_rink-outdoor', 'iceberg', 'igloo', 'industrial_area', 'inn-outdoor', 'islet', 'jacuzzi-indoor', 'jail-indoor', 'jail_cell', 'jewelry_shop', 'kasbah', 'kennel-indoor', 'kennel-outdoor', 'kindergarden_classroom', 'kitchen', 'kitchenette', 'labyrinth-outdoor', 'lake-natural', 'landfill', 'landing_deck', 'laundromat', 'lecture_room', 'library-indoor', 'library-outdoor', 'lido_deck-outdoor', 'lift_bridge', 'lighthouse', 'limousine_interior', 'living_room', 'lobby', 'lock_chamber', 'locker_room', 'mansion', 'manufactured_home', 'market-indoor', 'market-outdoor', 'marsh', 'martial_arts_gym', 'mausoleum', 'medina', 'moat-water', 'monastery-outdoor', 'mosque-indoor', 'mosque-outdoor', 'motel', 'mountain', 'mountain_snowy', 'movie_theater-indoor', 'museum-indoor', 'music_store', 'music_studio', 'nuclear_power_plant-outdoor', 'nursery', 'oast_house', 'observatory-outdoor', 'ocean', 'office', 'office_building', 'oil_refinery-outdoor', 'oilrig', 'operating_room', 'orchard', 'outhouse-outdoor', 'pagoda', 'palace', 'pantry', 'park', 'parking_garage-indoor', 'parking_garage-outdoor', 'parking_lot', 'parlor', 'pasture', 'patio', 'pavilion', 'pharmacy', 'phone_booth', 'physics_laboratory', 'picnic_area', 'pilothouse-indoor', 'planetarium-outdoor', 'playground', 'playroom', 'plaza', 'podium-indoor', 'podium-outdoor', 'pond', 'poolroom-establishment', 'poolroom-home', 'power_plant-outdoor', 'promenade_deck', 'pub-indoor', 'pulpit', 'putting_green', 'racecourse', 'raceway', 'raft', 'railroad_track', 'rainforest', 'reception', 'recreation_room', 'residential_neighborhood', 'restaurant', 'restaurant_kitchen', 'restaurant_patio', 'rice_paddy', 'riding_arena', 'river', 'rock_arch', 'rope_bridge', 'ruin', 'runway', 'sandbar', 'sandbox', 'sauna', 'schoolhouse', 'sea_cliff', 'server_room', 'shed', 'shoe_shop', 'shopfront', 'shopping_mall-indoor', 'shower', 'skatepark', 'ski_lodge', 'ski_resort', 'ski_slope', 'sky', 'skyscraper', 'slum', 'snowfield', 'squash_court', 'stable', 'stadium-baseball', 'stadium-football', 'stage-indoor', 'staircase', 'street', 'subway_interior', 'subway_station-platform', 'supermarket', 'sushi_bar', 'swamp', 'swimming_pool-indoor', 'swimming_pool-outdoor', 'synagogue-indoor', 'synagogue-outdoor', 'television_studio', 'temple-east_asia', 'temple-south_asia', 'tennis_court-indoor', 'tennis_court-outdoor', 'tent-outdoor', 'theater-indoor_procenium', 'theater-indoor_seats', 'thriftshop', 'throne_room', 'ticket_booth', 'toll_plaza', 'topiary_garden', 'tower', 'toyshop', 'track-outdoor', 'train_railway', 'train_station-platform', 'tree_farm', 'tree_house', 'trench', 'underwater-coral_reef', 'utility_room', 'valley', 'van_interior', 'vegetable_garden', 'veranda', 'veterinarians_office', 'viaduct', 'videostore', 'village', 'vineyard', 'volcano', 'volleyball_court-indoor', 'volleyball_court-outdoor', 'waiting_room', 'warehouse-indoor', 'water_tower', 'waterfall-block', 'waterfall-fan', 'waterfall-plunge', 'watering_hole', 'wave', 'wet_bar', 'wheat_field', 'wind_farm', 'windmill', 'wine_cellar-barrel_storage', 'wine_cellar-bottle_storage', 'wrestling_ring-indoor', 'yard', 'youth_hostel']

CLASS_FOR_PROMPT = [c.replace('_', ' ').replace('-', ' ') for c in CLASS_NAME_SUN397]


# data_dir = 'data/SUN397/train/'
# import shutil
# for line in open('train.txt'):
#     file = line.split('/')
#     cls = file[1]
#     if '-' in cls:
#         org_cls = cls.replace('-', '/')
#     else:
#         org_cls = cls
#     os.makedirs(data_dir + cls, exist_ok=True)
#     file = org_cls + '/' + file[2]
#     org_file = (file[0] + '/' + file).strip()
#     shutil.move('data/SUN397/' + org_file, 'data/SUN397/' + line.strip())

# data_dir = 'data/SUN397/val/'
# import shutil
# for cls in CLASS_NAME_SUN397:
#     if '-' in cls:
#         org_cls = cls.replace('-', '/')
#     else:
#         org_cls = cls
#     parent_path = org_cls[0] + '/' + org_cls
#     for file in os.listdir('data/SUN397/' + parent_path):
#         shutil.move('data/SUN397/' + parent_path + '/' + file, 'data/SUN397/val/' + cls + '/' + file)

data_dir = 'data/SUN397/val/'
import shutil
for cls in CLASS_NAME_SUN397:
    for i, file in enumerate(os.listdir('data/SUN397/val/'+cls)):
        if i > 49:
            os.remove('data/SUN397/val/' + cls + '/' + file)