from torchvision.datasets import OxfordIIITPet
import os
import shutil

# dset = OxfordIIITPet(root='data', download=False)

os.mkdir('data/fs')
for c in range(37):
    os.mkdir('data/fs/{}'.format(c))
    files = os.listdir('data/oxford-pets/train/{}'.format(c))
    # for i in range(16):
    shutil.copy(os.path.join('data/oxford-pets/train/{}'.format(c), files[0]), 'data/fs/{}'.format(c))



# file1 = open('/Users/baisefengche/Documents/GitHub/dataset-interfaces-main/pets/data/oxford-pets/annotations/test.txt', 'r')
# lines = file1.readlines()
#
# name_list = []
# for line in lines:
#     x = ''.join((x for x in line.split()[0] if not x.isdigit()))
#     x = x.replace('_', ' ')
#     name_list += [x]
#
# name_dependent_list = []
# [name_dependent_list.append(x) for x in name_list if x not in name_dependent_list]
#
# print(name_dependent_list)