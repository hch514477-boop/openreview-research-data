PETS_CLASS_NAMES=['Abyssinian ', 'american bulldog ', 'american pit bull terrier ', 'basset hound ', 'beagle ',
                  'Bengal ', 'Birman ', 'Bombay ', 'boxer ', 'British Shorthair ', 'chihuahua ', 'Egyptian Mau ',
                  'english cocker spaniel ', 'english setter ', 'german shorthaired ', 'great pyrenees ', 'havanese ',
                  'japanese chin ', 'keeshond ', 'leonberger ', 'Maine Coon ', 'miniature pinscher ', 'newfoundland ',
                  'Persian ', 'pomeranian ', 'pug ', 'Ragdoll ', 'Russian Blue ', 'saint bernard ', 'samoyed ',
                  'scottish terrier ', 'shiba inu ', 'Siamese ', 'Sphynx cat', 'staffordshire bull terrier ',
                  'wheaten terrier ', 'yorkshire terrier ']


