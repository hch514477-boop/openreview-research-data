
FGVC_AIRCRAFT_CLASSES = ['707-320', '727-200', '737-200', '737-300', '737-400', '737-500', '737-600', '737-700',
                         '737-800', '737-900', '747-100', '747-200', '747-300', '747-400', '757-200', '757-300',
                         '767-200', '767-300', '767-400', '777-200', '777-300', 'A300B4', 'A310', 'A318', 'A319',
                         'A320', 'A321', 'A330-200', 'A330-300', 'A340-200', 'A340-300', 'A340-500', 'A340-600',
                         'A380', 'ATR-42', 'ATR-72', 'An-12', 'BAE146-200', 'BAE146-300', 'BAE-125', 'Beechcraft1900',
                         'Boeing717', 'C-130', 'C-47', 'CRJ-200', 'CRJ-700', 'CRJ-900', 'Cessna172', 'Cessna208',
                         'Cessna525', 'Cessna560', 'Challenger600', 'DC-10', 'DC-3', 'DC-6', 'DC-8', 'DC-9-30',
                         'DH-82', 'DHC-1', 'DHC-6', 'DHC-8-100', 'DHC-8-300', 'DR-400', 'Dornier328', 'E-170',
                         'E-190', 'E-195', 'EMB-120', 'ERJ135', 'ERJ145', 'EmbraerLegacy600', 'EurofighterTyphoon',
                         'F-16A/B', 'F/A-18', 'Falcon2000', 'Falcon900', 'Fokker100', 'Fokker50', 'Fokker70',
                         'GlobalExpress', 'GulfstreamIV', 'GulfstreamV', 'HawkT1', 'Il-76', 'L-1011', 'MD-11',
                         'MD-80', 'MD-87', 'MD-90', 'Metroliner', 'ModelB200', 'PA-28', 'SR-20', 'Saab2000',
                         'Saab340', 'Spitfire', 'Tornado', 'Tu-134', 'Tu-154', 'Yak-42']


FGVC_AIRCRAFT_COARSE_CLASSES = ['Boeing', 'Airbus', 'ATR', 'Antonov', 'British', 'Beechcraft', 'Lockheed', 'Douglas', 'Canadair', 'Cessna',
           'McDonnell', 'de', 'Robin', 'Dornier', 'Embraer', 'Eurofighter', 'Dassault', 'Fokker', 'Bombardier',
           'Gulfstream', 'Ilyushin', 'Fairchild', 'Piper', 'Cirrus', 'Saab', 'Supermarine', 'Panavia', 'Tupolev',
           'Yakovlev', 'BritishAerospace', 'LockheedCorporation', 'DouglasAircraftCompany', 'McDonnellDouglas',
           'deHavilland', 'LockheedMartin', 'DassaultAviation', 'BombardierAerospace', 'GulfstreamAerospace',
           'CirrusAircraft']

#
# from torchvision.datasets import ImageFolder
#
# d = ImageFolder(root='data/gen203', transform=None)
# print(d.class_to_idx)
