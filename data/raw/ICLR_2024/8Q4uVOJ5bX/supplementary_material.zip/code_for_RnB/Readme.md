# R&B: Region and Boundary Aware Zero-shot Grounded Text-to-image Generation

## Environment Setup

Run the following command to set up the environment:
```buildoutcfg
conda create -n layout-guidance python=3.8
conda activate layout-guidance
pip install -r requirements.txt
```

## Inference 

Outputs including log file, generated images, config file,  are saved to path `./example_output`. Detail configuration can be found in the `./conf/base_config.yaml` and `inference.py`. You can set the `model_path` in `./conf/base_config.yaml` as your own path to SD checkpoint.
```buildoutcfg
python inference_RnB.py general.save_path=./example_output 
```