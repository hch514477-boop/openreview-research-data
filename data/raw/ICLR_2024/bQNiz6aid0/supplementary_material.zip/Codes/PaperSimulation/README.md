## Date: 2023/08/15

# Introduction

This readme gives a short description of all the PQ-QSSM Paper simulation archive.

# Version
- Python: 3.8(.13)
- PaddleQuantum: 2.2.2
- PaddlePaddle: 2.3.2
- QComputeSDK: 3.3.3
- qiskit: 0.34.2
- qiskit-aer: 0.9.0
- qiskit-terra: 0.19.1
- qiskit-aqua: 0.9.5
- qiskit-ignis: 0.6.0
- All other libs: current used versions

# Requirement
To run the following code successfully, please visit the following links for a setup of python environment: https://qml.baidu.com/ for PaddleQuantum, https://github.com/baidu/QCompute for QCompute and https://qiskit.org/documentation/getting_started.html for Qiskit. 

Currently the latest version of PaddleQuantum is 2.4.0 which might raise errors when running the codes. Please try to fix the version to 2.3.2 if that happen.

> **Caution:** Currently, the release version of PaddleQuantum and QCompute are not compatible. Please use different environments to run the `IdealModel` .py files and `NoiseModel` .py files. We apologize for the inconvenience.

# Installation

Please follow the `README.md` file(s) in each document.

# Content

This archive contains the following documents:
1. **IdealModel:** for ideal numerical experiments without quantum circuit noise on QSSM state learning.
2. **NoiseModel:** for noisy numerical experiments on QSSM state learning.
