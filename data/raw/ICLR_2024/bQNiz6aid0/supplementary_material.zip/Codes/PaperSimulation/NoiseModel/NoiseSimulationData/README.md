# Usage
The two `outputs_xxx` documents contain the raw loss data for plotting (fig. a), run the following two commands to access.
```shell
find outputs_2023-04-21_21:08-qssm-noisefree -type f | python load_lossdata.py > qssm_noisefree_loss.txt
find outputs_2023-04-18_21:15-qssm-noise -type f | python load_lossdata.py > qssm_noise_loss.txt
```
In file `qssm_noise_loss.txt` and  `qssm_noisefree_loss.txt`, the old column and the even columns represent the mean and the variance of loss, respectively.

Then by running the commands
```shell
python paper_loss_plot.py --datafiles qssm_noise_loss.txt qssm_noisefree_loss.txt --linecolor "tab:blue" "tab:green" --marker "o" "s" --figsize 8 6
```
can produce the loss variation plot.

Plot QSSM learnt shots distribution by running the following commands
```shell
cat paper_param.txt | python paper_dist_plot.py --fidelity 0.91187 --numshots 4096 --figsize 8 6
```
The file `paper_param.txt` contains the highest fidelity experimental optimal parameters where $F^{opt} = 0.91187$.
