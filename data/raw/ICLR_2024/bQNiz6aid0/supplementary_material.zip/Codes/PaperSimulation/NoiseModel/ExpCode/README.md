# README
You can run the numerical experiment on the server by
```python
python run_qsl.py --config config.toml --Nrounds x
```
The settings of the experiment are specified in `config.toml`. You can change the number of shots, optimization options and parameters of the noise model to configure your experiment.

The flag `--Nrounds` specifies the number of times you run the quantum state learning program. You can run the program multiple times to measure the performance of the model on average.

The program records its log message in `log-{datetime}` file and stores the losses in the optimization in `outputs/loss-{datetime}.txt`.