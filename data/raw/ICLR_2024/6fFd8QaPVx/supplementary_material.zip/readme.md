
#OneBNet: OneBNet: Binarized Neural Networks using Decomposed 1-D Binarized Convolutions 
on Edge Device

- For running this evaluation, you should have ImageNet data in **./data** directory. 
-- Before you run the training, **./results** directory should be pre-made. -- In **./results**, a directory is automatically generated, where training checkpoints and logging data are stored. 
- This baseline code is borrowed from ReActNet18 and ResNet. 
- The binarized convolution module is written in dorefanet1d.py, which supprots n-bit quantization. But n-bit quantized convolutions were not used. 
- To finish total training on our maching having AMD Ryzen Threadripper 193 PRO 5955WX 16-Cores CPU, 2 NVIDIA RTX 4090 GPUs, and 263-GB RAM,
about 5 days are required without ReActNet triangle derivative of Sign function. 
If the triangle derivative of ReActNet is used, about 30% additional training time will be needed in our evaluations.
 
- XbasicBlock1D module written in binresnet1d.py is the proposed basic block. 

- The proposed OneBNet with Two-Stage+TS (Teacher-Student Training) can reach 68.4%@Top-1. 
  Attached second_stage.out files contain the training data and accuracy per each epoch.

- In run.sh and run_ts.sh, you can see the direction for performing training from scratch and Two-Stage+TS training. 

- Data (Best validation accuracy)
scratch.out: activation: 1bit, weights: 1 bits trained from scratch (63.9%@Top-1)

first_stage.out: activation: 1bit, weights: 32 bits of the first training step using teacher-student training (69.0%@Top-1)
second_stage.out: activation: 1bit, weights: 1 bits of the second training step using teacher-student training (68.4%@Top-1)


