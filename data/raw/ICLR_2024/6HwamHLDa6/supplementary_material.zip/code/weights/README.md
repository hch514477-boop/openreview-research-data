You can get our pre-trained model on [Google Drive](https://drive.google.com/drive/folders/1Ta2e_vS5JejpkVrD3u_5o8NQQcgr_S1w?usp=share_link).


