#! /bin/bash
#SBATCH -J train_PTG
#SBATCH -o ./results/train_PTG.out               
#SBATCH -p compute                  
#SBATCH --qos=normal               
#SBATCH -N 1               
#SBATCH --ntasks-per-node=1                    
#SBATCH --cpus-per-task=1
#SBATCH --gres=gpu:3090:1

python3 -u -m domainbed.scripts.train\
       --data_dir=./data_domainbed/\
       --dataset VLCS\
       --algorithm PTG\
       --hparams_seed 0\
       --trial_seed 0\
       --seed 0\
       --test_envs 1\
       --checkpoint_freq 1\
       --steps 50\