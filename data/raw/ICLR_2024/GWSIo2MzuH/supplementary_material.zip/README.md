# Overview

Our supplementary material enables the replication of two experiments:
* Correlation Analysis
* Bound Comparison

## Correlation Analysis

The code is developed based on [this repository](https://github.com/xu-ji/information-bottleneck).

The analysis of $H(L^w)$ and $H(L^W|Y)$ is implemented in `information-bottleneck/toy/scripts/main_swag.py`, with the kernel density estimator implemented in `information-bottleneck/toy/util/general.py`.

## Bound Comparison

The code is developed based on [this repository](https://github.com/hrayrhar/f-CMI).

The estimation of our bounds is implemented in `f-CMI/scripts/fcmi_parse_results.py` and `f-CMI/modules/bound_utils.py`. The figures are plotted using the code in `f-CMI/scripts/mee_plots.py`.
