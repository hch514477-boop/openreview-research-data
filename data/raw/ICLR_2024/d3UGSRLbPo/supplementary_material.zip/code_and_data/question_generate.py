from openai_call import get_openai_response


def get_validation_question_via_prompting(sentence, instruction):

    # if(answer != None):
    #     instruction = f"For the above sentence about {query}, generate a yes/no question for which the answer is: {answer}.\n\n"
    #     prompt = "Sentence: " + sentence + "\n\n" + instruction
    # else:
    #     instruction = "Generate a self-contained question that checks the factuality of the above sentence.\n\n"
    #     prompt = "Sentence: " + sentence + "\n\n" + instruction
    prompt = "Sentence: " + sentence + "\n\n" + instruction
    kwargs = {
        "engine": "text-davinci-003",
        "temperature": 0,
        "max_tokens": 50,
        "prompt": prompt,
        "top_p": 0,
        "frequency_penalty": 0,
        "presence_penalty": 0,
    }

    return get_openai_response(kwargs, return_complete_response=False)
