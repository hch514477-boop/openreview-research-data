# Walker
sbatch slurm/full_comparison.sh walker_muzero walker-run-uniform_noise True uniform 0.2 True True [["mse",1.]] 50
sbatch slurm/full_comparison.sh walker_muzero walker-run-no_noise False uniform 0.0 True True [["mse",1.]] 50

sbatch slurm/full_comparison.sh walker_vaml_grad walker-run-uniform_noise True uniform 0.2 False True [["mse",1.],["vaml",1.]] 50
sbatch slurm/full_comparison.sh walker_vaml_grad walker-run-no_noise False uniform 0.0 False True [["mse",1.],["vaml",1.]] 50

sbatch slurm/full_comparison.sh walker_vaml walker-run-uniform_noise True uniform 0.2 False False [["mse",1.],["vaml",1.0]] 50
sbatch slurm/full_comparison.sh walker_vaml walker-run-no_noise False uniform 0.0 False False [["mse",1.],["vaml",1.0]] 50

sbatch slurm/full_comparison.sh walker_mse walker-run-uniform_noise True uniform 0.2 False False [["mse",1.]] 50
sbatch slurm/full_comparison.sh walker_mse walker-run-no_noise False uniform 0.0 False False [["mse",1.]] 50

# Quad
sbatch slurm/full_comparison.sh quad_muzero quadruped-run-uniform_noise True uniform 0.2 True True [["mse",1.]] 50
sbatch slurm/full_comparison.sh quad_muzero quadruped-run-no_noise False uniform 0.0 True True [["mse",1.]] 50

sbatch slurm/full_comparison.sh quad_vaml_grad quadruped-run-uniform_noise True uniform 0.2 False True [["mse",1.],["vaml",1.]] 50
sbatch slurm/full_comparison.sh quad_vaml_grad quadruped-run-no_noise False uniform 0.0 False True [["mse",1.],["vaml",1.]] 50

sbatch slurm/full_comparison.sh quad_vaml quadruped-run-uniform_noise True uniform 0.2 False False [["mse",1.],["vaml",1.0]] 50
sbatch slurm/full_comparison.sh quad_vaml quadruped-run-no_noise False uniform 0.0 False False [["mse",1.],["vaml",1.0]] 50

sbatch slurm/full_comparison.sh quad_mse quadruped-run-uniform_noise True uniform 0.2 False False [["mse",1.]] 50
sbatch slurm/full_comparison.sh quad_mse quadruped-run-no_noise False uniform 0.0 False False [["mse",1.]] 50

# Humanoid
sbatch slurm/full_comparison.sh humanoid_muzero humanoid-run-uniform_noise True uniform 0.2 True True [["mse",1.]] 100
sbatch slurm/full_comparison.sh humanoid_muzero humanoid-run-no_noise False uniform 0.0 True True [["mse",1.]] 100

sbatch slurm/full_comparison.sh humanoid_vaml_grad humanoid-run-uniform_noise True uniform 0.2 False True [["mse",1.],["vaml",1.]] 100
sbatch slurm/full_comparison.sh humanoid_vaml_grad humanoid-run-no_noise False uniform 0.0 False True [["mse",1.],["vaml",1.]] 100

sbatch slurm/full_comparison.sh humanoid_grad humanoid-run-uniform_noise True uniform 0.2 False False [["mse",1.],["vaml",1.0]] 100
sbatch slurm/full_comparison.sh humanoid_grad humanoid-run-no_noise False uniform 0.0 False False [["mse",1.],["vaml",1.0]] 100

sbatch slurm/full_comparison.sh humanoid_mse humanoid-run-uniform_noise True uniform 0.2 False False [["mse",1.]] 100
sbatch slurm/full_comparison.sh humanoid_mse humanoid-run-no_noise False uniform 0.0 False False [["mse",1.]] 100