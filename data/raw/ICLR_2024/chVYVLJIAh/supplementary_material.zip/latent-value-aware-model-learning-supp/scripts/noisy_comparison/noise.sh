# Humanoid
sbatch slurm/full_comparison.sh humanoid_muzero humanoid-run-large_uniform_noise True uniform 0.4 True True [["mse",1.]] 100
sbatch slurm/full_comparison.sh humanoid_vaml humanoid-run-large_uniform_noise True uniform 0.4 False False [["mse",1.],["vaml",1.]] 100
sbatch slurm/full_comparison.sh humanoid_mse humanoid-run-large_uniform_noise True uniform 0.4 False False [["mse",1.]] 100

sbatch slurm/full_comparison.sh humanoid_muzero humanoid-run-bimodal_noise True bimodal 0.2 True True [["mse",1.]] 100
sbatch slurm/full_comparison.sh humanoid_vaml humanoid-run-bimodal_noise True bimodal 0.2 False False [["mse",1.],["vaml",1.]] 100
sbatch slurm/full_comparison.sh humanoid_mse humanoid-run-bimodal_noise True bimodal 0.2 False False [["mse",1.]] 100

sbatch slurm/full_comparison.sh humanoid_muzero humanoid-run-large_bimodal_noise True bimodal 0.4 True True [["mse",1.]] 100
sbatch slurm/full_comparison.sh humanoid_vaml humanoid-run-large_bimodal_noise True bimodal 0.4 False False [["mse",1.],["vaml",1.]] 100
sbatch slurm/full_comparison.sh humanoid_mse humanoid-run-large_bimodal_noise True bimodal 0.4 False False [["mse",1.]] 100

# Quadruped
sbatch slurm/full_comparison.sh quad_muzero quadruped-run-large_uniform_noise True uniform 0.4 True True [["mse",1.]] 50
sbatch slurm/full_comparison.sh quad_vaml quadruped-run-large_uniform_noise True uniform 0.4 False False [["mse",1.],["vaml",1.]] 50
sbatch slurm/full_comparison.sh quad_mse quadruped-run-large_uniform_noise True uniform 0.4 False False [["mse",1.]] 50

sbatch slurm/full_comparison.sh quad_muzero quadruped-run-bimodal_noise True bimodal 0.2 True True [["mse",1.]] 50
sbatch slurm/full_comparison.sh quad_vaml quadruped-run-bimodal_noise True bimodal 0.2 False False [["mse",1.],["vaml",1.]] 50
sbatch slurm/full_comparison.sh quad_mse quadruped-run-bimodal_noise True bimodal 0.2 False False [["mse",1.]] 50

sbatch slurm/full_comparison.sh quad_muzero quadruped-run-large_bimodal_noise True bimodal 0.4 True True [["mse",1.]] 50
sbatch slurm/full_comparison.sh quad_vaml quadruped-run-large_bimodal_noise True bimodal 0.4 False False [["mse",1.],["vaml",1.]] 50
sbatch slurm/full_comparison.sh quad_mse quadruped-run-large_bimodal_noise True bimodal 0.4 False False [["mse",1.]] 50