# Walker
sbatch slurm/mve_ablation.sh walker_mve_muzero walker-run-uniform_noise True uniform 0.2 True True [["mse",1.]] 50
sbatch slurm/mve_ablation.sh walker_mve_muzero walker-run-no_noise False uniform 0.0 True True [["mse",1.]] 50

sbatch slurm/mve_ablation.sh walker_mve_vaml walker-run-uniform_noise True uniform 0.2 False False [["mse",1.],["vaml",1.0]] 50
sbatch slurm/mve_ablation.sh walker_mve_vaml walker-run-no_noise False uniform 0.0 False False [["mse",1.],["vaml",1.0]] 50

sbatch slurm/mve_ablation.sh walker_mve_mse walker-run-uniform_noise True uniform 0.2 False False [["mse",1.]] 50
sbatch slurm/mve_ablation.sh walker_mve_mse walker-run-no_noise False uniform 0.0 False False [["mse",1.]] 50

# Quad
sbatch slurm/mve_ablation.sh quad_mve_muzero quadruped-run-uniform_noise True uniform 0.2 True True [["mse",1.]] 50
sbatch slurm/mve_ablation.sh quad_mve_muzero quadruped-run-no_noise False uniform 0.0 True True [["mse",1.]] 50

sbatch slurm/mve_ablation.sh quad_mve_vaml quadruped-run-uniform_noise True uniform 0.2 False False [["mse",1.],["vaml",1.0]] 50
sbatch slurm/mve_ablation.sh quad_mve_vaml quadruped-run-no_noise False uniform 0.0 False False [["mse",1.],["vaml",1.0]] 50

sbatch slurm/mve_ablation.sh quad_mve_mse quadruped-run-uniform_noise True uniform 0.2 False False [["mse",1.]] 50
sbatch slurm/mve_ablation.sh quad_mve_mse quadruped-run-no_noise False uniform 0.0 False False [["mse",1.]] 50

# Humanoid
sbatch slurm/mve_ablation.sh humanoid_mve_muzero humanoid-run-uniform_noise True uniform 0.2 True True [["mse",1.]] 100
sbatch slurm/mve_ablation.sh humanoid_mve_muzero humanoid-run-no_noise False uniform 0.0 True True [["mse",1.]] 100

sbatch slurm/mve_ablation.sh humanoid_mve_grad humanoid-run-uniform_noise True uniform 0.2 False False [["mse",1.],["vaml",1.0]] 100
sbatch slurm/mve_ablation.sh humanoid_mve_grad humanoid-run-no_noise False uniform 0.0 False False [["mse",1.],["vaml",1.0]] 100

sbatch slurm/mve_ablation.sh humanoid_mve_mse humanoid-run-uniform_noise True uniform 0.2 False False [["mse",1.]] 100
sbatch slurm/mve_ablation.sh humanoid_mve_mse humanoid-run-no_noise False uniform 0.0 False False [["mse",1.]] 100