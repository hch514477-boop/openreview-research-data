# Walker
sbatch slurm/no_latent.sh walker_nolatent_muzero walker-run-no_noise False uniform 0.2 True True [["mse",1.]] 50
sbatch slurm/no_latent.sh walker_nolatent_nomse_muzero walker-run-no_noise False uniform 0.2 True True [] 50
sbatch slurm/no_latent.sh walker_nolatent_vaml walker-run-no_noise False uniform 0.2 False False [["mse",1.],["vaml",1.0]] 50
sbatch slurm/no_latent.sh walker_nolatent_nomse_vaml walker-run-no_noise False uniform 0.2 False False [["vaml",1.0]] 50
sbatch slurm/no_latent.sh walker_nolatent_mse walker-run-no_noise False uniform 0.2 False False [["mse",1.]] 50

# Quad
sbatch slurm/no_latent.sh quad_nolatent_muzero quadruped-run-no_noise False uniform 0.2 True True [["mse",1.]] 50
sbatch slurm/no_latent.sh quad_nolatent_nomse_muzero quadruped-run-no_noise False uniform 0.2 True True [] 50
sbatch slurm/no_latent.sh quad_nolatent_vaml quadruped-run-no_noise False uniform 0.2 False False [["mse",1.],["vaml",1.0]] 50
sbatch slurm/no_latent.sh quad_nolatent_nomse_vaml quadruped-run-no_noise False uniform 0.2 False False [["vaml",1.0]] 50
sbatch slurm/no_latent.sh quad_nolatent_mse quadruped-run-no_noise False uniform 0.2 False False [["mse",1.]] 50