# Walker
sbatch slurm/small_ablation.sh walker_small_muzero walker-run-uniform_noise True uniform 0.2 True True [["mse",1.]]
sbatch slurm/small_ablation.sh walker_small_muzero walker-run-no_noise False uniform 0.0 True True [["mse",1.]]

sbatch slurm/small_ablation.sh walker_small_vaml walker-run-uniform_noise True uniform 0.2 False False [["mse",1.],["vaml",1.]]
sbatch slurm/small_ablation.sh walker_small_vaml walker-run-no_noise False uniform 0.0 False False [["mse",1.],["vaml",1.]]

sbatch slurm/small_ablation.sh walker_small_mse walker-run-uniform_noise True uniform 0.2 False False [["mse",1.]]
sbatch slurm/small_ablation.sh walker_small_mse walker-run-no_noise False uniform 0.0 False False [["mse",1.]]

# Quad
sbatch slurm/small_ablation.sh quad_small_muzero quadruped-run-uniform_noise True uniform 0.2 True True [["mse",1.]]
sbatch slurm/small_ablation.sh quad_small_muzero quadruped-run-no_noise False uniform 0.0 True True [["mse",1.]]

sbatch slurm/small_ablation.sh quad_small_vaml quadruped-run-uniform_noise True uniform 0.2 False False [["mse",1.],["vaml",1.]]
sbatch slurm/small_ablation.sh quad_small_vaml quadruped-run-no_noise False uniform 0.0 False False [["mse",1.],["vaml",1.]]

sbatch slurm/small_ablation.sh quad_small_mse quadruped-run-uniform_noise True uniform 0.2 False False [["mse",1.]]
sbatch slurm/small_ablation.sh quad_small_mse quadruped-run-no_noise False uniform 0.0 False False [["mse",1.]]

# Humanoid
sbatch slurm/small_ablation.sh humanoid_small_muzero humanoid-run-uniform_noise True uniform 0.2 True True [["mse",1.]]
sbatch slurm/small_ablation.sh humanoid_small_muzero humanoid-run-no_noise False uniform 0.0 True True [["mse",1.]]

sbatch slurm/small_ablation.sh humanoid_small_vaml humanoid-run-uniform_noise True uniform 0.2 False False [["mse",1.],["vaml",1.]]
sbatch slurm/small_ablation.sh humanoid_small_vaml humanoid-run-no_noise False uniform 0.0 False False [["mse",1.],["vaml",1.]]

sbatch slurm/small_ablation.sh humanoid_small_mse humanoid-run-uniform_noise True uniform 0.2 False False [["mse",1.]]
sbatch slurm/small_ablation.sh humanoid_small_mse humanoid-run-no_noise False uniform 0.0 False False [["mse",1.]]