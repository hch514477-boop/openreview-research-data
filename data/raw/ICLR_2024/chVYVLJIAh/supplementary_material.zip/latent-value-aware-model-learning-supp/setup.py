from setuptools import find_packages, setup

install_requires = []

setup(
    name="lambda_ac",
    version="0.0.1",
    description="",
    author="",
    author_email="",
    url="",
    license="MIT License",
    packages=find_packages(),
    install_requires=install_requires,
)
