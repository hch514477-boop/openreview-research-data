import torch

from lambda_ac.rl_types import Agent


class RandomAgent(Agent):
    def __init__(self, env):
        self.action_space = env.action_space

    def select_action(self, state, step=0, episode=0, eval=False):
        return torch.Tensor(self.action_space.sample())
