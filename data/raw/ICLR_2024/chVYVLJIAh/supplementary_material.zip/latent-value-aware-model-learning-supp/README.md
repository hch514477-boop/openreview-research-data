# $\lambda$-AC implementation

NeurIPS 2023 anonymized version of the codebase

## Instructions

Install the requirements.txt in a conda or virtualenv.
We provide an updated version of Denis Yarat's dmc2gym tool that allows for running the noise corrupted experiments as described in the appendix of the paper.

The experiments in the paper can be recreated with the scripts provided in the folder.
