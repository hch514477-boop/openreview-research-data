# Revealing Vision-Language Integration in the Brain Using Multimodal Networks
To load and create relevant data for analysis:
```
python structure_data.py -s [SUBJECT] -t trial000 -a [ALIGNMENT] -w [WINDOW_SIZE]
```

To obtain the model layer JSON for extracting embeddings run
```
python vil_embeds/model_layer_json.py
```

To run a regression using a model and extraction point:
```
CUDA_VISIBLE_DEVICES=$DEVICE python run_regression.py --subject [SUBJECT] --trial_list trial000 --alignment [ALIGNMENT] --model_name [MODEL_NAME] --model_output [MODEL_OUTPUT] [--randomized]
```

To run the bootstrapping test and bootstrapping analysis:
```
CUDA_VISIBLE_DEVICES=$DEVICE python bootstrap_test.py --subject [SUBJECT] --trial_list trial000 --alignment [ALIGNMENT] --model_name [MODEL_NAME] --model_output [MODEL_OUTPUT] [--randomized]
```

All analysis is under the `comparison_analysis.ipynb` file. 