import hashlib

def file_as_bytes(file):
    with file:
        return file.read()

def compute_m5_hash(file_path):
    #from https://stackoverflow.com/a/3431835
    return hashlib.md5(file_as_bytes(open(file_path, 'rb'))).hexdigest()