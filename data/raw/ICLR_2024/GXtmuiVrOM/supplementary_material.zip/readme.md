# Domain Randomization via Entropy Maximization

Please consider the supplementary material at our project website https://gabrieletiboni.github.io/doraemon/

On the website, you may find videos of the experiments, and a link to our codebase for reproducing the paper results.