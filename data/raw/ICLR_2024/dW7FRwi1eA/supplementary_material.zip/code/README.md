
python MeDe_cifar.py --dataset cifar10 --mode train --train_noise_type symmetric --noise_rate 0.2 --mode train --T1 20 --T2 30  --meta_type loss
python MeDe_cifar.py --dataset cifar100 --mode test --train_noise_type symmetric --test_noise_type symmetric --noise_rate 0.2 --mode test --T1 20 --T2 30 --meta_type loss

python MeDe_cifar.py --dataset cifar100 --mode train --train_noise_type symmetric --noise_rate 0.2 --mode train --T1 20 --T2 30 --meta_type loss
python MeDe_cifar.py --dataset cifar10 --mode test --train_noise_type symmetric --test_noise_type symmetric --noise_rate 0.2 --mode test --T1 20 --T2 30 --meta_type loss


