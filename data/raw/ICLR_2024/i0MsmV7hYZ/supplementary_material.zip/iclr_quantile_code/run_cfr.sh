#!/bin/bash
for ((i=$1; i<$2; i=i+1))
do 
      python main.py --exp_num=$i --trainer=CFR --config=configs/dissim.yaml
done
