import os

import torch
from utils import load_dict

rmses = []
for mn in [10, 50,100,200,300,500]:
	cur_rmses = []
	for i in range(10):
		fn = 'checkpoints/dissim_seed1_mn%d/exp%04d_run000_test_result.pkl' % (mn, i)
		if not os.path.exists(fn):
			continue
		out = load_dict(fn)
		cur_rmses.append(out['cf_rmse'].item())
	print(mn, cur_rmses)
