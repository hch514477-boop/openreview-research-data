#########################
#### Libraray #######
#########################
pip install betty-ml
pip install munch

#########################
#### Hyper-parameters #######
#########################
All hyper-parameters are stored in configs directory.



#########################
#### Usage #######
#########################

python main.py --config=configs/toy1.yaml --trainer=Toy
python main.py --config=configs/ihdp100.yaml --trainer=ITE
python main.py --config=configs/jobs.yaml --trainer=ITE
python main.py --config=configs/disim.yaml --trainer=CFR
python main.py --config=configs/cfr_ihdp100.yaml --trainer=CFR