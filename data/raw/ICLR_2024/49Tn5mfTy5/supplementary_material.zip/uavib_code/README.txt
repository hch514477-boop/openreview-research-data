#### classification example


python ood_cifar_uaib.py --use_gpu --num_cores=4 --eval_on_ood=True --uaib_dim=8 --codebook_size=10 --train_epochs=200 --seed=3

python get_scores.py --path=/summaries_uaib/



 -----------------------------------------------------------------------------------
 
 #### synthetic exmperiment

 
 python synthetic_regression.py --example=1 --codebook_size=1


 python synthetic_regression.py --example=2 --codebook_size=2
