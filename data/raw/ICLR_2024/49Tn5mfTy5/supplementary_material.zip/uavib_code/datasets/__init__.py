
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Uncertainty baseline training datasets."""

from absl import logging

# pylint: disable=g-bad-import-order

from datasets.base import BaseDataset
from datasets.base import make_ood_dataset
from datasets.cifar import Cifar100Dataset
from datasets.cifar import Cifar10Dataset



from datasets.datasets import DATASETS
from datasets.datasets import get

from datasets.svhn import SvhnDataset


