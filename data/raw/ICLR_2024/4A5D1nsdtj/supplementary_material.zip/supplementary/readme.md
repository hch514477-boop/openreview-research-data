## Environment Settings    
- pytorch 1.7.0
- torch-geometric 1.6.1
- scipy 1.9.3
- seaborn 0.12.0
- scikit-learn 1.1.3


## Datasets
We follow the data processing as [ChebNet II](https://github.com/ivam-he/ChebNetII). Please acquire all the data from ChebNet II and put the data in the subfolder './data'. 


## Experiment Reproduction
Please run the scripts in run.sh to reproduce our experimental results.
