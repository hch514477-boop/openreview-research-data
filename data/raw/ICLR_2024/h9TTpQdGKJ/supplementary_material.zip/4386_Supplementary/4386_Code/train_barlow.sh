
# 사용 예

if [ $6 == "pr_max" ] ; then
    if [ $7 == 'corr' ] ; then
        CUDA_VISIBLE_DEVICES=$1 python main.py \
            --mode metasgd \
            --model resnet12 \
            --dataset cifar_fs \
            --subsampling \
            --use_sampler \
            --barlow \
            --adv \
            --qry_attack \
            --dynamic_attack \
            --inner_update_type encoder_only \
            --crop_size 32 \
            --batch_size 16 \
            --inner_steps 1 \
            --inner_steps_test 1 \
            --lr $2 \
            --inner_lr $3 \
            --loss_type $4 \
            --suffix $5'at'$8'aug'$9'prcorr' \
            --pr_max \
            --pr_type corr \
            --max_iters $8 \
            --aug_type $9 \
            --limit_train_batches 200 \
            --limit_val_batches 100 \
            --outer_steps 100000
    else
        CUDA_VISIBLE_DEVICES=$1 python main.py \
            --mode metasgd \
            --model resnet12 \
            --dataset cifar_fs \
            --subsampling \
            --use_sampler \
            --barlow \
            --adv \
            --qry_attack \
            --dynamic_attack \
            --inner_update_type encoder_only \
            --crop_size 32 \
            --batch_size 16 \
            --inner_steps 1 \
            --inner_steps_test 1 \
            --lr $2 \
            --inner_lr $3 \
            --loss_type $4 \
            --suffix $5'at'$8'aug'$9'prmse' \
            --pr_max \
            --pr_type mse \
            --max_iters $8 \
            --aug_type $9 \
            --limit_train_batches 200 \
            --limit_val_batches 100 \
            --outer_steps 100000
    fi
else
    CUDA_VISIBLE_DEVICES=$1 python main.py \
        --mode metasgd \
        --model resnet12 \
        --dataset cifar_fs \
        --subsampling \
        --use_sampler \
        --barlow \
        --adv \
        --qry_attack \
        --dynamic_attack \
        --inner_update_type encoder_only \
        --crop_size 32 \
        --batch_size 16 \
        --inner_steps 1 \
        --inner_steps_test 1 \
        --lr $2 \
        --inner_lr $3 \
        --loss_type $4 \
        --suffix $5'at'$8'aug'$9 \
        --max_iters $8 \
        --aug_type $9 \
        --limit_train_batches 200 \
        --limit_val_batches 100 \
        --outer_steps 100000
fi