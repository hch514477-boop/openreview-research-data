python eval.py --mode metasgd --model $2 --crop_size 32 --adv --barlow --inner_steps_test $4 --inner_update_type $3 --load_path $1 --dataset cifar_fs
python eval.py --mode metasgd --model $2 --crop_size 32 --adv --barlow --inner_steps_test $4 --inner_update_type $3 --load_path $1 --dataset cub 
python eval.py --mode metasgd --model $2 --crop_size 32 --adv --barlow --inner_steps_test $4 --inner_update_type $3 --load_path $1 --dataset tieredimagenet
python eval.py --mode metasgd --model $2 --crop_size 32 --adv --barlow --inner_steps_test $4 --inner_update_type $3 --load_path $1 --dataset cars
#python eval.py --mode metasgd --model $2 --adv --barlow --inner_steps_test $4 --inner_update_type $3 --load_path $1 --dataset aircraft
python eval.py --mode metasgd --model $2 --crop_size 32 --adv --barlow --inner_steps_test $4 --inner_update_type $3 --load_path $1 --dataset vggflower
python eval.py --mode metasgd --model $2 --crop_size 32 --adv --barlow --inner_steps_test $4 --inner_update_type $3 --load_path $1 --dataset miniimagenet

