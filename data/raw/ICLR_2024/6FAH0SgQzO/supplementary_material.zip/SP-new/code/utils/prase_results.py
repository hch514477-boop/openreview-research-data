

file = './logs/cifar10-c-concept-1/conceptEM/results-conceptem.txt'

with open(file, 'r') as f:
    lines = f.readlines()
    lines = [x.strip() for x in lines]
    lines = [x.split(', ') for x in lines]
    lines = [[float(y) for y in x] for x in lines]

train_losses = []
train_acces = []
local_losses = []
local_acces = []
global_losses = []
global_acces = []

i = 0
for line in lines:
    if i % 2 == 0:
        train_losses.append(line[0])
        train_acces.append(line[1])
        local_losses.append(line[2])
        local_acces.append(line[3])
    elif i % 2 == 1:
        global_losses.append(float(line[2]))
        global_acces.append(float(line[3]))
    i += 1

round = train_acces.index(max(train_acces))

print(round)

print(local_acces[round])
print(global_acces[round])

