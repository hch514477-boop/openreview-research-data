The code is build on the top of public code provided by FedEM.

An example for script:

python run_experiment.py cifar10-c conceptEM_Adam --n_learners 6 --n_rounds 201 --bz 128 --lr 0.03 --lr_scheduler multi_step --log_freq 1 --device 1 --optimizer sgd --seed 1234 --verbose 1

Our algorithms are named by conceptEM, conceptEM_Adam here.

You need to first run scripts in create_c folder to create datasets, then change the paths in run_experiment.py.