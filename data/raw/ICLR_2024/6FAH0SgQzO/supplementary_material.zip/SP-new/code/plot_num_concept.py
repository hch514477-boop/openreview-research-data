import re
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

sns.set_style("darkgrid")

x = np.array([1, 3, 5])

y_1 = [61.9, 30.47, 16.54]
y_2 = [48.0, 30.79, 17.96]
y_3 = [58.0, 43.35, 17.76]
y_4 = [64.2, 63.83, 39.34]

# y_1 = [61.9, 48.0, 58.0, 64.2]
# y_2 = [30.47, 30.79, 43.35, 63.83]
# y_3 = [16.54, 17.96, 17.76, 39.34]


plt.bar(x, y_1, alpha=0.9, width=0.35, label='FedAvg', color = sns.color_palette('deep')[0])
plt.bar(x+0.35, y_2, alpha=0.9, width=0.35, label='FeSEM', color = sns.color_palette('deep')[1])
plt.bar(x+0.7, y_3, alpha=0.9, width=0.35, label='FedEM', color = sns.color_palette('dark')[0])
plt.bar(x+1.05, y_4, alpha=0.9, width=0.35, label='FedConceptEM', color = sns.color_palette('dark')[1])

plt.legend(loc=1)
plt.xticks(x+0.35+0.175, ['1', '3', '5'], fontsize=12)
plt.yticks(fontsize=12)
plt.xlabel('Number of Concept', fontsize=18)
plt.ylabel('Accuracy', fontsize=18)
# plt.set_xticklabels(x)
# plt.title('Ablation study on the ')
plt.savefig('/Users/gyx/fsdownload/number-of-concept.pdf')
# plt.savefig('number_of_clients.pdf')