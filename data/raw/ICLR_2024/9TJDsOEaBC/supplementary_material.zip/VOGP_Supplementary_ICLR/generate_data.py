import os

datasets = ["SnAR","SNW","OKA","BC"]
for data in datasets:
    for i in range(20,20+10):
        os.system(f'python3 run.py --dataset {data} --seed {i} --gp_dependent {1} --epsilon {0.1} --noise_std {0.1}') 