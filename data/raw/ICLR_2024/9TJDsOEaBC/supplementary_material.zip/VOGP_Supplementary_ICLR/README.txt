Requirement: Python 3.10.12

In order to run the experiment, run generate_data.py or run.py. The results are saved into results folder. In order to assess the performance of save files inside results folder, run main_table.py. The needed libraries can be found in requirements.txt .