
library(parallel)
library(MASS)
library(fda)
library(e1071)
library(refund)
library(VGAM)
library(abind)

#### function ----
dgp<-function(n,sclass=0,h=0,alpha=0.1,xnb=50,int_nt=1000){
  
  for(ci in 1:5){
    zeta_phi<-matrix(unlist(lapply(1:int_nt,function(i) #xnb: num of basis of x
      c(1,sqrt(2)*cos((1:(xnb-1))*pi*i/int_nt)))),ncol=int_nt) #dim: xnb*int_nt
    x<-matrix(runif(n*xnb,-sqrt(3),sqrt(3)),ncol=xnb)%*%(zeta_phi * ((-1)^((1:xnb)+1)*(1:xnb)^(-1)) ) #dim: n*xnb %*% xnb*int_nt
    
    if(sclass==0){
      beta<-as.vector( (4*(-1)^((1:xnb)+1)*(1:xnb)^(-2)) %*% zeta_phi)
    }else if(sclass==1){
      beta<-as.vector( ( (4*(-1)^((1:xnb)+1) + runif(xnb,-1,1)*h/pi ) * (1:xnb)^(-2)) %*%zeta_phi)
    }else if(sclass==3){
      beta<-as.vector( ( (4*(-1)^((1:xnb)+1) - runif(xnb,1,2)*h/pi ) * (1:xnb)^(-2)) %*%zeta_phi)
    }else{
      rho<-exp(-15/int_nt);rho1<-sqrt(1-rho^2)
      z<-rnorm(1+int_nt,0,1);beta<-c(z[1],rep(0,int_nt))
      for(i in 1:int_nt){beta[i+1]<-rho*beta[i]+rho1*z[i+1]}
      beta<-beta[-1]
    }
    fx<-as.vector(alpha+x%*%beta/int_nt)
    y<-rbinom(n,1,exp(fx)/(1+exp(fx)));y[which(y==0)]<--1
    xobs<-x[,as.integer((1:nti)*(int_nt/nti))]
    
    if(sd(y)!=0){break}
  }
  return(list('y'=y,'x'=xobs))
}
dpfun<-function(d0,q=0.9,dx=0.01,pri=0,nol=0){
  n<-length(d0$y)
  if(pri){q0<-min(1-q,q-0.5,pri);q<-runif(n,q-q0,q+q0)}
  y1<-d0$y*(rbinom(n,1,q)*2-1)
  
  beta<-mat%*%t(d0$x)
  if(nol && nbasis!=1){
    if(nol==1){beta<-apply(beta,MARGIN=2,function(x) x/max(abs(x)))}else{
      beta<-tanh(beta)}}
  if(nbasis==1){beta<-matrix(beta,nrow=1);if(nol){beta<-tanh(beta)}}
  if(dx>0){beta<-beta+matrix(rlaplace(length(beta),0,dx),nrow=nrow(beta))}
  x1<-t(basismat%*%beta)
  
  return(list('y'=y1,'x'=x1,'beta'=t(beta)))
}
dwdfun<-function(d0,dtest,qi=0.1,lami=0.01,addcoef=NA,maxi=100,mini=1e-5,lammin=1e-5){#,nx=NA
  #maxi:maximum #iteration; mini:threshold of stop iteration; lammin:minmum eigenvalue selected
  x<-d0$x;y<-d0$y
  nti<-ncol(x);N<-2;
  if(is.na(addcoef[[1]])){add0<-0}else{add0<-as.vector(x%*%addcoef$beta/nti)}
  psi1<-rep(1,nti);psi2<-(0:nti)/nti-0.5
  k2<-((psi2^2-1/12)/2)[-1];k4<-((psi2^4-psi2^2/2+7/240)/24)[-(nti+1)]
  k4st<-matrix(NA,ncol=nti,nrow=nti)
  for(i in 1:nti){k4st[i,i:nti]<-k4st[i:nti,i]<-k4[1:(nti-i+1)]}
  kst<-k2%*%t(k2)-k4st;rm(i,k2,k4,k4st) #nti*nti
  R0<-x%*%kst%*%t(x)/nti^2 #n*n, inner_prod
  S0<-x%*%cbind(psi1,psi2[-1])/nti #n*N, inner_prod
  
  ## for given q and lambda, qi and lami
  R<-R0;S<-S0;n<-nrow(x);theta<-rep(0,1+N+n)
  R_svd<-svd(R);k0<-sum(R_svd$d>lammin)
  B<-cbind(c(n,colSums(S)),rbind(colSums(S),t(S)%*%S))
  C<-cbind(colSums(R),R%*%S)
  Binv<-ginv(B)
  CBinv<-C%*%Binv
  if(is.na(addcoef[[1]])){addi=0}else{addi<-as.vector(addcoef$alpha+add0)}
  
  Pi<-(R_svd$d[1:k0])^2+(R_svd$d[1:k0])*2*n*qi*lami/(qi+1)^2
  Dinv<-R_svd$u[,1:k0]%*%diag(1/Pi,nrow=length(Pi),ncol=length(Pi))%*%t(R_svd$v[,1:k0])
  DinvC<-Dinv%*%C
  P<-Dinv+DinvC%*%ginv(B-t(C)%*%DinvC)%*%t(DinvC);PCBinv<-P%*%CBinv
  Ainv<-cbind(rbind(Binv+t(CBinv)%*%PCBinv,-PCBinv),rbind(-t(PCBinv),P))
  # iteration of theta
  for(i in 1:maxi){
    u<-as.vector(y*(cbind(rep(1,n),S,R)%*%theta+addi));u0<-which(u>qi/(1+qi))
    d1loss<-rep(-1,length(u))
    if(length(u0)>0){d1loss[u0]<- -(qi/u[u0]/(qi+1))^(qi+1)}
    r<-y*d1loss/n;rm(u,u0,d1loss)
    d1theta<-c(sum(r),t(S)%*%r,R%*%r+2*lami*R%*%theta[-(1:(1+N))])
    theta1<-as.vector(theta-n*qi/(qi+1)^2*Ainv%*%d1theta)
    if(mean((theta1-theta)^2)<=mini){break}else{theta<-theta1}
  }
  # the misclassification probability
  hat_alpha<-theta1[1]
  hat_beta<-as.vector(cbind(psi1,psi2[-1])%*%theta1[2:(1+N)]+kst%*%t(x)%*%theta1[-(1:(1+N))])
  
  test<-mean(((as.vector(hat_alpha+dtest$x%*%hat_beta/nti)>0)*2-1)!=dtest$y)
  
  return(list('beta'=c(hat_alpha,hat_beta),'acc'=test))
}
cgfun<-function(d0,dtest,di=5){
  x<-t(d0$x[which(d0$y==1),]);y<-t(d0$x[which(d0$y==-1),])
  n1<-ncol(x);n2<-ncol(y)
  mu1<-rowMeans(x);mu2<-rowMeans(y);mu<-mu1-mu2;mu12<-(n1*mu1+n2*mu2)/(n1+n2)
  hatk<-((x-mu1)%*%t(x-mu1)+(y-mu2)%*%t(y-mu2))/(n1+n2-2)
  rec<-list()
  phi<-0;v<-z<-mu
  for(i in 1:di){
    h<-as.numeric(sum(v*z)/t(v)%*%hatk%*%v)
    phi<-phi+h*v
    z<-mu-as.vector(hatk%*%phi)
    rec[[i]]<-phi
    g<-as.numeric((t(z)%*%hatk%*%v)/(t(v)%*%hatk%*%v))
    v<-z-g*v
  }
  recg<-matrix(unlist(rec),ncol=di)
  ypre<-apply((dtest$x%*%recg>0)*2-1,MARGIN=2,function(ydi)mean(dtest$y!=ydi))
  return(list('beta'=rbind(rep(0,di),recg),'acc'=ypre))
}
vecfun <- function(d0, dtest){
  logistic_model <- glm(y ~ ., data = data.frame(x = d0$x, y = d0$y), family = "binomial")
  beta_logistic <- coef(logistic_model)
  svm_model <- svm(x = d0$x, y = d0$y, kernel = "linear", probability = TRUE)
  beta_svm <- coef(svm_model)
  beta <- cbind(c(beta_logistic[1],basismat%*%beta_logistic[-1]),
                c(beta_svm[1],basismat%*%beta_svm[-1]))
  acc<-unlist(lapply(1:ncol(beta),function(i)
    mean(((as.vector(beta[1,i]+dtest$x%*%beta[-1,i]/nti)>0)*2-1)!=dtest$y)))
  return(list('beta' = beta, 'acc' = acc))
}
accfun<-function(davgj,betaj,da){
  acc<-apply(betaj,MARGIN=2,function(coefi)
    as.numeric(((as.vector(coefi[1]+davgj$x%*%coefi[-1]/nti)>0)*2-1)!=davgj$y) )
  dam<-matrix(rbinom(length(acc),1,da),nrow=nrow(acc))
  acc1<-acc;acc1[which(dam==0)]<-1-acc1[which(dam==0)]
  acc<-colMeans(acc);acc1<-colMeans(acc1)
  acc2<-sapply((acc1+da-1)/(2*da-1),function(x) median(c(0,1,x)))
  acc<-cbind(acc,acc1,acc2)
  return(acc)
}
aggfun_T<-function(acck,betak,dtest){
  
  res<-apply(acck,MARGIN=1,function(acc){
    
    acc<-0.5-acc #larger is better, abs() larger is also better
    resi<-lapply(cutoff,function(p0){
      inx<-which(abs(acc)>(0.5-p0))
      acci<-acc[inx];hati<-t(t(betak[,inx])*sign(acci)) #change sign
      
      accmri<-apply(hati,MARGIN=2,function(coef)
        mean(((as.vector(coef[1]+dtest$x%*%coef[-1]/nti)>0)*2-1)!=dtest$y))
      accmri<-mean(accmri,na.rm=T)
      
      if(length(inx)==0){return(list('coef'=rep(NA,1+nti),'acc'=c(NA,accmri)))}else{
        hatw<-abs(acci)/sum(abs(acci))
        coef<-as.vector(hati%*%hatw)
        acc<-mean(((as.vector(coef[1]+dtest$x%*%coef[-1]/nti)>0)*2-1)!=dtest$y)
        return(list('coef'=coef,'acc'=c(acc,accmri)))}
    })
    coef<-matrix(do.call(c,lapply(resi,function(x) x$coef)),ncol=length(cutoff))
    #acc<-unlist(lapply(resi,function(x) x$acc))
    acc<-matrix(unlist(lapply(resi,function(x) x$acc)),nrow=2)
    return(list('beta'=coef,'acc'=acc))
  })
  #acc<-matrix(unlist(lapply(res,function(x) x$acc)),ncol=length(res))
  acc<-abind(lapply(res,function(x) x$acc),along=3)
  return(acc)
}
aggfun_F<-function(acck,betak,dtest){
  
  res<-apply(acck,MARGIN=1,function(acc){
    
    acc<-0.5-acc #larger is better, abs() larger is also better
    resi<-lapply(cutoff,function(p0){
      #inx<-which(acc<p0);hati<-betak[,inx]
      inx<-which((acc)>(0.5-p0))
      acci<-acc[inx];hati<-t(t(betak[,inx])*sign(acci)) #change sign
      
      if(length(inx)==0){return(list('coef'=rep(NA,1+nti),'acc'=NA))}else{
        hatw<-abs(acci)/sum(abs(acci))
        coef<-as.vector(hati%*%hatw)
        acc<-mean(((as.vector(coef[1]+dtest$x%*%coef[-1]/nti)>0)*2-1)!=dtest$y)
        return(list('coef'=coef,'acc'=acc))}
    })
    coef<-matrix(do.call(c,lapply(resi,function(x) x$coef)),ncol=length(cutoff))
    acc<-unlist(lapply(resi,function(x) x$acc))
    return(list('beta'=coef,'acc'=acc))
  })
  acc<-matrix(unlist(lapply(res,function(x) x$acc)),ncol=length(res))
  return(acc)
}

#### experiment ----
## parameters
nti<-50;ti<-(1:nti)/nti
nbasis<-4
order<-min(nbasis,4)
knots<-seq(0,1,1/(nbasis-order+1))
basis<-create.bspline.basis(c(0,1),nbasis,order,knots)
basismat<-eval.basis(ti,basis)
mat<-ginv(t(basismat)%*%basismat)%*%t(basismat)#p*p
rm(order,knots,basis)
cutoff<-seq(0,0.5,length.out=10+1)[-1]

cases<-'bothxy'
edpxy<-c(0.1,0.5,1:5,10)
if(cases=='onlyy'){
  edpy<-edpxy;dy_all<-exp(edpy)/(1+exp(edpy));dx_all<-rep(0,length(edpxy))}else if(cases=='onlyx'){
  edpx<-edpxy;dx_all<-2*nbasis/edpx;dy<-rep(1,length(edpxy))}else{
    edpy<-edpxy/(nbasis+1);dy_all<-exp(edpy)/(1+exp(edpy));dx_all<-2*(nbasis+1)/edpxy}
edpa<-exp(edpxy)/(1+exp(edpxy))

nnn<-matrix(c(rep(500,5),rep(100,2),50,100,50,rep(100,3),50,50,25,rep(50,4)),ncol=4)
nnn<-rbind(nnn,c(2500,250,50,50))
nnn<-rbind(nnn,c(5000,500,50,50))
nnn<-rbind(nnn,c(2500,250,100,50))
colnames(nnn)<-c('N','n0','n1','J');ntest<-500

myres<-list();myall<-list()
for(case in 1:nrow(nnn)){
  N<-nnn[case,1];n0<-nnn[case,2];n1<-nnn[case,3];J<-nnn[case,4]
  myres[[case]]<-list()
  
  for(j in 1:length(edpxy)){
  dx<-dx_all[j];dy<-dy_all[j];da<-edpa[j]
  
  set.seed(7777)
  iseed<-sample(1000:10000,500,replace=F)
  cl<-makeCluster(50,type="FORK")
  myres[[case]][[j]]<-parLapply(cl,1:500,function(i){
    tryCatch({
      set.seed(iseed[i])
      
      ## generate data
      dtest<-dgp(ntest);dtrain<-dgp(N);davg<-lapply(1:J,function(i)dgp(n1));mi=2
      dt1<-dpfun(dtrain,q=dy,dx=dx,nol=mi)
      
      ## build weak classifiers with training set
      models<-lapply(1:J,function(jj){
        inx<-sample(N,n0,replace=F)
        d1<-list('y'=dt1$y[inx],'x'=dt1$x[inx,],'beta'=dt1$beta[inx,])
        res1<-vecfun(list('y'=(d1$y+1)/2,'x'=d1$beta),dtest)
        res2<-dwdfun(d1,dtest);res3<-cgfun(d1,dtest)
        beta<-cbind(res1$beta,res2$beta,res3$beta)
        acc<-c(res1$acc,res2$acc,res3$acc);acc1<-accfun(davg[[jj]],beta,da)
        acc<-cbind('test'=acc,acc1)
        return(list('beta'=beta,'acc'=acc))
      })
      beta<-array(NA,dim=c(dim(models[[1]]$beta),J))
      for(ci in 1:J){beta[,,ci]<-models[[ci]]$beta}
      acc<-array(NA,dim=c(dim(models[[1]]$acc),J))
      for(ci in 1:J){acc[,,ci]<-models[[ci]]$acc}
      
      ## misclassification rate of weak classifiers
      accini<-apply(acc,MARGIN=c(1,2),function(x) mean(x,na.rm=T))
      colnames(accini)<-paste('cj',c('test','avg','err','crc'),sep='_')
      rownames(accini)<-c('logi','svm','dwd',paste0('cg',1:5))
      
      ## misclassification rate of MRMA and MR
      acci<-lapply(1:8,function(k) aggfun_T(acc[k,,],beta[,k,],dtest))
      acc_avg<-abind(acci,along=4)
      acc_avg_T<-acc_avg[1,,,] #MRMA
      acc_avg_mr<-acc_avg[2,,,] #MR
      
      ## misclassification rate of MA
      acci<-lapply(1:8,function(k) aggfun_F(acc[k,,],beta[,k,],dtest))
      acc_avg_F<-abind(acci,along=4)
      dimnames(acc_avg_mr)<-dimnames(acc_avg_T)<-dimnames(acc_avg_F)<-
        list(cutoff,c('test','avg','err','crc'),c('logi','svm','dwd',paste0('cg',1:5)))
      
      ## voting and averaging with equal weight
      davg1<-lapply(1:J,function(i) 
        list('y'=c(davg[[i]]$y,dtrain$y[(1:(N/J))+(i-1)*(N/J)]),
             'x'=rbind(davg[[i]]$x,dtrain$x[(1:(N/J))+(i-1)*(N/J),])))
      dt1<-lapply(davg1,function(dtii) dpfun(dtii,q=dy,dx=dx,nol=mi))
      models<-lapply(dt1,function(dtii){
        res1<-vecfun(list('y'=(dtii$y+1)/2,'x'=dtii$beta),dtest)
        res2<-dwdfun(dtii,dtest);res3<-cgfun(dtii,dtest)
        beta<-cbind(res1$beta,res2$beta,res3$beta)
        return(beta)
      })
      beta<-array(NA,dim=c(dim(models[[1]]),J))
      for(ci in 1:J){beta[,,ci]<-models[[ci]]}
      beta_w<-apply(beta,MARGIN=1:2,mean)
      acc<-apply(beta,MARGIN=2:3,function(coefi)
        as.numeric(((as.vector(coefi[1]+dtest$x%*%coefi[-1]/nti)>0)*2-1)) )
      acc_vote<-apply(acc,MARGIN=2,function(x) mean(sign(rowMeans(x))!=dtest$y))
      acc_w<-acc<-apply(beta_w,MARGIN=2,function(coefi)
        mean(as.numeric(((as.vector(coefi[1]+dtest$x%*%coefi[-1]/nti)>0)*2-1)!=dtest$y)) )
      
      ## classifier with all instances
      dall<-c(list(dtrain),davg)
      dall<-list('y'=unlist(lapply(dall,function(di) di$y)),
                 'x'=do.call(rbind,lapply(dall,function(di) di$x)))
      d1<-dpfun(dall,q=1,dx=0,nol=mi)
      acc0<-c(vecfun(list('y'=(d1$y+1)/2,'x'=d1$beta),dtest)$acc,
               dwdfun(d1,dtest)$acc,cgfun(d1,dtest)$acc)
      d1<-dpfun(dall,q=dy,dx=dx,nol=mi)
      acc1<-c(vecfun(list('y'=(d1$y+1)/2,'x'=d1$beta),dtest)$acc,
               dwdfun(d1,dtest)$acc,cgfun(d1,dtest)$acc)
      
      #weak,MA,MRMA,MR,voting,averaging,acc500
      return(list(accini,acc_avg_F,acc_avg_T,acc_avg_mr,cbind(acc_vote,acc_w),cbind(acc0,acc1)))
    },error=function(e){cat("ERROR : i = ",i,", ",conditionMessage(e), "\n")})
  })
  stopCluster(cl)
  print(j)
  save.image("single_server.Rdata")
  }
  
  set.seed(7777)
  iseed<-sample(1000:10000,500,replace=F)
  myall[[case]]<-parLapply(cl,1:500,function(i){
    tryCatch({
      set.seed(iseed[i])
      ## generate data
      dtest<-dgp(ntest);dall<-dgp(N+n1*J);mi=2
      
      ## classifier with all instances
      d1<-dpfun(dall,q=1,dx=0,nol=mi)
      acc0<-c(vecfun(list('y'=(d1$y+1)/2,'x'=d1$beta),dtest)$acc,
              dwdfun(d1,dtest)$acc,cgfun(d1,dtest)$acc)
      
      return(acc0)
    },error=function(e){cat("ERROR : i = ",i,", ",conditionMessage(e), "\n")})
  })
  
  print(case)
  save.image("single_server.Rdata")
}
save.image("single_server.Rdata")

