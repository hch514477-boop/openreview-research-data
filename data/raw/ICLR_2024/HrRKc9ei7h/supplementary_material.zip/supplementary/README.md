0. Both the real datasets, Adult-Income:`adult_reconstruction.csv` and Medical-Cost:`insurance.csv` are in the `data` folder.
1. The two algorithms coded from scratch are in the `bilevel` folder, they are `ORidge.py` and `Anh.py`
2. The `jupyter_notebooks` folder contains `.ipynb` notebooks for each of our experiments.
3. The `plots` and `tables` folders contain the plots and tables used in the paper.
4. The `10` random seeds used for shuffling the data are in `bilevel.Groupwise_seedruns.py` (see its constructor), they are `[473, 503, 623, 550, 692, 989, 617, 458, 301, 205]`
5. The random numpy seed we fix for the synthetic data generation ` = 21` and it is set explicitly in `groupwise_synthetic.ipynb`
6. The conda environment `greg_env.yml` has all dependencies.