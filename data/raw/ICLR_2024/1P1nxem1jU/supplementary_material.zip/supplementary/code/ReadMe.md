<!-- Improved compatibility of back to top link: See: https://github.com/othneildrew/Best-README-Template/pull/73 -->
<a name="readme-top"></a>


<!-- PROJECT LOGO -->
<br />
<div align="center">


  <h1 align="center">Dual-Prism</h1>

  <p align="center">
    A Spectral Perspective on Graph Data Augmentation for Graph Classification
    <!-- <br />
    <a href="https://github.com/othneildrew/Best-README-Template"><strong>Explore the docs »</strong></a>
    <br />
    <br />
    <a href="https://github.com/othneildrew/Best-README-Template">View Demo</a>
    ·
    <a href="https://github.com/othneildrew/Best-README-Template/issues">Report Bug</a>
    ·
    <a href="https://github.com/othneildrew/Best-README-Template/issues">Request Feature</a> -->
  </p>
</div>



<!-- TABLE OF CONTENTS -->
<details>
  <summary style="font-size: 20px;">Table of Contents</summary>
  <ol>
    <li><a href="#environment-setup">Environment Setup</a></li>
    <li><a href="#run-the-code">Run the Code</a></li>
  </ol>
</details>

## Environment Setup
This lightweight repository is implemented using python 3.7.12, pytorch 1.7.1 and cuda 10.1. All the relied packages are listed in the `environment.yaml` file. Run the following code, which will creates and activates a virual environment named *dp*.

```bash
conda env create -f environment.yaml
conda activate dp
```
<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Run the Code

To run the code, please use the following command:

```sh
cd .

CUDA_VISIBLE_DEVICES=0 python main.py
```

The dataset will be downloaded to the `datasets` folder and processed automatically. The running log will be stored in the `logs` folder. The summarized running results will be stored in the `results` folder.

<p align="right">(<a href="#readme-top">back to top</a>)</p>