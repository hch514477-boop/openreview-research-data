#!/bin/bash

export TRANSFORMERS_CACHE='/data/private_models/[ANONYMIZED]_models/huggingface'

CONFIG_NAME=125M accelerate launch --num_processes 7 --config_file ../../configs/accelerate/zero2-bf16.yaml ppo_hh.py

