## Reinforcement Learning Experiments

To reproduce the experiments in the paper, use the `launch.sh` script with the appropriate arguments. The script shows an example of launching the experiments for optimizing different sized policies against the Small proxy model.