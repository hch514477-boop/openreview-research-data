#!/bin/bash

sbatch --nodes=1 --gpus-per-node=4 --time=48:00:00 run.sh gpt2-large 2 4 1
sbatch --nodes=2 --gpus-per-node=4 --time=48:00:00 run.sh gpt2-xl 2 4 2
sbatch --nodes=8 --gpus-per-node=2 --time=48:00:00 run.sh llama-7b 8 2 3
