## Best-of-n inference
example: `bash launch_bon_inference.sh 16`