### White Box Optimization

The launch*.sh files contain the scripts for adversarial training
