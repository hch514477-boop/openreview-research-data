#!/bin/bash

# get the value from argument $1
end_val=$1

# loop from 0 to end_val
for ((a=0; a<end_val; a++))
do
    # sbatch run_bon_inference_separate_gpus.sh a b
    sbatch run_bon_inference_separate_gpus.sh $a $end_val
done
