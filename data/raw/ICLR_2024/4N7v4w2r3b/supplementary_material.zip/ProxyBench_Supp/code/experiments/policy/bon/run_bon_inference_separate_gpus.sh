#!/bin/bash
#SBATCH --gpus=1
#SBATCH --time=48:00:00
#SBATCH --output=logs/bon_inference_%j.out

# python create_pairwise_inference.py --model_name=$1 --split=train --num_completions_per_prompt 2 --outer_batch_size 16 --inner_batch_size 2 --gpu_num=$2 --total_gpus=8
# python create_pairwise_inference.py --model_name=$1 --split=test --num_completions_per_prompt 2 --outer_batch_size 16 --inner_batch_size 2 --gpu_num=$2 --total_gpus=8
python bon_inference.py --gpu_num=$1 --total_gpus=$2
