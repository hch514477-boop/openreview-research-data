#!/bin/bash

## Example usage:
seed=1
proxy_size="small"
proxy_path="deberta-v3-small_gm_labeled_5e-06_8_2_epoch2_sam0.pkl"
num_train=0
sbatch --nodes=1 --gpus=4 --cpus-per-gpu=16 --time=120:00:00 --qos=restricted_qos --out=ref_hh_%j_gpt2-xl.out \
       run_merged_chatbot.sh $((60062 + seed)) $num_train gpt2-xl $proxy_size $proxy_path $seed 3
sbatch --nodes=1 --gpus=4 --cpus-per-gpu=16 --time=120:00:00 --qos=restricted_qos --out=ref_hh_%j_gpt2-large.out \
       run_merged_chatbot.sh $((60063 + seed)) $num_train gpt2-large $proxy_size $proxy_path $seed 3
sbatch --nodes=1 --gpus=8 --cpus-per-gpu=16 --time=120:00:00 --qos=restricted_qos --out=final_ref_hh_%j_llama.out \
       run_merged_chatbot.sh $((62200 + seed)) $num_train llama $proxy_size $proxy_path $seed 7
