# ProxyBench

This folder includes the supplementary material for the paper "Benchmarking Neural Network Proxy Robustness to Optimization Pressure."
You can find the PDF file and the code to reproduce the benchmark results under this folder.
