Install and activate the environments.

```
    conda env create -f environment.yaml
    conda activate environment
```

To try our model, try the following command:
```
    python main.py --dataname [name]
```
where name can be ['cora', 'citeseer', 'pubmed', 'computer', 'photo', 'cs', 'physics'].

To examine the overlapped information between node features (as well as graph-augmented node features), please refer to the following two files:
```
    plot_distribution_raw.ipynb
    plot_distribution_aug.ipynb
```
