#!/bin/bash

git clone --recursive https://github.com/DLR-RM/rl-baselines3-zoo.git third_party/rl-baselines3-zoo
