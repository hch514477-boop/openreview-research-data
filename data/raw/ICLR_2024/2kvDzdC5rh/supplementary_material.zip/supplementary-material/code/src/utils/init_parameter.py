from argparse import ArgumentParser

class ArgumentDataObj():
    def __init__(self) -> None:
        self.data_dir = 'data'
        self.dataset = ''
        self.save_results_path = 'outputs'
        self.pretrain_dir = 'pretrain_models'
        self.bert_model = 'uncased_L-12_H-768_A-12'
        self.max_seq_length = None
        self.feat_dim = 768
        self.warmup_proportion = 0.1
        self.freeze_bert_parameters = False
        self.save_model = False
        self.pretrain = False
        self.dataset = None
        self.known_cls_ratio = 0.75
        self.cluster_num_factor = 1.0
        self.seed = 0
        self.method = 'DeepAligned'
        self.labeled_ratio = 0.1
        self.gpu_id = '0'
        self.train_batch_size = 128
        self.eval_batch_size = 64
        self.wait_patient = 20
        self.num_pretrain_epochs = 100
        self.num_train_epochs = 100
        self.lr_pre = 5e-5
        self.lr = 5e-5
        self.label_type = 'original'

def init_model():

    arguments = ArgumentDataObj() 
    
    
    return arguments
