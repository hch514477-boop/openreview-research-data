# IntentGPT

## Do symbolic link for the data

```
ln -s /mnt/colab_public/datasets/open_set_intent/data data
```

## Run the model
0. Install the requirements from environment.yml

``` 
conda env create -f environment.yaml
conda activate intent
pip install -e .
```
1. Obtain OpenAI and AnyScale tokens
    You can set the token in the environment variable OPENAI_API_KEY

2. Choose a config file from configs/ folder
3. Run main.py with the config file

``` 
python main.py config=configs/config.yaml
```

4. Try sending more parameters through command line

```
python main.py config=configs/config.yaml gpt_model=gpt-4 semantic_few_shot=true feedback_discovered_categories=true semantic_feedback_discovery=false use_wandb=false known_cls_ratio=0.75 num_few_shot_examples=10 force_recompute=false prompt_type=hard_prompt
```
