Paper's appendix is contained in `sampling simplicial cycles appendix.pdf`

Code for training language models using described methods (ignore, prompt, mask) is in `language-modeling.ipynb`

Code for training commutator translator is in `commutator-translator.ipynb`

Code for running baseline models is in `baselines.ipynb`

Utility code for working with free group (with setup recommendations) is contained in the folder `freegroup`

Top-level `requirements.txt` describes dependencies needed for running baselines and training procedures of the models

