#!/usr/bin/env python3
from params_proto.hyper import Sweep
import sys
import os
from rpi.scripts.sweep.default_args import Args
this_file_name = sys.argv[0]

with Sweep(Args) as sweep:
    Args.lmd = 0.9
    with sweep.product:
        Args.ase_sigma = [i for i in range(1, 6)]
        Args.seed = [i for i in range(8)]

sweep.save(os.path.splitext(this_file_name)[0] + '.jsonl')
