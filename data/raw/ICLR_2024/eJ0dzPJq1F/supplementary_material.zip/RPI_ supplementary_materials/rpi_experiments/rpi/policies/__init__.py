#!/usr/bin/env python3
# from pfrl.policies.deterministic_policy import *  # NOQA
from rpi.policies.gaussian_policy import *  # NOQA
from rpi.policies.softmax_policy import *  # NOQA
