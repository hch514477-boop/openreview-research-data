The theory justification exeperiments (Section 4.2) are implemented in notebooks "./NasRec/notebooks/EmpiricalJustification4Theory.ipynb" and "./NasRec/notebooks/empirical-justification-for-the-theory-warmup_to_100_Percent.ipynb

The NAS benchmarks (Section 4.3) are implemented in NASLib. 

The RecSys related experiments (Section 4.4) are implemented in NasRec.

The specific implementation details can be found in README.md in each repository.