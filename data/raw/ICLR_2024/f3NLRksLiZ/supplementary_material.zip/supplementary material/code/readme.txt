In the files "Deep_reservoir_pytorch.py" and "Deep_reservoir_keras.py," we have implemented reservoir computing for PyTorch and Keras, respectively.

The file "reservoirtransformers.py" represents the integration of ensemble reservoir computing with transformers.

The "configuration.py" represents the hyper-parameter configuration for reservoirtransformers

Within the "example notebook" folder, we have provided several examples for training models, including regression, classification, and chaotic scenarios.