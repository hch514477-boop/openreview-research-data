library(SAVER)
library(SingleCellExperiment)

train_matrix <- assay(sce, 'X')
train_matrix <- as.matrix(train_matrix)

saver_output <- saver(train_matrix, ncores = 64)

saver_mat <- saver_output$estimate

out <- as.matrix(saver_mat)

# return
out