library(SAVERX)
library(SingleCellExperiment)

train_matrix <- assay(sce, 'X')
train_matrix <- t(as.matrix(train_matrix))

file <- saverx(data.matrix=train_matrix, data.species='Human', ncores=64)
denoised.data <- readRDS(file)
out <- t(as.matrix(denoised.data))

# return
out