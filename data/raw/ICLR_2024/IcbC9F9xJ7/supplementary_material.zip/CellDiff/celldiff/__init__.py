__all__ = ["config"]

from celldiff import config
