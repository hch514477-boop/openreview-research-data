#!/bin/bash

echo "Task:"
read TASK

echo "Dataset:"
read DATASET

if [ $TASK == 'denoising' ]; then
    echo "MASK_RATIO:"
    read MASK_RATIO
else
    MASK_RATIO=10
fi

echo "Model:"
read MODEL

for SEED in 10 11 12 13 14 
do
    python run_baseline.py --task ${TASK} --dataset ${DATASET} --model ${MODEL} --seed ${SEED} --mask_ratio ${MASK_RATIO}
done