Required library:
PyTorch 11.6
SimpleITK 2.2.1
Numpy 1.23.5


Registration:
command "python PIRATE.py"
The moving and fixed images are in the folder "data". The output will be written to the folder "output".