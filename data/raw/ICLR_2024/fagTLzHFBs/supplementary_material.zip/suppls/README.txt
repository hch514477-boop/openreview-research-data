In this supplemental material, we provide two parts of the compared results.

For the recovery of the appearance of the FMO in the form of videos,
we provide two pairs of videos to compare the qualitative results of DeFMO and our method on the Falling Object sequences (key and rubber) in the directory "recover videos", "key_DeFMO.avi", "key_LDINet.avi",  "rubber_DeFMO.avi", and "rubber_LDINet.avi", respectively.

For the visualization of the outputs of linear interpolation and affine interpolation,
we provide qualitative results to compare the effect of the linear interpolation and affine interpolation in the file "linear_vs_affine.pdf".