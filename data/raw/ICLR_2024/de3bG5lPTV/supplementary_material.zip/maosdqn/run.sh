/bin/hostname
module load tensorflow/2.7.0
pip install torch==1.9.1+cu111 torchvision==0.10.1+cu111 torchaudio==0.9.1 -f https://download.pytorch.org/whl/torch_stable.html
pip install --user -r requirements.txt
cd lb-foraging
pip install -e .
cd ..
#python3 src/main.py --config=maosdqn --env-config=matrixgame
#python3 src/main.py --config=maosdqn --env-config=matrixgame3
#python3 src/main.py --config=maosdqn --env-config=tensorgame
#python3 src/main.py --config=maosdqn --env-config=gymma with env_args.time_limit=25 env_args.key="lbforaging:Foraging-5x5-2p-1f-coop-v2"
#python3 src/main.py --config=maosdqn --env-config=gymma with env_args.time_limit=40 env_args.key="lbforaging:Foraging-8x8-2p-2f-coop-v2"
#python3 src/main.py --config=maosdqn --env-config=gymma with env_args.time_limit=50 env_args.key="lbforaging:Foraging-10x10-3p-5f-v2"
#python3 src/main.py --config=maosdqn --env-config=gymma with env_args.time_limit=40 env_args.key="lbforaging:Foraging-10x10-3p-1f-pe-v2"
python3 src/main.py --config=maosdqn --env-config=gymma with env_args.time_limit=50 env_args.key="lbforaging:Foraging-12x12-6p-1f-pe-v2"