#!/bin/zsh
python -m src.train \
    --data ~/datasets/procgen/"$SIMULATOR"/batch00.data \
    --solver AStarSearch \
    --trainer ModelBasedTrainer \
    --batch-size 256 \
    --learning-rate 1e-4 \
    --max-iterations 200000 \
    --n-steps "$NS" \
    --n-trials "$NT" \
    --w-tdl "$TDL" \
    --w-oodl "$OODL" \
    --w-rwl "$RWL" \
    --w-trl "$TDL" \
    --exp-name "$SIMULATOR"-AStarSearch-ModelBasedTrainer-NS="$NS"
