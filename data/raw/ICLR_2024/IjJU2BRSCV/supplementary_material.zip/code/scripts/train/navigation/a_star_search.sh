#!/bin/zsh
python -m src.train \
    --data data/navigation/train/agent_in_center_hall/medium_1K.data \
    --solver AStarSearch \
    --trainer ModelBasedJointTrainer \
    --batch-size 200 \
    --learning-rate 1e-4 \
    --max-iterations 50000 \
    --n-steps "$NS" \
    --n-trials "$NT" \
    --exploration-constant "$E" \
    --w-tdl "$TDL" \
    --w-oodl "$OODL" \
    --w-rwl "$RWL" \
    --w-trl "$TDL" \
    --exp-name "$SIMULATOR"-AStarSearch-JointTraining-n_steps="$NS"-n_trials="$NT"-exploration="$E"
