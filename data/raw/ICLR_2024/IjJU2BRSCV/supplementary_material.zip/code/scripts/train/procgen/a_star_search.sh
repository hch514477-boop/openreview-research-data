#!/bin/zsh
python -m src.train \
    --data ~/datasets/procgen/"$SIMULATOR"/batch00.data \
    --solver AStarSearch \
    --trainer AStarSearchTrainer \
    --batch-size 256 \
    --learning-rate 1e-4 \
    --max-iterations 200000 \
    --n-steps "$NS" \
    --n-trials "$NT" \
    --exploration-constant "$E" \
    --w-tdl "$TDL" \
    --w-oodl "$OODL" \
    --w-rwl "$RWL" \
    --w-trl "$TRL" \
    --exp-name "$SIMULATOR"-AStarSearch-JointTraining-NS="$NS"-NT="$NT"-E="$E"
