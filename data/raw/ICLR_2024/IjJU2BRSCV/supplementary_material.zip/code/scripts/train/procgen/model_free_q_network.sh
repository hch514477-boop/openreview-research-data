#!/bin/zsh
python -m src.train \
    --data ~/datasets/procgen/"$SIMULATOR"/batch00.data \
    --solver ModelFreeQNetwork \
    --trainer ModelFreeTrainer \
    --batch-size 256 \
    --learning-rate 1e-4 \
    --max-iterations 200000 \
    --n-steps 0 \
    --n-trials 0 \
    --w-tdl "$TDL" \
    --w-oodl "$OODL" \
    --exp-name "$SIMULATOR"-ModelFreeQNetwork
