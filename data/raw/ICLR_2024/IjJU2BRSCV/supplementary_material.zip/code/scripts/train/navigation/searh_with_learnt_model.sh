#!/bin/zsh
python -m src.train \
    --data data/navigation/train/agent_in_center_hall/medium_1K.data \
    --solver AStarSearch \
    --trainer ModelBasedTrainer \
    --batch-size 200 \
    --learning-rate 1e-4 \
    --max-iterations 50000 \
    --n-steps "$NS" \
    --n-trials "$NT" \
    --w-tdl "$TDL" \
    --w-oodl "$OODL" \
    --w-rwl "$RWL" \
    --w-trl "$TRL" \
    --exp-name "$SIMULATOR"-AStarSearch-ModelBasedTrainer-NS="$NS"
