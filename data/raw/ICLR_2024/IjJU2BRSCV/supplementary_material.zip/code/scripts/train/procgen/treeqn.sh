#!/bin/zsh
python -m src.train \
    --data ~/datasets/procgen/"$SIMULATOR"/batch00.data \
    --solver TreeQN \
    --trainer TreeQNTrainer \
    --batch-size 256 \
    --learning-rate 1e-4 \
    --max-iterations 200000 \
    --n-steps "$NS" \
    --w-tdl "$TDL" \
    --w-oodl "$OODL" \
    --w-rwl "$RWL" \
    --exp-name "$SIMULATOR"-TreeQN_NS="$NS"
