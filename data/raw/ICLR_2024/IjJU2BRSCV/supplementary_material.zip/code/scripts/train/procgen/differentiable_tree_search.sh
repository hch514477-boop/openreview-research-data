#!/bin/zsh
python -m src.train \
    --data ~/datasets/procgen/"$SIMULATOR"/batch00.data \
    --solver DifferentiableTreeSearch \
    --trainer ModelBasedJointTrainer \
    --batch-size 256 \
    --learning-rate 1e-4 \
    --max-iterations 200000 \
    --n-steps "$NS" \
    --n-trials "$NT" \
    --w-tdl "$TDL" \
    --w-oodl "$OODL" \
    --w-rwl "$RWL" \
    --w-trl "$TRL" \
    --w-tsl "$TSL" \
    --exp-name "$SIMULATOR"-DifferentiableTreeSearch-JointTraining-n_steps="$NS"-n_trials="$NT"-TSL="$TSL"
