#!/bin/zsh
python -m src.train \
    --data data/navigation/train/agent_in_center_hall/medium_1K.data \
    --solver ModelFreeQNetwork \
    --trainer ModelFreeTrainer \
    --batch-size 200 \
    --learning-rate 1e-4 \
    --max-iterations 50000 \
    --w-tdl "$TDL" \
    --w-oodl "$OODL" \
    --exp-name "$SIMULATOR"-ModelFreeQNetwork
