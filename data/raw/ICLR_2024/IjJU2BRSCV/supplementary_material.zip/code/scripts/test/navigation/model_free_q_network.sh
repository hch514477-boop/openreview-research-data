#!/bin/zsh
SIMULATOR=navigation-1exit \
  python -m src.evaluate \
  --solver ModelFreeQNetwork \
  --weights models/navigation/model_free_q_network.model \
  --n-levels 10000 \
  --batch-size 1000