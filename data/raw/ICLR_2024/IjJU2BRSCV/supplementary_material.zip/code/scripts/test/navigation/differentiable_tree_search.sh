#!/bin/zsh
SIMULATOR=navigation-1exit \
  python -m src.evaluate \
  --solver DifferentiableTreeSearch \
  --weights models/navigation/differentiable_tree_search.model \
  --n-levels 10000 \
  --batch-size 1000