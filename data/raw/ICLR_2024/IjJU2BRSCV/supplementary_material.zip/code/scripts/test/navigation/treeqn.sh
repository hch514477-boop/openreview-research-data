#!/bin/zsh
SIMULATOR=navigation-1exit \
  python -m src.evaluate \
  --solver TreeQN \
  --weights models/navigation/treeqn.model \
  --n-levels 10000 \
  --batch-size 1000