#!/bin/zsh
SIMULATOR=navigation-1exit \
  python -m src.evaluate \
  --solver AStarSearch \
  --weights models/navigation/searh_with_learnt_world_model.model \
  --n-levels 10000 \
  --batch-size 1000