# SHINE
python detection.py
python explain.py
python retrain.py
python eval.py  # evaluate retrained policy in the poisoned environment
python eval.py --no_poison  # evaluate retrained policy in the clean environment

# NC
python explain_nc.py
python retrain.py -m nc
python eval.py -m nc
python eval.py -m nc --no_poison

# directly retraining
python retrain.py -m direct
python eval.py -m direct
python eval.py -m direct --no_poison
