# Requirements

- Python 3.10
- Pip packages:
```bash
pip install -r requirements.txt
```

# Usage

The basic usage of the training script is as follows:
```bash
python train.py -c [config] -o [override options] -l [log directory]
```

In `commands.sh`, we provide the all commands used to train the models in the paper.
After training, we evaluate the models using the following command:
```bash
python evaluate.py -l [log directory]
```
The SB-MCL (MAP) scores can be attained by turning on the `map` option.
```bash
python evaluate.py -l [SB-MCL log directory] -o "map=True"
```

# Datasets

All datasets are downloaded automatically by the code.
Note that downloading the CASIA dataset may take days.
