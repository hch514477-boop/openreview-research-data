# import module
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error


# compute MAPE
def MAPE(y_pred, y_true):
    eps = 1
    return np.mean(np.abs((y_pred - y_true) / (y_true+eps)))

# compute wMAPE
def WMAPE(y_pred, y_true):
    return np.sum(np.abs((y_pred - y_true))) / np.sum(np.abs(y_true))

# some other MAPE
def WMAPE_1(y_pred, y_true):
    return np.sum(np.abs((y_pred - y_true)))

def WMAPE_2(y_pred, y_true):
    return np.sum(np.abs(y_true))

