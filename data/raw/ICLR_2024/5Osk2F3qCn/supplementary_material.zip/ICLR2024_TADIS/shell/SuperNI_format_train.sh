ids=0
N_GPU=4
gpu_vis=0,1,2,3
MASTER_PORT=1234


MODEL="t5-xl-lm-adapt"
MODEL_PATH="google/t5-xl-lm-adapt"

NUM_EXP=1

WORLD_SIZE=$N_GPU CUDA_VISIBLE_DEVICES=$gpu_vis torchrun --nproc_per_node $N_GPU --master_port $MASTER_PORT \
    t5_instruction_tuning.py \
    --model_name_or_path $MODEL_PATH \
    --train_data_path "train_examples_SuperNI.jsonl" \
    --output_dir "output dir" \
    --cache_dir "./" \
    --num_train_epochs 5 \
    --model_max_length 1024 \
    --per_device_train_batch_size 4 \
    --per_device_eval_batch_size 4 \
    --gradient_accumulation_steps 16 \
    --save_strategy "epoch" \
    --evaluation_strategy "no" \
    --learning_rate 2e-4 \
    --logging_steps 2 \
    --lr_scheduler_type "cosine" \
    --report_to "wandb" \
    --quantify False \
    --bf16 True \
    --run_name "your run name" \
    --gradient_checkpointing True \
    --set_seed 42 \
    --generation_max_length 128\
    --generation_num_beams 1 \
    --project_name "your project name" \
    --fsdp "full_shard auto_wrap" \
    --fsdp_transformer_layer_cls_to_wrap "T5Block" 