ids=0
N_GPU=1
gpu_vis=1
MASTER_PORT=2342


MODEL="t5-xl-lm-adapt"
MODEL_PATH="google/t5-xl-lm-adapt"
CHECKPOINT=""

NUM_EXP=1



########### zero-shot ###########
WORLD_SIZE=$N_GPU CUDA_VISIBLE_DEVICES=$gpu_vis torchrun --nproc_per_node $N_GPU --master_port $MASTER_PORT \
    t5_eval.py \
    --random_seed 42 \
    --output_dir "output dir" \
    --project_name "your project name" \
    --run_name "your run name" \
    --model_name_or_path "eval model checkpoint" \
    --data_path "test_def_SuperNI" \
    --eval_batch_size 8 \
    --max_new_tokens 128 \
    --temperature 0 \
    --max_length 1024 \
    --decoder_input True \
    --tokenizer $MODEL_PATH \

############ few-shot ###########
WORLD_SIZE=$N_GPU CUDA_VISIBLE_DEVICES=$gpu_vis torchrun --nproc_per_node $N_GPU --master_port $MASTER_PORT \
    t5_eval.py \
    --random_seed 42 \
    --output_dir "output dir" \
    --project_name "your project name" \
    --run_name "your run name" \
    --model_name_or_path "eval model checkpoint" \
    --data_path "test_def_SuperNI" \
    --eval_batch_size 8 \
    --max_new_tokens 128 \
    --temperature 0 \
    --max_length 1024 \
    --tokenizer $MODEL_PATH \

