# Towards Energy Efficient Spiking Neural Networks: An Unstructured Pruning Framework

## Installing Dependencies

```bash
pip3 install torch torchvision
pip3 install tensorboard thop spikingjelly
```

## Usage

To reproduce the experiments on CIFAR10 in the paper, simply follow the default settings

```bash
python main.py
```

You can specify the output path and the weight of penalty term $\lambda$ by

```bash
python main.py --penalty-lmbda <lambda> --output-dir <path>
```

To reproduce the experiments on other datasets, follow the settings in the appendix
