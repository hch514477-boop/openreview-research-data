mkdir -p iclr24_plots
python scripts/plots_iclr24_comparison.py --results-dir ./iclr24_results/alg-comparison --output-dir iclr24_plots/
python scripts/plots_iclr24_variability.py --results-dir ./iclr24_results/variability-study --output-dir iclr24_plots/
