# Retro-fallback code

Our implementation of retro-fallback, code to run experiments, and experimental data are in this repo.

To run experiments, the reaction model repo and our custom fork of syntheseus must be in the `PYTHONPATH`.

- Start by running code in the folders `iclr24_expts/eMolecules` and `iclr24_expts/guacamol` directories to produce the inventory and test molecules.
- To run algorithm comparison experiments, run `bash iclr24_bash_scripts/run_all_comparison_experiments.sh` (by default they won't run because all the output files are present)
- To run the variability study, run `bash iclr24_bash_scripts/run_all_variability_experiments.sh`
- To reproduce our plots, run `bash iclr24_bash_scripts/make_plots.sh`
