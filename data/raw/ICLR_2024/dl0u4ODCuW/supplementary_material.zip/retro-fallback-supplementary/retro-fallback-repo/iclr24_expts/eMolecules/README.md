# eMolecules

Contains code to process and standardize the eMolecules inventory.

Actually it didn't fit in the 100Mb limit, so I just compressed the final inventory with `xz`. Use `unxz` to decompress.
