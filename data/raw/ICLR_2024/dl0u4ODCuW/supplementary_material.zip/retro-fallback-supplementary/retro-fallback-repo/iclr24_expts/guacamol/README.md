Contains code to produce the training / validation / testing sets from the GuacaMol datasets.

Just run `bash create_data.sh`
