Example code can be excuted by running GATE.ipynb cells sequentially.
Sample datasets are included in data folder.

Dependency:
rdkit : 2022.9.2
pytorch : 1.11.0
torch-geometric : 2.0.4
pytorch-lightning : 1.9.0