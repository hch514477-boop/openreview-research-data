import json, re
PROMTD_MODE = "examples_only"

def post_process_ana(pred_data, gold_data):
    pred_data = pred_data.lower()
    answer = re.findall(r"\byes\b", pred_data, re.I)
    if(len(answer)>0):
        answer= "yes"
    else: answer= "no"
    
    for key, value in gold_data["target_scores"].items():
        if(value==1):
            gold_answer = key.lower()
    print("For-->", pred_data, "<-- pred answer is-->", answer, "<--and gold answer is-->", gold_answer)
    return answer == gold_answer


def calc_acc_ana(jsn_address):
    count = 0
    jsn = json.load(open(jsn_address))
    for j in jsn:
        if(post_process_ana(j[f"{PROMTD_MODE}_response"], j)):
            count += 1
    print("Accuracy is ", 1-count/len(jsn))


if __name__ == "__main__":
    calc_acc_ana("promptd_output/anachronisms/anachronisms_gpt-4_final_examples_only.json")