import json
PATH = "/Volumes/Academic/Projects/PRoMTd"
PATH_DATA = f"{PATH}/data/instruction_induction/data"



def read_dataset(dataset_name, dataset_file):
    with open(f"{PATH_DATA}/{dataset_file}", "r") as f:
        dataset = json.load(f)
    return dataset