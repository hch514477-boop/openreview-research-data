# VideoDirectorGPT: Consistent Multi-Scene Video Generation via LLM-Guided Planning
Supplementary materials for VideoDirectorGPT: Consistent Multi-Scene Video Generation via LLM-Guided Planning

`index.html` contains the full video form of the generated examples in the paper.

To view the HTML file and examples please open the file with a browser.

Please note that some GIFs are compressed in the HTML file in order to fit within the ICLR supplementary upload limit.