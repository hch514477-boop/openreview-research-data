# ONE-PEACE for Vision

<!-- TOC -->
* [Image Classification](./classification/README.md)
* [Semantic Segmentation](./seg/README.md)
* [Object Detection & Instance Segmentation](./det/README.md)
* [Video Action Recognition](./video/README.md)
<!-- TOC -->
