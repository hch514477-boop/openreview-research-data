﻿Open the index.html. And wait for a while (maybe one or two minutes), all of the audios will be ready. You can check them.
