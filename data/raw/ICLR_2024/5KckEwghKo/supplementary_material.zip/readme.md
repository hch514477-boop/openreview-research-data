Code of OGC and GGCM
====

PyTorch implementation of OGC and GGCM for semi-supervised node classification [1].


## Running OGC:

``` 
python main_ogc.py --dataset cora 
python main_ogc.py --dataset citeseer 
python main_ogc.py --dataset pubmed 
```

## Running GGCM:
``` 
python main_ggcm.py --dataset cora
python main_ggcm.py --dataset citeseer
python main_ggcm.py --dataset pubmed
``` 
## References

[1] From Cluster Assumption to Graph Convolution: Graph-based Semi-Supervised Learning Revisited.
