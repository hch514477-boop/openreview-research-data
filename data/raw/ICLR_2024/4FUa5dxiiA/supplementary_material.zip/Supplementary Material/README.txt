Folder Beta_VMBPO contains the code for OpenAI Gym benchmark. 

To run MBPO: set parameter agent to SAC, parameter model to MBPO, parameter automatic_beta_tuning to False, and parameter real_ratio to 0.05.

To run VMBPO: set parameter agent to MPO, parameter model to VMBPO, parameter automatic_beta_tuning to False, and parameter real_ratio to 0.05.

To run beta-VMBPO: set parameter agent to SAC, parameter model to VMBPO, parameter automatic_beta_tuning to True, and parameter real_ratio to 0.05.

To run SAC: set parameter agent to SAC, parameter model to NoModel, parameter automatic_beta_tuning to False, and parameter real_ratio to 1.0.

Execute main_beta_vmbpo.py

This experiment requires libraries: numpy, pytorch, mujoco, gym, pickle, and matplotlib.

------------------------------------------------------------------------------------

Folder Tabular_VMBPO contains the code for the cliff and grid experiment. 
parallel_beta contains the code for VMBPO, MnM and Beta-VMBPO
all_algorithm contains the code for Q-learning

This experiment requires libraries: numpy and matplotlib.
