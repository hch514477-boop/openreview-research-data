python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar10 -ar resnet20 -s 10 --imb_type exp --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 500 --bins 10 --t_gap 0.4 --c_gap 0.4 --cl_gap 0.7 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar10 -ar resnet20 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 500 --bins 10 --t_gap 0.8 --c_gap 0.8 --cl_gap 1.1 --all yes

python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar10 -ar resnet20 -s 10 --imb_type poly --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 500 --bins 10 --t_gap 0.55 --c_gap 0.55 --cl_gap 0.9 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar10 -ar resnet20 -s 10 --imb_type poly --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 500 --bins 10 --t_gap 0.5 --c_gap 0.5 --cl_gap 1.15 --all yes

python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar10 -ar resnet20 -s 10 --imb_type major --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 500 --bins 10 --t_gap 0.3 --c_gap 0.3 --cl_gap 0.8 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar10 -ar resnet20 -s 10 --imb_type major --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 500 --bins 10 --t_gap 0.5 --c_gap 0.3 --cl_gap 0.85 --all yes


python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar100 -ar resnet20 -s 10 --imb_type exp --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 50 --bins 25 --t_gap 0.3 --c_gap 0.45 --cl_gap 0.52 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar100 -ar resnet20 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 50 --bins 25 --t_gap 0.3 --c_gap 0.45 --cl_gap 0.56 --all yes

python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar100 -ar resnet20 -s 10 --imb_type poly --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 50 --bins 25 --t_gap 0.3 --c_gap 0.45 --cl_gap 0.63 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar100 -ar resnet20 -s 10 --imb_type poly --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 50 --bins 25 --t_gap 0.3 --c_gap 0.45 --cl_gap 0.59 --all yes

python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar100 -ar resnet20 -s 10 --imb_type major --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 50 --bins 25 --t_gap 0.3 --c_gap 0.45 --cl_gap 0.52 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset cifar100 -ar resnet20 -s 10 --imb_type major --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 50 --bins 25 --t_gap 0.3 --c_gap 0.45 --cl_gap 0.5 --all yes


python -W ignore ICP/main_aps.py --alpha 0.1 --dataset mini -ar resnet20 -b 128 -s 10 --imb_type exp --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 150 --bins 25 --t_gap 0.5 --c_gap 0.8 --cl_gap 0.8 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset mini -ar resnet20 -b 128 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 150 --bins 25 --t_gap 0.55 --c_gap 0.95 --cl_gap 0.9 --all yes

python -W ignore ICP/main_aps.py --alpha 0.1 --dataset mini -ar resnet20 -b 128 -s 10 --imb_type poly --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 150 --bins 25 --t_gap 0.35 --c_gap 0.8 --cl_gap 0.6 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset mini -ar resnet20 -b 128 -s 10 --imb_type poly --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 150 --bins 25 --t_gap 0.35 --c_gap 0.8 --cl_gap 0.75 --all yes

python -W ignore ICP/main_aps.py --alpha 0.1 --dataset mini -ar resnet20 -b 128 -s 10 --imb_type major --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 150 --bins 25 --t_gap 0.45 --c_gap 0.75 --cl_gap 0.7 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset mini -ar resnet20 -b 128 -s 10 --imb_type major --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 150 --bins 25 --t_gap 0.45 --c_gap 0.8 --cl_gap 0.75 --all yes


python -W ignore ICP/main_aps.py --alpha 0.1 --dataset food -ar resnet20 -b 256 -s 10 --imb_type exp --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 125 --bins 25 --t_gap 0.45 --c_gap 0.9 --cl_gap 0.75 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset food -ar resnet20 -b 256 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 125 --bins 25 --t_gap 0.45 --c_gap 0.95 --cl_gap 0.9 --all yes

python -W ignore ICP/main_aps.py --alpha 0.1 --dataset food -ar resnet20 -b 256 -s 10 --imb_type poly --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 125 --bins 25 --t_gap 0.45 --c_gap 0.9 --cl_gap 0.75 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset food -ar resnet20 -b 256 -s 10 --imb_type poly --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 125 --bins 25 --t_gap 0.45 --c_gap 0.95 --cl_gap 0.75 --all yes

python -W ignore ICP/main_aps.py --alpha 0.1 --dataset food -ar resnet20 -b 256 -s 10 --imb_type major --rho 0.5 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 125 --bins 25 --t_gap 0.45 --c_gap 0.85 --cl_gap 0.8 --all yes
python -W ignore ICP/main_aps.py --alpha 0.1 --dataset food -ar resnet20 -b 256 -s 10 --imb_type major --rho 0.1 --epochs 200 --loss_type LDAM --gpu 0 -score_functions APS -methods MCP CCP k-CCP cluster_CP -seeds 0 1 2 3 4 5 6 7 8 9 --calibration_sampling balanced -avg_num_per_class 125 --bins 25 --t_gap 0.45 --c_gap 0.9 --cl_gap 0.85 --all yes




