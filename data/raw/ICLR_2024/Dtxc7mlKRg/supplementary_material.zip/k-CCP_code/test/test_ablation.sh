
python -W ignore ICP/main_ablation.py --alpha 0.1 --dataset cifar10 -ar resnet20 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 1 -methods CCP cluster_CP k-CCP -seeds 9 -score_functions APS --calibration_sampling balanced -avg_num_per_class 500 --bins 25 --mgap 0.75
python -W ignore ICP/main_ablation.py --alpha 0.1 --dataset cifar100 -ar resnet20 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 1 -methods CCP cluster_CP k-CCP -seeds 9 -score_functions APS --calibration_sampling balanced -avg_num_per_class 50 --bins 25 --mgap 0.75
python -W ignore ICP/main_ablation.py --alpha 0.1 --dataset mini -ar resnet20 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 1 -methods CCP cluster_CP k-CCP -seeds 9 -score_functions APS --calibration_sampling balanced -avg_num_per_class 150 --bins 25 --mgap 0.75
python -W ignore ICP/main_ablation.py --alpha 0.1 --dataset food -ar resnet20 -b 256 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 1 -methods CCP cluster_CP k-CCP -seeds 9 -score_functions APS --calibration_sampling balanced -avg_num_per_class 125 --bins 25 --mgap 0.75

