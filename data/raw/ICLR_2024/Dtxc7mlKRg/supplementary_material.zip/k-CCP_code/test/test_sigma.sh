
python -W ignore ICP/main_test4.py --alpha 0.1 --dataset cifar10 -ar resnet20 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 1 -score_functions APS -methods k-CCP_T -seeds 9 --calibration_sampling balanced -avg_num_per_class 500 --bins 10 --t_gap 0.8 --c_gap 0.8 
python -W ignore ICP/main_test4.py --alpha 0.1 --dataset cifar100 -ar resnet20 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 1 -score_functions APS -methods k-CCP_T -seeds 9 --calibration_sampling balanced -avg_num_per_class 50 --bins 25 --t_gap 0.3 --c_gap 0.45 
python -W ignore ICP/main_test4.py --alpha 0.1 --dataset mini -ar resnet20 -b 128 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 1 -score_functions APS -methods k-CCP_T -seeds 9 --calibration_sampling balanced -avg_num_per_class 150 --bins 25 --t_gap 0.55 --c_gap 0.95 
python -W ignore ICP/main_test4.py --alpha 0.1 --dataset food -ar resnet20 -b 256 -s 10 --imb_type exp --rho 0.1 --epochs 200 --loss_type LDAM --gpu 1 -score_functions APS -methods k-CCP_T -seeds 9 --calibration_sampling balanced -avg_num_per_class 125 --bins 25 --t_gap 0.45 --c_gap 0.95


