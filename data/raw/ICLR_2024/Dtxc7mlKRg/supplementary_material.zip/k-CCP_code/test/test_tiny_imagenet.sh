#!/bin/bash

python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet20 -s 10  --rho 0.5
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet20 -s 10  --rho 0.4
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet20 -s 10  --rho 0.3
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet20 -s 10  --rho 0.2
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet20 -s 10  --rho 0.1

python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet32 -s 10  --rho 0.5
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet32 -s 10  --rho 0.4
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet32 -s 10  --rho 0.3
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet32 -s 10  --rho 0.2
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet32 -s 10  --rho 0.1

python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet44 -s 10  --rho 0.5
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet44 -s 10  --rho 0.4
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet44 -s 10  --rho 0.3
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet44 -s 10  --rho 0.2
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet44 -s 10  --rho 0.1

python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet56 -s 10  --rho 0.5
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet56 -s 10  --rho 0.4
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet56 -s 10  --rho 0.3
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet56 -s 10  --rho 0.2
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet56 -s 10  --rho 0.1

python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet110 -s 10  --rho 0.5
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet110 -s 10  --rho 0.4
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet110 -s 10  --rho 0.3
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet110 -s 10  --rho 0.2
python -W ignore ./ICP/main.py -a 0.1  --dataset tiny -ar resnet110 -s 10  --rho 0.1

python -W ignore RowsCols.py --dataset tiny