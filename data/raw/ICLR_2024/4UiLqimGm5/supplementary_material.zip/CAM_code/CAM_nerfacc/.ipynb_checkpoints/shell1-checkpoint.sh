# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene bouncingballs --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene hellwarrior --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene hook --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene jumpingjacks --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene lego --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene mutant --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene standup --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene trex --data_root ../dnerf

PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf.py --scene chair --data_root ../nerf_synthetic --exp norm_chair_256
PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf.py --scene drums --data_root ../nerf_synthetic --exp norm_drums_256
PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf.py --scene ficus --data_root ../nerf_synthetic --exp norm_ficus_256
PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf.py --scene hotdog --data_root ../nerf_synthetic --exp norm_hotdog_256

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_tnerf.py --scene bouncingballs --data_root ../dnerf --exp test_bouncingballs_view
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_tnerf.py --scene hellwarrior --data_root ../dnerf --exp test_hellwarrior_view
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_tnerf.py --scene hook --data_root ../dnerf --exp test_hook_view
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_tnerf.py --scene jumpingjacks --data_root ../dnerf --exp test_jumpingjacks_view

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_nerf_prop.py --scene chair --data_root ../nerf_synthetic --exp prop_chair
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_nerf_prop.py --scene drums --data_root ../nerf_synthetic --exp prop_drums

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_nerf_prop.py --scene bicycle --data_root ../360_v2 --exp prop_bicycle
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_nerf_prop.py --scene garden --data_root ../360_v2 --exp prop_garden
