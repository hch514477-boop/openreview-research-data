# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene bouncingballs --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene hellwarrior --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene hook --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene jumpingjacks --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene lego --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene mutant --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene standup --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene trex --data_root ../dnerf

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf.py --scene chair --data_root ../nerf_synthetic --exp norm_chair
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf.py --scene drums --data_root ../nerf_synthetic --exp norm_drums
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf.py --scene ficus --data_root ../nerf_synthetic --exp norm_ficus
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf.py --scene hotdog --data_root ../nerf_synthetic --exp norm_hotdog

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_tnerf.py --scene mutant --data_root ../dnerf --exp test_mutant
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_tnerf.py --scene standup --data_root ../dnerf --exp test_standup
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_tnerf.py --scene trex --data_root ../dnerf --exp test_trex


# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_nerf_prop.py --scene lego --data_root ../nerf_synthetic --exp prop_lego
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_nerf_prop.py --scene materials --data_root ../nerf_synthetic --exp prop_materials

PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_nerf_prop.py --scene counter --data_root ../360_v2 --exp prop_counter
PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_nerf_prop.py --scene kitchen --data_root ../360_v2 --exp prop_kitchen

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_nerf_prop.py --scene chair --data_root ../nerf_synthetic --exp prop_chair
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_nerf_prop.py --scene drums --data_root ../nerf_synthetic --exp prop_drums
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_nerf_prop.py --scene ficus --data_root ../nerf_synthetic --exp prop_ficus
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=3 python examples/train_mlp_nerf_prop.py --scene hotdog --data_root ../nerf_synthetic --exp prop_hotdog
