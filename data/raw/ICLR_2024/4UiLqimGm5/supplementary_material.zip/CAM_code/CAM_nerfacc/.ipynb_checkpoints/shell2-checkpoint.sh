# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene bouncingballs --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene hellwarrior --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene hook --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene jumpingjacks --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene lego --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene mutant --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene standup --data_root ../dnerf
# PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python examples/train_mlp_tnerf.py --scene trex --data_root ../dnerf

PYTHONPATH=./ CUDA_VISIBLE_DEVICES=1 python examples/train_mlp_nerf.py --scene lego --data_root ../nerf_synthetic --exp norm_lego_256
PYTHONPATH=./ CUDA_VISIBLE_DEVICES=1 python examples/train_mlp_nerf.py --scene materials --data_root ../nerf_synthetic --exp norm_materials_256
PYTHONPATH=./ CUDA_VISIBLE_DEVICES=1 python examples/train_mlp_nerf.py --scene mic --data_root ../nerf_synthetic --exp norm_mic_256
PYTHONPATH=./ CUDA_VISIBLE_DEVICES=1 python examples/train_mlp_nerf.py --scene ship --data_root ../nerf_synthetic --exp norm_ship_256

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=1 python examples/train_mlp_tnerf.py --scene jumpingjacks --data_root ../dnerf --exp test_jumpingjacks

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_tnerf.py --scene lego --data_root ../dnerf --exp test_lego_view
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_tnerf.py --scene mutant --data_root ../dnerf --exp test_mutant_view
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_tnerf.py --scene standup --data_root ../dnerf --exp test_standup_view
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_tnerf.py --scene trex --data_root ../dnerf --exp test_trex_view

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf_prop.py --scene ficus --data_root ../nerf_synthetic --exp prop_ficus
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf_prop.py --scene hotdog --data_root ../nerf_synthetic --exp prop_hotdog

# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf_prop.py --scene stump --data_root ../360_v2 --exp prop_stump
# PYTHONPATH=./ CUDA_VISIBLE_DEVICES=0 python examples/train_mlp_nerf_prop.py --scene bonsai --data_root ../360_v2 --exp prop_bonsai