FLAVA
================

## Setup
* Clone the repository onto your machine.
* Followed the same setup in https://github.com/HimangiM/RepLAI
* Please refer to the .yaml file for installing the environment for the experiment


   

## Running

### As a single script
* Pretrain: Run `bash commands/cav_pretrain_{dataset}_base_{baseline}.sh`
  * Dataset could be VGGSound or AudioSet, which is the two benchmark datasets we use for our experiments.
  * For more information about baseline, please refer to our paper.
* Finetune: Run `bash commands/cav_finetune_{dataset}_base_adamw.sh`
  * Please see the shell file to set environment variables to target specific checkpoint.