## Getting Started

This package is self-contained and implemented in python.

Most of the code for the OQR-W implementation and the competing methods used in its benchmark is taken from the CQR package available at https://github.com/yromano/cqrnonconformist. 

Most of the code for the OQR-O implementation and the competing methods used in its benchmark is taken from the OQR package available at https://github.com/Shai128/oqr.

### Prerequisites

* python
* numpy
* scipy
* scikit-learn
* pytorch
* pandas

## Usage

To prevent path issues, the working directory should be ./QFR-code.

### QFR-W
To start the benchmarking experiment for the QFR-W, QR, IR, and Winkler methods, you can use the following command : 

```
python .\QFR-W\all_cqr_experiments.py
```
The methods, datasets and seeds used can be easily modified in the .\QFR-W\all_cqr_experiments.py file.  


### QFR-O

To start the benchmarking experiment for the QFR-O, OQR, and SQR methods, you can use the following command : 

```
python .\QFR-O\reproducible_experiments\run_all_data_experiments.py
```

The methods, datasets and seeds used can be easily modified in the .\QFR-O\reproducible_experiments\run_all_data_experiments.py file.  
