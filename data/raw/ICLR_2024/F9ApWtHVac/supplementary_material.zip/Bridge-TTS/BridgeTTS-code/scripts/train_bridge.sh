export CUDA_VISIBLE_DEVICES=0

OUTPUT_DIR=
# You can use the official checkpoint of Grad-TTS by renaming it as grad_{step}.pt, or train your own encoder.
ENC_CKPT_PATH="./checkpts"

predictor="hpsi"
config=bridgetts
f=0
g=10

python train.py \
    --config $config \
    --train_filelist_path "resources/filelists/ljspeech/train.txt" \
    --valid_filelist_path "resources/filelists/ljspeech/valid.txt" \
    --load_encoder \
    --cache_dataset \
    --f $f \
    --g $g \
    --encoder_ckpt_path $ENC_CKPT_PATH \
    --encoder_step 2280 \
    --predictor $predictor \
    --log_dir "${OUTPUT_DIR}/${config}_fixed_f=${f}_g=${g}_predictor=${predictor}"
