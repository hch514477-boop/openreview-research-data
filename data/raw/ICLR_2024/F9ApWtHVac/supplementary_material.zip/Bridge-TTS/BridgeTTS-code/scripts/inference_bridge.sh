export CUDA_VISIBLE_DEVICES=7

CKPT_DIR=
OUTPUT_DIR=


predictor="hpsi"

for sampler in sde_first_order pf_ode_first_order 
do

f=0
g=10

for MODEL_NAME in bridgetts_fixed_f=${f}_g=${g}_predictor=${predictor}
do
for CKPT_STEP in 2280
do
for TIME_STEPS in 1 2 4 50 1000
do

python inference.py \
    --config bridgetts \
    --test_filelist_path "resources/filelists/ljspeech/test.txt" \
    --num_test_examples 10 \
    --ckpt_dir $CKPT_DIR \
    --model_name $MODEL_NAME \
    --f $f \
    --g $g \
    --ckpt_step $CKPT_STEP \
    --timesteps $TIME_STEPS \
    --sampler $sampler \
    --predictor $predictor \
    --output_dir $OUTPUT_DIR

done
done
done
done


done