# This code is based on the open-source codebase provided by FACIL.
# https://github.com/mmasana/FACIL.git

cd src

# script for ucir w/o rfc
bash ucir_wo_rfc.sh


# script for ucir w/ rfc
bash ucir_w_rfc.sh


