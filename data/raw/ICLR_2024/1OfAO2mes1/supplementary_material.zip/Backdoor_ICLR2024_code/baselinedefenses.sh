dataset='cifar10' #'tinyimagenet' #'cifar10'
poison_ratio=0.1


for attack in 'Badnet' 'Blend' 'Wanet'  'CleanLabel' 'Trojan' 'LabelConsistent' #'Badnet'
do
        for trialno in  1 2 3
        do
                CUDA_VISIBLE_DEVICES=1 python STRIP.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno  --dataset $dataset
                #CUDA_VISIBLE_DEVICES=0 python ABL.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno  --dataset $dataset
        done
done






#for attack in 'Blend' 'Wanet' 'Badnet' #'CleanLabel' 'LabelConsistent' 'Trojan'
#do
#	for trialno in  1 2 3
#	do
#		#CUDA_VISIBLE_DEVICES=0 python STRIP.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno  --dataset $dataset
#		CUDA_VISIBLE_DEVICES=0 python ABL.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno  --dataset $dataset
#    	done
#done


#for attack in 'Blend' 'Wanet' 'Badnet' #'CleanLabel' 'LabelConsistent' 'Trojan'
#do
#        for trialno in  1 2 3
#        do
#                #CUDA_VISIBLE_DEVICES=0 python STRIP.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno  --dataset $dataset
#                CUDA_VISIBLE_DEVICES=0 python SD_FCT.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno  --dataset $dataset
#        done
#done
~
