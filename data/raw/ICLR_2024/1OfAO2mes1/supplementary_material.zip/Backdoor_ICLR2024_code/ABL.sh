dataset='tinyimagenet'  #'cifar10'
poison_ratio=0.1


for attack in 'Badnet' 'Blend'  'Wanet' 'CleanLabel' 'LabelConsistent' 'Trojan'
do
	for trialno in  1 2 3
	do
		CUDA_VISIBLE_DEVICES=1 python SD_FCT.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno  --dataset $dataset
		#CUDA_VISIBLE_DEVICES=1 python ABL.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno  --dataset $dataset
    	done
done
