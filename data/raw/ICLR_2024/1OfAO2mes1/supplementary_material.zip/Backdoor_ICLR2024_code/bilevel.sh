poison_ratio=0.1
attack='Badnet_Adaptive1'
tau=0.1

for trialno in   3
do
    python bilevel_full.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno --tau $tau
done


#poison_ratio=0.05
#attack='Blend'
#tau=0.1

#for trialno in  2
#do
#    CUDA_VISIBLE_DEVICES=1 python bilevel_full.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno --tau $tau
#done

#poison_ratio=0.1
#attack='Trojan'
#tau=0.1

#for trialno in  2 3
#do
#    python bilevel_full.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno --tau $tau
#done

#poison_ratio=0.1
#attack='LabelConsistent'
#tau=0.1

#for trialno in  2 3
#do
#    CUDA_VISIBLE_DEVICES=1 python bilevel_full.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno --tau $tau
#done



poison_ratio=0.1
#attack='Badnet' #'Badnet'
#tau=0.1
#dataset='imagenet200'
#epoch_inner=5

#for trialno in  2 3
#do
#    CUDA_VISIBLE_DEVICES=1 python bilevel_full.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno --tau $tau --dataset $dataset --epoch_inner $epoch_inner
#done




#attack='Wanet' #'Badnet'
#tau=0.1
#dataset='tinyimagenet' #'imagenet200'
#epoch_inner=5

#for trialno in  1 2 3
#do
#    CUDA_VISIBLE_DEVICES=1 python bilevel_full.py --poison_ratio $poison_ratio --attack $attack --trialno $trialno --tau $tau --dataset $dataset --epoch_inner $epoch_inner
#done






