
attack='Badnet_Adaptive4'

for runs in  1 2 3
do
    for poison_ratio in 0.1
    do
        CUDA_VISIBLE_DEVICES=1 python trainnew.py --poison_ratio $poison_ratio --attack $attack
    done
done

#attack='LabelConsistent'

#for runs in 2 3
#do
#    for poison_ratio in 0.1
#    do
#        CUDA_VISIBLE_DEVICES=3 python trainnew.py --poison_ratio $poison_ratio --attack $attack
#    done
#done
######################################################################################################################
## imagenet200

#attack='Badnet'
#epochs=60
#lr=0.5

#for runs in 1 2 3
#do
#    for poison_ratio in 0.1
#    do
#        CUDA_VISIBLE_DEVICES=1 python trainnew.py --poison_ratio $poison_ratio --attack $attack --save_samples 'False' --dataset 'imagenet200' --lr $lr --epochs $epochs
#    done
#done


#attack='Blend'

#for runs in 1 2 3
#do
#    for poison_ratio in 0.1
#    do
#        CUDA_VISIBLE_DEVICES=1 python trainnew.py --poison_ratio $poison_ratio --attack $attack --save_samples 'False' --dataset 'imagenet200' --lr $lr --epochs $epochs
#    done
#done



######################################################################################################################
## tinyimagenet

#attack='CleanLabel'
#epochs=100

#for runs in  2  
#do
#    for poison_ratio in 0.9
#    do
#        CUDA_VISIBLE_DEVICES=1  python trainnew.py --poison_ratio $poison_ratio --attack $attack --save_samples 'False' --dataset 'tinyimagenet'  --epochs 100 --lr 0.1 --decreasing_lr '40,80'
#    done
#done

