# CMID

## 3-Slab Dataset

The python notebook `CMIDSlab3Data.ipynb` can be run directly on Google Colab to reproduce results on the 3-Slab Dataset.


## CMNIST and CPMNIST Dataset

The python notebook `CMID_MNIST.ipynb` can be run directly on Google Colab to reproduce results on CMNIST and CPMNIST Datasets.


## Subgroup Robustness Datasets

The folder `CMID-main` contains the code and instructions to reproduce results on the subgroup robustness datasets (Waterbirds, CelebA, MultiNLI and CivilComments) as well as Camelyon17-WILDS dataset.