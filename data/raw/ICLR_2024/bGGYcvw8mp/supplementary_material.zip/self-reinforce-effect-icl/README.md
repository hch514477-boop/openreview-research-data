bash run.sh
