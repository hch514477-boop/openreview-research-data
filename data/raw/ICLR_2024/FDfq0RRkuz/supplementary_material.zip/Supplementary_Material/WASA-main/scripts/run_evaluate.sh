export NCCL_P2P_DISABLE=1

CUDA_VISIBLE_DEVICES=7 python run_lm_finetuning_final.py --data_path=seed_2023/data/embedded_warmup_10c_20 --model_type=watermark-gpt --model_name_or_path=seed_2023/model/model_10c_20 --block_size=512 --control_var --do_evaluate --use_model_generate > seed_2023/logs/evaluation/model_10c_20 2>&1
CUDA_VISIBLE_DEVICES=7 python run_lm_finetuning_final.py --data_path=seed_2023/data/embedded_warmup_10c_20 --model_type=watermark-gpt --model_name_or_path=seed_2023/model/model_10c_20 --block_size=512 --control_var --find_top3 > seed_2023/logs/evaluation/top3_10c_20 2>&1
CUDA_VISIBLE_DEVICES=5 python run_lm_finetuning_final.py --data_path=seed_2023/data/embedded_warmup_10c_20 --model_type=watermark-gpt --model_name_or_path=seed_2023/model/model_10c_20 --block_size=512 --control_var --find_top5 > seed_2023/logs/evaluation/top5_10c_20 2>&1
