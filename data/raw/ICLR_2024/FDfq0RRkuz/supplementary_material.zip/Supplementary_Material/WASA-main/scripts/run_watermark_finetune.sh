export NCCL_P2P_DISABLE=1

CUDA_VISIBLE_DEVICES=7 python run_lm_finetuning_final.py --model_type=watermark-gpt --data_path=seed_2023/data/embedded_warmup_10c_20 --output_dir=seed_2023/model/model_10c_20 --pre_trained_model_type=gpt2-large --tokenizer_name=gpt2-large --overwrite_cache --overwrite_output_dir --fp16 --block_size=512 --do_train --do_eval --per_gpu_train_batch_size=3 --per_gpu_eval_batch_size=32 --gradient_accumulation_steps=8 --num_train_epochs=1 --save_steps=2000  --logging_steps=500 > seed_2023/logs/finetune/model_10c_20.log 2>&1
