export NCCL_P2P_DISABLE=1

CUDA_VISIBLE_DEVICES=7 python run_lm_finetuning_final.py --data_path=seed_2023/data/embedded_warmup_10c_20 --model_type=watermark-gpt --output_dir=seed_2023/model/model_10c_20 --tokenizer_name=gpt2-large --block_size=512 --do_eval --per_gpu_eval_batch_size=32  > seed_2023/logs/eval/model_10c_20.log 2>&1