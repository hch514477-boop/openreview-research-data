import torch.nn as nn
import torch

# This implementation of Conditioner is modified based on: https://github.com/AWehenkel/Graphical-Normalizing-Flows/blob/master/models/Conditionners/Conditioner.py

class Conditioner(nn.Module):
    def __init__(self):
        super(Conditioner, self).__init__()
        self.is_invertible = True

    def forward(self, x, context=None):
        pass

    def depth(self):
        pass
