# The official implementation of ARRLC



To replicate the results in the paper:

```bash
# Install python dependency
pip install -r requirements.txt


# Run all experiments
sh run.sh

```



To run a single experiment (e.g., ARRLC on Cliff Walking with p=0.1), please refer to commands and comments in `run.sh`.