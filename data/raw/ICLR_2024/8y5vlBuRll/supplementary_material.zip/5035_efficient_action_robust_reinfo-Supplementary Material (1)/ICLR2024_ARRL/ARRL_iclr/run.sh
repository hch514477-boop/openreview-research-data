### "Cliff Walking"
# ARRLC
for perturb_type in fix random
do
    python train.py --num_episodes 2000 --num_eval_trajectory 50 --rho 0.2 --p 0.2 --perturb_type ${perturb_type} --env_name "CliffWalking-v0" --agent_type arrlc --const 50000 &
    python train.py --num_episodes 2000 --num_eval_trajectory 50 --rho 0.2 --p 0.1 --perturb_type ${perturb_type} --env_name "CliffWalking-v0" --agent_type arrlc --const 50000 &
done

# ORLC
for perturb_type in fix random
do
    python train.py --num_episodes 2000 --num_eval_trajectory 50 --rho 0.2 --p 0.2 --perturb_type ${perturb_type} --env_name "CliffWalking-v0" --agent_type orlc --const 50000 &
    python train.py --num_episodes 2000 --num_eval_trajectory 50 --rho 0.2 --p 0.1 --perturb_type ${perturb_type} --env_name "CliffWalking-v0" --agent_type orlc --const 50000 &
done

# Robust Q-Learning
for perturb_type in fix random
do
    python train.py --num_episodes 20000 --num_eval_trajectory 50 --rho 0.2 --p 0.2 --perturb_type ${perturb_type} --env_name "CliffWalking-v0" --agent_type rq  &
    python train.py --num_episodes 20000 --num_eval_trajectory 50 --rho 0.2 --p 0.1 --perturb_type ${perturb_type} --env_name "CliffWalking-v0" --agent_type rq  &
done





### "Inverted Pendulum"
# ARRLC
for perturb_type in fix random
do
    python train.py --num_episodes 2000 --num_eval_trajectory 50 --rho 0.2 --p 0.2 --perturb_type ${perturb_type} --env_name "InvertedPendulum-v4" --agent_type arrlc --const 50000 &
    python train.py --num_episodes 2000 --num_eval_trajectory 50 --rho 0.2 --p 0.1 --perturb_type ${perturb_type} --env_name "InvertedPendulum-v4" --agent_type arrlc --const 50000 &
done

# ORLC
for perturb_type in fix random
do
    python train.py --num_episodes 2000 --num_eval_trajectory 50 --rho 0.2 --p 0.2 --perturb_type ${perturb_type} --env_name "InvertedPendulum-v4" --agent_type orlc --const 50000 &
    python train.py --num_episodes 2000 --num_eval_trajectory 50 --rho 0.2 --p 0.1 --perturb_type ${perturb_type} --env_name "InvertedPendulum-v4" --agent_type orlc --const 50000 &
done


# Robust Q-Learning
for perturb_type in fix random
do
    python train.py --num_episodes 50000 --num_eval_trajectory 50 --rho 0.2 --p 0.2 --epsilon 0.1 --perturb_type ${perturb_type} --env_name "InvertedPendulum-v4" --agent_type rq &
    python train.py --num_episodes 50000 --num_eval_trajectory 50 --rho 0.2 --p 0.1 --epsilon 0.1 --perturb_type ${perturb_type} --env_name "InvertedPendulum-v4" --agent_type rq &
done

