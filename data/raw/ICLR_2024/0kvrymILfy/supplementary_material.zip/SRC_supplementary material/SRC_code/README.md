## Selective Recalibration

The code and results for the experiments in Section 5.1 are contained in:

```
notebooks/id_train_and_eval.ipynb
notebooks/id_recalibration.ipynb
notebooks/id_results_plots.ipynb
```

The code and results for the experiments in Section 5.2 are contained in:

```
notebooks/ood_train.ipynb
notebooks/ood_eval.ipynb
```

