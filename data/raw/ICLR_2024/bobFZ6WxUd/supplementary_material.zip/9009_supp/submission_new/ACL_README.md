#how to train?

1. Download and pre-process the data https://github.com/facebookresearch/fairseq/blob/main/examples/nonautoregressive_translation/README.md
2. install required packages following: https://github.com/facebookresearch/fairseq  (do not use the latest numpy, use 1.23.0 or so, also install sacremoses)
3. bash training_commands/xxx.sh

