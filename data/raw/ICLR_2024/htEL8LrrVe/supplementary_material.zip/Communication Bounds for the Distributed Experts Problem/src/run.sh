python simulate.py --case ewa --be 100 --T 10000 &
python simulate.py --case dewa-baseline --be 100 --T 10000 &
python simulate.py --case dewa-m-baseline --be 100 --T 10000 &
python simulate.py --case ewa --be 100 --T 10000 --sparse &
python simulate.py --case dewa-baseline --be 100 --T 10000 --sparse &
python simulate.py --case ewa-m --be 100 --T 10000 &
python simulate.py --case ewa-m --be 100 --T 10000 --sparse &
python simulate.py --case exp3-m --be 1 --T 100000 &
python simulate.py --case exp3-m --be 1 --T 100000 --sparse &
python simulate.py --case dewa-m-baseline --be 100 --T 10000 --sparse &
python simulate.py --case dewa-p-baseline --be 100 --T 10000 &
python simulate.py --case dewa-m-p-baseline --be 100 --T 10000 &
python simulate.py --case dewa-p-baseline --be 100 --T 10000 --sparse &
python simulate.py --case dewa-m-p-baseline --be 100 --T 10000 --sparse &
python simulate.py --case dewa --be 100 --T 10000 &
python simulate.py --case dewa-m --be 100 --T 10000 &
python simulate.py --case dewa --be 1 --T 100000 &
python simulate.py --case dewa-m --be 1 --T 100000 &
python simulate.py --case dewa --be 100 --T 10000 --sparse &
python simulate.py --case dewa-m --be 100 --T 10000 --sparse &
python simulate.py --case dewa --be 1 --T 100000 --sparse &
python simulate.py --case dewa-m --be 1 --T 100000 --sparse &
python simulate.py --case dewa-p --be 100 --T 10000 &
python simulate.py --case dewa-m-p --be 100 --T 10000 &
python simulate.py --case dewa-p --be 1 --T 100000 &
python simulate.py --case dewa-m-p --be 1 --T 100000 &
python simulate.py --case dewa-p --be 100 --T 10000 --sparse &
python simulate.py --case dewa-m-p --be 100 --T 10000 --sparse &
python simulate.py --case dewa-p --be 1 --T 100000 --sparse &
python simulate.py --case dewa-m-p --be 1 --T 100000 --sparse &
python simulate.py --case exp3 --be 1 --T 100000 &
python simulate.py --case dewa-baseline --be 1 --T 100000 &
python simulate.py --case dewa-m-baseline --be 1 --T 100000 &
python simulate.py --case exp3 --be 1 --T 100000 --sparse &
python simulate.py --case dewa-baseline --be 1 --T 100000 --sparse &
python simulate.py --case dewa-m-baseline --be 1 --T 100000 --sparse &
python simulate.py --case dewa-p-baseline --be 1 --T 100000 &
python simulate.py --case dewa-m-p-baseline --be 1 --T 100000 &
python simulate.py --case dewa-p-baseline --be 1 --T 100000 --sparse &
python simulate.py --case dewa-m-p-baseline --be 1 --T 100000 --sparse &
