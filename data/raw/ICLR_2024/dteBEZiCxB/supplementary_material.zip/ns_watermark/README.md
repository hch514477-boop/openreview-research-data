# Necessary and Sufficient Watermark for LLMs


Necessary and Sufficient Watermark is a method for inserting watermarks into generated texts without degrading text quality.

## Requirements
See `setup.sh`.

## Quickstart

You can generated text by NS-Watermark as follows:
```
prompt = <your prompt>
input_ids = tokenizer(prompt, padding=True, return_tensors="pt").input_ids

watermark = NecessaryAndSufficientWatermark(gamma=0.0001)
output_ids = watermark.generate(model, input_ids, max_length=100, alpha=1)
```

We provide an example in `examples.ipynb`.