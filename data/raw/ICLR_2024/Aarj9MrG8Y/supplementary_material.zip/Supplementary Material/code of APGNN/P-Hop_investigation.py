import os
P = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Cora
for p in P:
    os.system('python main.py --dataset cora --reg_lambda 0.005 --lr 0.01 --dropout 0.8 --npow {0} '
              '--runs 3 --print_interval 1000 --max_epochs 1200 '
              '--patience 1500 --device 0'.format(p))

# Cornell
# for p in P:
#     os.system('python main.py --dataset cornell --reg_lambda 0.001 --lr 0.01 --dropout 0.2 --npow {0} '
#               '--runs 5 --print_interval 1000 --max_epochs 120 '
#               '--patience 100 --device 0'.format(p))