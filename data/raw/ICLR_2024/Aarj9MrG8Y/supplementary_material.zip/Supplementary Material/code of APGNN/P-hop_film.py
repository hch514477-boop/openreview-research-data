import os
P = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Film
for p in P:
    os.system('python main.py --dataset film --reg_lambda 0.001 --lr 0.01 --dropout 0.2 --npow {0} '
              '--print_interval 1000 --max_epochs 1200 --alpha 0.5 '
              '--patience 500 --device 0'.format(p))