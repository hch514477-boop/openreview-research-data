import os
P = [1, 2, 3, 4, 5, 6]
Niter = [60, 30, 20, 15, 12, 10]

# Cornell
for p in P:
    for niter in Niter:
        os.system('python main.py --dataset cornell --reg_lambda 0.001 --lr 0.01 --dropout 0.2 --npow {0} '
                  '--print_interval 1000 --max_epochs 1500 --alpha 0.6 --runs 10 --niter {1} '
                  '--patience 500 --device 0'.format(p, niter))