import os
Alpha = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.99]

# Citeseer
for alpha in Alpha:
    os.system('python main.py --dataset citeseer --reg_lambda 0.00625 --lr 0.01 --dropout 0.5 --npow 1 '
              '--print_interval 1000 --max_epochs 1500 --alpha {0} '
              '--patience 200 --device 1'.format(alpha))