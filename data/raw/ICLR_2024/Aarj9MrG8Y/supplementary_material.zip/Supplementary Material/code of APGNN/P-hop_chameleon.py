import os
P = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Chameleon
for p in P:
    os.system('python main.py --dataset chameleon --reg_lambda 0 --lr 0.05 --dropout 0.7 --npow {0} '
              '--print_interval 1000 --max_epochs 2000 --alpha 0.9 '
              '--patience 500 --device 0'.format(p))