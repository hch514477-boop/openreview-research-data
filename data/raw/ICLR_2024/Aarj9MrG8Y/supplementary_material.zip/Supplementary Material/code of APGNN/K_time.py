import os

# Texas
Dataset = ['cora']
Model = ['APGNN','APPNP', 'GNN-LF', 'GNN-HF']
Niter = [300, 500, 1000]

for dataset in Dataset:
    for model in Model:
        for niter in Niter:
            os.system('python main.py --dataset {0} '
                      '--runs 1 --print_interval 200 --max_epochs 201 --model {1} '
                      '--patience 300 --device 1 '
                      '--niter {2}'.format(dataset, model, niter))