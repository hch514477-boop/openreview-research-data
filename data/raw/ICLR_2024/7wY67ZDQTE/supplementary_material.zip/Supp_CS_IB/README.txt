The demo for CS-IB on the California Hosing dataset.

Running the demo with "python -u CS_IB_Housing.py" 
'loss_cs.py' contains the codes of conditional CS_divergence (Eq.18), and CS_QMI (Eq.19).




 