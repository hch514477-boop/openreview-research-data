# FACH
Linear Complexity Framework for Feature-Aware Graph Coarsening via Hashing
