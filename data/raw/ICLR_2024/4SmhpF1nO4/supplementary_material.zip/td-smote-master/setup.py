#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""The setup script."""

from setuptools import find_packages, setup

with open('readme.md', encoding='utf-8') as readme_file:
    readme = readme_file.read()

with open('requirements.txt') as f:
    requirements = f.readlines()

setup(
    install_requires=requirements,
    include_package_data=True,
    packages=find_packages(include=['tabular_deep_smote']),
    keywords='TDSMOTE',
    name='tdsmote',
    python_requires='>=3.8'
)
