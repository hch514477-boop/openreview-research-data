import torch

baseline = torch.zeros(16, 16)

# cifar100 t4
fb1 = torch.zeros(16, 16)
fb1[11][0] = 1.
fb1[5][1] = 1.

# cifar100 t6
fb2 = torch.zeros(16, 16)
fb2[7][0] = 1.
fb2[4][1] = 1.

# cifar10 t4
fb3 = torch.zeros(16, 16)
fb3[2][0] = 1.
fb3[5][1] = 1.

# cifar10 t6
fb4 = torch.zeros(16, 16)
fb4[7][1] = 1.
fb4[4][0] = 1.

# cifar10dvs t10
fb5 = torch.zeros(16, 16)
fb5[11][4] = 1.
fb5[3][0] = 1.

# tiny-imagenet t5
fb6 = torch.zeros(16, 16)
fb6[8][1] = 1.
fb6[13][0] = 1.
