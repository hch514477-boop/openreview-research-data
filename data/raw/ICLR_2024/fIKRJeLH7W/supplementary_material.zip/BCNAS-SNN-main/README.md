# BCNAS-SNN

## Introduction
The code example of BCNAS-SNN: Proper Backward Connection Placement Boosts Spiking Neural Networks, which is under review as a conference paper at ICML 2023.

## Environment
Python == 3.8.5, PyTorch == 1.7.0, torchvision == 0.8.0

## Dataset
The preprocess of CIFAR10DVS refers to https://github.com/brain-intelligence-lab/temporal_efficient_training.
