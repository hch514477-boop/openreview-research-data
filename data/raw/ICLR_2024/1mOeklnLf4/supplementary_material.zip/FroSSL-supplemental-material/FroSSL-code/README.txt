We provide the source code that we used for our experiments.
requirements.txt should work for both the notebooks folder and ssl-testbed folder.

1) In the ssl-testbed folder, there is a comprehesive SSL framework with several datasets and methods implemented.
Example scripts are provided that can run FroSSL.

2) In the the notebooks folder, there are experiments pertaining to the aligned init theory.

3) In the solo-learn-parameters folder, .yaml files are provided which detail the exact hyperparameters used in Section 6.1.