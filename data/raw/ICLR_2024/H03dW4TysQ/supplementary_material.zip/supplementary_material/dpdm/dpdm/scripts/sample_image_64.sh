SAMPLE_FLAGS="--batch_size 4 --num_samples 4 --timestep_respacing 250"
MODEL_FLAGS="--if_finetune True --dropout 0.1 --attention_resolutions 32,16,8 --class_cond True --diffusion_steps 1000 --image_size 64 --learn_sigma True --noise_schedule cosine --num_channels 192 --num_head_channels 64 --num_res_blocks 3 --resblock_updown True --use_new_attention_order True --use_fp16 True --use_scale_shift_norm True"

CUDA_VISIBLE_DEVICES=0 python sample_image.py $MODEL_FLAGS \
													 --classifier_scale 1.0 \
													 --classifier_depth 4 \
													 --classifier_path models/64x64_classifier.pt \
													 --model_path models/64x64_dpdm.pt \
													 --gater_path models/64x64_gaternet.pt \
													 --label 207 \
													 $SAMPLE_FLAGS \
													 --save_path samples \
													 --step_respacing 250 \
													 --skip_1024layers 10,6 \
													 --double_mid False \