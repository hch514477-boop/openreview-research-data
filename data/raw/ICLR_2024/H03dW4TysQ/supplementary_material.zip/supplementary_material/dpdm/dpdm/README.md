# DPDM
## Our code is based on [Guided Diffusion](https://github.com/openai/guided-diffusion)



## Download pre-trained models and relevant files
The diffusion model checkpoints we use is released by [Guided Diffusion](http://arxiv.org/abs/2105.05233). You can download them here:

 * 256x256 classifier: [256x256_classifier.pt](https://openaipublic.blob.core.windows.net/diffusion/jul-2021/256x256_classifier.pt)
 * 64x64 classifier: [64x64_classifier.pt](https://openaipublic.blob.core.windows.net/diffusion/jul-2021/64x64_classifier.pt)

<font color= "#FF0000"> The all files (including check points in nips2023.zip) mentioned above should be saved at "scripts/models/".</font> <br />

(We provide ready check points of size 23%, 20% for image generation of size 256x256 and of size 29% for image generation of size 64x64.)

## Run
Run the following command to sample using dpdm. 
```
cd scripts
bash sample_image_256.sh
bash sample_image_64.sh
```

The  number of parameters in dpdm of size 256x256 and corresponding settings are as follows:
```
23% parameters
--skip_1024layers 12,6
--double_mid True
```

```
20% parameters
--skip_1024layers 11,7
--double_mid False
```
