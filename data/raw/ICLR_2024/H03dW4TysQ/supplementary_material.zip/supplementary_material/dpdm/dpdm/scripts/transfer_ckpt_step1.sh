python transfer_ckpt.py --model_path models/static_skip_256x256_diffusion.pt \
						--if_finetune False \