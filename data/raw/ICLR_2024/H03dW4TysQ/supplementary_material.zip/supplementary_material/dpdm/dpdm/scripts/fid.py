from cleanfid import fid

fdir1 = "path1"
fdir2 = "path2"
score = fid.compute_fid(fdir1, fdir2)

print("The FID is", score)