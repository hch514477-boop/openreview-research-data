"""
Train a diffusion model on images.
"""

import argparse
import os
import sys
sys.path.append("..")

import torch

from guided_diffusion import dist_util, logger
from guided_diffusion.image_datasets import load_data
from guided_diffusion.resample import create_named_schedule_sampler
from guided_diffusion.script_util import (
    model_and_diffusion_defaults,
    create_model_and_diffusion,
    args_to_dict,
    add_dict_to_argparser,
)
from guided_diffusion.train_util import TrainLoop, get_scales
from guided_diffusion.unet import FNN

import wandb
import torch.distributed as dist


def main():
    args = create_argparser().parse_args()

    dist_util.setup_dist(os.environ["CUDA_VISIBLE_DEVICES"])
    logger.configure(dir = args.save_path)
    if dist.get_rank() == 0:
        if args.use_wandb == "True":
            wandb.init(project="DDDM")

    ##########################################
    fnn_ckpt = torch.load(args.gater_path, map_location="cpu")
    out_size = 0
    for k in fnn_ckpt.keys():
        out_size = int(fnn_ckpt[k].shape[0])

    fnn = FNN(dims=[args.t_spli_num, 64, out_size], threshold=args.threshold)
    fnn.load_state_dict(
        fnn_ckpt,
    )
    fnn.to(dist_util.dev())
    fnn.eval()

    layer_used_num_list = get_scales(fnn, args.t_spli_num)
    args.layer_used_num_list = layer_used_num_list
    ##########################################
    logger.log("creating model and diffusion...")
    model, diffusion = create_model_and_diffusion(
        **args_to_dict(args, model_and_diffusion_defaults().keys())
    )
    model.to(dist_util.dev())
    schedule_sampler = create_named_schedule_sampler(args.schedule_sampler, diffusion)

    logger.log("creating data loader...")
    data = load_data(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        image_size=args.image_size,
        class_cond=args.class_cond,
    )

    logger.log("training...")
    TrainLoop(
        model=model,
        diffusion=diffusion,
        data=data,
        batch_size=args.batch_size,
        microbatch=args.microbatch,
        lr=args.lr,
        ema_rate=args.ema_rate,
        log_interval=args.log_interval,
        save_interval=args.save_interval,
        resume_checkpoint=args.resume_checkpoint,
        use_fp16=args.use_fp16,
        fp16_scale_growth=args.fp16_scale_growth,
        schedule_sampler=schedule_sampler,
        weight_decay=args.weight_decay,
        lr_anneal_steps=args.lr_anneal_steps,
        loss_a_list=[args.diffusion_a],
        use_wandb=args.use_wandb,
        gater_net_threshold=args.threshold,
        if_finetune=True,
        gater_path=args.gater_path,
    ).run_loop(args.single_label)


def create_argparser():
    defaults = dict(
        data_dir="",
        schedule_sampler="uniform",
        lr=1e-4,
        weight_decay=0.0,
        lr_anneal_steps=0,
        batch_size=1,
        microbatch=-1,  # -1 disables microbatches
        ema_rate="0.9999",  # comma-separated list of EMA values
        log_interval=10,
        save_interval=10000,
        resume_checkpoint="",
        use_fp16=False,
        fp16_scale_growth=1e-3,
    )
    defaults.update(model_and_diffusion_defaults())
    parser = argparse.ArgumentParser()
    add_dict_to_argparser(parser, defaults)
    parser.add_argument(
        "--save_path", type=str, help="The path to save the log and the result"
    )
    parser.add_argument(
        "--single_label", type=int, default=-1,
        help="If your training wants to use single label, you have to make sure the label you assign match with the data"
    )
    parser.add_argument(
        "--use_wandb", type=str, default="False",
    )
    parser.add_argument(
        "--diffusion_a", type=float, default=0.99,
    )
    parser.add_argument(
        "--gater_path", type=str, help=""
    )
    return parser


if __name__ == "__main__":
    main()
