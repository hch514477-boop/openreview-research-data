python transfer_ckpt.py --model_path models/static_skip_256x256_diffusion.pt \
						--gater_path models/gaternet_for_256x256.pt \
						--expand_scale 0.5 \
						--threshold 0.49999 \
						--if_finetune True \