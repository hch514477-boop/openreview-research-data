MODEL_FLAGS="--if_finetune True --attention_resolutions 32,16,8 --class_cond True --image_size 256 --learn_sigma True --num_channels 256 --num_head_channels 64 --num_res_blocks 2 --resblock_updown True --use_scale_shift_norm True"
DIFFUSION_FLAGS="--diffusion_steps 1000 --noise_schedule linear"
TRAIN_FLAGS="--lr 1e-5 --batch_size 128 --microbatch 4 --log_interval 10"

CUDA_VISIBLE_DEVICES=0 python train_diffusion.py --data_dir xxx \
										 $MODEL_FLAGS \
										 $DIFFUSION_FLAGS \
										 $TRAIN_FLAGS \
										 --resume_checkpoint models/256x256_dddm_step2.pt \
										 --gater_path models/gaternet_for_256x256.pt \
										 --save_path xxx \
										 --single_label 207 \
										 --save_interval 500 \
										 --expand_scale 0.5 \
										 --t_spli_num 10 \
										 --timesteps 1000 \
										 --threshold 0.49999 \
										 --use_wandb False \