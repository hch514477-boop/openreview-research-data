SAMPLE_FLAGS="--batch_size 4 --num_samples 4 --timestep_respacing 250"
MODEL_FLAGS="--if_finetune True --attention_resolutions 32,16,8 --class_cond True --diffusion_steps 1000 --image_size 256 --learn_sigma True --noise_schedule linear --num_channels 256 --num_head_channels 64 --num_res_blocks 2 --resblock_updown True --use_fp16 True --use_scale_shift_norm True"

CUDA_VISIBLE_DEVICES=0 python check_train_code.py $MODEL_FLAGS \
													 --classifier_scale 1.0 \
													 --classifier_path models/256x256_classifier.pt \
													 --model_path models/256x256_dddm_step2.pt \
													 --gater_path models/gaternet_for_256x256.pt \
													 --label 207 \
													 $SAMPLE_FLAGS \
													 --save_path xxx \
													 --expand_scale 0.5 \
													 --t_spli_num 10 \
													 --timesteps 1000 \
													 --threshold 0.49999 \
													 --step_respacing 250 \