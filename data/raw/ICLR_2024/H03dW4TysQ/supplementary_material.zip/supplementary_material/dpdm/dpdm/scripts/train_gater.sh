MODEL_FLAGS="--attention_resolutions 32,16,8 --class_cond True --image_size 256 --learn_sigma True --num_channels 256 --num_head_channels 64 --num_res_blocks 2 --resblock_updown True --use_scale_shift_norm True"
DIFFUSION_FLAGS="--diffusion_steps 1000 --noise_schedule linear"
TRAIN_FLAGS="--lr 1e-2 --batch_size 64 --microbatch 4 --log_interval 10"

CUDA_VISIBLE_DEVICES=0 python train_gater.py --data_dir xxx \
										 $MODEL_FLAGS \
										 $DIFFUSION_FLAGS \
										 $TRAIN_FLAGS \
										 --save_path xxx \
										 --single_label 207 \
										 --save_interval 1000 \
										 --expand_scale 4 \
										 --expand_scale_io 8 \
										 --t_spli_num 10 \
										 --timesteps 1000 \
										 --threshold 0.49999 \
										 --diffusion_a 0.9 \
										 --deg_times 10.0 \
										 --resume_checkpoint models/256x256_dddm.pt \
										 --use_wandb False \