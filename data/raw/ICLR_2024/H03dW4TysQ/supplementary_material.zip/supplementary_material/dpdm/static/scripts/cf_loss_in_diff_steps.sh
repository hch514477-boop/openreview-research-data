SAMPLE_FLAGS="--batch_size 4 --micro_size 4"
MODEL_FLAGS="--train_mode True --reverse_info_path models/reverse_info.pt --attention_resolutions 32,16,8 --class_cond True --diffusion_steps 1000 --image_size 256 --learn_sigma True --noise_schedule linear --num_channels 256 --num_head_channels 64 --num_res_blocks 2 --resblock_updown True --use_fp16 True --use_scale_shift_norm True"

CUDA_VISIBLE_DEVICES=0 python cf_loss_in_diff_steps.py $MODEL_FLAGS \
													 --classifier_scale 1.0 \
													 --classifier_path models/256x256_classifier.pt \
													 --model_path models/pruned_diffusion.pt \
													 --label 207 \
													 $SAMPLE_FLAGS \
													 --save_path xxx \
													 --standard_model_path models/256x256_diffusion.pt \
													 --data_dir xxx \
													 --step_respacing 250 \