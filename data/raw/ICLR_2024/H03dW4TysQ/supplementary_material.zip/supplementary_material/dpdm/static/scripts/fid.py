from cleanfid import fid

fdir1 = "xxx"
fdir2 = "xxx"
score = fid.compute_fid(fdir1, fdir2)

print("The FID is", score)