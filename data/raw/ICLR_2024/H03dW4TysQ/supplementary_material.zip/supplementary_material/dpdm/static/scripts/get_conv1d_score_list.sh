SAMPLE_FLAGS="--batch_size 4 --timestep_respacing 250"
MODEL_FLAGS="--attention_resolutions 32,16,8 --class_cond True --diffusion_steps 1000 --image_size 256 --learn_sigma True --noise_schedule linear --num_channels 256 --num_head_channels 64 --num_res_blocks 2 --resblock_updown True --use_fp16 True --use_scale_shift_norm True"

CUDA_VISIBLE_DEVICES=0 python get_conv1d_score_list.py $MODEL_FLAGS \
												--classifier_scale 1.0 \
												--classifier_path models/256x256_classifier.pt \
												--model_path models/256x256_diffusion.pt \
												--begin_id 0 \
												--split_size 50 \
												--label 207 \
												--save_path xxx \
												$SAMPLE_FLAGS \