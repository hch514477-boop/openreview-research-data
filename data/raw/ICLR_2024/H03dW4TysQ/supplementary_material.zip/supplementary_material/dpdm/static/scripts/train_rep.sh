MODEL_FLAGS="--attention_resolutions 32,16,8 --class_cond True --image_size 256 --learn_sigma True --num_channels 256 --num_head_channels 64 --num_res_blocks 2 --resblock_updown True --use_scale_shift_norm True"
DIFFUSION_FLAGS="--diffusion_steps 1000 --noise_schedule linear"
TRAIN_FLAGS="--lr 1e-4 --batch_size 256 --microbatch 8 --log_interval 10 --weight_decay 0.0001"

CUDA_VISIBLE_DEVICES=0 python train_rep.py --data_dir xxx \
										 $MODEL_FLAGS \
										 $DIFFUSION_FLAGS \
										 $TRAIN_FLAGS \
										 --save_path xxx \
										 --resume_checkpoint models/256x256_diffusion.pt \
										 --single_label 207 \
										 --use_simple_train False \
										 --step_respacing 250 \
										 --save_interval 200 \
										 --lasso_strength 0.0001 \
										 --mask_interval 200 \
										 --before_mask_iters 1000 \
										 --rep_train_thresh 0.001 \