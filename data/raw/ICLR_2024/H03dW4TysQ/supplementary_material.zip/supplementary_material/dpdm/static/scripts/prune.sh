SAMPLE_FLAGS="--batch_size 1 --num_samples 1 --timestep_respacing 250"
MODEL_FLAGS="--attention_resolutions 32,16,8 --class_cond True --diffusion_steps 1000 --image_size 256 --learn_sigma True --noise_schedule linear --num_channels 256 --num_head_channels 64 --num_res_blocks 2 --resblock_updown True --use_fp16 True --use_scale_shift_norm True"

CUDA_VISIBLE_DEVICES=0 python prune.py $MODEL_FLAGS \
									  --classifier_scale 1.0 \
									  --classifier_path models/256x256_classifier.pt \
									  --model_path models/256x256_diffusion.pt \
									  $SAMPLE_FLAGS \
									  --score_path models/score_list.npy \
									  --pruning_scale 0.5 \
									  --conv1d_scale 0.4 \
									  --linear_scale 0.2 \
									  --conv1d_score_path models \
									  --linear_score_path models \