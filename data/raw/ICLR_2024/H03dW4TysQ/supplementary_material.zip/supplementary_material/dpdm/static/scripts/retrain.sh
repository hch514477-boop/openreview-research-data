MODEL_FLAGS="--train_mode True --reverse_info_path models/reverse_info.pt --attention_resolutions 32,16,8 --class_cond True --image_size 256 --learn_sigma True --num_channels 256 --num_head_channels 64 --num_res_blocks 2 --resblock_updown True --use_scale_shift_norm True"
DIFFUSION_FLAGS="--diffusion_steps 1000 --noise_schedule linear"
TRAIN_FLAGS="--lr 1e-4 --batch_size 256 --microbatch 8 --log_interval 10"

CUDA_VISIBLE_DEVICES=0 python retrain.py --data_dir xxx \
										 $MODEL_FLAGS \
										 $DIFFUSION_FLAGS \
										 $TRAIN_FLAGS \
										 --save_path xxx \
										 --use_gen_loss False \
										 --standard_model_path models/256x256_diffusion.pt \
										 --resume_checkpoint models/pruned_diffusion.pt \
										 --single_label 207 \
										 --use_simple_train False \
										 --step_respacing 250 \
										 --save_interval 200 \