SAMPLE_FLAGS="--batch_size 4 --num_samples 4 --timestep_respacing 250"
MODEL_FLAGS="--reverse_info_path models/reverse_info.pt --attention_resolutions 32,16,8 --class_cond True --diffusion_steps 1000 --image_size 256 --learn_sigma True --noise_schedule linear --num_channels 256 --num_head_channels 64 --num_res_blocks 2 --resblock_updown True --use_fp16 True --use_scale_shift_norm True"

CUDA_VISIBLE_DEVICES=0 python check_muti_use_of_UNet.py $MODEL_FLAGS \
													 --classifier_scale 1.0 \
													 --classifier_path models/256x256_classifier.pt \
													 --model_path models/pruned_diffusion.pt \
													 --label 207 \
													 $SAMPLE_FLAGS \
													 --save_path xxx \
													 --standard_model_path models/256x256_diffusion.pt \
													 --start_step_of_pruned 0 \
													 --size_of_group 10 \