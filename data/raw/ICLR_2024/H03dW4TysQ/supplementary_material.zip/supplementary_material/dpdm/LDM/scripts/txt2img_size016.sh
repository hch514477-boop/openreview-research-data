CUDA_VISIBLE_DEVICES=0 python scripts/txt2img.py \
--config configs/latent-diffusion/txt2img-1p4B-eval.yaml \
--prompt "A street sign that reads 'DOG'" \
--model_path xxx.ckpt \
--ddim_eta 0.0 \
--n_samples 4 \
--n_iter 1 \
--scale 5.0 \
--ddim_steps 50 \