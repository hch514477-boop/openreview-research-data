CUDA_VISIBLE_DEVICES=0 python scripts/sample.py --config configs/latent-diffusion/cin256-v2_sample.yaml \
												--ckpt models/ldm/cin256-v2/model.ckpt \
												--label 936 \
												--num_samples 4 \
												--batch_size 4 \
												--save_path results/xxx \