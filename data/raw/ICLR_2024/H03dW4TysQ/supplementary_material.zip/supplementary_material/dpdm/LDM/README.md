# DPDM
## Our code is based on [Latent Diffusion](https://github.com/compvis/latent-diffusion)



## Check Points
We provide check points on both label-to-image and text-to-image tasks.

## Run
For the label-to-image task, run: 
```
bash scripts/sample.sh
```

For the text-to-image task, run: 
```
bash scripts/txt2img_size016.sh
```
or
```
bash scripts/txt2img_size027.sh
```
