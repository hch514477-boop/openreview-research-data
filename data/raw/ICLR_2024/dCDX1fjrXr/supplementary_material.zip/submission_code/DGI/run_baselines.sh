# cora
OMP_NUM_THREADS=4 python original_execute.py --dataset cora

# citeseer
OMP_NUM_THREADS=4 python original_execute.py --dataset citeseer

# wiki
OMP_NUM_THREADS=4 python original_execute.py --dataset wiki

# pupmed
OMP_NUM_THREADS=4 python original_execute.py --dataset pubmed

# photo
OMP_NUM_THREADS=4 python original_execute.py --dataset photo

# cs
OMP_NUM_THREADS=4 python original_execute.py --dataset cs

# computers
OMP_NUM_THREADS=4 python original_execute.py --dataset computers

# physics
OMP_NUM_THREADS=4 python original_execute.py --dataset physics

# Reddit
# OMP_NUM_THREADS=4 python original_execute.py --dataset Reddit