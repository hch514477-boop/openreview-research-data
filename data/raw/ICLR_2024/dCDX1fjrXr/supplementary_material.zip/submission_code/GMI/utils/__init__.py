from models.logreg import LogReg
from .loads import Mask