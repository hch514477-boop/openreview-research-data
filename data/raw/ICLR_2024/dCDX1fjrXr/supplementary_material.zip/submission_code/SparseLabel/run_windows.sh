# # # # # # # # # # # GUIDED RUN

# cora
python SparseLabel.py --dataset cora --AGC_norm 0 --AGC_tol 0.001 --AGC_power 60

# citeseer
python SparseLabel.py --dataset citeseer --AGC_norm 0 --AGC_tol 0.001 --AGC_power 60

# wiki
python SparseLabel.py --dataset wiki --AGC_norm 0 --AGC_tol 0.001 --AGC_power 60

# pupmed
python SparseLabel.py --dataset pubmed --AGC_norm 0 --AGC_tol 0.001 --AGC_power 60

# photo
python SparseLabel.py --dataset photo --AGC_norm 0 --AGC_tol 0.001 --AGC_power 60

# cs
python SparseLabel.py --dataset cs --AGC_norm 0 --AGC_tol 0.001 --AGC_power 60

# computers
python SparseLabel.py --dataset computers --AGC_norm 0 --AGC_tol 0.001 --AGC_power 60

# physics
python SparseLabel.py --dataset physics --AGC_norm 0 --AGC_tol 0.001 --AGC_power 60

# Reddit
# OMP_NUM_THREADS=4 python SparseLabel.py --dataset Reddit --AGC_norm 0 --AGC_tol 0.001 --AGC_power 60
