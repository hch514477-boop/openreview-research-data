# Table 1 Data

Run `table_nopop.py` for the CQL results, then run `table.py` twice (changing the source) for the popcql and dualdicecql results. You'll have to set the source in the source code.

Then open `parse.ipynb` and run the entire thing.
