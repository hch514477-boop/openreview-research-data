
1. requirements.txt contains the environment needed;
2. download the clip model and put it in the smr_tome directory;
3. prepare the dataset following the path in smr_tome/startup_smr_pt.py;
4. 'cd smr_tome' and 'python startup_smr_pt.py'.