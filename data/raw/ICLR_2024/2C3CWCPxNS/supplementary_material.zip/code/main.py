from src import Burgers1D_CRunner, Burgers2D_CRunner
from src import Poisson2D_CRunner, Poisson2D_CGRunner, \
    Poisson3D_CGRunner, Poisson2D_MSRunner
from src import Heat2D_VCRunner, Heat2D_MSRunner, \
    Heat2D_CGRunner, Heat2D_LTRunner
from src import Wave1D_CRunner, Wave2D_CGRunner, Wave2D_MSRunner
from src import NS2D_CRunner, NS2D_CGRunner, NS2D_LTRunner
from src import GSRunner, KSRunner
from src import PInvRunner, HInvRunner

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--case", type=str, default="Burgers1D_C")
casename = parser.parse_args().case

runner = globals()[casename + "Runner"]()

# runner = Burgers1D_CRunner()
# runner = Burgers2D_CRunner()

# runner = Poisson2D_CRunner()
# runner = Poisson2D_CGRunner()
# runner = Poisson3D_CGRunner()
# runner = Poisson2D_MSRunner()

# runner = Heat2D_VCRunner()
# runner = Heat2D_MSRunner()
# runner = Heat2D_CGRunner()
# runner = Heat2D_LTRunner()

# runner = Wave1D_CRunner()
# runner = Wave2D_CGRunner()
# runner = Wave2D_MSRunner()

# runner = NS2D_CRunner()
# runner = NS2D_CGRunner()
# runner = NS2D_LTRunner()

# runner = GSRunner()
# runner = KSRunner()

runner.load_config()
config = runner.get_config()

# Modify the config if needed

runner.setup()
runner.run()
