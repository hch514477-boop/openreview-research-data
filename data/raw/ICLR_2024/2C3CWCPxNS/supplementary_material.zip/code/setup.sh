# Make sure to run this script in the root directory of the project
# Make sure to have conda installed
# Create new conda environment and install packages
conda create -n cpinn python=3.11
conda activate cpinn
pip install torch==2.0.1 matplotlib==3.7.1 scipy==1.11.1 gmsh==4.11.1 \
    meshio==5.3.4 DeepXDE==1.9.2 h5py==3.9.0 dill=0.3.7
conda install -c conda-forge fenics
pip install cashocs==2.0.12
# Download the dataset
git clone https://github.com/i207M/PINNacle.git
cp -r PINNacle/data/* data/param/
cp -r PINNacle/ref/* data/ref/
rm -rf PINNacle/
