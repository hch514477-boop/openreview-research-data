# Burgers
from src.burgers.burgers1d_c.runner import Burgers1D_CRunner
from src.burgers.burgers2d_c.runner import Burgers2D_CRunner

# Poisson
from src.poisson.poisson2d_c.runner import Poisson2D_CRunner
from src.poisson.poisson2d_cg.runner import Poisson2D_CGRunner
from src.poisson.poisson3d_cg.runner import Poisson3D_CGRunner
from src.poisson.poisson2d_ms.runner import Poisson2D_MSRunner

# Heat
from src.heat.heat2d_vc.runner import Heat2D_VCRunner
from src.heat.heat2d_ms.runner import Heat2D_MSRunner
from src.heat.heat2d_cg.runner import Heat2D_CGRunner
from src.heat.heat2d_lt.runner import Heat2D_LTRunner

# Wave
from src.wave.wave1d_c.runner import Wave1D_CRunner
from src.wave.wave2d_cg.runner import Wave2D_CGRunner
from src.wave.wave2d_ms.runner import Wave2D_MSRunner

# NS
from src.ns.ns2d_c.runner import NS2D_CRunner
from src.ns.ns2d_cg.runner import NS2D_CGRunner
from src.ns.ns2d_lt.runner import NS2D_LTRunner

# Chaotic
from src.chaotic.gs.runner import GSRunner
from src.chaotic.ks.runner import KSRunner

# Inverse
from src.inverse.pinv.runner import PInvRunner
from src.inverse.hinv.runner import HInvRunner
