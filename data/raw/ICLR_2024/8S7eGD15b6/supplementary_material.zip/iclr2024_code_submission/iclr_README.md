This repository is an amalgamation of the following repositories:

https://github.com/a554b554/kWTA-Activation

https://github.com/locuslab/smoothing

https://github.com/wgrathwohl/JEM

https://github.com/NVlabs/DiffPure

https://github.com/openai/improved-diffusion/


You will need download and train some models.

* Please download this file to code/diffusion/

https://openaipublic.blob.core.windows.net/diffusion/march-2021/cifar10_uncond_50M_500K.pt

* Please download this file to jem_models/

http://www.cs.toronto.edu/~wgrathwohl/CIFAR10_MODEL.pt


To set up the environment, run the following command:

```python deploy.py```


To train kWTA models, please execute:

```python code/train_kwta_cifar.py```


To run experiments for Section 3 and Section 5, execute 

```python run_all_experiments.py```

This will output jsons to different results folders. The jsons can be analyzed with

```python analyze_json_results.py --json_dir <dir-where-jsons-are>```

The experiments for Section 4 were completed by using only slightly modified versions of these repositories. The code was cloned from these repositories and modified as explained in the paper (just reset the random seeds before every inference). Because it is very similar to already public code, we do not include it here.

https://github.com/locuslab/smoothing

https://github.com/wgrathwohl/JEM

https://github.com/NVlabs/DiffPure

Thanks for reviewing our submission!
