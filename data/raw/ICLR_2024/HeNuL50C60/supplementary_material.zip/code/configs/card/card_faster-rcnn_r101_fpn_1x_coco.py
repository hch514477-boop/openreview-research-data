_base_ = './faster-rcnn_r50_fpn_1x_coco.py'
model = dict(
    backbone=dict(
        depth=101,
        init_cfg=dict(type='Pretrained',
                      checkpoint='torchvision://resnet101')),
    roi_head=dict(
        type='StandardRoIHead',
        bbox_head=dict(
            type='MaskShared2FCBBoxHead',
            num_classes=7,
            loss_cls=dict(
                type='CrossEntropyLoss', is_reweight=True, use_sigmoid=False, loss_weight=1.0),
            loss_bbox=dict(type='L1Loss', loss_weight=1.0))),
)
