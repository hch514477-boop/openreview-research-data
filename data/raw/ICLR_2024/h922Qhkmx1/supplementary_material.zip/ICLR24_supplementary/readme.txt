For listening to examples, access ~/examples/index.html
