CUDA_VISIBLE_DEVICES=0 python main.py \
--experiment cifar100 \
--scenario class \
--iters 5000 \
--lr 1e-4 \
--div_weight 1e-12 \
--seed 4 \
--pdf \
--task-boundary \
--save-dir cifar100/boundary-aware/ebm-class-ours-e-12 \
--ebm \

