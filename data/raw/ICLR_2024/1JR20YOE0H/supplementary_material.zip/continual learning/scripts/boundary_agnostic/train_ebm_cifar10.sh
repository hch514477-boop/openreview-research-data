CUDA_VISIBLE_DEVICES=0 python main.py \
--experiment cifar10 \
--scenario class \
--lr 1e-4 \
--seed 0 \
--div_weight 1e-13 \
--pdf \
--epc-per-virtual-task 50 \
--save-dir cifar10/boundary-agnostic/ebm1-class-e-13 \
--ebm \

CUDA_VISIBLE_DEVICES=0 python main.py \
--experiment cifar10 \
--scenario class \
--lr 1e-4 \
--seed 1 \
--div_weight 1e-13 \
--pdf \
--epc-per-virtual-task 50 \
--save-dir cifar10/boundary-agnostic/ebm1-class-e-13 \
--ebm \


CUDA_VISIBLE_DEVICES=0 python main.py \
--experiment cifar10 \
--scenario class \
--lr 1e-4 \
--seed 2 \
--div_weight 1e-13 \
--pdf \
--epc-per-virtual-task 50 \
--save-dir cifar10/boundary-agnostic/ebm1-class-e-13 \
--ebm \


CUDA_VISIBLE_DEVICES=0 python main.py \
--experiment cifar10 \
--scenario class \
--lr 1e-4 \
--seed 3 \
--div_weight 1e-13 \
--pdf \
--epc-per-virtual-task 50 \
--save-dir cifar10/boundary-agnostic/ebm1-class-e-13 \
--ebm \

CUDA_VISIBLE_DEVICES=0 python main.py \
--experiment cifar10 \
--scenario class \
--lr 1e-4 \
--seed 4 \
--div_weight 1e-13 \
--pdf \
--epc-per-virtual-task 50 \
--save-dir cifar10/boundary-agnostic/ebm1-class-e-13 \
--ebm \






