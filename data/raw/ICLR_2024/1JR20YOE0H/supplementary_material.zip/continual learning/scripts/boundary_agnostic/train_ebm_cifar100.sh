CUDA_VISIBLE_DEVICES=0 python main.py \
--experiment cifar100 \
--scenario class \
--lr 1e-4 \
--seed 2 \
--div_weight 1e-13 \
--pdf \
--epc-per-virtual-task 50 \
--save-dir cifar100/boundary-agnostic/ebm-class-e-13 \
--ebm \


