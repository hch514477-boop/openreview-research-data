Single-file code submission for the paper: Interpretable Deep Clustering

Please use Google Colab / your local jupyter environment to run idc_mnist.ipynb

