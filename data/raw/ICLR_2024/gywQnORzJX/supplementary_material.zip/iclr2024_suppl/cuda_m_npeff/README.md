# CUDA m-NPEFF

CUDA/C++ implementation of the m-NPEFF factorization algorithm.


## Random Commands


```bash

# Install hdf5 libraries for C/C++?
sudo apt install libhdf5-dev
sudo apt-get install libhdf5-serial-dev
# IDK if either were needed, but adding "-I/usr/include/hdf5/serial -lhdf5_cpp"
# as nvcc compiler flags got stuff working.


# # Abseil. IDK if this is the best way. Need to point library/linker to it.
# conda install -c conda-forge abseil-cpp

```
#### Install CMake

```bash
pip3 install cmake

# To run cmake:

# Configure:
cmake -S . -B build

# Build:
cmake --build build

# Run executable (example here)
./build/mains/dummy_main

# Run tests (need to build first):
ctest --test-dir build

# Build then run tests:
cmake --build build; ctest --test-dir build

```

- https://cliutils.gitlab.io/modern-cmake/
- https://gitlab.com/CLIUtils/modern-cmake/tree/master/examples/extended-project


#### Install NCCL
```bash

sudo rm /usr/share/keyrings/cuda-archive-keyring.gpg 
rm ./cuda-keyring_1.0-1_all.deb

sudo rm /etc/apt/sources.list.d/cuda.list
sudo rm /etc/apt/sources.list.d/cuda-ubuntu1804-x86_64.list
sudo rm /etc/apt/sources.list.d/cuda-ubuntu2004-x86_64.list

# cd /tmp

# Local
wget --no-check-certificate https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2004/x86_64/cuda-keyring_1.0-1_all.deb
# Banana for whatever reason.
# wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu1804/x86_64/cuda-keyring_1.0-1_all.deb
sudo dpkg -i cuda-keyring_1.0-1_all.deb
sudo apt-get update
sudo apt install -f libnccl2 libnccl-dev


```
