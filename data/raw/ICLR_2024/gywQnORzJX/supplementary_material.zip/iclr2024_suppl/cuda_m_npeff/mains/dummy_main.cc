// Dummy main file for figuring out cmake stuff.

#include <iostream>
#include <string>

#include <gflags/gflags.h>

#include <containers/dense_matrix.h>
#include <containers/sparse_matrix.h>

#include <inputs/lrm_pefs.h>

#include <preprocess/construct_csr_matrix.h>
#include <preprocess/partition_by_columns.h>
#include <preprocess/column_pruning.h>
#include <preprocess/pef_normalization.h>

#include <util/h5_util.h>

int main(int argc, char *argv[]) {
    gflags::ParseCommandLineFlags(&argc, &argv, true);
    
    // std::cout << "test" << "\n";

    std::string filepath("fielpathsdf");
    // npeff::inputs::LrmPefs::load(filepath);

    npeff::DenseMatrix<float> mat(13, 80);

    std::cout << npeff::util::h5::TypeId<float>::id << "\n";
    std::cout << npeff::util::h5::TypeId<int32_t>::id << "\n";
    std::cout << "test" << "\n";

}
