
sh ~/Desktop/projects/cuda_m_npeff/dev_scripts/move_code_to_fruit.sh


cd /fruitbasket/users/m/project_code/cuda_m_npeff

export PATH=/home/m/.local/bin:$PATH

cmake -DCMAKE_CUDA_ARCHITECTURES=86 -S . -B build
cmake --build build

# Compile on mango/banana, then can run on guava/watermelon.

###########################################################
