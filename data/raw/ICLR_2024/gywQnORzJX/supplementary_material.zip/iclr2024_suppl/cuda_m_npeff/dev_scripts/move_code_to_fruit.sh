#!/bin/bash

# sh ~/Desktop/projects/cuda_m_npeff/dev_scripts/move_code_to_fruit.sh


USER=m
SERVER=banana
# SERVER=mango

LOCAL_CODE_DIR=~/Desktop/projects/cuda_m_npeff
REMOTE_CODE_DIR=/fruitbasket/users/m/project_code/cuda_m_npeff


rsync -ra -e ssh \
    --exclude "build" \
    --exclude "Testing" \
    --exclude "*/__pycache__" \
    --exclude "*/.git" \
    "${LOCAL_CODE_DIR}/" \
    "${USER}@${SERVER}.cs.unc.edu:${REMOTE_CODE_DIR}/"
