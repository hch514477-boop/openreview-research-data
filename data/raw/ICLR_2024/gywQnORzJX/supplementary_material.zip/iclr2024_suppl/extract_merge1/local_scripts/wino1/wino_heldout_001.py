R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/wino1/wino_heldout_001.py

"""

import dataclasses
from importlib import reload
import os
import time

from colorama import Fore, Back, Style
import matplotlib.pyplot as plt
import numpy as np
import scipy.sparse as sps
import seaborn as sns
import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.models import transformer_model_vars as tmv
from em.tools.nmf import nmf_common
from em.tools.nmf import nmf_transform
from em.util import flat_pack
from em.util import hf_util
from em.util.color_util import cu

from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf


rocket_cmap = sns.color_palette("rocket", as_cmap=True)

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/winogrange1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

PRETRAINED_MODEL = 'bert-base-uncased'
SEQUENCE_LENGTH = 50
EVAL_BATCH_SIZE = 128

MODEL = "bert_base_mnli_to_winogrande_custom_8_epochs_01"
PER_EXAMPLES_FISHERS = f"{MODEL}.winogrande_heldout.no_embeddings.sparse_dynamic_raw.32k.32k.h5"
DECOMP_FILENAME = f"nmf_decomp.per_sub_block.10k.16k.256.{PER_EXAMPLES_FISHERS}"

FROM_PT = False

N_DECOMPS = 25


'''

Coefficient fractor: 0.300   Fraction threshold: 0.500   P-value threshold: 0.0100
    Top examples fraction: 0.176
    Top examples accuracy: 0.478
    Remaining examples accuracy: 0.887

'''
# _NCF_BASE_FILENAME = f'nmf_components_fishers.incorrect.per_sub_block.10k.16k.256.{PER_EXAMPLES_FISHERS}'
# ncf.print_parameters_and_accuracy_infos_matching_file(os.path.join(FISHERS_DIR, _NCF_BASE_FILENAME))


###############################################################################

tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL)

container = am.load_pef_nmf_analysis_container(
    pef_filepath=os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    nmf_filepath=os.path.join(PER_EXAMPLES_FISHERS_DIR, DECOMP_FILENAME),
    n_nmfs=N_DECOMPS,
    tokenizer=tokenizer,
    shift_labels=True,
)

# Do this kinda hack to get labels correct. Having shift_labels=True
# and then doing this gets the string labels and the integer labels
# properly matched.
container.labels = container.pef.labels
container.examples = container._make_nli_examples()


container.nmfs.force_load_all()

###############################################################################

incorrect_indicator = container.get_incorrect_prediction_indicator()

sp = ncf.SelectionParameters(
    coeff_factor=0.5,
    frac_threshold=0.6,
    p_value_threshold=0.01,
)
ac_fisher = ncf.get_apparently_tuned_fisher(container, incorrect_indicator, sp)

###############################################################################

component_indices_per_subset = [
    list(sorted(c.component_index for c in ssi.correct_component_infos))
    for ssi in ac_fisher.subset_infos
]


for i, inds in enumerate(component_indices_per_subset):
    print(i, inds)


container.print_top_examples(n_examples=8, nmf_index=0, component_index=161)


###############################################################################

# model = TFAutoModelForSequenceClassification.from_pretrained(
#     os.path.join(MODELS_DIR, MODEL), from_pt=False)
# model.compile(
#     metrics=tf.keras.metrics.SparseCategoricalAccuracy(),
#     loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
# )

# train_for_eval_ds = em_datasets.load(
#     'winogrande/custom',
#     split='train',
#     tokenizer=tokenizer,
#     sequence_length=SEQUENCE_LENGTH,
#     force_deterministic=True,
# )
# train_for_eval_ds = train_for_eval_ds.batch(EVAL_BATCH_SIZE).cache()

# heldout_ds = em_datasets.load(
#     'winogrande/custom',
#     split='heldout',
#     tokenizer=tokenizer,
#     sequence_length=SEQUENCE_LENGTH,
#     force_deterministic=True,
# )
# heldout_ds = heldout_ds.batch(EVAL_BATCH_SIZE).cache()

# val_ds = em_datasets.load(
#     'winogrande/custom',
#     split='validation',
#     tokenizer=tokenizer,
#     sequence_length=SEQUENCE_LENGTH,
#     force_deterministic=True,
# )
# val_ds = val_ds.batch(EVAL_BATCH_SIZE).cache()

# model.evaluate(val_ds)
# model.evaluate(heldout_ds)
# model.evaluate(train_for_eval_ds)

