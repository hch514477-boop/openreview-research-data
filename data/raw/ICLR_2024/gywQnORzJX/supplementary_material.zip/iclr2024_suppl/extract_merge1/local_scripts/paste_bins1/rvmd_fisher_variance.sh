
VIRTUALENV_NAME=extract_merge1

CODE_DIR=/fruitbasket/users/m/project_code/extract_merge1
DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

cd $CODE_DIR
workon $VIRTUALENV_NAME
export PYTHONPATH="$PYTHONPATH:$CODE_DIR",
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets


###################################################################################
###################################################################################


# Do comparison of variance of per-example fisher for parameters with high metric derived vs high raw fisher
# (and the whole 2x2 combination grid)


###################################################################################
###################################################################################

FISHER_DIR=/fruitbasket/users/m/project_data/extract_merge1/fishers0

TASK="mnli"
MODEL="prajjwal1/bert-small-mnli"
PRETRAINED_MODEL="prajjwal1/bert-small"

#######################################

CUDA_VISIBLE_DEVICES=0 python ./scripts1/ogmm/compute_fisher.py  \
    --model=$MODEL \
    --glue_task=$TASK \
    --fisher_path="$FISHER_DIR/bert_small_${TASK}_fisher.131k.h5" \
    --batch_size=64 \
    --n_examples=131072

#######################################


CUDA_VISIBLE_DEVICES=0 python ./scripts1/misc_prelims/sparse_fisher_variances.py  \
    --output_path="$FISHER_DIR/bert_small_${TASK}_sparse_fisher_variances_32k.sp05.metric.131k.h5" \
    --model=$MODEL \
    --pretrained_model=$PRETRAINED_MODEL \
    --glue_task=$TASK \
    --dense_fisher="$FISHER_DIR/bert_small_${TASK}_fisher.131k.h5" \
    --batch_size=32 \
    --n_examples=32768 \
    --sparsification_method="metric_derived" \
    --sparsity=0.05


CUDA_VISIBLE_DEVICES=1 python ./scripts1/misc_prelims/sparse_fisher_variances.py  \
    --output_path="$FISHER_DIR/bert_small_${TASK}_sparse_fisher_variances_32k.sp05.uniform.131k.h5" \
    --model=$MODEL \
    --pretrained_model=$PRETRAINED_MODEL \
    --glue_task=$TASK \
    --dense_fisher="$FISHER_DIR/bert_small_${TASK}_fisher.131k.h5" \
    --batch_size=32 \
    --n_examples=32768 \
    --sparsification_method="uniform" \
    --sparsity=0.05


#######################################

# Run on my laptop.
FISHER_DIR=/fruitbasket/users/m/project_data/extract_merge1/fishers0
TASK="mnli"
METHOD="metric"
# METHOD="uniform"
rsync -ra -e ssh \
    "m@banana.cs.unc.edu:$FISHER_DIR/bert_small_${TASK}_sparse_fisher_variances_32k.sp05.${METHOD}.131k.h5" \
    "$HOME/Desktop/projects_data/extract_merge1/fishers0/"

