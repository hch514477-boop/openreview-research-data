R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=2,3 python -i local_scripts/nmf/nmf_bert_small_dev001.py

"""
import collections
import dataclasses
import os
from importlib import reload
import itertools
import time
from typing import Any, List, Sequence

import h5py
import matplotlib.pyplot as plt
import numpy as np
from sklearn.decomposition import NMF
import tensorflow as tf
import tensorflow_probability as tfp
import torch
from torchnmf.nmf import NMF as TorchNMF
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em.datasets import glue
from em.evaluation import evaluation
from em.fishers import diagonal
from em.fishers import per_example
from em.fishers import sparse_diagonal
from em.merging import merging
from em.models.generative import vae
# from em.models.generative import soc
from em.util import hf_util
from em.util import vat_da_faak_vpn

# from em.tools import bionmf_gpu as bionmf

from local_scripts.nmf import nmf_dev_bert as ndb
from local_scripts.soc import soc_dev_common as sdc

###############################################################################

gpus = tf.config.experimental.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)

ndb.separate_tf_torch_gpus()


###############################################################################
TASK = 'mnli'
MODEL = "prajjwal1/bert-small-mnli"
PRETRAINED_MODEL = "prajjwal1/bert-small"

METRIC_VAR_FISHER = "bert_small_mnli_sparse_fisher_variances_32k.sp05.metric.131k.h5"
UNIFORM_VAR_FISHER = "bert_small_mnli_sparse_fisher_variances_32k.sp05.uniform.131k.h5"
###############################################################################

sparse_fisher = sparse_diagonal.SparseDiagonalFisher.load(os.path.join(ndb.FISHER_DIR, METRIC_VAR_FISHER))

trained_model = TFAutoModelForSequenceClassification.from_pretrained(MODEL, from_pt=True)
tokenizer = AutoTokenizer.from_pretrained(MODEL)

model_variables = hf_util.get_mergeable_variables(trained_model)
model_fishers = sparse_fisher.fishers

model_variables, model_fishers = sdc.filter_out_embeddings_variables(model_variables, model_fishers)

###############################################################################
###############################################################################

PER_EXAMPLE_FISHER_BATCH_SIZE = 256

N_NMF_EXAMPLES = 1024

# N_NMF_COMPONENTS = 32
N_NMF_COMPONENTS = 64
# N_NMF_COMPONENTS = 256

###############################################################################

pe_ds = ndb.create_dataset_for_per_example_fishers(
    tokenizer,
    batch_size=PER_EXAMPLE_FISHER_BATCH_SIZE,
    task=TASK,
)

examples, labels, fishers = ndb.get_fishers_with_examples(
    trained_model,
    pe_ds,
    n_examples=N_NMF_EXAMPLES,
    variables=model_variables,
    sparse_indices=model_fishers,
    normalize_fishers=True,
    expectation_wrt_logits=True,
)

predictions = tf.argmax(trained_model(examples).logits, axis=-1)

print('asdafsadfasdf')


###############################################################################

fishers = fishers.numpy()

torch.cuda.set_device(1)

torch_fishers = torch.from_numpy(fishers.T).cuda()

nmf_model = TorchNMF(torch_fishers.shape, rank=N_NMF_COMPONENTS).cuda()
nmf_model.fit(torch_fishers)

W = nmf_model.W.detach().cpu().numpy()
Ht = nmf_model.H.detach().cpu().numpy()

# plt.imshow(W.T)
# plt.show()

ndb.print_top_examples(W, tokenizer, examples, labels, n_examples=8, component=0)
# ndb.print_top_examples(W, tokenizer, examples, predictions, n_examples=8, component=0)

# plt.plot(Ht[:, 5])
# plt.plot(Ht[:, 26])
# plt.show()

plt.plot(W[0])
plt.show()
