

VIRTUALENV_NAME=extract_merge1

CODE_DIR=/fruitbasket/users/m/project_code/extract_merge1
DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

cd $CODE_DIR
workon $VIRTUALENV_NAME
export PYTHONPATH="$PYTHONPATH:$CODE_DIR",
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

TCAV_DIR="/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/tcav"



run_tcav() {
    local device=$1
    local decomposition_filepath=$2
    local activations_filename=$3
    local output_filename=$4
    local decomposition_type=$5

    local n_runs=500
    local n_top_examples=32
    local n_negative_examples=128
    local n_scoring_examples=5000

    local CLS_ACTS_DIR="/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers"

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/comp_measure/run_bert_tcav_exp.py \
        --decomposition_filepath="${decomposition_filepath}" \
        --decomposition_type=$decomposition_type \
        --activations_filepath="${CLS_ACTS_DIR}/${activations_filename}" \
        --model="connectivity/feather_berts_0"   \
        --from_pt=true \
        --output_filepath="${TCAV_DIR}/${output_filename}" \
        --n_runs=$n_runs \
        --n_top_examples=$n_top_examples \
        --n_negative_examples=$n_negative_examples \
        --n_scoring_examples=$n_scoring_examples
}

run_tcav 0 \
    "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/kmeans.128comps.feather_berts_0.snli.train.50000ex.bert_cls_activations.h5" \
    "feather_berts_0.snli.train_skip_50k.50000ex.bert_cls_activations.h5" \
    "tcav.kmeans.128comps.feather_berts_0.snli.train.50000ex.bert_cls_activations.json" \
    K_MEANS

run_tcav 1 \
    "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/ica.128comps.feather_berts_0.snli.train.50000ex.bert_cls_activations.h5" \
    "feather_berts_0.snli.train_skip_50k.50000ex.bert_cls_activations.h5" \
    "tcav.ica.128comps.feather_berts_0.snli.train.50000ex.bert_cls_activations.json" \
    ICA




og_pef_name="feather_berts_0.snli_train.all_vars.50000ex.65536.h5"
og_h_name="spH.nmf_decomp2.c512_1250Iters_65536pe_mvpp10_50000ex.${og_pef_name}"
nmf_name="fit_w.skip50000.50000ex.65536vpe.${og_h_name}"

run_tcav 3 \
    "/fruitbasket/users/m/project_data/extract_merge1/pi1/per_example_fishers/${nmf_name}" \
    "feather_berts_0.snli.train_skip_50k.50000ex.bert_cls_activations.h5" \
    "tcav.diagonal_npeff.feather_berts_0.train_skip_50k.json" \
    NPEFF


###################################################################################

make_tcav_p_csv() {
    local tcav_filepath=$1
    CUDA_VISIBLE_DEVICES= python ./em/projects/neurips2023/make_tcav_p_csv.py \
        --tcav_filepath=$tcav_filepath
}

make_tcav_p_csv "/fruitbasket/users/m/project_data/extract_merge1/snli3og_lrm_npeff/tcav/tcav.feather_berts_0.train.50000ex.65536.mnpeff.512comps.001.fit_to_train_skip_50k.h5"
# 3.716422759460206e-24

make_tcav_p_csv "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/tcav/tcav.kmeans.128comps.feather_berts_0.snli.train.50000ex.bert_cls_activations.json"
# 0.0

make_tcav_p_csv "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/tcav/tcav.ica.128comps.feather_berts_0.snli.train.50000ex.bert_cls_activations.json"
# 5.382087540140508e-24

make_tcav_p_csv "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/tcav/tcav.diagonal_npeff.feather_berts_0.train_skip_50k.json"
# 0.0010229108100621752


# snli: 0, 3, 8, 17
# qqp: 0, 3, 9, 10
