R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/nmf/nmf_math_bert_small_dev001.py

"""

import collections
import dataclasses
import os
from importlib import reload
import itertools
import time
from typing import Any, List, Sequence

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
import torch
from torchnmf.nmf import NMF as TorchNMF
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em.datasets import glue
from em.evaluation import evaluation
from em.fishers import diagonal
from em.fishers import per_example
from em.fishers import sparse_diagonal
from em.util import hf_util
from em.util import vat_da_faak_vpn

from em.tools.nmf import nmf_common

from local_scripts.nmf import nmf_dev_bert as ndb
from local_scripts.soc import soc_dev_common as sdc

###############################################################################

gpus = tf.config.experimental.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)

# ndb.separate_tf_torch_gpus()

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/math_datasets_dev1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models1')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers0')

#######################################

# TASK = 'math_dataset/original_true_false'
# MODEL = "og_tf__bert_small"
# FROM_PT = False
# PER_EXAMPLES_FISHERS = "og_tf__bert_small.no_embeddings.sparse_dynamic_raw.16k.32k.h5"

# PRETRAINED_MODEL = "prajjwal1/bert-small"

#######################################

TASK = 'math_dataset/original_true_false'
MODEL = "og_tf__bert_small__100k_steps"
FROM_PT = False
# PER_EXAMPLES_FISHERS = "og_tf__bert_small__100k_steps.no_embeddings.sparse_dynamic_raw.32k.32k.h5"
PER_EXAMPLES_FISHERS = "og_tf__bert_small__100k_steps.no_embeddings_no_pooler.sparse_dynamic_raw.32k.32k.h5"

PRETRAINED_MODEL = "prajjwal1/bert-small"

###############################################################################

# N_EXAMPLES = 65536
N_EXAMPLES = 8 * 1024
# N_EXAMPLES = 4 * 1024
# N_EXAMPLES = 32 * 1024
# N_EXAMPLES = 16 * 1024

# START_FISHER_INDEX, END_FISHER_INDEX = (0, 1024)
START_FISHER_INDEX, END_FISHER_INDEX = (0, 4096)
# START_FISHER_INDEX, END_FISHER_INDEX = (0, 2 * 4096)

# N_NMF_COMPONENTS = 32
# N_NMF_COMPONENTS = 64
N_NMF_COMPONENTS = 128

#######################################

tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL)

print('Starting to load saved per-example Fishers.')
start = time.time()
pe_fishers_data = per_example.PerExampleFlatFishers.load(
    os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    n_examples=N_EXAMPLES,
    start_fisher_index=START_FISHER_INDEX,
    end_fisher_index=END_FISHER_INDEX,
)
print('Load saved per-example Fishers time: ', time.time() - start)

fisher_values = pe_fishers_data.fishers
fisher_indices = pe_fishers_data.fisher_indices
fisher_dense_size = pe_fishers_data.fisher_dense_size

# #
# #
# # Only for sparse_dynamic_metric_derived here.
# sq_parameter_deltas = pe_fishers_data.sq_parameter_deltas
# normalized_sq_parameter_deltas = sq_parameter_deltas / sq_parameter_deltas.max()
# for i in range(fisher_values.shape[0]):
#     # fisher_values[i] *= sq_parameter_deltas[fisher_indices[i]]
#     fisher_values[i] *= normalized_sq_parameter_deltas[fisher_indices[i]]

# #
# #

first_index = np.ones_like(fisher_indices) * np.arange(fisher_indices.shape[0], dtype=fisher_indices.dtype)[:, None]

indices = np.stack([
    first_index.reshape([-1]),
    fisher_indices.reshape([-1]),
], axis=0)

values = pe_fishers_data.fishers.reshape([-1])

examples = {'input_ids': pe_fishers_data.input_ids}
labels = pe_fishers_data.labels
predicted_logits = pe_fishers_data.predicted_logits

#######################################


print([fisher_indices.shape[0], fisher_dense_size])
print(indices.shape)
print(values.shape)


# TODO: Do the transpose of this, should be fairly straightforward.
torch_fishers = torch.sparse_coo_tensor(indices, values, [fisher_indices.shape[0], fisher_dense_size]).cuda()
torch_fishers = torch_fishers.t_()

start = time.time()
nmf_model = TorchNMF(torch_fishers.shape, rank=N_NMF_COMPONENTS).cuda()
nmf_model.fit(
    torch_fishers,
    verbose=True,
    # beta=2,
    tol=1e-6,
)
print('NMF time: ', time.time() - start)

#######################################

W = nmf_model.W.detach().cpu().numpy()

ndb.print_top_examples(W, tokenizer, examples, labels, n_examples=8, component=0)


###

Ht = nmf_model.H.detach().cpu().numpy()


# DECOMP_FILENAME = 'nmf_decomp.8k.4k.128.og_tf__bert_small__100k_steps.no_embeddings.sparse_dynamic_raw.32k.32k.h5'

# decomp = nmf_common.NmfDecomposition(W=W, H=Ht.T)
# decomp.save(os.path.join(PER_EXAMPLES_FISHERS_DIR, DECOMP_FILENAME))


###

# q = H.T.dot(H)
# w = (H**2).T.sum(axis=1, keepdims=True).dot((H**2).sum(axis=0, keepdims=True))
# r = q / np.sqrt(w)
# plt.imshow(r)
# plt.show()

