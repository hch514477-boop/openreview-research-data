
R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python local_scripts/m_npeff/snli2/make_snli_latex001.py

"""
from importlib import reload
import os

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer

from em.tools.nmf import lrm_npeff
from em.projects.m_npeff import snli_context
from em.projects.m_npeff import latex_generation
from em.fishers import lrm_pefs

from em.util.color_util import cu

###############################################################################

NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/snli2_lrm_npeff/per_example_fishers/"
NMF_NAME = "bert_base_snli_150k_holdout_4_epochs_01_epoch2.heldout_from_train_2.50000ex.65536.512comps.expansion64comps.no_full_join.001.coeffs_fit001.h5"
NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)

# Use this only to get the predictions and example token ids without having to
# evaluate the model.
PEFS_DIR = "/fruitbasket/users/m/project_data/extract_merge1/snli2_lrm_npeff/per_example_fishers/"
PEFS_NAME = "bert_base_snli_150k_holdout_4_epochs_01_epoch2.heldout_from_train_2.50000ex.65536.h5"
PEFS_PATH = os.path.join(PEFS_DIR, PEFS_NAME)

###############################################################################

TOKENIZER = 'bert-base-uncased'
SPLIT = 'train[-100000:-50000]'

###############################################################################

nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=False)

ctx = snli_context.SnliContext(
    split=SPLIT,
    tokenizer=AutoTokenizer.from_pretrained(TOKENIZER),
    nmf=nmf,
)


# (y + 1) % 3
# [2, 0, 1]

logits = lrm_pefs.SparseLrmPefs.load_logits(PEFS_PATH)
logits = np.stack([logits[:, i] for i in [2, 0, 1]], axis=-1)


# reload(latex_generation)
lg = latex_generation.TopExamplesLatexGenerator(
    snli_ctx=ctx,
    predicted_logits=logits,
    n_top_examples=16,
)

latex_str = lg.generate_all_components_latex()

filename = 'snli2.bert_base_snli_150k_holdout_4_epochs_01_epoch2.heldout_from_train_2.50000ex.65536.512comps.expansion64comps.no_full_join.001.coeffs_fit001.tex'

with open(os.path.join('/fruitbasket/users/m/tmp', filename), 'w') as f:
    f.write(latex_str)


print(cu.hlg(filename))


R"""

make_pdf() {
    local filename=$1

    rsync -ra -e ssh \
        "m@mango.cs.unc.edu:/fruitbasket/users/m/tmp/${filename}.tex" \
        "$HOME/Downloads/${filename}.tex"

    xelatex -interaction=batchmode -output-directory=/tmp ~/Downloads/${filename}.tex
    mv /tmp/${filename}.pdf ~/Desktop/projects_data/extract_merge1/ll/pdfs
}

make_pdf snli2.bert_base_snli_150k_holdout_4_epochs_01_epoch2.heldout_from_train_2.50000ex.65536.512comps.expansion64comps.no_full_join.001.coeffs_fit001


"""
