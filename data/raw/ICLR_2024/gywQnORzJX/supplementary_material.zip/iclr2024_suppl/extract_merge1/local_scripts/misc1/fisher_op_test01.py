R"""

cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i local_scripts/misc1/fisher_op_test01.py


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/misc1/fisher_op_test01.py
"""

import collections
import dataclasses
import os
from importlib import reload
import itertools
import time
from typing import Any, List, Sequence

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf

from em.ops import diagonal_fisher_util
from em.util import vat_da_faak_vpn

###############################################################################
DEBUG = diagonal_fisher_util._DEBUG
###############################################################################


model = tf.keras.Sequential([
    tf.keras.layers.Dense(32, activation='relu'),
    tf.keras.layers.Dense(16, activation='relu'),
    tf.keras.layers.Dense(5, activation=None),
])


input_size = 128

model(tf.keras.Input([input_size]))


@tf.function
def fn():
    inputs = tf.random.uniform([6, input_size])
    logits = model(inputs, training=False)
    return diagonal_fisher_util.diagonal_fishers(logits, model.trainable_variables, per_example=True)


fn()



# ops = DEBUG.ops
# op = ops[0]

