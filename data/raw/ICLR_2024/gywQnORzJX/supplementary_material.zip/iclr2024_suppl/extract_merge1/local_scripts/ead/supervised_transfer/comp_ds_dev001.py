R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1

python3 -i local_scripts/ead/supervised_transfer/comp_ds_dev001.py


CUDA_VISIBLE_DEVICES=1 python -i local_scripts/ead/supervised_transfer/comp_ds_dev001.py

"""
import csv
import dataclasses
from importlib import reload
import os
import random
import sys
import time
from typing import Sequence, Mapping

import sympy as sp

from em.datasets.antiderivative.scomps import exex

csv.field_size_limit(sys.maxsize)

###############################################################################
###############################################################################

CSV_PATH = '~/Desktop/projects_data/extract_merge1/antiderivative/datasets/expressions001_ead.3M.04.5s.csv'

gen = exex.ExexGenerator(
    expressions_source=exex.CsvExpressionsSource(CSV_PATH),
    p_constant_type={
        'small_int': 0.5,
        'moderate_int': 0.2,
        'rational': 0.15,
        # 'irrational': 0.15
    }
)

expr, label = gen.sample_expression()
print(expr, label)
