#!/bin/bash

# sh ~/Desktop/projects/extract_merge1/local_scripts/move_code_to_fruit.sh


USER=m
# SERVER=banana
SERVER=mango

LOCAL_CODE_DIR=~/Desktop/projects/extract_merge1
REMOTE_CODE_DIR=/fruitbasket/users/m/project_code/extract_merge1
# REMOTE_DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1


rsync -ra -e ssh \
    --exclude "*/__pycache__" \
    --exclude "*/build" \
    --exclude "*/.git" \
    "${LOCAL_CODE_DIR}/" \
    "${USER}@${SERVER}.cs.unc.edu:${REMOTE_CODE_DIR}/"
