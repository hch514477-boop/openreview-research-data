R"""



cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/divis/divis_per_layer_nmf001.py

"""
import collections
from importlib import reload
import itertools
import os
import time

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import tensorflow as tf

from em.datasets import divisibility as div_ds
from em.fishers import per_example
from em.models import divis_models
from em.models import transformer_model_vars as tmv
from em.tools.clustering import vat
from em.tools.nmf import parallel_sklearn_nmf as p_nmf
from em.tools.nmf import nmf_common
from em.util import flat_pack

from em.analysis import bert_nmf_analysis as bna
from em.analysis import bert_nmf_analysis2 as bna2

rocket_cmap = sns.color_palette("rocket", as_cmap=True)

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/divis_mech1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

MODEL = "misc_divis_model_001_deep_semi_sixteenth"
PER_EXAMPLES_FISHERS = f"{MODEL}.sparse_dynamic_raw.64k.32k.h5"

DECOMP = f"nmf_decomp.32k.8k.384.{PER_EXAMPLES_FISHERS}"
N_EXAMPLES = 32 * 1024
START_FISHER_INDEX, END_FISHER_INDEX = (0, 8 * 1024)

###############################################################################


model, model_config = divis_models.load_model_from_file(os.path.join(MODELS_DIR, f'{MODEL}.h5'))


print('Starting to load saved per-example Fishers.')
start = time.time()
pe_fishers_data = per_example.PerExampleFlatFishers.load(
    os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    n_examples=N_EXAMPLES,
    start_fisher_index=START_FISHER_INDEX,
    end_fisher_index=END_FISHER_INDEX,
    extra_data_fields=['dividends', 'divisors'],
)
print('Load saved per-example Fishers time: ', time.time() - start)


###############################################################################

def load_nmf_decomp(subset_index: int):
    print('Starting to load saved NMF decomposition.')
    start = time.time()
    filename = f"{DECOMP[:-3]}.ssi{subset_index}.h5"
    decomp = nmf_common.NmfDecomposition.load(os.path.join(PER_EXAMPLES_FISHERS_DIR, filename))
    decomp.normalize_components_to_unit_norm()
    decomp.H = decomp.get_full_H()
    print('Load saved NMF decomposition time: ', time.time() - start)
    return decomp


# ssi1 = 6
# ssi2 = 7

# ssi1 = 2
# ssi2 = 3

ssi1 = 4
ssi2 = 5

decomp1 = load_nmf_decomp(ssi1)
decomp2 = load_nmf_decomp(ssi2)

variables = model.trainable_variables
homogenized_variables = tmv.homogenize_kernel_biases(variables)

###############################################################################


def print_top_examples(decomp, component_index: int, n_examples: int):
    _, inds = tf.math.top_k(decomp.W[:, component_index], k=n_examples)
    for ind in inds:
        label = pe_fishers_data.labels[ind]
        prediction = np.argmax(pe_fishers_data.predicted_logits[ind])
        #
        divisor = pe_fishers_data.divisors[ind]
        dividend = pe_fishers_data.dividends[ind]
        example = f'{divisor}|{dividend}'
        #
        print(f'{label}, {prediction}: {example}')


print_top_examples(decomp1, 0, n_examples=16)
print_top_examples(decomp2, 0, n_examples=16)

###############################################################################

rsH1 = decomp1.H.reshape([decomp1.H.shape[0], *homogenized_variables[ssi1].shape])
rsH2 = decomp2.H.reshape([decomp2.H.shape[0], *homogenized_variables[ssi2].shape])


def plot_sing_values(rsH, comps, top_k: int = 16):
    comps = rsH[comps]
    s = tf.linalg.svd(comps, compute_uv=False)
    for x in s:
        plt.plot(x[:top_k] / tf.reduce_sum(x))
    plt.show()


def dense_layer_on_homog(dense, x):
    w = tf.concat([dense.kernel, dense.bias[None, :]], axis=0)
    return dense.activation(x @ w)


def l2_normalize(x):
    return x / (np.sqrt((x**2).sum(axis=-1, keepdims=True)) + 1e-12)


def print_top_examples_for_top_pairs(A, n_pairs: int, n_examples_per_pair: int = 8):
    m, n = A.shape
    _, inds = tf.math.top_k(tf.reshape(A, [-1]), k=n_pairs)
    inds = tf.stack([inds // m, inds % m], axis=-1).numpy()
    for i, j in inds:
        print(f'Component {i}:')
        print_top_examples(decomp1, i, n_examples=n_examples_per_pair)
        print(f'Component {j}:')
        print_top_examples(decomp2, j, n_examples=n_examples_per_pair)
        print('')


# plot_sing_values(rsH2, list(range(32)))

blah1 = np.concatenate([rsH1.sum(axis=1), np.ones([rsH1.shape[0], 1], dtype=rsH1.dtype)], axis=-1)
# rsH1.sum(axis=1)
blah2 = rsH2.sum(axis=2)


# TODO: Better way than adding small constant, needed to get rid of NaNs
# that throw errors in the NMF.
ha, ga = p_nmf.perform_nmfs(rsH1 + 1e-12, n_components=1)
ha = np.sqrt(np.squeeze(ha, axis=-1))
ga = np.sqrt(np.squeeze(ga, axis=-2))

hb, gb = p_nmf.perform_nmfs(rsH2 + 1e-12, n_components=1)
hb = np.sqrt(np.squeeze(hb, axis=-1))
gb = np.sqrt(np.squeeze(gb, axis=-2))


res_block_index = (ssi1 - 2) // 2
res_block = model.layers[3 + res_block_index]


rha = dense_layer_on_homog(res_block.dense1, ha).numpy()
hrha = np.concatenate([rha, np.ones([rha.shape[0], 1], dtype=rha.dtype)], axis=-1)

###############################################################################

# plt.imshow(hrha @ hb.T, cmap=rocket_cmap);plt.tight_layout();plt.show()
# plt.imshow(rha @ hb[:, :-1].T, cmap=rocket_cmap);plt.tight_layout();plt.show()

# print_top_examples_for_top_pairs(hrha @ hb.T, n_pairs=8)
# print_top_examples_for_top_pairs(rha @ hb[:, :-1].T, n_pairs=8)

# print_top_examples_for_top_pairs(l2_normalize(hrha) @ l2_normalize(hb).T, n_pairs=8)
# print_top_examples_for_top_pairs(l2_normalize(rha) @ l2_normalize(hb[:, :-1]).T, n_pairs=8)


# # 19, 75
# print_top_examples(decomp1, 19, n_examples=8)
# print_top_examples(decomp2, 75, n_examples=8)

# # 20, 88
# print_top_examples(decomp1, 20, n_examples=8)
# print_top_examples(decomp2, 88, n_examples=8)

# # 222, 273
# print_top_examples(decomp1, 222, n_examples=8)
# print_top_examples(decomp2, 273, n_examples=8)

# # 262, 291
# print_top_examples(decomp1, 262, n_examples=8)
# print_top_examples(decomp2, 291, n_examples=8)


# A = blah1 @ blah2.T
# plt.imshow(A, cmap=rocket_cmap);plt.show()


# # 254, 42
# print_top_examples(decomp1, 254, n_examples=8)
# print_top_examples(decomp2, 42, n_examples=8)

# # 261, 37
# print_top_examples(decomp1, 261, n_examples=8)
# print_top_examples(decomp2, 37, n_examples=8)


###############################################################################

def plot_sim_matrix(decomp, plot=True):
    cos_dissim_matrix = 1 - decomp.H @ decomp.H.T
    vat_dissim_matrix, permutation = vat.vat_reorder_dissimilarity_matrix(cos_dissim_matrix)
    M = 1 - vat_dissim_matrix
    if plot:
        bna.plot_sim_matrix(M, show=True)
    return permutation


permutation1 = plot_sim_matrix(decomp1, plot=False)
permutation2 = plot_sim_matrix(decomp2, plot=False)

# print_top_examples(decomp1, permutation1[0], n_examples=8)
# print_top_examples(decomp1, permutation1[1], n_examples=8)
# print_top_examples(decomp1, permutation1[2], n_examples=8)
# print_top_examples(decomp1, permutation1[3], n_examples=8)
# print_top_examples(decomp1, permutation1[4], n_examples=8)

# print_top_examples(decomp2, permutation2[0], n_examples=8)
# print_top_examples(decomp2, permutation2[1], n_examples=8)
# print_top_examples(decomp2, permutation2[2], n_examples=8)
# print_top_examples(decomp2, permutation2[3], n_examples=8)
# print_top_examples(decomp2, permutation2[4], n_examples=8)

###############################################################################

# ha, ga, hb, gb

# plt.imshow(ga @ hb[:, :-1].T, cmap=rocket_cmap);plt.tight_layout();plt.show()
# plt.imshow(ga[permutation1] @ hb[permutation2][:, :-1].T, cmap=rocket_cmap);plt.tight_layout();plt.show()
# plt.imshow(l2_normalize(ga[permutation1]) @ l2_normalize(hb[permutation2])[:, :-1].T, cmap=rocket_cmap);plt.tight_layout();plt.show()

# print_top_examples_for_top_pairs(ga @ hb[:, :-1].T, n_pairs=16)


###############################################################################

plt.imshow(decomp1.W[:, permutation1].T @ decomp2.W[:, permutation2], cmap=rocket_cmap);plt.tight_layout();plt.show()

# print_top_examples(decomp1, 42, n_examples=8)
# print_top_examples(decomp2, 110, n_examples=8)

print_top_examples_for_top_pairs(decomp1.W.T @ decomp2.W, n_pairs=32)


def asdfasdf(comp1: int, comp2: int):
    plt.plot(rsH1[comp1].sum(axis=0))
    plt.plot(rsH2[comp2].sum(axis=1))
    plt.show()


# asdfasdf(178, 90)
# asdfasdf(123, 126)
# asdfasdf(343, 243)

# asdfasdf(221, 90)


comp1_inds = tf.argsort((decomp1.W.T @ decomp2.W)[:, 90], direction='DESCENDING')
asdfasdf(comp1_inds[0], 90)


print_top_examples(decomp2, 90, n_examples=16)

print_top_examples(decomp1, comp1_inds[5], n_examples=8)
print_top_examples(decomp1, comp1_inds[7], n_examples=8)
print_top_examples(decomp1, comp1_inds[11], n_examples=8)
print_top_examples(decomp1, comp1_inds[12], n_examples=8)
print_top_examples(decomp1, comp1_inds[13], n_examples=8)

# # Maybes, (ended up looking different than 90)
# print_top_examples(decomp1, comp1_inds[9], n_examples=8)
# print_top_examples(decomp1, comp1_inds[14], n_examples=8)


comp1_inds0 = tf.argsort((l2_normalize(hrha) @ l2_normalize(hb).T)[:, 90], direction='DESCENDING')
# comp1_inds0[0] is very similar to comp 90 of decomp2.
print_top_examples(decomp1, comp1_inds0[0], n_examples=8)

asdfasdf(comp1_inds0[0], 90)
###############################################################################

# plt.imshow(rsH1[1], cmap=rocket_cmap);plt.tight_layout();plt.show()
# plt.imshow(rsH2[0].T, cmap=rocket_cmap);plt.tight_layout();plt.show()
