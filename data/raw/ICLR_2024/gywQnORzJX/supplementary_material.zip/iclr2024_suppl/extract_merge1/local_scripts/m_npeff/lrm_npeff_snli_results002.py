R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python -i local_scripts/m_npeff/lrm_npeff_snli_results002.py

"""
from importlib import reload
import os

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer

from em.tools.nmf import lrm_npeff
from em.projects.m_npeff import snli_context

###############################################################################

# NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/"
NMF_DIR = "/playpen/users/m/project_data/m_npeff1/per_example_fishers"

NMF_NAME_1 = "test_mnpeff_002.h5"
NMF_NAME_2 = "test_mnpeff_002.coeffs_fit001.h5"

# NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)

TOKENIZER = 'bert-base-uncased'

###############################################################################

ctx1 = snli_context.SnliContext(
    split='train',
    tokenizer=AutoTokenizer.from_pretrained(TOKENIZER),
    nmf=lrm_npeff.LrmNpeffDecomposition.load(os.path.join(NMF_DIR, NMF_NAME_1), read_G=False),
)

ctx2 = snli_context.SnliContext(
    split='train_skip_50k',
    tokenizer=AutoTokenizer.from_pretrained(TOKENIZER),
    nmf=lrm_npeff.LrmNpeffDecomposition.load(os.path.join(NMF_DIR, NMF_NAME_2), read_G=False),
)


ctx1.get_top_examples(6, 12).print_all()
print(4 * '\n')
ctx2.get_top_examples(6, 12).print_all()
