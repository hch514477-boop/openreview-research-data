R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python local_scripts/m_npeff/lrm_npeff_snli_latex001.py

"""
from importlib import reload
import os

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer

from em.tools.nmf import lrm_npeff
from em.projects.m_npeff import snli_context
from em.projects.m_npeff import latex_generation

from em.util.color_util import cu

# ###############################################################################

# NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/"
# # NMF_DIR = "/playpen/users/m/project_data/m_npeff1/per_example_fishers"
# # NMF_NAME = "test_mnpeff_002.coeffs_fit001.h5"
# # NMF_NAME = "test_mnpeff_004.coeffs_fit001.h5"
# # NMF_NAME = "test_mnpeff_005.coeffs_fit001.h5"
# # NMF_NAME = "test_mnpeff_006.coeffs_fit001.h5"
# # NMF_NAME = "test_mnpeff_007.h5"
# # NMF_NAME = "test_mnpeff_002.expansion_001.h5"
# # NMF_NAME = "test_mnpeff_002.expansion_002.coeffs_fit001.h5"
# # NMF_NAME = "test_mnpeff_002.expansion_004.coeffs_fit001.h5"
# NMF_NAME = "test_mnpeff_002.expansion_005.coeffs_fit001.h5"
# # NMF_NAME = "test_stiefel_m_npeff001.h5"
# # NMF_NAME = "test_stiefel_m_npeff003.h5"
# # NMF_NAME = "test_stiefel_m_npeff004.h5"
# NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)


# # Use this only to get the predictions and example token ids without having to
# # evaluate the model.
# PEFS_FOR_PREDICTIONS_DIR = "/fruitbasket/users/m/project_data/extract_merge1/pi1/per_example_fishers/"
# PEFS_FOR_PREDICTIONS_NAME = "feather_berts_0.snli_train.all_vars.skip50000.250000ex.131072.h5"
# # PEFS_FOR_PREDICTIONS_NAME = "feather_berts_0.snli_train.all_vars.50000ex.65536.h5"
# PEFS_FOR_PREDICTIONS_PATH = os.path.join(PEFS_FOR_PREDICTIONS_DIR, PEFS_FOR_PREDICTIONS_NAME)

# TOKENIZER = 'bert-base-uncased'

# ###############################################################################

###############################################################################

NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/snli3og_lrm_npeff/per_example_fishers"
# NMF_NAME = "feather_berts_0.train.50000ex.65536.mnpeff.512comps.001.fit_to_train_skip_50k.h5"
NMF_NAME = "feather_berts_0.train.50000ex.65536.mnpeff.512comps.001.wrongs_only.expansion_001.no_full_joint.fit_to_train_skip_50k.h5"
NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)


# Use this only to get the predictions and example token ids without having to
# evaluate the model.
PEFS_FOR_PREDICTIONS_DIR = "/fruitbasket/users/m/project_data/extract_merge1/pi1/per_example_fishers/"
PEFS_FOR_PREDICTIONS_NAME = "feather_berts_0.snli_train.all_vars.skip50000.250000ex.131072.h5"
# PEFS_FOR_PREDICTIONS_NAME = "feather_berts_0.snli_train.all_vars.50000ex.65536.h5"
PEFS_FOR_PREDICTIONS_PATH = os.path.join(PEFS_FOR_PREDICTIONS_DIR, PEFS_FOR_PREDICTIONS_NAME)

TOKENIZER = 'bert-base-uncased'

###############################################################################

nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=False)

ctx = snli_context.SnliContext(
    split='train_skip_50k',
    # split='train',
    tokenizer=AutoTokenizer.from_pretrained(TOKENIZER),
    nmf=nmf,
)

eval_ctx = ctx.create_eval_ctx_from_pefs_file(PEFS_FOR_PREDICTIONS_PATH)


reload(latex_generation)
lg = latex_generation.TopExamplesLatexGenerator(
    snli_ctx=ctx,
    predicted_logits=eval_ctx.og_logits,
    n_top_examples=16,
)

latex_str = lg.generate_all_components_latex()
# print(latex_str)

# filename = 'train_skip_50k.top16.256comps.tex'
# filename = 'train_skip_50k.top16.512comps.tex'
# filename = 'train_skip_50k.top16.256comps.ortho_reg01.tex'
# filename = 'train_skip_50k.top16.256comps.ortho_reg02.tex'
# filename = 'train_skip_50k.top16.256comps.131k.tex'
# filename = 'train_skip_50k.top16.256comps.32comps_from_wrongs.tex'
# filename = 'train.top16.256comps.stieffel001.tex'
# filename = 'train.top16.64comps.stieffel003.tex'
# filename = 'train.top16.256comps.stieffel004.tex'
# filename = 'train_skip_50k.top16.256comps.32comps_from_wrongs.002.tex'
# filename = 'train_skip_50k.top16.256comps.32comps_from_wrongs.004.tex'
# filename = 'train_skip_50k.top16.256comps.32comps_from_wrongs.005.tex'


# filename = 'mnli_to_snli.tex'
filename = 'mnli_to_snli.expansion.tex'

with open(os.path.join('/fruitbasket/users/m/tmp', filename), 'w') as f:
    f.write(latex_str)


print(cu.hlg(filename))


# Component 251 looks very interesting

R"""

make_pdf() {
    local filename=$1

    rsync -ra -e ssh \
        "m@mango.cs.unc.edu:/fruitbasket/users/m/tmp/${filename}.tex" \
        "$HOME/Downloads/${filename}.tex"

    xelatex -interaction=batchmode -output-directory=/tmp ~/Downloads/${filename}.tex
    mv /tmp/${filename}.pdf ~/Desktop/projects_data/extract_merge1/ll/pdfs
}

# make_pdf train_skip_50k.top16.256comps
# make_pdf train_skip_50k.top16.512comps
# make_pdf train_skip_50k.top16.256comps.ortho_reg01
# make_pdf train_skip_50k.top16.256comps.ortho_reg02
# make_pdf train_skip_50k.top16.256comps.131k
# make_pdf train_skip_50k.top16.256comps.32comps_from_wrongs
# make_pdf train.top16.256comps.stieffel001
# make_pdf train.top16.64comps.stieffel003
# make_pdf train.top16.256comps.stieffel004
# make_pdf train_skip_50k.top16.256comps.32comps_from_wrongs.002
# make_pdf train_skip_50k.top16.256comps.32comps_from_wrongs.004
# make_pdf train_skip_50k.top16.256comps.32comps_from_wrongs.005
# make_pdf mnli_to_snli
make_pdf mnli_to_snli.expansion


"""
