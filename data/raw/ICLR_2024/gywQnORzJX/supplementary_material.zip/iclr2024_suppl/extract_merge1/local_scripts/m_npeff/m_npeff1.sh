###################################################################################
###################################################################################


VIRTUALENV_NAME=extract_merge1

CODE_DIR=/fruitbasket/users/m/project_code/extract_merge1
DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

cd $CODE_DIR
workon $VIRTUALENV_NAME
export PYTHONPATH="$PYTHONPATH:$CODE_DIR",
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

###################################################################################
###################################################################################

EXPS_DIR="${DATA_DIR}/m_npeff1"
DATASETS_DIR="${EXPS_DIR}/datasets"
MODELS_DIR="${EXPS_DIR}/models"
FISHER_DIR="${EXPS_DIR}/fishers"
PER_EXAMPLE_FISHERS_DIR="${EXPS_DIR}/per_example_fishers"

###################################################################################
###################################################################################


compute_pefs() {
    local device=$1
    local n_vals_pe=$2
    local n_ex=$3
    local split=$4

    local model="connectivity/feather_berts_0"
    local pef="feather_berts_0.${split}.${n_ex}ex.${n_vals_pe}.h5"

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/data_gen/compute_lrm_pefs.py  \
        --output_path="${PER_EXAMPLE_FISHERS_DIR}/${pef}" \
        --model="${model}"   \
        --from_pt=true \
        --tokenizer="bert-base-uncased" \
        --task=snli/default \
        --split=$split \
        --n_examples=$n_ex \
        --batch_size=4 \
        --n_fisher_values_per_example=$n_vals_pe \
        --sequence_length=128
}

# compute_pefs 1 65536 50000 train
# compute_pefs 0 65536 100 train
# compute_pefs 0 65536 50000 train_skip_50k
compute_pefs 0 131072 50000 train



cp /fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/feather_berts_0.train_skip_50k.50000ex.65536.h5 \
    /playpen/users/m/project_data/m_npeff1/per_example_fishers
    


# rsync -ra -e ssh \
#     "m@mango.cs.unc.edu:/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/feather_berts_0.train.100ex.65536.h5" \
#     "${HOME}/Desktop/projects_data/extract_merge1/"

###################################################################################

filter_pefs_to_incorrects() {
    local pef_filepath=$1
    local output_filepath=$2

    CUDA_VISIBLE_DEVICES= python ./em/projects/m_npeff/mains/filter_lrm_pefs_to_wrong_predictions.py \
        --pef_path="${pef_filepath}" \
        --output_path="${output_filepath}" \
        --special_processing=HF_MNLI
}

filter_pefs_to_incorrects \
    "/playpen/users/m/project_data/m_npeff1/per_example_fishers/feather_berts_0.train.50000ex.65536.h5" \
    "/playpen/users/m/project_data/m_npeff1/per_example_fishers/feather_berts_0.train.50000ex.65536.wrongs_only.h5"



cp /playpen/users/m/project_data/m_npeff1/per_example_fishers/feather_berts_0.train.50000ex.65536.wrongs_only.h5 \
    /fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers
    
    
###################################################################################


orthogonally_reject_components() {
    local decomposition_filepath=$1
    local output_filepath=$2
    local max_sim=$3

    CUDA_VISIBLE_DEVICES= python ./em/projects/m_npeff/mains/make_components_orthogonally_rejected.py \
        --decomposition_filepath="${decomposition_filepath}" \
        --output_filepath="${output_filepath}" \
        --max_similarity="${max_sim}"
}

orthogonally_reject_components \
    "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/test_mnpeff_002.expansion_005.coeffs_fit001.h5" \
    "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/test_mnpeff_002.expansion_005.coeffs_fit001.orej35.h5" \
    0.35
