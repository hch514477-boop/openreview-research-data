R"""



cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/math_ds_writeup1/h512_l8_analysis001.py

"""
from importlib import reload
import os
import re
import time

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.models import transformer_model_vars as tmv
from em.tools.clustering import vat
from em.tools.nmf import nmf_common
from em.util import flat_pack
from em.util import hf_util

from em.analysis import bert_nmf_analysis as bna
from em.analysis import bert_nmf_analysis2 as bna2
from em.experimental import selective_ablation1

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/math_datasets_dev1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models1')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers0')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers0')
VOCABS_DIR = os.path.join(EXPS_DIR, 'vocabs1')

###############################################################################

TASK = 'math_dataset/original_true_false'
SEQUENCE_LENGTH = 128

MODEL = "og_tf__h512_l8_spm__100k_steps"
FROM_PT = False

TOKENIZER = os.path.join(VOCABS_DIR, "math_ds_og_tf.178")

PER_EXAMPLES_FISHERS = "og_tf__h512_l8_spm__100k_steps.sparse_dynamic_raw.16k.32k.h5"
DECOMP = f'nmf_decomp.8k.4k.64.{PER_EXAMPLES_FISHERS}'

N_EXAMPLES = 8 * 1024
START_FISHER_INDEX, END_FISHER_INDEX = (0, 4096)

###############################################################################

'''

'''
# bna.print_top_examples(decomp.W, tokenizer, pe_fishers_data.input_ids, pe_fishers_data.labels, n_examples=8, component=14)

# COMPONENT = 59
COMPONENT = 0

###############################################################################
# TODO: In proper code, I can probably multithread/multiprocess this to do all these
# loads below in parallel.
#############################

tokenizer = AutoTokenizer.from_pretrained(TOKENIZER)

print('Starting to load saved NMF decomposition.')
start = time.time()
decomp = nmf_common.NmfDecomposition.load(os.path.join(PER_EXAMPLES_FISHERS_DIR, DECOMP))
decomp.normalize_components_to_unit_norm()
print('Load saved NMF decomposition time: ', time.time() - start)


print('Starting to load saved per-example Fishers.')
start = time.time()
pe_fishers_data = per_example.PerExampleFlatFishers.load(
    os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    n_examples=N_EXAMPLES,
    start_fisher_index=START_FISHER_INDEX,
    end_fisher_index=END_FISHER_INDEX,
)
print('Load saved per-example Fishers time: ', time.time() - start)

###############################################################################

W = decomp.W
H = decomp.H

#######################################

finetuned_model = TFAutoModelForSequenceClassification.from_pretrained(
    os.path.join(MODELS_DIR, MODEL), from_pt=FROM_PT
)

finetuned_vars = hf_util.get_mergeable_variables(finetuned_model)

###############################################################################

# component = H[COMPONENT]

# flat_packer = flat_pack.FlatPacker([v.shape for v in merge_vars])
# assert flat_packer.flat_size == component.shape[0]

###############################################################################

cos_sim_matrix = H @ H.T
cos_dissim_matrix = 1 - cos_sim_matrix

# ivat_dissim_matrix = vat.ivat_reorder_dissimilarity_matrix(cos_dissim_matrix)
# ivat_sim_matrix = 1 - ivat_dissim_matrix

# reload(vat)
vat_dissim_matrix, permutation = vat.vat_reorder_dissimilarity_matrix(cos_dissim_matrix)
vat_sim_matrix = 1 - vat_dissim_matrix

# plt.imshow(vat_sim_matrix, vmin=0, vmax=1);plt.show()

# M equals vat_sim_matrix (up to numerical precision)
M = cos_sim_matrix[permutation]
M = M[:, permutation]

bna.plot_sim_matrix(M, show=True)


###############################################################################

localizer = bna2.ComponentLocalizationInfo(variables=finetuned_vars)

frac_in_subsets = []
for i in range(decomp.H.shape[0]):
    frac_in_subsets.append(localizer.fraction_per_layer(decomp.H[i]))

frac_in_subsets = np.array(frac_in_subsets)

reordered_frac_in_subsets = frac_in_subsets[permutation]

#######################################

subset_labels = [
    'Layer 8',
    'Layer 7',
    'Layer 6',
    'Layer 5',
    'Layer 4',
    'Layer 3',
    'Layer 2',
    'Layer 1',
]

bna.plot_component_locations(
    frac_in_subsets=reordered_frac_in_subsets,
    subset_labels=subset_labels,
    vertical_stretch=5,
)
###############################################################################


def print_top_examples(
    component: int,
    n_examples: int,
):
    _, inds = tf.math.top_k(decomp.W[:, component], k=n_examples)
    for ind in inds:
        label = pe_fishers_data.labels[ind]
        prediction = np.argmax(pe_fishers_data.predicted_logits[ind])
        example = tokenizer.decode(pe_fishers_data.input_ids[ind])
        example = example.replace(tokenizer.pad_token or '', '')
        # example = example.replace(tokenizer.cls_token or '', '')
        # example = example.replace(tokenizer.sep_token or '', '')
        example = example.strip()
        print(f'{label}, {prediction}: {example}')


print_top_examples(n_examples=16, component=0)


###############################################################################

# # numerics = [str(d) for d in range(10)]
# keywords = ['divide', 'factor', 'multiple']

# assert all(kw in tokenizer.vocab for kw in keywords)

# asdf = []
# for token in tokenizer.vocab.keys():
#     # if any(n in token for n in numerics):
#     if re.search(r'^\d+$', token):
#         # print(token)
#         asdf.append(token)

# asdf = list(sorted(asdf))
# print(asdf)

###############################################################################


# def compute_sparse_hits_per_parameter(self) -> np.ndarray:
#     counts = np.zeros([self.fisher_dense_size], dtype=np.int32)
#     for i in range(self.fisher_indices.shape[0]):
#         counts[self.fisher_indices[i]] += 1
#     return counts

# sph = compute_sparse_hits_per_parameter(pe_fishers_data)

# reload(per_example); q, w = per_example.PerExampleFlatFishers.to_sparse_reduced_fishers(pe_fishers_data)

