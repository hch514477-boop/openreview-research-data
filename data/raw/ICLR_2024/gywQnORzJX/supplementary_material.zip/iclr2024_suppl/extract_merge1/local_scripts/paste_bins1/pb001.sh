
VIRTUALENV_NAME=extract_merge1

CODE_DIR=/fruitbasket/users/m/project_code/extract_merge1
DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

cd $CODE_DIR
workon $VIRTUALENV_NAME
export PYTHONPATH="$PYTHONPATH:$CODE_DIR",
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets


###################################################################################
###################################################################################


rsync -ra -e ssh \
    "$HOME/Desktop/projects_data/extract_merge1/fishers0/" \
    "m@banana.cs.unc.edu:/fruitbasket/users/m/project_data/extract_merge1/fishers0/"


###################################################################################
###################################################################################


FISHER_DIR=/fruitbasket/users/m/project_data/extract_merge1/fishers0

EVAL_TASK=rte
RTE_MODEL=textattack/roberta-base-RTE
MNLI_MODEL=textattack/roberta-base-MNLI

# Fisher merge
CUDA_VISIBLE_DEVICES=0 python ./scripts1/sparse/sparse_merge_and_evaluate.py  \
    --base_model=$RTE_MODEL \
    --base_fisher=$FISHER_DIR/rte_fisher.sparse.03.md.h5 \
    --fishers=$FISHER_DIR/mnli_fisher.sparse.03.md.h5 \
    --glue_task=$EVAL_TASK

###################################################################################
###################################################################################


FISHER_DIR=/fruitbasket/users/m/project_data/extract_merge1/fishers0
BASE_MODEL=roberta-base

MRPC_MODEL=textattack/roberta-base-MRPC

# Compute MRPC Fisher.
CUDA_VISIBLE_DEVICES=0 python ./scripts1/ogmm/compute_fisher.py  \
    --model=$MRPC_MODEL \
    --glue_task="mrpc" \
    --fisher_path="$FISHER_DIR/mrpc_fisher.h5" \
    --batch_size=16

# Sparsify MRPC Fisher.
CUDA_VISIBLE_DEVICES=0 python scripts1/sparse/sparsify_diagonal_fisher.py \
    --fisher_path="$FISHER_DIR/mrpc_fisher.h5" \
    --output_path="$FISHER_DIR/mrpc_fisher.sparse.03.md.h5" \
    --method=metric_derived \
    --sparsity=0.03 \
    --finetuned_model=$MRPC_MODEL \
    --pretrained_model=$BASE_MODEL

#######################################

CUDA_VISIBLE_DEVICES=0  python ./scripts1/ogmm/merge_and_evaluate.py  \
    --models=$MRPC_MODEL,$MNLI_MODEL \
    --fishers=$FISHER_DIR/mrpc_fisher.h5,$FISHER_DIR/mnli_fisher.h5 \
    --glue_task='mrpc'

# Fisher merge
CUDA_VISIBLE_DEVICES=0 python ./scripts1/sparse/sparse_merge_and_evaluate.py  \
    --base_model=$MRPC_MODEL \
    --base_fisher=$FISHER_DIR/mrpc_fisher.sparse.03.md.h5 \
    --fishers=$FISHER_DIR/mnli_fisher.sparse.03.md.h5 \
    --glue_task='mrpc'


###################################################################################
###################################################################################


FISHER_DIR=/fruitbasket/users/m/project_data/extract_merge1/fishers0
BASE_MODEL=bert-base-uncased

#######################################

compute_fisher() {
    device=$1
    task=$2
    task_model=$3

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/ogmm/compute_fisher.py  \
        --model=$task_model \
        --glue_task="${task}" \
        --fisher_path="$FISHER_DIR/bert_${task}_fisher.h5" \
        --batch_size=16

    CUDA_VISIBLE_DEVICES=$device python scripts1/sparse/sparsify_diagonal_fisher.py \
        --fisher_path="$FISHER_DIR/bert_${task}_fisher.h5" \
        --output_path="$FISHER_DIR/bert_${task}_fisher.sparse.03.md.h5" \
        --method=metric_derived \
        --sparsity=0.03 \
        --finetuned_model=$task_model \
        --pretrained_model=$BASE_MODEL

}


compute_fisher 0 qnli textattack/bert-base-uncased-QNLI

#######################################

TASK=mrpc
TASK_MODEL=textattack/bert-base-uncased-MRPC

CUDA_VISIBLE_DEVICES=0 python ./scripts1/ogmm/compute_fisher.py  \
    --model=$TASK_MODEL \
    --glue_task="${TASK}" \
    --fisher_path="$FISHER_DIR/bert_${TASK}_fisher.h5" \
    --batch_size=16

CUDA_VISIBLE_DEVICES=0 python scripts1/sparse/sparsify_diagonal_fisher.py \
    --fisher_path="$FISHER_DIR/bert_${TASK}_fisher.h5" \
    --output_path="$FISHER_DIR/bert_${TASK}_fisher.sparse.03.md.h5" \
    --method=metric_derived \
    --sparsity=0.03 \
    --finetuned_model=$TASK_MODEL \
    --pretrained_model=$BASE_MODEL

#######################################

TASK=mnli
TASK_MODEL=textattack/bert-base-uncased-MNLI

CUDA_VISIBLE_DEVICES=1 python ./scripts1/ogmm/compute_fisher.py  \
    --model=$TASK_MODEL \
    --glue_task="${TASK}" \
    --fisher_path="$FISHER_DIR/bert_${TASK}_fisher.h5" \
    --batch_size=16

CUDA_VISIBLE_DEVICES=1 python scripts1/sparse/sparsify_diagonal_fisher.py \
    --fisher_path="$FISHER_DIR/bert_${TASK}_fisher.h5" \
    --output_path="$FISHER_DIR/bert_${TASK}_fisher.sparse.03.md.h5" \
    --method=metric_derived \
    --sparsity=0.03 \
    --finetuned_model=$TASK_MODEL \
    --pretrained_model=$BASE_MODEL

#######################################

TASK=rte
TASK_MODEL=textattack/bert-base-uncased-RTE

CUDA_VISIBLE_DEVICES=2 python ./scripts1/ogmm/compute_fisher.py  \
    --model=$TASK_MODEL \
    --glue_task="${TASK}" \
    --fisher_path="$FISHER_DIR/bert_${TASK}_fisher.h5" \
    --batch_size=16

CUDA_VISIBLE_DEVICES=2 python scripts1/sparse/sparsify_diagonal_fisher.py \
    --fisher_path="$FISHER_DIR/bert_${TASK}_fisher.h5" \
    --output_path="$FISHER_DIR/bert_${TASK}_fisher.sparse.03.md.h5" \
    --method=metric_derived \
    --sparsity=0.03 \
    --finetuned_model=$TASK_MODEL \
    --pretrained_model=$BASE_MODEL




###################################################################################
###################################################################################


FISHER_DIR=/fruitbasket/users/m/project_data/extract_merge1/fishers0
BASE_MODEL=bert-base-uncased

sparse_merge_mnli() {
    device=$1
    task=$2
    task_model=$3

    shift 3

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/sparse/sparse_merge_and_evaluate.py  \
        --base_model=$task_model \
        --base_fisher="${FISHER_DIR}/bert_${task}_fisher.sparse.03.md.h5" \
        --fishers=$FISHER_DIR/bert_mnli_fisher.sparse.03.md.h5 \
        --glue_task=$task \
        "$@"
}

dense_merge_mnli() {
    device=$1
    task=$2
    task_model=$3

    CUDA_VISIBLE_DEVICES=$device  python ./scripts1/ogmm/merge_and_evaluate.py  \
        --models="${task_model},textattack/bert-base-uncased-MNLI" \
        --fishers="$FISHER_DIR/bert_${task}_fisher.h5,$FISHER_DIR/bert_mnli_fisher.h5" \
        --glue_task="${task}"
}

#######################################

sparse_merge_mnli 0 rte textattack/bert-base-uncased-RTE
dense_merge_mnli 0 rte textattack/bert-base-uncased-RTE

sparse_merge_mnli 0 mrpc textattack/bert-base-uncased-MRPC
dense_merge_mnli 0 mrpc textattack/bert-base-uncased-MRPC

sparse_merge_mnli 0 qnli textattack/bert-base-uncased-QNLI
dense_merge_mnli 0 qnli textattack/bert-base-uncased-QNLI

###################################################################################
###################################################################################


FISHER_DIR=/fruitbasket/users/m/project_data/extract_merge1/fishers0
BASE_MODEL=bert-large-uncased

#######################################

compute_fisher() {
    device=$1
    task=$2
    task_model=$3

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/ogmm/compute_fisher.py  \
        --model=$task_model \
        --glue_task="${task}" \
        --fisher_path="$FISHER_DIR/bert_large_${task}_fisher.h5" \
        --batch_size=16

    CUDA_VISIBLE_DEVICES=$device python scripts1/sparse/sparsify_diagonal_fisher.py \
        --fisher_path="$FISHER_DIR/bert_large_${task}_fisher.h5" \
        --output_path="$FISHER_DIR/bert_large_${task}_fisher.sparse.03.md.h5" \
        --method=metric_derived \
        --sparsity=0.03 \
        --finetuned_model=$task_model \
        --pretrained_model=$BASE_MODEL

}


compute_fisher 0 rte textattack/bert-large-uncased-RTE

###################################################################################
###################################################################################

CUDA_VISIBLE_DEVICES=0 python ./scripts1/training/finetune_glue.py  \
    --output_path=/tmp/finetune_glue_test \
    --model=roberta-base \
    --task=rte \
    --batch_size=32 \
    --learning_rate=1e-5 \
    --n_epochs=10
