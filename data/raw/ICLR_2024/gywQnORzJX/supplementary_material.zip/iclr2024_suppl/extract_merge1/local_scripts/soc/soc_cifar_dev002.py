R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i local_scripts/soc/soc_cifar_dev002.py



CUDA_VISIBLE_DEVICES=0 python -i local_scripts/soc/soc_cifar_dev002.py
CUDA_VISIBLE_DEVICES=1 python -i local_scripts/soc/soc_cifar_dev002.py


"""
import collections
import dataclasses
import os
from importlib import reload
import itertools
import time
from typing import Any, List, Sequence

import h5py
import matplotlib.pyplot as plt
import numpy as np
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer
import tensorflow as tf
import tensorflow_probability as tfp

from em.datasets import glue
from em.evaluation import evaluation
from em.fishers import diagonal
from em.fishers import per_example
from em.fishers import sparse_diagonal
from em.merging import merging
from em.models.generative import vae
# from em.models.generative import soc
from em.util import hf_util
from em.util import vat_da_faak_vpn

from local_scripts.soc import soc_dev_common as sdc
from local_scripts.soc import soc_dev_cifar as cf


tfd = tfp.distributions


###############################################################################
###############################################################################

PE_BATCH_SIZE = 256
SOC_BATCH_SIZE = 256

#######################################

trained_model = cf.load_trained_model()
setattr(trained_model, 'num_labels', 10)

pe_ds = cf.create_dataset_for_per_example_fishers(PE_BATCH_SIZE)


def something(n_iters):
    gen = per_example.stream_per_example_diagonal_fishers(
        trained_model,
        dataset=pe_ds,
        variables=trained_model.trainable_variables,
        unbatch=False,
        expectation_wrt_logits=False,
    )
    times = []
    for batch_fishers in itertools.islice(gen, n_iters):
        times.append(time.time())
    return np.array(times)

###############################################################################


latent_size = 512
n_components = 512 + 128
width = 1024

component_size = cf.compute_component_size(trained_model)


soc_ds = cf.create_soc_dataset(
    trained_model,
    soc_batch_size=SOC_BATCH_SIZE,
    pe_batch_size=PE_BATCH_SIZE,
)

autoencoder = tf.keras.Sequential([
    *sdc.make_dense_layers([width, latent_size], 'gelu'),
    *sdc.make_dense_layers([width, n_components], 'gelu'),
])

soc_model = sdc.AeSoc(
    autoencoder=autoencoder,
    component_size=component_size,
    n_components=n_components,
    #
    non_negative_components=True,
    non_negative_coefficients=True,
    #
    # non_negative_components=False,
    # non_negative_coefficients=False,
    #
    unit_norm_components=False,
)
loss = sdc.SparsityLoss(
    tf.keras.losses.MeanSquaredError(),
    model=soc_model,
    lmbda_comp=0.0,
    lmbda_coeff=1e-4,
    lmbda_comp_unit_norm=1e-2,
)

# lr = 1e-2
lr = 1e-3
# lr = 3e-4
soc_model.compile(
    # loss=loss,
    loss=tf.keras.losses.MeanSquaredError(),
    # optimizer=tf.keras.optimizers.Adam(lr, clipnorm=0.1),
    metrics=[tf.keras.metrics.MeanSquaredError()]
)
soc_model.fit(soc_ds, steps_per_epoch=1024, epochs=100)



R"""

for _, x in soc_ds:
    break

y = soc_model(x)

y[:10,:5]

tf.reduce_all(y[0] == y[1]).numpy()


x[:10,:5]

"""