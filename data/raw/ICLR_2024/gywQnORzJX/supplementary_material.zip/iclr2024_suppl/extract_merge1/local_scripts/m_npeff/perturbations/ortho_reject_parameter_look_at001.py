R"""




cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=3 python -i local_scripts/m_npeff/perturbations/ortho_reject_parameter_look_at001.py

"""

from importlib import reload
import os

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em.fishers import diagonal
from em.tools.nmf import lrm_npeff
from em.util import flat_pack

from em.projects.m_npeff import perturbation_finder
from em.projects.m_npeff import snli_context
from em.projects.pi import qqp_components_context as QCC

from em.util.color_util import cu


###############################################################################

FISHER_DIR = "/fruitbasket/users/m/project_data/extract_merge1/pi1/fishers/"
FISHER_NAME = "feather_berts_0.mnli_snli_train.all_vars.50000ex.h5"
FISHER_PATH = os.path.join(FISHER_DIR, FISHER_NAME)

NMF_DIR = "/playpen/users/m/project_data/m_npeff1/per_example_fishers"
NMF_NAME = "test_mnpeff_005.coeffs_fit001.h5"
NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)

# Use this only to get the predictions and example token ids without having to
# evaluate the model.
PEFS_FOR_PREDICTIONS_DIR = "/fruitbasket/users/m/project_data/extract_merge1/pi1/per_example_fishers/"
PEFS_FOR_PREDICTIONS_NAME = "feather_berts_0.snli_train.all_vars.skip50000.250000ex.131072.h5"
PEFS_FOR_PREDICTIONS_PATH = os.path.join(PEFS_FOR_PREDICTIONS_DIR, PEFS_FOR_PREDICTIONS_NAME)

MODEL = "connectivity/feather_berts_0"
TOKENIZER = 'bert-base-uncased'

###############################################################################

og_model = TFAutoModelForSequenceClassification.from_pretrained(MODEL, from_pt=True)


# fisher = diagonal.DiagonalFisher.load(FISHER_PATH)
# flat_fisher = fisher.as_flat_fisher().numpy()
# flat_fisher /= np.sqrt(np.sum(flat_fisher**2))

print('Starting to read in decomposition.')
nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=True)
print('Decomposition read in.')
nmf.normalize_components_to_unit_norm()
print('Decomposition components normalized.')

ctx = snli_context.SnliContext(
    split='train_skip_50k',
    tokenizer=AutoTokenizer.from_pretrained(TOKENIZER),
    nmf=nmf,
    load_examples=False,
)
print('SNLI context made.')

###############################################################################

N_TOTAL_EXAMPLES = 1014
reload(snli_context); ctx.__class__ = snli_context.SnliContext
# eval_ctx = ctx.create_eval_ctx(og_model)
eval_ctx = ctx.create_eval_ctx_from_pefs_file(PEFS_FOR_PREDICTIONS_PATH)
print('Eval context made.')

model = TFAutoModelForSequenceClassification.from_pretrained(MODEL, from_pt=True)

###############################################################################


def find_unnormalized_perturbation(component_index: int, max_sim: float = 0.0):
    # Assumes rows of G have unit norm.
    G = nmf.G
    #
    g_main = np.copy(G[component_index])
    #
    if max_sim > 0.0:
        for i in range(G.shape[0]):
            if i == component_index:
                continue
            if np.abs(G[component_index].dot(G[i])) > max_sim:
                continue
            g_main -= g_main.dot(G[i]) * G[i]
        #
    g = np.zeros([nmf.n_parameters], dtype=np.float32)
    g[nmf.new_to_old_col_indices] = g_main
    return g

###############################################################################


def examine(component_index: int, n_top_params: int, max_sim: float = 1e9):
    g = find_unnormalized_perturbation(component_index, max_sim)
    g /= np.sqrt(np.sum(g**2))
    #
    variables = model.trainable_variables
    packer = flat_pack.FlatPacker([v.shape for v in variables])
    offsets = packer.decode_tf(tf.cast(g, tf.float32))
    #
    allocs = [tf.reduce_sum(tf.square(x)) for x in offsets]
    total_alloc = tf.reduce_sum(allocs)
    allocs = np.array([(a / total_alloc).numpy() for a in allocs])
    #
    top_inds = np.argsort(-allocs)[:n_top_params]
    for i in top_inds:
        print(f'{allocs[i]:.4f} {variables[i].name} {list(variables[i].shape)}')


###############################################################################

# examine(2, n_top_params=16, max_sim=0.35)
examine(6, n_top_params=16, max_sim=0.35)
examine(7, n_top_params=16, max_sim=0.35)
examine(7, n_top_params=16, max_sim=0.0)


examine(72, n_top_params=16, max_sim=0.35)
examine(72, n_top_params=16, max_sim=0.0)

#


"""
- Maybe look for patterns in what components are easy/hard to perturb selectively.
- Look at cossine sims of G for ortho_reg=0 vs ortho_reg=1.
- See if look at paraeter-space allocation of ortho-reejcted components.
    - Are they focused on the vocab layer for a single (or multiple) words.
    - Compare selectivity to just perturbing word in vocab.
- Maybe use component coefficient correlation instead of parameter-space similarity
  to determine which components to be orthogonal to.
"""