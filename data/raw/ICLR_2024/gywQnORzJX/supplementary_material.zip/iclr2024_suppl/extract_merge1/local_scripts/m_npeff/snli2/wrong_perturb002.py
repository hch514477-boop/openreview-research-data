R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=2 python -i local_scripts/m_npeff/snli2/wrong_perturb002.py

"""

import dataclasses
from importlib import reload
from typing import List
import os

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em.fishers import diagonal
from em.tools.nmf import lrm_npeff
from em.fishers import lrm_pefs
from em.util import flat_pack
from em import datasets as em_datasets

from em.projects.m_npeff import snli_context
from em.projects.pi import qqp_components_context as QCC

from em.util.color_util import cu


###############################################################################

NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/snli2_lrm_npeff/per_example_fishers/"
NMF_NAME = "bert_base_snli_150k_holdout_4_epochs_01_epoch2.heldout_from_train_2.50000ex.65536.512comps.expansion64comps.no_full_join.001.coeffs_fit001.h5"
NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)

# Use this only to get the predictions and example token ids without having to
# evaluate the model.
PEFS_DIR = "/fruitbasket/users/m/project_data/extract_merge1/snli2_lrm_npeff/per_example_fishers/"
PEFS_NAME = "bert_base_snli_150k_holdout_4_epochs_01_epoch2.heldout_from_train_2.50000ex.65536.h5"
PEFS_PATH = os.path.join(PEFS_DIR, PEFS_NAME)

MODEL_DIR = "/fruitbasket/users/m/project_data/extract_merge1/snli2_lrm_npeff/models"
MODEL_NAME = "bert_base_snli_150k_holdout_4_epochs_01_epoch2"
MODEL = os.path.join(MODEL_DIR, MODEL_NAME)

###############################################################################

TOKENIZER = 'bert-base-uncased'
SPLIT = 'train[-100000:-50000]'

###############################################################################


###############################################################################

og_model = TFAutoModelForSequenceClassification.from_pretrained(MODEL, from_pt=False)


tokenizer = AutoTokenizer.from_pretrained(TOKENIZER)

print('Starting to load in nmf.')
nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=True)
nmf.normalize_components_to_unit_norm()

print('Starting to load in logits.')
logits = lrm_pefs.SparseLrmPefs.load_logits(PEFS_PATH)

print('Starting to create evaluation context.')
eval_ctx = QCC.EvaluationContext2.create_from_ds_and_logits(
    ds=em_datasets.load('snli/default', split=SPLIT, sequence_length=128, tokenizer=tokenizer),
    logits=logits,
)
print('Evaluation context made.')

###############################################################################

N_TOTAL_EXAMPLES = 8 * 1014

model = TFAutoModelForSequenceClassification.from_pretrained(MODEL, from_pt=False)

###############################################################################


def find_unnormalized_perturbation(component_index: int, max_sim: float = 1e9):
    # Assumes rows of G have unit norm.
    G = nmf.G
    #
    g_main = np.copy(G[component_index])
    #
    if max_sim > 0.0:
        for i in range(G.shape[0]):
            if i == component_index:
                continue
            if np.abs(G[component_index].dot(G[i])) > max_sim:
                continue
            g_main -= g_main.dot(G[i]) * G[i]
        #
    g = np.zeros([nmf.n_parameters], dtype=np.float32)
    g[nmf.new_to_old_col_indices] = g_main
    return g


def find_unnormalized_perturbation2(x: np.ndarray, component_index: int, max_sim: float = 1e9):
    # Assumes rows of G have unit norm.
    G = nmf.G
    #
    x = np.copy(x)
    #
    if max_sim > 0.0:
        for i in range(G.shape[0]):
            if i == component_index:
                continue
            if np.abs(G[component_index].dot(G[i])) > max_sim:
                continue
            x -= x.dot(G[i]) * G[i]
        #
    g = np.zeros([nmf.n_parameters], dtype=np.float32)
    g[nmf.new_to_old_col_indices] = x
    return g


def compute_unnormalized_gradient(component_index: int, n_top_examples: int = 128, batch_size: int = 16):
    variables = model.trainable_variables
    grads = [tf.Variable(tf.zeros_like(v)) for v in variables]
    #
    loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(
        from_logits=True, reduction=tf.keras.losses.Reduction.SUM)
    #
    top_inds = np.argsort(-nmf.W[:, component_index])[:n_top_examples]
    for x, y in eval_ctx.get_ds(top_inds).batch(batch_size):
        with tf.GradientTape(watch_accessed_variables=False) as tape:
            tape.watch(variables)
            logits = model(x, training=False).logits
            loss = loss_fn(y, logits)
        batch_grads = tape.gradient(loss, variables)
        for g, b in zip(grads, batch_grads):
            g.assign_add(b)
    return grads

###############################################################################


@dataclasses.dataclass
class PerturbationResults:
    top_results: QCC.QqpEvaluationResults
    total_results: QCC.QqpEvaluationResults
    
    def ratio(self):
        return self.top_results.kl() / self.total_results.kl()


def perturb_weights(offsets, multiplier):
    for ogv, v, offset in zip(og_model.trainable_variables, model.trainable_variables, offsets):
        v.assign(ogv + multiplier * offset)


def eval_ratio(component_index: int, n_top_examples: int = 128, n_total_examples=N_TOTAL_EXAMPLES):
    top_inds = np.argsort(-nmf.W[:, component_index])[:n_top_examples]
    top_results = eval_ctx.evaluate(model, top_inds)
    total_results = eval_ctx.evaluate(model, np.arange(n_total_examples))
    return PerturbationResults(top_results=top_results, total_results=total_results)


# def run_and_eval(component_index: int, multiplier_mag=1.0, max_sim: float = 1e9):
#     g = find_unnormalized_perturbation(component_index, max_sim)
#     g /= np.sqrt(np.sum(g**2))
#     #
#     packer = flat_pack.FlatPacker([v.shape for v in model.trainable_variables])
#     offsets = packer.decode_tf(tf.cast(g, tf.float32))
#     #
#     perturb_weights(offsets, multiplier_mag)
#     r1 = eval_ratio(component_index)
#     #
#     perturb_weights(offsets, -multiplier_mag)
#     r2 = eval_ratio(component_index)
#     #
#     return r1 if r1.ratio() > r2.ratio() else r2


def run_and_eval(component_index: int, multiplier_mag=1.0, max_sim: float = 1e9):
    g = find_unnormalized_perturbation(component_index, max_sim)
    g /= np.sqrt(np.sum(g**2))
    #
    loss_grad = compute_unnormalized_gradient(component_index)
    #
    packer = flat_pack.FlatPacker([v.shape for v in model.trainable_variables])
    offsets = packer.decode_tf(tf.cast(g, tf.float32))
    #
    dp = tf.reduce_sum([tf.reduce_sum(o * g) for o, g in zip(offsets, loss_grad)])
    #
    if dp > 0:
        multiplier_mag = -multiplier_mag
    #
    perturb_weights(offsets, multiplier_mag)
    return eval_ratio(component_index)


def grad_and_eval(component_index: int, multiplier_mag=1.0):
    loss_grad = compute_unnormalized_gradient(component_index)
    grad_norm = tf.sqrt(tf.reduce_sum([tf.reduce_sum(tf.square(g)) for g in loss_grad]))
    #
    perturb_weights(loss_grad, -multiplier_mag / grad_norm.numpy())
    return eval_ratio(component_index)


def run_and_eval2(component_index: int, multiplier_mag=1.0, max_sim: float = 1e9):
    loss_grad = compute_unnormalized_gradient(component_index)
    #
    flat_grad = np.concatenate([g.numpy().reshape([-1])for g in loss_grad])
    reduced_flat_grad = flat_grad[nmf.new_to_old_col_indices]
    #
    g = find_unnormalized_perturbation2(reduced_flat_grad, component_index, max_sim)
    g /= np.sqrt(np.sum(g**2))
    #
    packer = flat_pack.FlatPacker([v.shape for v in model.trainable_variables])
    offsets = packer.decode_tf(tf.cast(g, tf.float32))
    #
    perturb_weights(offsets, -multiplier_mag)
    return eval_ratio(component_index)


def run_and_eval3(component_index: int, multiplier_mag=1.0, max_sim: float = 1e9):
    loss_grad = compute_unnormalized_gradient(component_index)
    #
    flat_grad = np.concatenate([g.numpy().reshape([-1])for g in loss_grad])
    reduced_flat_grad = flat_grad[nmf.new_to_old_col_indices]
    reduced_flat_grad /= np.sqrt(np.sum(reduced_flat_grad**2))
    #
    x = reduced_flat_grad + nmf.G[component_index]
    #
    g = find_unnormalized_perturbation2(x, component_index, max_sim)
    g /= np.sqrt(np.sum(g**2))
    #
    packer = flat_pack.FlatPacker([v.shape for v in model.trainable_variables])
    offsets = packer.decode_tf(tf.cast(g, tf.float32))
    #
    perturb_weights(offsets, -multiplier_mag)
    return eval_ratio(component_index)


def run_and_eval2_multi(components: List[int], multiplier_mag=1.0, max_sim: float = 1e9):
    p = np.zeros([nmf.n_parameters], dtype=np.float32)
    for component_index in components:
        loss_grad = compute_unnormalized_gradient(component_index)
        #
        flat_grad = np.concatenate([g.numpy().reshape([-1])for g in loss_grad])
        reduced_flat_grad = flat_grad[nmf.new_to_old_col_indices]
        g = find_unnormalized_perturbation2(reduced_flat_grad, component_index, max_sim)
        g /= np.sqrt(np.sum(g**2))
        #
        p += g
    packer = flat_pack.FlatPacker([v.shape for v in model.trainable_variables])
    offsets = packer.decode_tf(tf.cast(p, tf.float32))
    #
    perturb_weights(offsets, -multiplier_mag)
    return eval_ratio(component_index)


###############################################################################


def compute_baseline_top_acc(component_index: int, n_top_examples: int = 128):
    top_inds = np.argsort(-nmf.W[:, component_index])[:n_top_examples]
    labels = eval_ctx.all_examples[1][top_inds]
    preds = np.argmax(eval_ctx.og_logits, axis=-1)[top_inds]
    return np.mean((labels == preds).astype(np.float32))


###############################################################################


results = run_and_eval(0, 0, max_sim=0.35)
print('Baselines:')
print(f'    ratio: {results.ratio()}')
print(f'    top acc: {results.top_results.acc()}')
print(f'    total acc: {results.total_results.acc()}')
print('')



# mp = 3e-1
# mp = 8e-2
mp = 1e-1
# mp = 1.5e-1

# [0, 5, 17, 22,]
# COMP_INDS = [201, 337, 371, 569]
# COMP_INDS = range(64)
COMP_INDS = list(range(64)) + [201, 337, 371, 569]
for comp in COMP_INDS:
    # results = run_and_eval(comp, mp, max_sim=0.35)
    # results = grad_and_eval(comp, mp)
    # results = run_and_eval2(comp, mp, max_sim=0.35)
    results = run_and_eval2(comp, mp, max_sim=0.7)
    # results = run_and_eval3(comp, mp, max_sim=0.35)
    print(f'Component: {comp}')
    print(f'    ratio: {results.ratio()}')
    print(f'    top acc: {results.top_results.acc()}')
    print(f'    total acc: {results.total_results.acc()}')
    print('')


# 13, 35, 46, 47
components = [9, 10, 13, 35, 46, 47]
results = run_and_eval2_multi(components, 3e-2, max_sim=0.7)
print(f'Components: {components}')
print(f'    ratio: {results.ratio()}')
print(f'    top acc: {results.top_results.acc()}')
print(f'    total acc: {results.total_results.acc()}')
print('')



# for comp in list(range(64)) + [201, 337, 371, 569]:
#     acc = compute_baseline_top_acc(comp)
#     print(f'{comp}: {acc}')




"""
mp = 1e-1, run_and_eval2(comp, mp, max_sim=0.7)
Component: 0
    ratio: 20.440305709838867
    top acc: 0.796875
    total acc: 0.8801775147928994

Component: 1
    ratio: 69.53929138183594
    top acc: 0.8203125
    total acc: 0.8789447731755424

Component: 2
    ratio: 42.27510070800781
    top acc: 0.8828125
    total acc: 0.8795611439842209

Component: 3
    ratio: 56.43498611450195
    top acc: 0.9375
    total acc: 0.8782051282051282

Component: 4
    ratio: 51.39317321777344
    top acc: 0.7734375
    total acc: 0.8807938856015779

Component: 5
    ratio: 81.79862976074219
    top acc: 0.8359375
    total acc: 0.8793145956607495

Component: 6
    ratio: 47.25022888183594
    top acc: 0.84375
    total acc: 0.8788214990138067

Component: 7
    ratio: 60.543312072753906
    top acc: 0.796875
    total acc: 0.8782051282051282

Component: 8
    ratio: 65.28384399414062
    top acc: 0.8984375
    total acc: 0.878698224852071

Component: 9
    ratio: 77.19164276123047
    top acc: 0.875
    total acc: 0.8800542406311637

Component: 10
    ratio: 169.53485107421875
    top acc: 0.8984375
    total acc: 0.8803007889546351

Component: 11
    ratio: 68.6898422241211
    top acc: 0.921875
    total acc: 0.8784516765285996

Component: 12
    ratio: 43.607078552246094
    top acc: 0.8125
    total acc: 0.8782051282051282

Component: 13
    ratio: 55.56337356567383
    top acc: 0.8984375
    total acc: 0.8801775147928994

Component: 14
    ratio: 53.80844497680664
    top acc: 0.8515625
    total acc: 0.8778353057199211

Component: 15
    ratio: 97.50509643554688
    top acc: 0.890625
    total acc: 0.8795611439842209

Component: 16
    ratio: 88.5660400390625
    top acc: 0.8515625
    total acc: 0.8798076923076923

Component: 17
    ratio: 58.16432571411133
    top acc: 0.8046875
    total acc: 0.8798076923076923

Component: 18
    ratio: 76.65481567382812
    top acc: 0.8671875
    total acc: 0.8795611439842209

Component: 19
    ratio: 41.60158157348633
    top acc: 0.8203125
    total acc: 0.8790680473372781

Component: 20
    ratio: 43.6728515625
    top acc: 0.8203125
    total acc: 0.8790680473372781

Component: 21
    ratio: 95.53570556640625
    top acc: 0.90625
    total acc: 0.8791913214990138

Component: 22
    ratio: 130.3751678466797
    top acc: 0.78125
    total acc: 0.8795611439842209

Component: 23
    ratio: 74.04273223876953
    top acc: 0.8984375
    total acc: 0.8788214990138067

Component: 24
    ratio: 51.91197967529297
    top acc: 0.859375
    total acc: 0.8794378698224852

Component: 25
    ratio: 63.571327209472656
    top acc: 0.8671875
    total acc: 0.8794378698224852

Component: 26
    ratio: 101.9087905883789
    top acc: 0.90625
    total acc: 0.8784516765285996

Component: 27
    ratio: 67.353515625
    top acc: 0.7734375
    total acc: 0.8785749506903353

Component: 28
    ratio: 103.51233673095703
    top acc: 0.8828125
    total acc: 0.8784516765285996

Component: 29
    ratio: 86.90533447265625
    top acc: 0.8671875
    total acc: 0.878698224852071

Component: 30
    ratio: 31.957931518554688
    top acc: 0.8359375
    total acc: 0.8782051282051282

Component: 31
    ratio: 25.42095947265625
    top acc: 0.8203125
    total acc: 0.8783284023668639

Component: 32
    ratio: 58.97712326049805
    top acc: 0.859375
    total acc: 0.8795611439842209

Component: 33
    ratio: 144.36769104003906
    top acc: 0.8828125
    total acc: 0.8778353057199211

Component: 34
    ratio: 59.61838912963867
    top acc: 0.84375
    total acc: 0.8790680473372781

Component: 35
    ratio: 156.3778533935547
    top acc: 0.8828125
    total acc: 0.8801775147928994

Component: 36
    ratio: 123.53715515136719
    top acc: 0.8984375
    total acc: 0.878698224852071

Component: 37
    ratio: 58.050445556640625
    top acc: 0.890625
    total acc: 0.8801775147928994

Component: 38
    ratio: 63.99335861206055
    top acc: 0.890625
    total acc: 0.8788214990138067

Component: 39
    ratio: 70.45791625976562
    top acc: 0.8828125
    total acc: 0.8788214990138067

Component: 40
    ratio: 40.93063735961914
    top acc: 0.875
    total acc: 0.8794378698224852

Component: 41
    ratio: 66.40796661376953
    top acc: 0.8671875
    total acc: 0.8790680473372781

Component: 42
    ratio: 48.8135986328125
    top acc: 0.828125
    total acc: 0.878698224852071

Component: 43
    ratio: 57.0986213684082
    top acc: 0.890625
    total acc: 0.8790680473372781

Component: 44
    ratio: 64.07218170166016
    top acc: 0.8359375
    total acc: 0.8779585798816568

Component: 45
    ratio: 82.16497039794922
    top acc: 0.8125
    total acc: 0.8782051282051282

Component: 46
    ratio: 72.62085723876953
    top acc: 0.859375
    total acc: 0.8803007889546351

Component: 47
    ratio: 48.96274948120117
    top acc: 0.84375
    total acc: 0.8801775147928994

Component: 48
    ratio: 36.160423278808594
    top acc: 0.828125
    total acc: 0.8785749506903353

Component: 49
    ratio: 82.03094482421875
    top acc: 0.7578125
    total acc: 0.8782051282051282

Component: 50
    ratio: 33.08513641357422
    top acc: 0.84375
    total acc: 0.8793145956607495

Component: 51
    ratio: 65.07771301269531
    top acc: 0.953125
    total acc: 0.8785749506903353

Component: 52
    ratio: 42.294734954833984
    top acc: 0.84375
    total acc: 0.878698224852071

Component: 53
    ratio: 67.94928741455078
    top acc: 0.8671875
    total acc: 0.878698224852071

Component: 54
    ratio: 121.24952697753906
    top acc: 0.921875
    total acc: 0.8790680473372781

Component: 55
    ratio: 68.07994842529297
    top acc: 0.984375
    total acc: 0.8789447731755424

Component: 56
    ratio: 83.49871063232422
    top acc: 0.8671875
    total acc: 0.8791913214990138

Component: 57
    ratio: 72.84208679199219
    top acc: 0.890625
    total acc: 0.8785749506903353

Component: 58
    ratio: 75.96916961669922
    top acc: 0.8984375
    total acc: 0.8796844181459567

Component: 59
    ratio: 73.47769165039062
    top acc: 0.9375
    total acc: 0.8793145956607495

Component: 60
    ratio: 57.98965072631836
    top acc: 0.8046875
    total acc: 0.8796844181459567

Component: 61
    ratio: 97.58131408691406
    top acc: 0.828125
    total acc: 0.8784516765285996

Component: 62
    ratio: 53.9676513671875
    top acc: 0.828125
    total acc: 0.8788214990138067

Component: 63
    ratio: 145.35256958007812
    top acc: 0.9453125
    total acc: 0.8780818540433925

Component: 201
    ratio: 38.81917953491211
    top acc: 0.765625
    total acc: 0.8793145956607495

Component: 337
    ratio: 93.7544174194336
    top acc: 0.890625
    total acc: 0.8793145956607495

Component: 371
    ratio: 68.55830383300781
    top acc: 0.7578125
    total acc: 0.878698224852071

Component: 569
    ratio: 91.8411636352539
    top acc: 0.828125
    total acc: 0.8783284023668639

mp = 1e-1, run_and_eval2(comp, mp, max_sim=0.35)

Baselines:
    ratio: 1.7879689931869507
    top acc: 0.6796875
    total acc: 0.8788214990138067

Component: 0
    ratio: 31.353042602539062
    top acc: 0.796875
    total acc: 0.8793145956607495

Component: 1
    ratio: 69.93519592285156
    top acc: 0.8125
    total acc: 0.8785749506903353

Component: 2
    ratio: 42.44927978515625
    top acc: 0.8828125
    total acc: 0.8795611439842209

Component: 3
    ratio: 56.34087371826172
    top acc: 0.9375
    total acc: 0.8783284023668639

Component: 4
    ratio: 50.24337387084961
    top acc: 0.765625
    total acc: 0.8807938856015779

Component: 5
    ratio: 81.72393798828125
    top acc: 0.8359375
    total acc: 0.8791913214990138

Component: 6
    ratio: 47.41786575317383
    top acc: 0.84375
    total acc: 0.8788214990138067

Component: 7
    ratio: 60.46062088012695
    top acc: 0.796875
    total acc: 0.8780818540433925

Component: 8
    ratio: 61.99885559082031
    top acc: 0.90625
    total acc: 0.8782051282051282

Component: 9
    ratio: 81.52857971191406
    top acc: 0.875
    total acc: 0.8805473372781065

Component: 10
    ratio: 169.7125244140625
    top acc: 0.8984375
    total acc: 0.8804240631163708

Component: 11
    ratio: 68.74388885498047
    top acc: 0.9296875
    total acc: 0.8784516765285996

Component: 12
    ratio: 43.5989875793457
    top acc: 0.8125
    total acc: 0.8782051282051282

Component: 13
    ratio: 53.39924240112305
    top acc: 0.890625
    total acc: 0.8795611439842209

Component: 14
    ratio: 52.88133239746094
    top acc: 0.8515625
    total acc: 0.8778353057199211

Component: 15
    ratio: 93.12425231933594
    top acc: 0.8828125
    total acc: 0.8796844181459567

Component: 16
    ratio: 89.18175506591797
    top acc: 0.859375
    total acc: 0.8800542406311637

Component: 17
    ratio: 54.540313720703125
    top acc: 0.8046875
    total acc: 0.879930966469428

Component: 18
    ratio: 76.0503158569336
    top acc: 0.8671875
    total acc: 0.8795611439842209

Component: 19
    ratio: 34.9228515625
    top acc: 0.828125
    total acc: 0.8794378698224852

Component: 20
    ratio: 44.09330368041992
    top acc: 0.828125
    total acc: 0.8794378698224852

Component: 21
    ratio: 95.7718505859375
    top acc: 0.90625
    total acc: 0.8791913214990138

Component: 22
    ratio: 130.45193481445312
    top acc: 0.78125
    total acc: 0.8796844181459567

Component: 23
    ratio: 74.16259002685547
    top acc: 0.8984375
    total acc: 0.878698224852071

Component: 24
    ratio: 51.27359390258789
    top acc: 0.859375
    total acc: 0.8794378698224852

Component: 25
    ratio: 63.300167083740234
    top acc: 0.8671875
    total acc: 0.8796844181459567

Component: 26
    ratio: 101.81205749511719
    top acc: 0.90625
    total acc: 0.8784516765285996

Component: 27
    ratio: 76.6214599609375
    top acc: 0.7421875
    total acc: 0.8779585798816568

Component: 28
    ratio: 103.26190948486328
    top acc: 0.8828125
    total acc: 0.8784516765285996

Component: 29
    ratio: 87.11702728271484
    top acc: 0.8671875
    total acc: 0.8785749506903353

Component: 30
    ratio: 31.971525192260742
    top acc: 0.8359375
    total acc: 0.8782051282051282

Component: 31
    ratio: 26.184547424316406
    top acc: 0.8203125
    total acc: 0.8784516765285996

Component: 32
    ratio: 58.75174331665039
    top acc: 0.859375
    total acc: 0.8795611439842209

Component: 33
    ratio: 144.23248291015625
    top acc: 0.8828125
    total acc: 0.8777120315581854

Component: 34
    ratio: 59.13943099975586
    top acc: 0.84375
    total acc: 0.8790680473372781

Component: 35
    ratio: 155.83636474609375
    top acc: 0.875
    total acc: 0.8800542406311637

Component: 36
    ratio: 123.44026947021484
    top acc: 0.8984375
    total acc: 0.878698224852071

Component: 37
    ratio: 58.048789978027344
    top acc: 0.890625
    total acc: 0.8803007889546351

Component: 38
    ratio: 64.06016540527344
    top acc: 0.890625
    total acc: 0.878698224852071

Component: 39
    ratio: 73.75302124023438
    top acc: 0.8828125
    total acc: 0.8782051282051282

Component: 40
    ratio: 40.47956466674805
    top acc: 0.875
    total acc: 0.8789447731755424

Component: 41
    ratio: 66.51100158691406
    top acc: 0.8671875
    total acc: 0.8790680473372781

Component: 42
    ratio: 48.78532028198242
    top acc: 0.828125
    total acc: 0.8788214990138067

Component: 43
    ratio: 55.15529251098633
    top acc: 0.8984375
    total acc: 0.8788214990138067

Component: 44
    ratio: 64.28128814697266
    top acc: 0.8359375
    total acc: 0.8780818540433925

Component: 45
    ratio: 80.61338806152344
    top acc: 0.8203125
    total acc: 0.8782051282051282

Component: 46
    ratio: 67.91612243652344
    top acc: 0.8671875
    total acc: 0.8795611439842209

Component: 47
    ratio: 48.57584762573242
    top acc: 0.84375
    total acc: 0.8803007889546351

Component: 48
    ratio: 36.239341735839844
    top acc: 0.828125
    total acc: 0.8784516765285996

Component: 49
    ratio: 81.8157730102539
    top acc: 0.7578125
    total acc: 0.8784516765285996

Component: 50
    ratio: 33.1325798034668
    top acc: 0.84375
    total acc: 0.8793145956607495

Component: 51
    ratio: 65.13090515136719
    top acc: 0.953125
    total acc: 0.8785749506903353

Component: 52
    ratio: 42.29765319824219
    top acc: 0.84375
    total acc: 0.8788214990138067

Component: 53
    ratio: 67.69062805175781
    top acc: 0.8671875
    total acc: 0.8789447731755424

Component: 54
    ratio: 121.15409088134766
    top acc: 0.921875
    total acc: 0.8791913214990138

Component: 55
    ratio: 66.83995819091797
    top acc: 0.984375
    total acc: 0.8788214990138067

Component: 56
    ratio: 83.26484680175781
    top acc: 0.8671875
    total acc: 0.8791913214990138

Component: 57
    ratio: 68.31398010253906
    top acc: 0.890625
    total acc: 0.8788214990138067

Component: 58
    ratio: 72.8655014038086
    top acc: 0.8984375
    total acc: 0.8795611439842209

Component: 59
    ratio: 73.46744537353516
    top acc: 0.9453125
    total acc: 0.8790680473372781

Component: 60
    ratio: 57.8956184387207
    top acc: 0.8046875
    total acc: 0.8800542406311637

Component: 61
    ratio: 97.13251495361328
    top acc: 0.828125
    total acc: 0.8785749506903353

Component: 62
    ratio: 54.14188003540039
    top acc: 0.828125
    total acc: 0.8789447731755424

Component: 63
    ratio: 144.51097106933594
    top acc: 0.9453125
    total acc: 0.8779585798816568

Component: 201
    ratio: 40.78402328491211
    top acc: 0.7578125
    total acc: 0.8794378698224852

Component: 337
    ratio: 47.956886291503906
    top acc: 0.890625
    total acc: 0.8793145956607495

Component: 371
    ratio: 63.03131866455078
    top acc: 0.7734375
    total acc: 0.8789447731755424

Component: 569
    ratio: 73.5744857788086
    top acc: 0.8359375
    total acc: 0.8783284023668639

"""






























"""


run_and_eval3, top 128, max_sim=0.35, mp=1e-1

Component: 0
    ratio: 6.992675304412842
    top acc: 0.640625
    total acc: 0.8651380670611439

Component: 1
    ratio: 3.864316940307617
    top acc: 0.71875
    total acc: 0.8650147928994083

Component: 2
    ratio: 18.418737411499023
    top acc: 0.9140625
    total acc: 0.8756163708086785

Component: 3
    ratio: 8.308926582336426
    top acc: 0.9375
    total acc: 0.875

Component: 4
    ratio: 8.986869812011719
    top acc: 0.7109375
    total acc: 0.8705621301775148

Component: 5
    ratio: 10.102982521057129
    top acc: 0.734375
    total acc: 0.8678500986193294

Component: 6
    ratio: 13.992204666137695
    top acc: 0.859375
    total acc: 0.8779585798816568

Component: 7
    ratio: 8.745497703552246
    top acc: 0.7734375
    total acc: 0.8758629191321499

Component: 8
    ratio: 7.8571906089782715
    top acc: 0.6640625
    total acc: 0.8648915187376726

Component: 9
    ratio: 9.682841300964355
    top acc: 0.671875
    total acc: 0.8668639053254438

Component: 10
    ratio: 7.9514546394348145
    top acc: 0.484375
    total acc: 0.8475098619329389

Component: 11
    ratio: 10.525009155273438
    top acc: 0.75
    total acc: 0.8652613412228797

Component: 12
    ratio: 8.797332763671875
    top acc: 0.7734375
    total acc: 0.8701923076923077

Component: 13
    ratio: 4.774518013000488
    top acc: 0.7265625
    total acc: 0.8595907297830375

Component: 14
    ratio: 10.9758882522583
    top acc: 0.765625
    total acc: 0.8740138067061144

Component: 15
    ratio: 9.470019340515137
    top acc: 0.734375
    total acc: 0.8701923076923077

Component: 16
    ratio: 9.344168663024902
    top acc: 0.75
    total acc: 0.875

Component: 17
    ratio: 10.647066116333008
    top acc: 0.5546875
    total acc: 0.8544132149901381

Component: 18
    ratio: 3.083536148071289
    top acc: 0.796875
    total acc: 0.8716715976331361

Component: 19
    ratio: 9.543700218200684
    top acc: 0.6328125
    total acc: 0.8656311637080868

Component: 20
    ratio: 8.680752754211426
    top acc: 0.7421875
    total acc: 0.8710552268244576

Component: 21
    ratio: 7.8436503410339355
    top acc: 0.6328125
    total acc: 0.8556459566074951

Component: 22
    ratio: 9.409056663513184
    top acc: 0.65625
    total acc: 0.871301775147929

Component: 23
    ratio: 6.702352046966553
    top acc: 0.6953125
    total acc: 0.8618096646942801

Component: 24
    ratio: 20.954925537109375
    top acc: 0.8515625
    total acc: 0.8791913214990138

Component: 25
    ratio: 10.564155578613281
    top acc: 0.8125
    total acc: 0.8753698224852071

Component: 26
    ratio: 11.520843505859375
    top acc: 0.71875
    total acc: 0.8621794871794872

Component: 27
    ratio: 24.90460968017578
    top acc: 0.671875
    total acc: 0.8767258382642998

Component: 28
    ratio: 7.845373630523682
    top acc: 0.8125
    total acc: 0.8703155818540433

Component: 29
    ratio: 7.15977144241333
    top acc: 0.671875
    total acc: 0.8609467455621301

Component: 30
    ratio: 7.14210319519043
    top acc: 0.796875
    total acc: 0.8696992110453649

Component: 31
    ratio: 6.213683128356934
    top acc: 0.6875
    total acc: 0.8667406311637081

Component: 32
    ratio: 7.376115798950195
    top acc: 0.6171875
    total acc: 0.8630424063116371

Component: 33
    ratio: 21.260351181030273
    top acc: 0.890625
    total acc: 0.8780818540433925

Component: 34
    ratio: 13.033426284790039
    top acc: 0.8359375
    total acc: 0.8780818540433925

Component: 35
    ratio: 16.57748031616211
    top acc: 0.8515625
    total acc: 0.8778353057199211

Component: 36
    ratio: 34.52586364746094
    top acc: 0.9140625
    total acc: 0.8775887573964497

Component: 37
    ratio: 10.917169570922852
    top acc: 0.890625
    total acc: 0.8782051282051282

Component: 38
    ratio: 11.848506927490234
    top acc: 0.84375
    total acc: 0.8742603550295858

Component: 39
    ratio: 8.11844253540039
    top acc: 0.7265625
    total acc: 0.8653846153846154

Component: 40
    ratio: 6.622683048248291
    top acc: 0.8125
    total acc: 0.8692061143984221

Component: 41
    ratio: 18.098430633544922
    top acc: 0.84375
    total acc: 0.8783284023668639

Component: 42
    ratio: 8.543519973754883
    top acc: 0.8046875
    total acc: 0.8769723865877712

Component: 43
    ratio: 23.317296981811523
    top acc: 0.8828125
    total acc: 0.8772189349112426

Component: 44
    ratio: 11.45964527130127
    top acc: 0.8046875
    total acc: 0.8772189349112426

Component: 45
    ratio: 8.048699378967285
    top acc: 0.6640625
    total acc: 0.8605769230769231

Component: 46
    ratio: 11.025486946105957
    top acc: 0.6171875
    total acc: 0.8695759368836292

Component: 47
    ratio: 6.9499101638793945
    top acc: 0.8125
    total acc: 0.8761094674556213

Component: 48
    ratio: 7.505402565002441
    top acc: 0.7890625
    total acc: 0.873767258382643

Component: 49
    ratio: 8.237447738647461
    top acc: 0.71875
    total acc: 0.8683431952662722

Component: 50
    ratio: 4.528034687042236
    top acc: 0.8203125
    total acc: 0.8662475345167653

Component: 51
    ratio: 5.124183654785156
    top acc: 0.8125
    total acc: 0.8563856015779092

Component: 52
    ratio: 7.618478298187256
    top acc: 0.734375
    total acc: 0.865507889546351

Component: 53
    ratio: 7.648583889007568
    top acc: 0.5
    total acc: 0.8545364891518737

Component: 54
    ratio: 9.114899635314941
    top acc: 0.6328125
    total acc: 0.8674802761341223

Component: 55
    ratio: 12.411877632141113
    top acc: 0.6640625
    total acc: 0.8549063116370809

Component: 56
    ratio: 8.433034896850586
    top acc: 0.59375
    total acc: 0.866370808678501

Component: 57
    ratio: 28.031782150268555
    top acc: 0.8828125
    total acc: 0.8772189349112426

Component: 58
    ratio: 8.764348983764648
    top acc: 0.8515625
    total acc: 0.8783284023668639

Component: 59
    ratio: 7.35804557800293
    top acc: 0.859375
    total acc: 0.8690828402366864

Component: 60
    ratio: 15.756624221801758
    top acc: 0.6875
    total acc: 0.8709319526627219

Component: 61
    ratio: 5.622816562652588
    top acc: 0.6875
    total acc: 0.8582347140039448

Component: 62
    ratio: 6.5868425369262695
    top acc: 0.671875
    total acc: 0.8673570019723866

Component: 63
    ratio: 9.393259048461914
    top acc: 0.8828125
    total acc: 0.8705621301775148

Component: 201
    ratio: 10.136549949645996
    top acc: 0.5390625
    total acc: 0.8669871794871795

Component: 337
    ratio: 13.75994873046875
    top acc: 0.4765625
    total acc: 0.8549063116370809

Component: 371
    ratio: 8.025228500366211
    top acc: 0.609375
    total acc: 0.8672337278106509

Component: 569
    ratio: 9.447578430175781
    top acc: 0.6484375
    total acc: 0.8579881656804734





top 128, max_sim=0.2, mp=1e-1

Component: 0
    ratio: 4.242572784423828
    top acc: 0.6875
    total acc: 0.8651380670611439

Component: 1
    ratio: 8.350646018981934
    top acc: 0.5078125
    total acc: 0.8536735700197239

Component: 2
    ratio: 10.909939765930176
    top acc: 0.7578125
    total acc: 0.865507889546351

Component: 3
    ratio: 2.323190450668335
    top acc: 0.84375
    total acc: 0.8570019723865878

Component: 4
    ratio: 8.722846031188965
    top acc: 0.7109375
    total acc: 0.8738905325443787

Component: 5
    ratio: 8.817203521728516
    top acc: 0.6875
    total acc: 0.8562623274161736

Component: 6
    ratio: 8.156583786010742
    top acc: 0.703125
    total acc: 0.8669871794871795

Component: 7
    ratio: 17.75154685974121
    top acc: 0.796875
    total acc: 0.8801775147928994

Component: 8
    ratio: 16.19014549255371
    top acc: 0.9140625
    total acc: 0.8779585798816568

Component: 9
    ratio: 23.53985595703125
    top acc: 0.859375
    total acc: 0.8784516765285996

Component: 10
    ratio: 12.377836227416992
    top acc: 0.765625
    total acc: 0.8696992110453649

Component: 11
    ratio: 9.905855178833008
    top acc: 0.7890625
    total acc: 0.8678500986193294

Component: 12
    ratio: 8.934806823730469
    top acc: 0.7578125
    total acc: 0.8695759368836292

Component: 13
    ratio: 4.779078960418701
    top acc: 0.71875
    total acc: 0.8579881656804734

Component: 14
    ratio: 10.829374313354492
    top acc: 0.765625
    total acc: 0.8745069033530573

Component: 15
    ratio: 8.40781307220459
    top acc: 0.7578125
    total acc: 0.8706854043392505

Component: 16
    ratio: 9.919005393981934
    top acc: 0.7578125
    total acc: 0.8745069033530573

Component: 17
    ratio: 9.388111114501953
    top acc: 0.578125
    total acc: 0.8541666666666666

Component: 18
    ratio: 3.0966947078704834
    top acc: 0.796875
    total acc: 0.8715483234714004

Component: 19
    ratio: 9.971397399902344
    top acc: 0.6328125
    total acc: 0.8660009861932939

Component: 20
    ratio: 8.41307258605957
    top acc: 0.7421875
    total acc: 0.8701923076923077

Component: 21
    ratio: 7.091629505157471
    top acc: 0.6484375
    total acc: 0.8557692307692307

Component: 22
    ratio: 9.042590141296387
    top acc: 0.671875
    total acc: 0.871301775147929

Component: 23
    ratio: 6.425771713256836
    top acc: 0.703125
    total acc: 0.8616863905325444

Component: 24
    ratio: 21.882108688354492
    top acc: 0.84375
    total acc: 0.8803007889546351

Component: 25
    ratio: 10.318285942077637
    top acc: 0.8125
    total acc: 0.8754930966469427

Component: 26
    ratio: 10.991503715515137
    top acc: 0.7265625
    total acc: 0.8625493096646942

Component: 27
    ratio: 28.073549270629883
    top acc: 0.65625
    total acc: 0.8768491124260355

Component: 28
    ratio: 7.992057800292969
    top acc: 0.8203125
    total acc: 0.8698224852071006

Component: 29
    ratio: 6.936286449432373
    top acc: 0.671875
    total acc: 0.8603303747534516

Component: 30
    ratio: 7.428265571594238
    top acc: 0.7890625
    total acc: 0.8694526627218935

Component: 31
    ratio: 6.377198219299316
    top acc: 0.6875
    total acc: 0.8664940828402367

Component: 32
    ratio: 7.609819412231445
    top acc: 0.59375
    total acc: 0.86267258382643

Component: 33
    ratio: 21.459001541137695
    top acc: 0.890625
    total acc: 0.8778353057199211

Component: 34
    ratio: 13.494575500488281
    top acc: 0.84375
    total acc: 0.8789447731755424

Component: 35
    ratio: 16.054258346557617
    top acc: 0.8671875
    total acc: 0.8777120315581854

Component: 36
    ratio: 34.10788345336914
    top acc: 0.9140625
    total acc: 0.8777120315581854

Component: 37
    ratio: 11.513484001159668
    top acc: 0.890625
    total acc: 0.8785749506903353

Component: 38
    ratio: 12.610607147216797
    top acc: 0.84375
    total acc: 0.8736439842209073

Component: 39
    ratio: 7.249714374542236
    top acc: 0.78125
    total acc: 0.8689595660749507

Component: 40
    ratio: 6.483384132385254
    top acc: 0.8125
    total acc: 0.8693293885601578

Component: 41
    ratio: 17.12832260131836
    top acc: 0.84375
    total acc: 0.8784516765285996

Component: 42
    ratio: 7.594314098358154
    top acc: 0.8046875
    total acc: 0.8764792899408284

Component: 43
    ratio: 23.363971710205078
    top acc: 0.8984375
    total acc: 0.877465483234714

Component: 44
    ratio: 11.686827659606934
    top acc: 0.796875
    total acc: 0.8772189349112426

Component: 45
    ratio: 8.197371482849121
    top acc: 0.6640625
    total acc: 0.8592209072978304

Component: 46
    ratio: 11.28696060180664
    top acc: 0.59375
    total acc: 0.8694526627218935

Component: 47
    ratio: 6.561093330383301
    top acc: 0.8125
    total acc: 0.8759861932938856

Component: 48
    ratio: 7.858500957489014
    top acc: 0.7890625
    total acc: 0.873767258382643

Component: 49
    ratio: 7.8387227058410645
    top acc: 0.71875
    total acc: 0.868836291913215

Component: 50
    ratio: 4.250650405883789
    top acc: 0.8203125
    total acc: 0.8669871794871795

Component: 51
    ratio: 5.498295783996582
    top acc: 0.7890625
    total acc: 0.8557692307692307

Component: 52
    ratio: 7.289671421051025
    top acc: 0.734375
    total acc: 0.8651380670611439

Component: 53
    ratio: 7.456355571746826
    top acc: 0.5
    total acc: 0.8542899408284024

Component: 54
    ratio: 9.393830299377441
    top acc: 0.625
    total acc: 0.8677268244575936

Component: 55
    ratio: 12.105559349060059
    top acc: 0.6875
    total acc: 0.8551528599605522

Component: 56
    ratio: 8.217220306396484
    top acc: 0.6015625
    total acc: 0.8667406311637081

Component: 57
    ratio: 31.044584274291992
    top acc: 0.8828125
    total acc: 0.8769723865877712

Component: 58
    ratio: 8.192286491394043
    top acc: 0.859375
    total acc: 0.878698224852071

Component: 59
    ratio: 7.246962547302246
    top acc: 0.859375
    total acc: 0.8692061143984221

Component: 60
    ratio: 15.219344139099121
    top acc: 0.6875
    total acc: 0.8704388560157791

Component: 61
    ratio: 5.226905822753906
    top acc: 0.6953125
    total acc: 0.8582347140039448

Component: 62
    ratio: 6.872095584869385
    top acc: 0.6640625
    total acc: 0.8668639053254438

Component: 63
    ratio: 9.34204387664795
    top acc: 0.8671875
    total acc: 0.8699457593688363

Component: 201
    ratio: 10.308683395385742
    top acc: 0.5390625
    total acc: 0.866370808678501

Component: 337
    ratio: 13.30040168762207
    top acc: 0.5
    total acc: 0.8555226824457594

Component: 371
    ratio: 8.292838096618652
    top acc: 0.609375
    total acc: 0.8673570019723866

Component: 569
    ratio: 9.854377746582031
    top acc: 0.6484375
    total acc: 0.8578648915187377



top 128, max_sim=0.35, mp=1e-1

Component: 0
    ratio: 5.694489002227783
    top acc: 0.8046875
    total acc: 0.8796844181459567

Component: 1
    ratio: 9.922780990600586
    top acc: 0.7109375
    total acc: 0.8667406311637081

Component: 2
    ratio: 11.388388633728027
    top acc: 0.7734375
    total acc: 0.8674802761341223

Component: 3
    ratio: 2.469618797302246
    top acc: 0.84375
    total acc: 0.8598372781065089

Component: 4
    ratio: 9.081643104553223
    top acc: 0.7109375
    total acc: 0.8738905325443787

Component: 5
    ratio: 8.977216720581055
    top acc: 0.6875
    total acc: 0.8570019723865878

Component: 6
    ratio: 8.24150562286377
    top acc: 0.703125
    total acc: 0.867603550295858

Component: 7
    ratio: 17.837478637695312
    top acc: 0.796875
    total acc: 0.8806706114398422

Component: 8
    ratio: 16.423023223876953
    top acc: 0.9140625
    total acc: 0.8775887573964497

Component: 9
    ratio: 20.528352737426758
    top acc: 0.875
    total acc: 0.8785749506903353

Component: 10
    ratio: 11.096002578735352
    top acc: 0.6953125
    total acc: 0.8666173570019724

Component: 11
    ratio: 9.8782320022583
    top acc: 0.765625
    total acc: 0.8664940828402367

Component: 12
    ratio: 8.933012962341309
    top acc: 0.765625
    total acc: 0.8701923076923077

Component: 13
    ratio: 4.847327709197998
    top acc: 0.71875
    total acc: 0.8584812623274162

Component: 14
    ratio: 10.785905838012695
    top acc: 0.765625
    total acc: 0.8742603550295858

Component: 15
    ratio: 8.413567543029785
    top acc: 0.75
    total acc: 0.8709319526627219

Component: 16
    ratio: 9.905623435974121
    top acc: 0.7578125
    total acc: 0.8743836291913215

Component: 17
    ratio: 9.4104642868042
    top acc: 0.578125
    total acc: 0.8541666666666666

Component: 18
    ratio: 3.1160964965820312
    top acc: 0.796875
    total acc: 0.8719181459566075

Component: 19
    ratio: 9.977274894714355
    top acc: 0.6328125
    total acc: 0.8660009861932939

Component: 20
    ratio: 8.414328575134277
    top acc: 0.7421875
    total acc: 0.8701923076923077

Component: 21
    ratio: 7.090455532073975
    top acc: 0.6484375
    total acc: 0.8558925049309665

Component: 22
    ratio: 9.043195724487305
    top acc: 0.671875
    total acc: 0.871301775147929

Component: 23
    ratio: 6.424070835113525
    top acc: 0.703125
    total acc: 0.8616863905325444

Component: 24
    ratio: 21.849483489990234
    top acc: 0.84375
    total acc: 0.8803007889546351

Component: 25
    ratio: 10.320158958435059
    top acc: 0.8125
    total acc: 0.8753698224852071

Component: 26
    ratio: 10.993441581726074
    top acc: 0.7265625
    total acc: 0.8625493096646942

Component: 27
    ratio: 28.10265350341797
    top acc: 0.65625
    total acc: 0.8768491124260355

Component: 28
    ratio: 7.999607086181641
    top acc: 0.8203125
    total acc: 0.8696992110453649

Component: 29
    ratio: 6.93583345413208
    top acc: 0.671875
    total acc: 0.8603303747534516

Component: 30
    ratio: 7.4295735359191895
    top acc: 0.7890625
    total acc: 0.8694526627218935

Component: 31
    ratio: 6.376484394073486
    top acc: 0.6875
    total acc: 0.8666173570019724

Component: 32
    ratio: 7.6095709800720215
    top acc: 0.59375
    total acc: 0.86267258382643

Component: 33
    ratio: 21.44642448425293
    top acc: 0.890625
    total acc: 0.8779585798816568

Component: 34
    ratio: 13.488661766052246
    top acc: 0.84375
    total acc: 0.8788214990138067

Component: 35
    ratio: 16.041616439819336
    top acc: 0.8671875
    total acc: 0.8777120315581854

Component: 36
    ratio: 34.125282287597656
    top acc: 0.9140625
    total acc: 0.8777120315581854

Component: 37
    ratio: 11.523111343383789
    top acc: 0.890625
    total acc: 0.8785749506903353

Component: 38
    ratio: 12.6090726852417
    top acc: 0.84375
    total acc: 0.8736439842209073

Component: 39
    ratio: 7.249776363372803
    top acc: 0.78125
    total acc: 0.868836291913215

Component: 40
    ratio: 6.483364582061768
    top acc: 0.8125
    total acc: 0.8693293885601578

Component: 41
    ratio: 17.15080451965332
    top acc: 0.84375
    total acc: 0.8784516765285996

Component: 42
    ratio: 7.6001200675964355
    top acc: 0.8046875
    total acc: 0.8764792899408284

Component: 43
    ratio: 23.36801528930664
    top acc: 0.8984375
    total acc: 0.877465483234714

Component: 44
    ratio: 11.693589210510254
    top acc: 0.796875
    total acc: 0.8772189349112426

Component: 45
    ratio: 8.195652961730957
    top acc: 0.6640625
    total acc: 0.8592209072978304

Component: 46
    ratio: 11.2866849899292
    top acc: 0.59375
    total acc: 0.8694526627218935

Component: 47
    ratio: 6.555917739868164
    top acc: 0.8125
    total acc: 0.8759861932938856

Component: 48
    ratio: 7.863218307495117
    top acc: 0.7890625
    total acc: 0.873767258382643

Component: 49
    ratio: 7.844847202301025
    top acc: 0.71875
    total acc: 0.8689595660749507

Component: 50
    ratio: 4.251936435699463
    top acc: 0.8203125
    total acc: 0.8669871794871795

Component: 51
    ratio: 5.49723482131958
    top acc: 0.7890625
    total acc: 0.8558925049309665

Component: 52
    ratio: 7.290998935699463
    top acc: 0.734375
    total acc: 0.8650147928994083

Component: 53
    ratio: 7.454668045043945
    top acc: 0.5
    total acc: 0.8545364891518737

Component: 54
    ratio: 9.392232894897461
    top acc: 0.625
    total acc: 0.8677268244575936

Component: 55
    ratio: 12.103086471557617
    top acc: 0.6875
    total acc: 0.8551528599605522

Component: 56
    ratio: 8.215611457824707
    top acc: 0.6015625
    total acc: 0.8667406311637081

Component: 57
    ratio: 31.008872985839844
    top acc: 0.8828125
    total acc: 0.8772189349112426

Component: 58
    ratio: 8.17940902709961
    top acc: 0.859375
    total acc: 0.878698224852071

Component: 59
    ratio: 7.245784759521484
    top acc: 0.859375
    total acc: 0.8692061143984221

Component: 60
    ratio: 15.22091293334961
    top acc: 0.6875
    total acc: 0.8705621301775148

Component: 61
    ratio: 5.228199005126953
    top acc: 0.6953125
    total acc: 0.8582347140039448

Component: 62
    ratio: 6.871064186096191
    top acc: 0.6640625
    total acc: 0.8668639053254438

Component: 63
    ratio: 9.343167304992676
    top acc: 0.8671875
    total acc: 0.8698224852071006

Component: 201
    ratio: 10.30876350402832
    top acc: 0.5390625
    total acc: 0.8664940828402367

Component: 337
    ratio: 13.300683975219727
    top acc: 0.5
    total acc: 0.8553994082840237

Component: 371
    ratio: 8.295137405395508
    top acc: 0.609375
    total acc: 0.8673570019723866

Component: 569
    ratio: 9.853206634521484
    top acc: 0.6484375
    total acc: 0.8579881656804734


"""