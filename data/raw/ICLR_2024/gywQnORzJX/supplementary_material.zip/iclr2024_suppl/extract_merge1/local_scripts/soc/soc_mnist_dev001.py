R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i local_scripts/soc/soc_mnist_dev001.py



CUDA_VISIBLE_DEVICES=0 python -i local_scripts/soc/soc_mnist_dev001.py


"""
import collections
import dataclasses
import os
from importlib import reload
import itertools
import time
from typing import Any, List, Sequence

import h5py
import matplotlib.pyplot as plt
import numpy as np
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer
import tensorflow as tf
import tensorflow_probability as tfp

from em.datasets import glue
from em.evaluation import evaluation
from em.fishers import diagonal
from em.fishers import per_example
from em.fishers import sparse_diagonal
from em.merging import merging
from em.models.generative import vae
# from em.models.generative import soc
from em.util import hf_util
from em.util import vat_da_faak_vpn

from local_scripts.soc import soc_dev_common as sdc


tfd = tfp.distributions


###############################################################################
###############################################################################

# BATCH_SIZE = 256
# BATCH_SIZE = 2048
BATCH_SIZE = 1024

#######################################


# (x_train, _), _ = tf.keras.datasets.mnist.load_data()
(x_train, _), _ = tf.keras.datasets.fashion_mnist.load_data()
x_train = x_train.astype(np.float32) / 255.0
x_train = x_train.reshape([-1, 28**2])

ds = tf.data.Dataset.from_tensor_slices(x_train)
ds = ds.repeat().shuffle(1000).batch(BATCH_SIZE).map(lambda x: (x, x))


#######################################

component_size = 28**2

#######################################

# beta = 1.0
beta = 0.0

# vae_latent_size = 256
vae_latent_size = 512

# n_components = 256
n_components = 512 + 128

width = 1024

# n_components = 32
# n_components = 128
# n_components = 64

# autoencoder = vae.Vae(
#     encoder=tf.keras.Sequential(sdc.make_dense_layers([512, 2 * vae_latent_size], 'gelu')),
#     decoder=tf.keras.Sequential(sdc.make_dense_layers([512, n_components], 'gelu')),
#     representation_size=vae_latent_size,
#     beta=beta,
# )
autoencoder = tf.keras.Sequential([
    *sdc.make_dense_layers([width, vae_latent_size], 'gelu'),
    *sdc.make_dense_layers([width, n_components], 'gelu'),
])

soc_model = sdc.AeSoc(
    autoencoder=autoencoder,
    component_size=component_size,
    n_components=n_components,
    non_negative_components=True,
    non_negative_coefficients=True,
    unit_norm_components=False,
)
loss = sdc.SparsityLoss(
    tf.keras.losses.MeanSquaredError(),
    model=soc_model,
    # lmbda_comp=1e-3,
    lmbda_comp=0.0,
    # lmbda_comp=1e-4,
    #
    # lmbda_coeff=1e-2,
    # lmbda_coeff=1e-4,
    lmbda_coeff=1e-4,
    # lmbda_comp_unit_norm=1e-1,
    lmbda_comp_unit_norm=1e-2,
)

# lr = 1e-3
lr = 1e-3
# lr = 3e-4
soc_model.compile(
    loss=loss,
    # loss=tf.keras.losses.MeanSquaredError(),
    optimizer=tf.keras.optimizers.Adam(lr, clipnorm=0.1),
    metrics=[tf.keras.metrics.MeanSquaredError()]
)
# soc_model.fit(ds, steps_per_epoch=1024, epochs=10)
soc_model.fit(ds, steps_per_epoch=1024, epochs=100)


# sdc.plot_component(soc_model, 0)


for _, x in ds:
    break

y = soc_model(x)

sdc.imshow_mnist(x[0])
sdc.imshow_mnist(y[0])


avg_coeffs = tf.reduce_sum(tf.abs(soc_model._call_coeffs), axis=0)
_, inds = tf.math.top_k(avg_coeffs, k=n_components)

sorted_components = tf.gather(soc_model.get_components(), inds)

# sdc.plot_component(soc_model, inds[0])

sdc.imshow_mnist_multi(sorted_components[:50], 10)


R"""

for _, x in ds:
    break

y = soc_model(x)

sdc.imshow_mnist(x[0])
sdc.imshow_mnist(y[0])


y[:10,300:305]

tf.reduce_all(y[0] == y[1]).numpy()


x[:10,300:305]

soc_model.get_components()[:10,300:305]

plt.imshow(tf.transpose(soc_model._call_coeffs), cmap='gray'); plt.show()

"""
