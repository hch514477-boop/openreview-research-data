R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/ead/supervised_transfer/st_dev001.py

"""
import collections
from importlib import reload
import itertools
import os
import re
import time
from typing import Sequence

import numpy as np
import sympy as sp
from sympy.parsing.sympy_parser import parse_expr
import matplotlib.pyplot as plt

import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer
from tqdm import tqdm

from em.datasets.antiderivative import antiderivative_ds
from em.fishers import per_example
from em.tools.nmf import nmf_common
from em.util.color_util import cu
from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf
from em.projects.ead import ead_misc1 as eadm
from em.util import vat_da_faak_vpn

from em.datasets.antiderivative import expression_metadata as emd

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/ead1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

PRETRAINED_MODEL = 'bert-base-uncased'


# MODEL = "best_base_ead_infix_ds5s01_35k_dev001"
# PER_EXAMPLES_FISHERS = f"{MODEL}.ds5s01.no_embeddings.sparse_dynamic_raw.16k.16k.h5"
# DECOMP_FILENAME = f"nmf_decomp.per_sub_block.16k.16k.256.{PER_EXAMPLES_FISHERS}"

MODEL = "best_base_ead_infix_150k_dev002"
PER_EXAMPLES_FISHERS = f"{MODEL}.val.no_embeddings.sparse_dynamic_raw.16k.16k.h5"
DECOMP_FILENAME = f"nmf_decomp.per_sub_block.16k.16k.256.{PER_EXAMPLES_FISHERS}"


FROM_PT = False

N_DECOMPS = 25

###############################################################################

tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL)

###############################################################################

pef = per_example.PerExampleFlatFishers.load(
    os.path.expanduser(os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS)),
    n_examples=16 * 1024,
    # This leads to the Fishers not being loaded, which ends up being much faster.
    start_fisher_index=0,
    end_fisher_index=0,
)

nmfs = am._LazyNmfList(os.path.join(PER_EXAMPLES_FISHERS_DIR, DECOMP_FILENAME), n_nmfs=N_DECOMPS)

container = eadm.EadAnalysisContainer(
    pef=pef,
    nmfs=nmfs,
    tokenizer=tokenizer,
)
# container.nmfs.force_load_all()

###############################################################################


def to_latex_string(example_index: int):
    # Hacky.
    s = container.make_example_for_component_latex_string(0, 0, example_index)
    if '$$ $$' in s:
        return ''
    s = re.sub(r'\[COEFF\]\: \d\.\d+', '', s)
    return s


incorrect_inds, = np.nonzero(container.get_incorrect_prediction_indicator())
incorrect_inds = list(sorted(incorrect_inds, key=lambda i: container.labels[i]))

latex_examples_strs = []
for i in incorrect_inds:
    latex_examples_strs.append(to_latex_string(i))

latex_body = '\n\n'.join(latex_examples_strs)
print(latex_body)
