R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/nmf/nmf_per_layer_dev001.py

"""
import collections
from importlib import reload
import itertools
import os
import time

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import tensorflow as tf

from em.datasets import divisibility as div_ds
from em.fishers import per_example
from em.models import divis_models
from em.models import transformer_model_vars as tmv
from em.tools.clustering import vat
from em.tools.nmf import parallel_sklearn_nmf as p_nmf
from em.tools.nmf import nmf_common
from em.util import flat_pack
from em.util import sparse_util

from em.analysis import bert_nmf_analysis as bna
from em.analysis import bert_nmf_analysis2 as bna2

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/divis_mech1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

MODEL = "misc_divis_model_001_half"
PER_EXAMPLES_FISHERS = f"{MODEL}.sparse_dynamic_raw.32k.32k.h5"

DECOMP = f"nmf_decomp.16k.8k.64.{PER_EXAMPLES_FISHERS}"
N_EXAMPLES = 16 * 1024
START_FISHER_INDEX, END_FISHER_INDEX = (0, 8 * 1024)

###############################################################################


model, model_config = divis_models.load_model_from_file(os.path.join(MODELS_DIR, f'{MODEL}.h5'))
variables = model.trainable_variables

print('Starting to load saved per-example Fishers.')
start = time.time()
pe_fishers_data = per_example.PerExampleFlatFishers.load(
    os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    n_examples=N_EXAMPLES,
    start_fisher_index=START_FISHER_INDEX,
    end_fisher_index=END_FISHER_INDEX,
    extra_data_fields=['dividends', 'divisors'],
)
print('Load saved per-example Fishers time: ', time.time() - start)


###############################################################################
index = 3


homogenized_variables = tmv.homogenize_kernel_biases(variables)
reload(flat_pack)
packer = flat_pack.FlatPacker([v.shape for v in homogenized_variables])

start_index, end_index = packer.get_range_for_tensor_by_index(index)

all_subset_values = []
all_subset_indices = []
for values, inds in zip(pe_fishers_data.fishers, pe_fishers_data.fisher_indices):
    mask = (start_index <= inds) & (inds < end_index)
    subset_values = values[mask]
    subset_inds = inds[mask] - start_index
    all_subset_values.append(subset_values)
    all_subset_indices.append(subset_inds)


# reload(sparse_util)
reduction_info, (reduced_subset_values, reduced_subset_indices) = sparse_util.remove_always_zero_indices(
    all_subset_values,
    all_subset_indices,
    dense_size=end_index - start_index,
    threshold=1,
)

reload(sparse_util)
coo_indices = sparse_util.to_torch_coo_indices(reduced_subset_indices)
coo_values = np.concatenate(list(reduced_subset_values), axis=-1)

dense_shape = [len(reduced_subset_indices), reduction_info.reduced_size]

# unpacked = packer.decode_sparse_tf(pe_fishers_data.fishers, pe_fishers_data.fisher_indices)
# sparse_fishers_for_layer = unpacked[index]
# sparse_fishers_for_layer = tf.sparse.split(sparse_fishers_for_layer)

# indices_for_layer = [s.indices for s in sparse_fishers_for_layer]
