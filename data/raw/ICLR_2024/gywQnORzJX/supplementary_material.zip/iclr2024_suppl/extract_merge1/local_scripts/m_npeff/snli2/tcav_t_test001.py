R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python -i local_scripts/m_npeff/snli2/tcav_t_test001.py

"""
import os

import numpy as np
from scipy import stats

from em.analysis.tcav import bert_tcav

TCAV_DIR = "/fruitbasket/users/m/project_data/extract_merge1/snli3og_lrm_npeff/tcav"

TCAV_FILENAME = "tcav.feather_berts_0.train.50000ex.65536.mnpeff.512comps.001.fit_to_train_skip_50k.h5"


def compute_p_values(scores: np.ndarray, mu0=0.5):
    # scores.shape [n_runs, n_classes]
    n = float(scores.shape[0])
    means = np.mean(scores, axis=0)
    sorta_std_dev = np.sqrt(np.sum((scores - means[None, :])**2, axis=0)) / n
    t = (means - mu0) / sorta_std_dev
    # two-sided pvalue
    pval = stats.t.sf(np.abs(t), int(n) - 1) * 2
    return pval


def compute_p_values_for_all_comps(tcav_run_scores):
    return np.stack([
        compute_p_values(tcav_run_scores[i])
        for i in sorted(tcav_run_scores.keys())
    ], axis=0)


tcav_run_scores = bert_tcav.load_run_scores(os.path.join(TCAV_DIR, TCAV_FILENAME))

# print(compute_p_values(tcav_run_scores[0]))
# print(compute_p_values(tcav_run_scores[1]))

ps = compute_p_values_for_all_comps(tcav_run_scores)
print(ps)

