R"""




cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python -i local_scripts/m_npeff/lrm_npeff_snli_results001.py

"""
from importlib import reload
import os

import numpy as np
import tensorflow as tf

from em.tools.nmf import lrm_npeff

###############################################################################

NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/"
NMF_NAME = "test_mnpeff_002.h5"
NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)
###############################################################################

# nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=False)

nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=True)
nmf.normalize_components_to_unit_norm()


def compute_G_sparsity(threshold):
    G = nmf.G
    total = G.shape[0] * G.shape[1]
    nnz = (np.abs(G) >= threshold).astype(np.int64).sum()
    return nnz / total


for i in range(6, 11):
    print(i, compute_G_sparsity(10**-i))

# 1e-6  0.3415960320469396
# 1e-7  0.6495623822009366
# 1e-8  0.8944026773762734
# 1e-9  0.9849220250301077
# 1e-10 0.998393797691774
