R"""



cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/divis/divis_per_layer_nmf002.py

"""
import collections
from importlib import reload
import itertools
import os
import time

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import tensorflow as tf

from em.datasets import divisibility as div_ds
from em.fishers import per_example
from em.models import divis_models
from em.models import transformer_model_vars as tmv
from em.tools.clustering import vat
from em.tools.nmf import parallel_sklearn_nmf as p_nmf
from em.tools.nmf import nmf_common
from em.util import flat_pack

from em.analysis import bert_nmf_analysis as bna
from em.analysis import bert_nmf_analysis2 as bna2

rocket_cmap = sns.color_palette("rocket", as_cmap=True)

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/divis_mech1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

MODEL = "misc_divis_model_001_deep_semi_sixteenth"
PER_EXAMPLES_FISHERS = f"{MODEL}.sparse_dynamic_raw.64k.32k.h5"

DECOMP = f"nmf_decomp.32k.8k.384.{PER_EXAMPLES_FISHERS}"
N_EXAMPLES = 32 * 1024
START_FISHER_INDEX, END_FISHER_INDEX = (0, 8 * 1024)

###############################################################################


model, model_config = divis_models.load_model_from_file(os.path.join(MODELS_DIR, f'{MODEL}.h5'))


print('Starting to load saved per-example Fishers.')
start = time.time()
pe_fishers_data = per_example.PerExampleFlatFishers.load(
    os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    n_examples=N_EXAMPLES,
    start_fisher_index=START_FISHER_INDEX,
    end_fisher_index=END_FISHER_INDEX,
    extra_data_fields=['dividends', 'divisors'],
)
print('Load saved per-example Fishers time: ', time.time() - start)


###############################################################################

def load_nmf_decomp(subset_index: int):
    print('Starting to load saved NMF decomposition.')
    start = time.time()
    filename = f"{DECOMP[:-3]}.ssi{subset_index}.h5"
    decomp = nmf_common.NmfDecomposition.load(os.path.join(PER_EXAMPLES_FISHERS_DIR, filename))
    decomp.normalize_components_to_unit_norm()
    decomp.H = decomp.get_full_H()
    print('Load saved NMF decomposition time: ', time.time() - start)
    return decomp


# decomp1 = load_nmf_decomp(0)
decomp1 = load_nmf_decomp(1)

variables = model.trainable_variables
homogenized_variables = tmv.homogenize_kernel_biases(variables)

###############################################################################


def print_top_examples(decomp, component_index: int, n_examples: int):
    _, inds = tf.math.top_k(decomp.W[:, component_index], k=n_examples)
    for ind in inds:
        label = pe_fishers_data.labels[ind]
        prediction = np.argmax(pe_fishers_data.predicted_logits[ind])
        #
        divisor = pe_fishers_data.divisors[ind]
        dividend = pe_fishers_data.dividends[ind]
        example = f'{divisor}|{dividend}'
        #
        print(f'{label}, {prediction}: {example}')


print_top_examples(decomp1, 0, n_examples=16)


rsH1 = decomp1.H.reshape([decomp1.H.shape[0], *homogenized_variables[1].shape])
plt.imshow(rsH1[1].T, cmap=rocket_cmap);plt.tight_layout();plt.show()
plt.imshow(np.sqrt(rsH1[1].T), cmap=rocket_cmap);plt.tight_layout();plt.show()


# comp 1: 5, last digit 0
# comp 2: 5, last digit 5

plt.plot(rsH1[1, -1])
plt.plot(rsH1[2, -1])
plt.show()


def asdfasdf(component_index: int):
    comp = rsH1[component_index]
    ker, bias = comp[:-1], comp[-1]
    #
    embeddings = homogenized_variables[0]
    ker = ker.reshape([-1, embeddings.shape[-1], ker.shape[-1]])
    ker = np.sqrt(ker)
    #
    asdf = tf.einsum('de,sef->dsf', embeddings, ker)
    asdf = tf.reshape(asdf, [-1, asdf.shape[-1]])
    #
    plt.imshow(asdf)
    plt.tight_layout()
    plt.show()


asdfasdf(1)
asdfasdf(2)
