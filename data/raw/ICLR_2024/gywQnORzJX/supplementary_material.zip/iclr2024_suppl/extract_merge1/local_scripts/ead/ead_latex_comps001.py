R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/ead/ead_latex_comps001.py

"""
import collections
from importlib import reload
import itertools
import os
import time
from typing import Sequence

import numpy as np
import sympy as sp
from sympy.parsing.sympy_parser import parse_expr

import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em.datasets.antiderivative import antiderivative_ds
from em.fishers import per_example
from em.tools.nmf import nmf_common
from em.util.color_util import cu
from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf
from em.projects.ead import ead_misc1 as eadm
from em.util import vat_da_faak_vpn

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/ead1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

PRETRAINED_MODEL = 'bert-base-uncased'


# MODEL = "best_base_ead_infix_ds5s01_35k_dev001"
# PER_EXAMPLES_FISHERS = f"{MODEL}.ds5s01.no_embeddings.sparse_dynamic_raw.16k.16k.h5"
# DECOMP_FILENAME = f"nmf_decomp.per_sub_block.16k.16k.256.{PER_EXAMPLES_FISHERS}"

# MODEL = "best_base_ead_infix_150k_dev002"
# PER_EXAMPLES_FISHERS = f"{MODEL}.val.no_embeddings.sparse_dynamic_raw.16k.16k.h5"
# DECOMP_FILENAME = f"nmf_decomp.per_sub_block.16k.16k.256.{PER_EXAMPLES_FISHERS}"


MODEL = "best_base_ead_infix_75k_dev003"
PER_EXAMPLES_FISHERS = f"{MODEL}.val.no_embeddings_pooler.sparse_dynamic_raw.16k.16k.h5"
DECOMP_FILENAME = f"nmf_decomp.per_sub_block.16k.16k.256.{PER_EXAMPLES_FISHERS}"


FROM_PT = False

# N_DECOMPS = 25
N_DECOMPS = 23

###############################################################################

tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL)

###############################################################################

print('Starting to load saved per-example Fishers.')
start = time.time()
pef = per_example.PerExampleFlatFishers.load(
    os.path.expanduser(os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS)),
    n_examples=16 * 1024,
    # This leads to the Fishers not being loaded, which ends up being much faster.
    start_fisher_index=0,
    end_fisher_index=0,
)
print('Load saved per-example Fishers time: ', time.time() - start)

nmfs = am._LazyNmfList(os.path.join(PER_EXAMPLES_FISHERS_DIR, DECOMP_FILENAME), n_nmfs=N_DECOMPS)

container = eadm.EadAnalysisContainer(
    pef=pef,
    nmfs=nmfs,
    tokenizer=tokenizer,
)

container.nmfs.force_load_all()

###############################################################################

subset_names = am.make_per_sub_block_subset_names(N_DECOMPS - 1)
subset_names.append('Pooler')

N_EXAMPLES = 8

# FILENAME = "ead_bert_base_all_comps_001"
# FILENAME = "ead_bert_base_all_comps_002"
FILENAME = "ead_bert_base_all_comps_dsv3_001"

# reload(eadm); container.__class__ = eadm.EadAnalysisContainer

contents = container.make_all_components_latex_string(n_examples=N_EXAMPLES, nmf_names=subset_names)

with open(f'/fruitbasket/users/m/tmp/{FILENAME}.tex', 'w') as f:
    f.write(container.wrap_latex_contents(contents))


R"""


# FILENAME=ead_bert_base_all_comps_001
# FILENAME=ead_bert_base_all_comps_002
FILENAME=ead_bert_base_all_comps_dsv3_001

rsync -ra -e ssh \
    "m@banana.cs.unc.edu:/fruitbasket/users/m/tmp/$FILENAME.tex" \
    "$HOME/Downloads/$FILENAME.tex"

xelatex -interaction=batchmode -output-directory=/tmp ~/Downloads/$FILENAME.tex
mv /tmp/$FILENAME.pdf ~/Downloads


"""
