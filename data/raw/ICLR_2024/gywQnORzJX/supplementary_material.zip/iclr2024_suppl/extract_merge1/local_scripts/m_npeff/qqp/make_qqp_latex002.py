R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python local_scripts/m_npeff/qqp/make_qqp_latex002.py

"""
from importlib import reload
import os

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer

from em.fishers import lrm_pefs
from em.tools.nmf import lrm_npeff
from em.projects.m_npeff import qqp_context
from em.projects.m_npeff import qqp_latex_generation

from em.util.color_util import cu

# ###############################################################################

# NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/qqp_lrm_npeff2/per_example_fishers"

# # NMF_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.h5"
# # NMF_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit001.h5"
# NMF_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit_to_validation001.h5"
# NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)

# ###############################################################################

# PEFS_DIR = "/fruitbasket/users/m/project_data/extract_merge1/qqp_lrm_npeff2/per_example_fishers"

# # PEFS_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.h5"
# PEFS_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.validation.40430ex.65536.h5"
# PEFS_PATH = os.path.join(PEFS_DIR, PEFS_NAME)

# ###############################################################################

# TOKENIZER = 'bert-base-uncased'
# # SPLIT = 'train[-50000:]'
# SPLIT = 'validation'

# ###############################################################################

###############################################################################

NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/qqp_lrm_npeff2/per_example_fishers"

# NMF_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit001.h5"

# NMF_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.h5"
NMF_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit_to_validation001.h5"
NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)

###############################################################################

PEFS_DIR = "/fruitbasket/users/m/project_data/extract_merge1/qqp_lrm_npeff2/per_example_fishers"

# PEFS_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.h5"
PEFS_NAME = "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.validation.40430ex.65536.h5"
PEFS_PATH = os.path.join(PEFS_DIR, PEFS_NAME)

###############################################################################

TOKENIZER = 'bert-base-uncased'
# SPLIT = 'train[-50000:]'
SPLIT = 'validation'

###############################################################################

print('Starting to load in nmf.')
nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=False)

print('Starting to load in logits.')
logits = lrm_pefs.SparseLrmPefs.load_logits(PEFS_PATH)

print('Starting to create context.')
ctx = qqp_context.QqpContext(
    split=SPLIT,
    tokenizer=AutoTokenizer.from_pretrained(TOKENIZER),
    nmf=nmf,
)

reload(qqp_latex_generation)
print('Starting to create latex generator.')
lg = qqp_latex_generation.TopExamplesLatexGenerator(
    qqp_ctx=ctx,
    predicted_logits=logits,
    n_top_examples=16,
)

print('Generating latex.')
latex_str = lg.generate_all_components_latex()
# print(latex_str)

###############################################################################

# filename = 'qqp.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.tex'
# filename = 'qqp.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit001.tex'
# filename = 'qqp.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit_to_validation001.tex'
# filename = 'test_fit_coeffs001.tex'

# filename = 'qqp.expansion.fitting_examples.tex'
# filename = 'qqp.tex'
filename = 'qqp.expansion.validation.tex'
with open(os.path.join('/fruitbasket/users/m/tmp', filename), 'w') as f:
    f.write(latex_str)

print(cu.hlg(filename[:-len('.tex')]))

###############################################################################


R"""

make_pdf() {
    local filename=$1

    rsync -ra -e ssh \
        "m@mango.cs.unc.edu:/fruitbasket/users/m/tmp/${filename}.tex" \
        "$HOME/Downloads/${filename}.tex"

    xelatex -interaction=batchmode -output-directory=/tmp ~/Downloads/${filename}.tex
    mv /tmp/${filename}.pdf ~/Desktop/projects_data/extract_merge1/ll/pdfs
}

# make_pdf qqp.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001
# make_pdf test_fit_coeffs001
# make_pdf qqp.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit001
make_pdf qqp.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit_to_validation001

make_pdf qqp.expansion.fitting_examples
make_pdf qqp
make_pdf qqp.expansion.validation


"""
