R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/ead/ead_latex_comps002.py

"""
import collections
from importlib import reload
import itertools
import os
import time
from typing import Sequence

import numpy as np
import sympy as sp
from sympy.parsing.sympy_parser import parse_expr

import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em.datasets.antiderivative import antiderivative_ds
from em.fishers import per_example
from em.tools.nmf import nmf_common
from em.util.color_util import cu
from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf
from em.projects.ead import ead_misc1 as eadm
from em.util import vat_da_faak_vpn

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/ead1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

PRETRAINED_MODEL = 'bert-base-uncased'


MODEL = "best_base_ead_infix_ds5s01_35k_dev001"
PER_EXAMPLES_FISHERS = f"{MODEL}.ds5s01.no_embeddings.sparse_dynamic_raw.16k.16k.h5"
DECOMP_FILENAME = f"nmf_decomp.per_sub_block.16k.16k.256.{PER_EXAMPLES_FISHERS}"


FROM_PT = False

N_DECOMPS = 25

###############################################################################

tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL)

###############################################################################

print('Starting to load saved per-example Fishers.')
start = time.time()
pef = per_example.PerExampleFlatFishers.load(
    os.path.expanduser(os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS)),
    n_examples=16 * 1024,
    # This leads to the Fishers not being loaded, which ends up being much faster.
    start_fisher_index=0,
    end_fisher_index=0,
)
print('Load saved per-example Fishers time: ', time.time() - start)

nmfs = am._LazyNmfList(os.path.join(PER_EXAMPLES_FISHERS_DIR, DECOMP_FILENAME), n_nmfs=N_DECOMPS)

container = eadm.EadAnalysisContainer(
    pef=pef,
    nmfs=nmfs,
    tokenizer=tokenizer,
)

container.nmfs.force_load_all()

###############################################################################

incorrects = container.get_incorrect_prediction_indicator()

selection_parameters = ncf.SelectionParameters(
    # coeff_factor=0.5,
    coeff_factor=0.33,
    frac_threshold=0.25,
    p_value_threshold=0.01,
)
tuned_comp_infos = ncf.get_components_appearing_tuned(
    container,
    indicator=incorrects,
    selection_parameters=selection_parameters,
)

example_indices_per_component_per_subset = [
    {
        c.component_index: c.get_all_relevant_example_indices(container)
        for c in correct_component_infos
    }
    for correct_component_infos in ncf.group_by_nmf(container, tuned_comp_infos)
]

###############################################################################

subset_names = am.make_per_sub_block_subset_names(N_DECOMPS - 1)
subset_names.append('Pooler')

###############################################################################
# reload(eadm); container.__class__ = eadm.EadAnalysisContainer

# FILENAME = "ead_bert_base_all_comps_incorrect_comps_001"
FILENAME = "ead_bert_base_all_comps_incorrect_comps_002"

preface = container.selection_parameters_to_latex_string(selection_parameters)

contents = container.make_latex_string_for_some_components_and_examples(
    nmf_names=subset_names,
    example_indices_per_component_per_subset=example_indices_per_component_per_subset,
)

with open(f'/fruitbasket/users/m/tmp/{FILENAME}.tex', 'w') as f:
    f.write(container.wrap_latex_contents(contents, preface))

R"""


# FILENAME=ead_bert_base_all_comps_incorrect_comps_001
FILENAME=ead_bert_base_all_comps_incorrect_comps_002

rsync -ra -e ssh \
    "m@banana.cs.unc.edu:/fruitbasket/users/m/tmp/$FILENAME.tex" \
    "$HOME/Downloads/$FILENAME.tex"

xelatex -interaction=batchmode -output-directory=/tmp ~/Downloads/$FILENAME.tex
mv /tmp/$FILENAME.pdf ~/Downloads


"""
