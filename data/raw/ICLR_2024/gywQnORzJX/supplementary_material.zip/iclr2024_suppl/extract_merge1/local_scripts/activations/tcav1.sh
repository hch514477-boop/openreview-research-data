


# cd ~/Desktop/projects/extract_merge1
# export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


# python3 ./scripts1/data_gen/compute_bert_cls_activations.py \
#     --output_path=/tmp/test_bert_cls_activations.h5 \
#     --model="connectivity/feather_berts_0" \
#     --from_pt=true \
#     --tokenizer="bert-base-uncased" \
#     --sequence_length=128 \
#     --task=glue/rte \
#     --split=train \
#     --batch_size=8 \
#     --n_examples=256


# python3 ./scripts1/data_gen/compute_resnet_activations.py \
#     --output_path=/tmp/test_resnet_activations.h5 \
#     --model="resnet:resnet50_imagenet" \
#     --task=imagenet/resnet \
#     --split=train \
#     --batch_size=8 \
#     --n_examples=256

###################################################################################
###################################################################################

VIRTUALENV_NAME=extract_merge1

CODE_DIR=/fruitbasket/users/m/project_code/extract_merge1
DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

cd $CODE_DIR
workon $VIRTUALENV_NAME
export PYTHONPATH="$PYTHONPATH:$CODE_DIR",
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

###################################################################################
###################################################################################

EXPS_DIR="${DATA_DIR}/m_npeff1"
DATASETS_DIR="${EXPS_DIR}/datasets"
MODELS_DIR="${EXPS_DIR}/models"
FISHER_DIR="${EXPS_DIR}/fishers"
PER_EXAMPLE_FISHERS_DIR="${EXPS_DIR}/per_example_fishers"

###################################################################################
###################################################################################

compute_bert_cls_activations() {
    local device=$1
    local n_ex=$2
    local split=$3

    local output="feather_berts_0.snli.${split}.${n_ex}ex.bert_cls_activations.h5"

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/data_gen/compute_bert_cls_activations.py \
        --output_path="${PER_EXAMPLE_FISHERS_DIR}/${output}" \
        --model="connectivity/feather_berts_0" \
        --from_pt=true \
        --tokenizer="bert-base-uncased" \
        --sequence_length=128 \
        --task=snli/default \
        --split=$split \
        --batch_size=8 \
        --n_examples=$n_ex
}


compute_bert_cls_activations 0 50000 train
# compute_bert_cls_activations 0 50000 train_skip_50k


###################################################################################


run_bert_ica() {
    local device=$1
    local activations_name=$2
    local n_components=$3

    local output="ica.${n_components}comps.${activations_name}"

    CUDA_VISIBLE_DEVICES=$device python ./em/projects/baselines/run_bert_ica.py \
        --output_path="${PER_EXAMPLE_FISHERS_DIR}/${output}" \
        --activations_path="${PER_EXAMPLE_FISHERS_DIR}/${activations_name}" \
        --n_components=${n_components}
}

run_bert_ica 0 "feather_berts_0.snli.train.50000ex.bert_cls_activations.h5" 128

###################################################################################


run_bert_kmeans() {
    local device=$1
    local activations_name=$2
    local n_components=$3

    local output="kmeans.${n_components}comps.${activations_name}"

    CUDA_VISIBLE_DEVICES=$device python ./em/projects/baselines/run_bert_kmeans.py \
        --output_path="${PER_EXAMPLE_FISHERS_DIR}/${output}" \
        --activations_path="${PER_EXAMPLE_FISHERS_DIR}/${activations_name}" \
        --n_components=${n_components}
}

run_bert_kmeans 3 "feather_berts_0.snli.train.50000ex.bert_cls_activations.h5" 128



###################################################################################

compute_resnet_activations() {
    local device=$1
    local n_ex=$2
    local split=$3

    local output="resnet50.imagenet.${split}.${n_ex}ex.activations.h5"

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/data_gen/compute_resnet_activations.py \
    --output_path="${PER_EXAMPLE_FISHERS_DIR}/${output}" \
    --model="resnet:resnet50_imagenet" \
    --task=imagenet/resnet \
    --split=$split \
    --batch_size=128 \
    --n_examples=$n_ex
}

compute_resnet_activations 0 20000 train
compute_resnet_activations 1 30000 validation


###################################################################################


run_resnet_ica() {
    local device=$1
    local activations_name=$2
    local n_components=$3

    local output="ica.${n_components}comps.${activations_name}"

    CUDA_VISIBLE_DEVICES=$device python ./em/projects/baselines/run_resnet_ica.py \
        --output_path="${PER_EXAMPLE_FISHERS_DIR}/${output}" \
        --activations_path="${PER_EXAMPLE_FISHERS_DIR}/${activations_name}" \
        --n_components=${n_components}
}

run_resnet_ica 0 "resnet50.imagenet.train.20000ex.activations.h5" 128

###################################################################################

run_resnet_kmeans() {
    local device=$1
    local activations_name=$2
    local n_components=$3

    local output="kmeans.${n_components}comps.${activations_name}"

    CUDA_VISIBLE_DEVICES=$device python ./em/projects/baselines/run_resnet_kmeans.py \
        --output_path="${PER_EXAMPLE_FISHERS_DIR}/${output}" \
        --activations_path="${PER_EXAMPLE_FISHERS_DIR}/${activations_name}" \
        --n_components=${n_components}
}

run_resnet_kmeans 3 "resnet50.imagenet.train.20000ex.activations.h5" 128



###################################################################################
