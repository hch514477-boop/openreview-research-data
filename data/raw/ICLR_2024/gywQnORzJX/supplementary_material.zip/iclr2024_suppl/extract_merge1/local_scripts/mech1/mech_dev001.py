R"""



cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/mech1/mech_dev001.py

"""
from importlib import reload
import os
import re
import time

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.models import transformer_model_vars as tmv
from em.tools.clustering import vat
from em.tools.nmf import nmf_common
from em.util import flat_pack
from em.util import hf_util

from em.analysis import bert_nmf_analysis as bna
from em.analysis import bert_nmf_analysis2 as bna2
from em.experimental import selective_ablation1

from em.analysis import mechanistic1 as mech

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/math_datasets_dev1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models1')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers0')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers0')

###############################################################################

TASK = 'math_dataset/original_true_false'
SEQUENCE_LENGTH = 128

MODEL = "og_tf__bert_small__100k_steps"
FROM_PT = False

PRETRAINED_MODEL = "prajjwal1/bert-small"

FISHER = "og_tf__bert_small__100k_steps.dense.32k.h5"
PER_EXAMPLES_FISHERS = "og_tf__bert_small__100k_steps.no_embeddings_no_pooler.sparse_dynamic_raw.32k.32k.h5"

DECOMP = 'nmf_decomp.8k.4k.256.reduced_1.og_tf__bert_small__100k_steps.no_embeddings_no_pooler.sparse_dynamic_raw.32k.32k.h5'
N_EXAMPLES = 8 * 1024
START_FISHER_INDEX, END_FISHER_INDEX = (0, 4096)


###############################################################################
# TODO: In proper code, I can probably multithread/multiprocess this to do all these
# loads below in parallel.
#############################

tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL)

print('Starting to load fisher.')
start = time.time()
dense_fisher = diagonal.DiagonalFisher.load(os.path.join(FISHERS_DIR, FISHER))
print('Load saved fishertime: ', time.time() - start)


print('Starting to load saved NMF decomposition.')
start = time.time()
decomp = nmf_common.NmfDecomposition.load(os.path.join(PER_EXAMPLES_FISHERS_DIR, DECOMP))
decomp.normalize_components_to_unit_norm()
decomp.H = decomp.get_full_H()
print('Load saved NMF decomposition time: ', time.time() - start)


print('Starting to load saved per-example Fishers.')
start = time.time()
pe_fishers_data = per_example.PerExampleFlatFishers.load(
    os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    n_examples=N_EXAMPLES,
    start_fisher_index=START_FISHER_INDEX,
    end_fisher_index=END_FISHER_INDEX,
)
print('Load saved per-example Fishers time: ', time.time() - start)

###############################################################################

W = decomp.W
H = decomp.H

#######################################

# We did not compute per-example Fishers for the embeddings or the pooler, so ignore them.
variable_filter = tmv.VariableFilter(
    merge_embeddings=False,
    merge_pooler=False,
)

finetuned_model = TFAutoModelForSequenceClassification.from_pretrained(
    os.path.join(MODELS_DIR, MODEL), from_pt=FROM_PT
)

finetuned_vars = hf_util.get_mergeable_variables(finetuned_model)
batch_fishers = dense_fisher.fishers

finetuned_vars, batch_fishers = variable_filter.filter_parallel_lists(finetuned_vars, batch_fishers)

###############################################################################
"""
We are focusing on examples of the rough form: is [integer literal] prime/composite?
"""

reload(mech)
mctx = mech.MechanisticContext(
    decomp=decomp,
    pe_fishers_data=pe_fishers_data,
    tokenizer=tokenizer,
    finetuned_variables=finetuned_vars,
)

prime_composite_comp_inds = mctx.get_components_matching_regex(
    mech.ExampleRegexes.LITERAL_PRIMALITY_REGEX,
    # check_top_k=8,
    check_top_k=16,
    min_match_fraction=0.7,
)
print(len(prime_composite_comp_inds))

pure_digits_token_ids = mctx.get_pure_digits_token_ids()

for ind in prime_composite_comp_inds:
    print(f'Component {ind}')
    top_inds = mctx.get_component_top_example_indices(ind, n_examples=16)
    top_input_ids = pe_fishers_data.input_ids[top_inds]
    for example_ids in top_input_ids:
        digit_token_ids = [t for t in example_ids if t in pure_digits_token_ids]
        print(digit_token_ids)
    print('')

# for ind in prime_composite_comp_inds:
#     print(f'Component {ind}')
#     mctx.print_top_examples(n_examples=4, component=ind)
#     print('')

###############################################################################

cos_sim_matrix = H[prime_composite_comp_inds] @ H[prime_composite_comp_inds].T
cos_dissim_matrix = 1 - cos_sim_matrix

vat_dissim_matrix, permutation = vat.vat_reorder_dissimilarity_matrix(cos_dissim_matrix)
vat_sim_matrix = 1 - vat_dissim_matrix

M = cos_sim_matrix[permutation]
M = M[:, permutation]

bna.plot_sim_matrix(M, show=True)

###############################################################################

reordered_prime_composite_comp_inds = np.array(prime_composite_comp_inds)[permutation]

for i, ind in enumerate(reordered_prime_composite_comp_inds):
    print(f'Component {ind}, (reordered to {i})')
    top_inds = mctx.get_component_top_example_indices(ind, n_examples=4)
    top_input_ids = pe_fishers_data.input_ids[top_inds]
    for example_ids in top_input_ids:
        digit_token_ids = [t for t in example_ids if t in pure_digits_token_ids]
        print(digit_token_ids)
    print('')


# for i, ind in enumerate(reordered_prime_composite_comp_inds):
#     print(f'Component {ind}, (reordered to {i})')
#     mctx.print_top_examples(n_examples=4, component=ind)
#     print('')


###############################################################################

reload(bna2)
localizer = bna2.ComponentLocalizationInfo(variables=finetuned_vars)

frac_in_subsets = []

# for i in range(H.shape[0]):
#     frac_in_subsets.append(localizer.fraction_per_variable(H[i]))

for i in range(H[prime_composite_comp_inds].shape[0]):
    # frac_in_subsets.append(localizer.fraction_per_layer(H[prime_composite_comp_inds][i]))
    frac_in_subsets.append(localizer.fraction_per_variable(H[prime_composite_comp_inds][i]))

frac_in_subsets = np.array(frac_in_subsets)

reordered_frac_in_subsets = frac_in_subsets[permutation]

#######################################

# subset_labels = [
#     'Layer 4',
#     'Layer 3',
#     'Layer 2',
#     'Layer 1',
# ]
reload(tmv)
subset_labels = [tmv.to_nice_name(v) for v in reversed(finetuned_vars)]

reload(bna)
bna.plot_component_locations(
    frac_in_subsets=reordered_frac_in_subsets,
    subset_labels=subset_labels,
    # vertical_stretch=1,
    vertical_stretch=3,
    yticks_fontsize=9,
)


comp_vars = localizer._packer.decode_tf(H[prime_composite_comp_inds])


# nice_var_name = 'layer3/output/dense/kernel'
nice_var_name = 'layer1/intermediate/dense/kernel'

var_index = subset_labels[::-1].index(nice_var_name)

comp_var = comp_vars[var_index].numpy()
reordered_comp_var = comp_var[permutation]

q = reordered_comp_var / (np.sqrt((reordered_comp_var**2).sum(axis=-1).sum(axis=-1)) + 1e-12)[:, None, None]
S = np.einsum('ijk,ljk->il', q, q)
bna.plot_sim_matrix(S, show=True)

variable = finetuned_vars[var_index]

q = reordered_comp_var * variable.numpy()
q = q / (np.sqrt((q**2).sum(axis=-1).sum(axis=-1)) + 1e-12)[:, None, None]
T = np.einsum('ijk,ljk->il', q, q)
plt.imshow(T, cmap=sns.color_palette("rocket", as_cmap=True));plt.show()


# plt.imshow(tf.reduce_sum(comp_vars[var_index], axis=-1));plt.show()
# plt.imshow(tf.reduce_sum(comp_vars[var_index], axis=-2));plt.show()

# plt.imshow(comp_vars[var_index][0].numpy().T, cmap=sns.color_palette("rocket", as_cmap=True));plt.show()


###############################################################################

all_prime_composite_example_inds = []

for i in range(mctx.n_examples):
    example = mctx.get_example_str(i)
    if re.search(mech.ExampleRegexes.LITERAL_PRIMALITY_REGEX, example):
        all_prime_composite_example_inds.append(i)

all_prime_composite_example_inds = np.array(all_prime_composite_example_inds, dtype=np.int32)

# plt.imshow(W[all_prime_composite_example_inds].T, cmap=sns.color_palette("rocket", as_cmap=True));plt.show()


frac_masses_on_comps = mctx.get_fraction_of_example_masses_on_components(
    all_prime_composite_example_inds,
    prime_composite_comp_inds,
)


# plt.plot(np.sort(frac_masses_on_comps));plt.show()


# print(mctx.get_example_str(all_prime_composite_example_inds[np.argmin(frac_masses_on_comps)]))

inds = np.argpartition(frac_masses_on_comps, 32)[:32]
inds = all_prime_composite_example_inds[inds]
for i in inds:
    print(mctx.get_example_str(i))

###############################################################################

bna.plot_coeffs_for_top_examples(
    decomp,
    np.arange(W.shape[-1]),
    n_examples=16,
    # component=prime_composite_comp_inds[0],
    component=reordered_prime_composite_comp_inds[0],
    show=True,
)

mctx.print_top_examples(n_examples=16, component=reordered_prime_composite_comp_inds[0])

