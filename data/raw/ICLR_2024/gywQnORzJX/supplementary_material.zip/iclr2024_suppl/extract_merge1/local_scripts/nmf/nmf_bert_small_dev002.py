R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=3 python -i local_scripts/nmf/nmf_bert_small_dev002.py

"""

import collections
import dataclasses
import os
from importlib import reload
import itertools
import time
from typing import Any, List, Sequence

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
import torch
from torchnmf.nmf import NMF as TorchNMF
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em.datasets import glue
from em.evaluation import evaluation
from em.fishers import diagonal
from em.fishers import per_example
from em.fishers import sparse_diagonal
from em.util import hf_util
from em.util import vat_da_faak_vpn

from local_scripts.nmf import nmf_dev_bert as ndb
from local_scripts.soc import soc_dev_common as sdc

###############################################################################

gpus = tf.config.experimental.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)

# ndb.separate_tf_torch_gpus()

###############################################################################
TASK = 'mnli'
MODEL = "prajjwal1/bert-small-mnli"
PRETRAINED_MODEL = "prajjwal1/bert-small"

PER_EXAMPLES_FISHERS = "dev_bert_small_mnli.no_embeddings.sparse_static.md.4k.h5"

###############################################################################

# N_EXAMPLES = 1024
# N_EXAMPLES = 2048
N_EXAMPLES = 4096

# START_FISHER_INDEX, END_FISHER_INDEX = (0, 16 * 1024)
# START_FISHER_INDEX, END_FISHER_INDEX = (0, 32 * 1024)
START_FISHER_INDEX, END_FISHER_INDEX = (-32 * 1024, -1)

# N_NMF_COMPONENTS = 32
N_NMF_COMPONENTS = 64
# N_NMF_COMPONENTS = 256

#######################################

tokenizer = AutoTokenizer.from_pretrained(MODEL)

print('Starting to load saved per-example Fishers.')
start = time.time()
pe_fishers_data = per_example.PerExampleFlatFishers.load(
    os.path.join(ndb.PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    n_examples=N_EXAMPLES,
    start_fisher_index=START_FISHER_INDEX,
    end_fisher_index=END_FISHER_INDEX,
)
print('Load saved per-example Fishers time: ', time.time() - start)

fishers = pe_fishers_data.fishers
examples = {'input_ids': pe_fishers_data.input_ids}
labels = pe_fishers_data.labels
predicted_logits = pe_fishers_data.predicted_logits

#######################################

torch_fishers = torch.from_numpy(fishers.T).cuda()

start = time.time()
nmf_model = TorchNMF(torch_fishers.shape, rank=N_NMF_COMPONENTS).cuda()
nmf_model.fit(torch_fishers)
print('NMF time: ', time.time() - start)

W = nmf_model.W.detach().cpu().numpy()
Ht = nmf_model.H.detach().cpu().numpy()

# plt.imshow(W.T)
# plt.show()

ndb.print_top_examples(W, tokenizer, examples, labels, n_examples=8, component=0)
# ndb.print_top_examples(W, tokenizer, examples, predictions, n_examples=8, component=0)

# plt.plot(Ht[:, 5])
# plt.plot(Ht[:, 26])
# plt.show()

# plt.plot(W[0])
# plt.show()
