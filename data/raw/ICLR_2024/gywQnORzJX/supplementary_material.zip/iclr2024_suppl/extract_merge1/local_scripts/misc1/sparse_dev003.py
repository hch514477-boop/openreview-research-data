R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i local_scripts/misc1/sparse_dev003.py

"""
import os

import tensorflow as tf

from em.datasets import glue
from em.evaluation import evaluation
from em.fishers import diagonal
from em.fishers import sparse_diagonal
from em.merging import merging
from em.util import hf_util
from em.util import vat_da_faak_vpn


FISHER_DIR = os.path.expanduser('~/Desktop/projects_data/extract_merge1/fishers0')

RTE_SPARSE_FISHER = 'rte_fisher.sparse.03.md.h5'
MNLI_SPARSE_FISHER = 'mnli_fisher.sparse.03.md.h5'

EVAL_TASK = 'rte'

sparse_rte_fisher = sparse_diagonal.SparseDiagonalFisher.load(os.path.join(FISHER_DIR, RTE_SPARSE_FISHER))
sparse_mnli_fisher = sparse_diagonal.SparseDiagonalFisher.load(os.path.join(FISHER_DIR, MNLI_SPARSE_FISHER))


# for f1, f2 in zip(sparse_rte_fisher.fishers, sparse_mnli_fisher.fishers):
#     m1 = tf.sparse.to_dense(f1) > 0
#     m2 = tf.sparse.to_dense(f2) > 0
#     mm = m1 & m2
#     #
#     m1 = tf.reduce_sum(tf.cast(m1, tf.int32)).numpy()
#     m2 = tf.reduce_sum(tf.cast(m2, tf.int32)).numpy()
#     mm = tf.reduce_sum(tf.cast(mm, tf.int32)).numpy()
#     print(f'{mm} / {(m1 + m2) // 2}')
