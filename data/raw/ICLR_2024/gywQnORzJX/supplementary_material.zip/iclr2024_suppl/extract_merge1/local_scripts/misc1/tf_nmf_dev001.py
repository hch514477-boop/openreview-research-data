R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i local_scripts/misc1/tf_nmf_dev001.py


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/misc1/tf_nmf_dev001.py
CUDA_VISIBLE_DEVICES=1 python -i local_scripts/misc1/tf_nmf_dev001.py

CUDA_VISIBLE_DEVICES= python -i local_scripts/misc1/tf_nmf_dev001.py

"""
import time

import numpy as np
from sklearn.decomposition import NMF
import tensorflow as tf

# from em.tools import tf_nmf
from em.tools import bionmf_gpu as bionmf

# TfNMF = tf_nmf.TfNMF


# n_samples = 64
# n_features = 256

n_samples = 4 * 2048
n_features = 16 * 1024

# n_samples = 6400
# n_features = 25600

X = tf.abs(tf.random.normal([n_samples, n_features]))


n_components = 256

# tf_model = TfNMF(n_components)
# tf_model._fit_transform(X)

start = time.time()
gpu_model = bionmf.NmfGpu()
W, Ht = gpu_model.run_nmf(X.numpy(), n_components=n_components)
print(time.time() - start)

# start = time.time()
# sk_model = NMF(n_components)
# sk_model.fit_transform(X.numpy())
# print(time.time() - start)
