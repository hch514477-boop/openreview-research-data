###################################################################################
###################################################################################


VIRTUALENV_NAME=extract_merge1

CODE_DIR=/fruitbasket/users/m/project_code/extract_merge1
DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

cd $CODE_DIR
workon $VIRTUALENV_NAME
export PYTHONPATH="$PYTHONPATH:$CODE_DIR",
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

###################################################################################
###################################################################################

EXPS_DIR="${DATA_DIR}/qqp_lrm_npeff2"
DATASETS_DIR="${EXPS_DIR}/datasets"
MODELS_DIR="${EXPS_DIR}/models"
FISHER_DIR="${EXPS_DIR}/fishers"
PER_EXAMPLE_FISHERS_DIR="${EXPS_DIR}/per_example_fishers"
PERTURBATIONS_DIR="${EXPS_DIR}/perturbations"
TCAV_DIR="${EXPS_DIR}/tcav"

###################################################################################
###################################################################################


# 363,846 => 313,846 => roughly 10000 steps per epoch
train_qqp_50k_holdout() {
    local device=$1

    local output_name="bert_base_qqp_50k_holdout_4_epochs_01"

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/training/finetune.py \
        --output_path="${MODELS_DIR}/${output_name}" \
        --task='glue/qqp' \
        --split='train[:-50000]' \
        --batch_size=32 \
        --model='bert-base-uncased' \
        --learning_rate="2e-5" \
        --n_steps=40000
}

train_qqp_50k_holdout 0

###################################################################################

compute_pefs() {
    local device=$1
    local n_vals_pe=$2
    local n_ex=$3
    local split=$4
    local split_name=$5

    local model="bert_base_qqp_50k_holdout_4_epochs_01_epoch9"
    local pef="${model}.${split_name}.${n_ex}ex.${n_vals_pe}.h5"

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/data_gen/compute_lrm_pefs.py  \
        --output_path="${PER_EXAMPLE_FISHERS_DIR}/${pef}" \
        --model="${MODELS_DIR}/${model}"   \
        --from_pt=false \
        --tokenizer="bert-base-uncased" \
        --task=glue/qqp \
        --split=$split \
        --n_examples=$n_ex \
        --batch_size=4 \
        --n_fisher_values_per_example=$n_vals_pe \
        --sequence_length=128
}

compute_pefs 0 65536 50000 train[-50000:] heldout_from_train
compute_pefs 1 65536 50000 train[:-50000] train
compute_pefs 3 65536 40430 validation validation


# compute_pefs 3 65536 100 validation DUMMY_TEST_DEBUG_001


###################################################################################

cd /fruitbasket/users/m/project_code/cuda_m_npeff
export PATH=/home/m/.local/bin:$PATH


DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
EXPS_DIR="${DATA_DIR}/qqp_lrm_npeff2"
DATASETS_DIR="${EXPS_DIR}/datasets"
MODELS_DIR="${EXPS_DIR}/models"
FISHER_DIR="${EXPS_DIR}/fishers"
PER_EXAMPLE_FISHERS_DIR="${EXPS_DIR}/per_example_fishers"

PLAYPLAN_PEFS_DIR="/playpen/users/m/project_data/qqp_lrm_npeff2/per_example_fishers/"

cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.h5" $PLAYPLAN_PEFS_DIR

CUDA_VISIBLE_DEVICES=0,1,2,3 ./build/mains/run_m_npeff \
    --pef_filepath="${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.h5" \
    --min_nonzero_per_col=8 \
    --n_components=256 \
    --learning_rate_G_G_only=3e-5 \
    --learning_rate_G=3e-4 \
    --output_filepath="${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.h5" \
    --n_preprocess_cpu_threads=32 \
    --n_iters_G_only=100 \
    --n_iters_joint=1500 \
    --pefs_col_offsets_non_cumulative=false

###################################################################################

filter_pefs_to_incorrects() {
    local pef_filepath=$1
    local output_filepath=$2

    CUDA_VISIBLE_DEVICES= python ./em/projects/m_npeff/mains/filter_lrm_pefs_to_wrong_predictions.py \
        --pef_path="${pef_filepath}" \
        --output_path="${output_filepath}"
}

filter_pefs_to_incorrects \
    "/fruitbasket/users/m/project_data/extract_merge1/qqp_lrm_npeff2/per_example_fishers/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.h5" \
    "/fruitbasket/users/m/project_data/extract_merge1/qqp_lrm_npeff2/per_example_fishers/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.h5"


###################################################################################



cd /fruitbasket/users/m/project_code/cuda_m_npeff
export PATH=/home/m/.local/bin:$PATH


DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
EXPS_DIR="${DATA_DIR}/qqp_lrm_npeff2"
DATASETS_DIR="${EXPS_DIR}/datasets"
MODELS_DIR="${EXPS_DIR}/models"
FISHER_DIR="${EXPS_DIR}/fishers"
PER_EXAMPLE_FISHERS_DIR="${EXPS_DIR}/per_example_fishers"

PLAYPLAN_PEFS_DIR="/playpen/users/m/project_data/qqp_lrm_npeff2/per_example_fishers/"


cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.h5" $PLAYPLAN_PEFS_DIR
cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.h5" $PLAYPLAN_PEFS_DIR



# # NOTE: This made some nans/infs
# CUDA_VISIBLE_DEVICES=0 ./build/mains/fit_m_npeff_coeffs \
#     --pef_filepath="/${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.h5" \
#     --decomposition_filepath=$PLAYPLAN_PEFS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.h5 \
#     --output_filepath=$PER_EXAMPLE_FISHERS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.coeffs_fit001.h5 \
#     --n_preprocess_cpu_threads=32 \
#     --n_iters=1500 \
#     --n_columns_per_chunk=2500000 \
#     --pefs_col_offsets_non_cumulative=false


# Re-run as above made some nans/infs.
CUDA_VISIBLE_DEVICES=0 ./build/mains/fit_m_npeff_coeffs \
    --pef_filepath="/${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.h5" \
    --decomposition_filepath=$PLAYPLAN_PEFS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.h5 \
    --output_filepath=$PER_EXAMPLE_FISHERS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.coeffs_fit001.h5 \
    --n_preprocess_cpu_threads=32 \
    --n_iters=500 \
    --n_columns_per_chunk=2500000 \
    --mu_eps=1e-6 \
    --pefs_col_offsets_non_cumulative=false




cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.coeffs_fit001.h5" $PLAYPLAN_PEFS_DIR


CUDA_VISIBLE_DEVICES=0,1 ./build/mains/run_m_npeff_expansion \
    --pef_filepath="/${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.h5" \
    --decomposition_filepath=$PLAYPLAN_PEFS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.coeffs_fit001.h5 \
    --n_additional_components=64 \
    --learning_rate_G_G_only=1e-3 \
    --learning_rate_G=3e-4 \
    --output_filepath=$PER_EXAMPLE_FISHERS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.h5 \
    --n_preprocess_cpu_threads=32 \
    --n_iters_G_only=100 \
    --n_iters_joint_expansion_only=500 \
    --n_iters_joint=1500 \
    --use_W_from_decomposition=true



cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.h5" $PLAYPLAN_PEFS_DIR


CUDA_VISIBLE_DEVICES=0 ./build/mains/fit_m_npeff_coeffs \
    --pef_filepath="/${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.h5" \
    --decomposition_filepath=$PLAYPLAN_PEFS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.h5 \
    --output_filepath=$PER_EXAMPLE_FISHERS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit001.h5 \
    --n_preprocess_cpu_threads=64 \
    --n_iters=500 \
    --n_columns_per_chunk=2500000 \
    --n_examples_per_chunk=25000 \
    --mu_eps=1e-6 \
    --pefs_col_offsets_non_cumulative=false



# cmake --build build; CUDA_VISIBLE_DEVICES=0,1 ./build/mains/run_m_npeff_expansion \
#     --pef_filepath="/${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.h5" \
#     --decomposition_filepath=$PLAYPLAN_PEFS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.coeffs_fit001.h5 \
#     --n_additional_components=64 \
#     --learning_rate_G_G_only=1e-5 \
#     --learning_rate_G=3e-4 \
#     --output_filepath=$PER_EXAMPLE_FISHERS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.h5 \
#     --n_preprocess_cpu_threads=64 \
#     --n_iters_G_only=100 \
#     --n_iters_joint_expansion_only=500 \
#     --n_iters_joint=1500 \
#     --use_W_from_decomposition=true



cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.h5" $PLAYPLAN_PEFS_DIR
cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.h5" $PLAYPLAN_PEFS_DIR

CUDA_VISIBLE_DEVICES=0 ./build/mains/fit_m_npeff_coeffs \
    --pef_filepath="/${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.h5" \
    --decomposition_filepath=$PLAYPLAN_PEFS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.h5 \
    --output_filepath=$PER_EXAMPLE_FISHERS_DIR/test_qqp_comps_refit001.h5 \
    --n_preprocess_cpu_threads=64 \
    --n_iters=1000 \
    --n_columns_per_chunk=2500000 \
    --n_examples_per_chunk=25000 \
    --pefs_col_offsets_non_cumulative=false




cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.validation.40430ex.65536.h5" $PLAYPLAN_PEFS_DIR

CUDA_VISIBLE_DEVICES=0 ./build/mains/fit_m_npeff_coeffs \
    --pef_filepath="/${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.validation.40430ex.65536.h5" \
    --decomposition_filepath=$PLAYPLAN_PEFS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.h5 \
    --output_filepath=$PER_EXAMPLE_FISHERS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit_to_validation001.h5 \
    --n_preprocess_cpu_threads=64 \
    --n_iters=500 \
    --n_columns_per_chunk=2500000 \
    --n_examples_per_chunk=25000 \
    --mu_eps=1e-6 \
    --pefs_col_offsets_non_cumulative=false

cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.50000ex.65536.wrongs_only.expansion_001.coeffs_fit_to_validation001.h5" $PLAYPLAN_PEFS_DIR



##########################################################################



cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.h5" $PLAYPLAN_PEFS_DIR
cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.validation.40430ex.65536.h5" $PLAYPLAN_PEFS_DIR

CUDA_VISIBLE_DEVICES=0 ./build/mains/fit_m_npeff_coeffs \
    --pef_filepath="/${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.validation.40430ex.65536.h5" \
    --decomposition_filepath=$PLAYPLAN_PEFS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.h5 \
    --output_filepath=$PER_EXAMPLE_FISHERS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.h5 \
    --n_preprocess_cpu_threads=64 \
    --n_iters=500 \
    --n_columns_per_chunk=2500000 \
    --n_examples_per_chunk=25000 \
    --mu_eps=1e-6 \
    --pefs_col_offsets_non_cumulative=false


###################################################################################




run_perturbations_kl() {
    local device=$1
    local split=$2
    local perturbation_magnitude=$3
    local max_abs_cos_sim=$4
    local nmf_filename=$5
    local pef_filename=$6
    local output_name=$7

    local model="bert_base_qqp_50k_holdout_4_epochs_01_epoch9"

    local n_top_examples=128
    local n_total_examples=10000

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/comp_measure/run_m_npeff_perturbations_kl.py \
        --nmf_filepath="${PER_EXAMPLE_FISHERS_DIR}/${nmf_filename}" \
        --pef_filepath="${PER_EXAMPLE_FISHERS_DIR}/${pef_filename}" \
        --model="${MODELS_DIR}/${model}"   \
        --from_pt=false \
        --tokenizer=bert-base-uncased \
        --sequence_length=128 \
        --task=glue/qqp \
        --split=$split \
        --output_filepath="${PERTURBATIONS_DIR}/${output_name}" \
        --n_top_examples=$n_top_examples \
        --n_total_examples=$n_total_examples \
        --perturbation_magnitude=$perturbation_magnitude \
        --max_abs_cos_sim=$max_abs_cos_sim
}

# run_perturbations_kl 3 validation 1e-1 0.35 \
#     bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.h5 \
#     bert_base_qqp_50k_holdout_4_epochs_01_epoch9.validation.40430ex.65536.h5 \
#     kl_perturbations.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.json


run_perturbations_kl 3 validation 1e-1 "-1" \
    bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.h5 \
    bert_base_qqp_50k_holdout_4_epochs_01_epoch9.validation.40430ex.65536.h5 \
    kl_perturbations.no_semiorth.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.json




rsync -ra -e ssh \
    "m@mango.cs.unc.edu:/fruitbasket/users/m/project_data/extract_merge1/qqp_lrm_npeff2/perturbations/*" \
    "$HOME/Desktop/projects_data/extract_merge1/neurips2023/perturbation_kl_jsons/qqp_lrm_npeff2/"



# Expansion fitting examples inconsistent labelling components:
# Component 4
# Component 8
# Component 9 (maybe)
# Component 11
# Component 20 (maybe)
# Component 21 [good one]
# Component 23 [I think good one]
# Component 24
# Component 26 [probably a good one]
# Component 31 [good one]
# Component 33 [probably a good one]
# Component 36 [good one]
# Component 45 [probably a good one]
# Component 50 [maybe]
# Component 52 [possible a good one]
# Component 61

###################################################################################
###################################################################################
###################################################################################


compute_activations() {
    local device=$1
    local split=$2
    local n_examples=$3
    local output_name=$4

    local CLS_ACTS_DIR="/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers"

    local model="bert_base_qqp_50k_holdout_4_epochs_01_epoch9"

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/data_gen/compute_bert_cls_activations.py \
        --output_path="${CLS_ACTS_DIR}/${output_name}" \
        --model="${MODELS_DIR}/${model}"   \
        --from_pt=false \
        --tokenizer=bert-base-uncased \
        --sequence_length=128 \
        --task=glue/qqp \
        --split=$split \
        --n_examples=$n_examples \
        --batch_size=64
}

compute_activations 0 validation 40430 "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.qqp.validation.40430ex.bert_cls_activations.h5"




run_tcav() {
    local device=$1
    local decomposition_filepath=$2
    local activations_filename=$3
    local output_filename=$4
    local decomposition_type=$5

    local n_runs=500
    local n_top_examples=32
    local n_negative_examples=128
    local n_scoring_examples=5000

    local CLS_ACTS_DIR="/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers"
    local model="bert_base_qqp_50k_holdout_4_epochs_01_epoch9"

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/comp_measure/run_bert_tcav_exp.py \
        --decomposition_filepath="${decomposition_filepath}" \
        --decomposition_type=$decomposition_type \
        --activations_filepath="${CLS_ACTS_DIR}/${activations_filename}" \
        --model="${MODELS_DIR}/${model}"   \
        --from_pt=false \
        --output_filepath="${TCAV_DIR}/${output_filename}" \
        --n_runs=$n_runs \
        --n_top_examples=$n_top_examples \
        --n_negative_examples=$n_negative_examples \
        --n_scoring_examples=$n_scoring_examples
}

run_tcav 0 \
    "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.h5" \
    "bert_base_qqp_50k_holdout_4_epochs_01_epoch9.qqp.validation.40430ex.bert_cls_activations.h5" \
    "tcav.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.json" \
    NPEFF



CUDA_VISIBLE_DEVICES= python ./scripts1/comp_measure/compute_pef_norm_ratios.py \
    --pef_path="/${PER_EXAMPLE_FISHERS_DIR}//bert_base_qqp_50k_holdout_4_epochs_01_epoch9.validation.40430ex.65536.h5" \
    --nmf_path=$PER_EXAMPLE_FISHERS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.h5 \
    --top_ks=128,64,32,16

###################################################################################
###################################################################################
###################################################################################

# compute_pefs_paws() {
#     local device=$1
#     local n_vals_pe=$2
#     local n_ex=$3
#     local split=$4

#     local model="bert_base_qqp_50k_holdout_4_epochs_01_epoch9"
#     local pef="${model}.paws_final.${split}.${n_ex}ex.${n_vals_pe}.h5"

#     CUDA_VISIBLE_DEVICES=$device python ./scripts1/data_gen/compute_lrm_pefs.py  \
#         --output_path="${PER_EXAMPLE_FISHERS_DIR}/${pef}" \
#         --model="${MODELS_DIR}/${model}"   \
#         --from_pt=false \
#         --tokenizer="bert-base-uncased" \
#         --task=paws/final \
#         --split=$split \
#         --n_examples=$n_ex \
#         --batch_size=4 \
#         --n_fisher_values_per_example=$n_vals_pe \
#         --sequence_length=128
# }

# compute_pefs_paws 2 65536 49401 train
# compute_pefs_paws 3 65536 8000 validation

# ###################################################################################

# cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.paws_final.train.49401ex.65536.h5" $PLAYPLAN_PEFS_DIR


# CUDA_VISIBLE_DEVICES=0,1,2,3 ./build/mains/run_m_npeff \
#     --pef_filepath="${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.paws_final.train.49401ex.65536.h5" \
#     --min_nonzero_per_col=12 \
#     --n_components=512 \
#     --learning_rate_G_G_only=3e-5 \
#     --learning_rate_G=3e-4 \
#     --output_filepath="${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.paws_final.train.49401ex.65536.mnpeff.512comps.001.h5" \
#     --n_preprocess_cpu_threads=64 \
#     --n_iters_G_only=100 \
#     --n_iters_joint=1500 \
#     --pefs_col_offsets_non_cumulative=false



# cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.paws_final.validation.8000ex.65536.h5" $PLAYPLAN_PEFS_DIR
# cp "${PER_EXAMPLE_FISHERS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.paws_final.train.49401ex.65536.mnpeff.512comps.001.h5" $PLAYPLAN_PEFS_DIR


# CUDA_VISIBLE_DEVICES=3 ./build/mains/fit_m_npeff_coeffs \
#     --pef_filepath="${PLAYPLAN_PEFS_DIR}/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.paws_final.validation.8000ex.65536.h5" \
#     --decomposition_filepath=$PLAYPLAN_PEFS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.paws_final.train.49401ex.65536.mnpeff.512comps.001.h5 \
#     --output_filepath=$PER_EXAMPLE_FISHERS_DIR/bert_base_qqp_50k_holdout_4_epochs_01_epoch9.paws_final.validation.8000ex.65536.coeffs_fit_to_validation001.h5 \
#     --n_preprocess_cpu_threads=64 \
#     --n_iters=500 \
#     --n_columns_per_chunk=2500000 \
#     --mu_eps=1e-6 \
#     --pefs_col_offsets_non_cumulative=false




