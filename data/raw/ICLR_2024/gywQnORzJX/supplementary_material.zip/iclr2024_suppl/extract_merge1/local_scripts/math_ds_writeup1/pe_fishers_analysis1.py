R"""


rsync -ra -e ssh \
    "m@banana.cs.unc.edu:/fruitbasket/users/m/project_data/extract_merge1/math_datasets_dev1/writeup1/images/" \
    "$HOME/Desktop/projects_data/extract_merge1/math_ds_writeup1/images/"




cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/math_ds_writeup1/pe_fishers_analysis1.py

"""
from importlib import reload
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.models import transformer_model_vars as tmv
from em.tools.clustering import vat
from em.tools.nmf import nmf_common
from em.util import flat_pack
from em.util import hf_util

from em.analysis import bert_nmf_analysis as bna
from em.experimental import selective_ablation1

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/math_datasets_dev1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models1')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers0')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers0')

###############################################################################

TASK = 'math_dataset/original_true_false'
SEQUENCE_LENGTH = 128

MODEL = "og_tf__bert_small__100k_steps"
FROM_PT = False

PRETRAINED_MODEL = "prajjwal1/bert-small"

FISHER = "og_tf__bert_small__100k_steps.dense.32k.h5"
PER_EXAMPLES_FISHERS = "og_tf__bert_small__100k_steps.no_embeddings.sparse_dynamic_raw.32k.32k.h5"
DECOMP = 'nmf_decomp.8k.4k.128.og_tf__bert_small__100k_steps.no_embeddings.sparse_dynamic_raw.32k.32k.h5'

# N_EXAMPLES = 8 * 1024
# START_FISHER_INDEX, END_FISHER_INDEX = (0, 4096)

###############################################################################

tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL)

print('Starting to load fisher.')
start = time.time()
dense_fisher = diagonal.DiagonalFisher.load(os.path.join(FISHERS_DIR, FISHER))
print('Load saved fishertime: ', time.time() - start)


print('Starting to load saved per-example Fishers.')
start = time.time()
pe_fishers_data = per_example.PerExampleFlatFishers.load(
    os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    # n_examples=N_EXAMPLES,
    # start_fisher_index=START_FISHER_INDEX,
    # end_fisher_index=END_FISHER_INDEX,
)
print('Load saved per-example Fishers time: ', time.time() - start)

###############################################################################

# We did not compute per-example Fishers for the embeddings, so ignore them.
variable_filter = tmv.VariableFilter(
    merge_embeddings=False,
)

finetuned_model = TFAutoModelForSequenceClassification.from_pretrained(
    os.path.join(MODELS_DIR, MODEL), from_pt=FROM_PT
)

finetuned_vars = hf_util.get_mergeable_variables(finetuned_model)
batch_fishers = dense_fisher.fishers

finetuned_vars, batch_fishers = variable_filter.filter_parallel_lists(finetuned_vars, batch_fishers)

###############################################################################

pe_fishers = pe_fishers_data.fishers


def frac_captured_hist(fisher_size: int):
    spfs = pe_fishers[:, :fisher_size]
    bna.plot_fraction_of_pe_fisher_captured_histogram(spfs)

# frac_captured_hist(1 * 1024)
# frac_captured_hist(512)


# fisher_sizes = [256, 512, 1024, 2 * 1024, 4 * 1024, 8 * 1024, 16 * 1024, 32 * 1024]
fisher_size_sets = [
    [128, 256, 512],
    [1024, 2 * 1024, 4 * 1024],
    [8 * 1024, 16 * 1024, 32 * 1024],
]

p = sns.color_palette('dark')
colors = [
    [p[0], p[3], p[7]],
    # [p[1], p[2], p[9]],
    [p[1], p[6], p[9]],
    # [p[4], p[5], p[8]]
    [p[4], p[2], p[8]]
]

# colors = [
#     p[0:3],
#     p[3:6],
#     p[6:9],
# ]


reload(bna) 
# bna.plot_fraction_of_pe_fisher_captured_histogram_for_fisher_sizes(
#     pe_fishers,
#     sizes=fisher_size_sets[2],
#     alpha=0.5,
# )

FIGS_DIR = os.path.join(EXPS_DIR, 'writeup1', 'images')

for i in range(3):
    bna.plot_fraction_of_pe_fisher_captured_histogram_for_fisher_sizes(
        pe_fishers,
        sizes=fisher_size_sets[i],
        colors=colors[i],
        alpha=0.65,
        show=False,
    )
    # plt.savefig(os.path.join(FIGS_DIR, f'l2_fraction_pe_fishers_{i}.svg'), transparent=True)
    plt.show()

# bna.plot_fraction_of_pe_fisher_captured_histogram_for_fisher_sizes(
#     pe_fishers,
#     sizes=fisher_size_sets[2],
#     alpha=0.5,
# )
