R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i local_scripts/protein_bert/getting_started/pb_dev001.py


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/protein_bert/getting_started/pb_dev001.py

"""
import numpy as np
import tensorflow as tf

# from em.models.protein_bert import pb_checkpoint
# from em.models.protein_bert import pb_models
# from em.models.protein_bert import pb_vocab

# ###############################################################################

# tokenizer = pb_vocab.DEFAULT_TOKENIZER

# sequence_length = 64

# ###############################################################################

# pretrained_path = '~/Desktop/projects_data/extract_merge1/pb/weights/default_protein_bert_body.h5'

# ckpt = pb_checkpoint.CheckpointData.load(pretrained_path)

# config = pb_models.ProteinBertConfig(
#     body=ckpt.body_config,
#     classifier=pb_models.ClassifierConfig(
#         n_classes=2,
#         dropout_rate=0.1,
#     ),
#     sequence_length=sequence_length,
# )

# model = pb_models.ProteinBertForSequenceClassification(config)
# model._og_body.set_weights(ckpt.body_weights)

# model.compile()

# ###############################################################################

# logits = model(3 * tf.ones([3, sequence_length]))
