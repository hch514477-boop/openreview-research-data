R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i local_scripts/ead/metadata_util_dev001.py

"""
from importlib import reload

import sympy as sp
from sympy.parsing.sympy_parser import parse_expr

from em.datasets.antiderivative import expression_metadata as emd


def reload_all():
    reload(emd.function_types); reload(emd)


local_dict = {
    'x': sp.Symbol('x', real=True, nonzero=True),
}
expr_str = '-5 * cos(x) ** -64 / 2 + 64'

expr = parse_expr(expr_str, evaluate=True, local_dict=local_dict)

# adsf = emd.has_repeated_number(expr)
# print(adsf)
# cos_expr = parse_expr('cos(x)', evaluate=True, local_dict=local_dict)

reload_all()
q = emd.function_types.compute_all_fn_types(expr)
print(q)

