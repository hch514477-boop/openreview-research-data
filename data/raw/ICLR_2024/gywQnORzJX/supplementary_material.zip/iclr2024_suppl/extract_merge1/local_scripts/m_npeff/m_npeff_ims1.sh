###################################################################################
###################################################################################


VIRTUALENV_NAME=extract_merge1

CODE_DIR=/fruitbasket/users/m/project_code/extract_merge1
DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

cd $CODE_DIR
workon $VIRTUALENV_NAME
export PYTHONPATH="$PYTHONPATH:$CODE_DIR",
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets

###################################################################################
###################################################################################

EXPS_DIR="${DATA_DIR}/m_npeff_ims1"
DATASETS_DIR="${EXPS_DIR}/datasets"
MODELS_DIR="${EXPS_DIR}/models"
FISHER_DIR="${EXPS_DIR}/fishers"
PER_EXAMPLE_FISHERS_DIR="${EXPS_DIR}/per_example_fishers"

###################################################################################
###################################################################################


compute_pefs() {
    local device=$1
    local n_vals_pe=$2
    local n_ex=$3
    local split=$4
    local top_k_classes=$5

    local model="resnet:resnet50_imagenet"
    local pef="resnet50_imagenet.${split}.${n_ex}ex.${n_vals_pe}.tkc${top_k_classes}.h5"

    CUDA_VISIBLE_DEVICES=$device python ./scripts1/data_gen/compute_lrm_pefs.py  \
        --output_path="${PER_EXAMPLE_FISHERS_DIR}/${pef}" \
        --model="${model}"   \
        --from_pt=true \
        --task=imagenet/resnet \
        --split=$split \
        --n_examples=$n_ex \
        --batch_size=1 \
        --n_fisher_values_per_example=$n_vals_pe \
        --sequence_length=224 \
        --top_k_classes=$top_k_classes
}

# compute_pefs 2 65536 20000 train 5
compute_pefs 3 65536 30000 validation 5


# resnet50_imagenet.train.20000ex.65536.tkc5.h5
# resnet50_imagenet.validation.30000ex.65536.tkc5.h5

# /fruitbasket/users/m/project_data/extract_merge1/m_npeff_ims1/per_example_fishers

###################################################################################

cd /fruitbasket/users/m/project_code/cuda_m_npeff
export PATH=/home/m/.local/bin:$PATH


DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1
EXPS_DIR="${DATA_DIR}/m_npeff_ims1"
DATASETS_DIR="${EXPS_DIR}/datasets"
MODELS_DIR="${EXPS_DIR}/models"
FISHER_DIR="${EXPS_DIR}/fishers"
PER_EXAMPLE_FISHERS_DIR="${EXPS_DIR}/per_example_fishers"

PLAYPLAN_PEFS_DIR="/playpen/users/m/project_data/m_npeff_ims1/per_example_fishers/"

# 5841.25
cp "${PER_EXAMPLE_FISHERS_DIR}/resnet50_imagenet.train.20000ex.65536.tkc5.h5" $PLAYPLAN_PEFS_DIR

CUDA_VISIBLE_DEVICES=0,1,2,3 ./build/mains/run_m_npeff \
    --pef_filepath="${PLAYPLAN_PEFS_DIR}/resnet50_imagenet.train.20000ex.65536.tkc5.h5" \
    --min_nonzero_per_col=6 \
    --n_components=512 \
    --learning_rate_G_G_only=1e-3 \
    --learning_rate_G=3e-4 \
    --output_filepath="${PER_EXAMPLE_FISHERS_DIR}/resnet50_imagenet.train.tkc5.mnpeff.512comps.001.h5" \
    --n_preprocess_cpu_threads=32 \
    --n_iters_G_only=100 \
    --n_iters_joint=2000 \
    --rand_gen_seed=55 \
    --pefs_col_offsets_non_cumulative=false


###################################################################################


cp "${PER_EXAMPLE_FISHERS_DIR}/resnet50_imagenet.validation.30000ex.65536.tkc5.h5" $PLAYPLAN_PEFS_DIR
cp "${PER_EXAMPLE_FISHERS_DIR}/resnet50_imagenet.train.tkc5.mnpeff.512comps.001.h5" $PLAYPLAN_PEFS_DIR

CUDA_VISIBLE_DEVICES=0 ./build/mains/fit_m_npeff_coeffs \
    --pef_filepath="/${PLAYPLAN_PEFS_DIR}/resnet50_imagenet.validation.30000ex.65536.tkc5.h5" \
    --decomposition_filepath=$PLAYPLAN_PEFS_DIR/resnet50_imagenet.train.tkc5.mnpeff.512comps.001.h5 \
    --output_filepath=$PER_EXAMPLE_FISHERS_DIR/resnet50_imagenet.train.tkc5.mnpeff.512comps.001.fit_to_validation.001.h5 \
    --n_preprocess_cpu_threads=32 \
    --n_iters=1500 \
    --n_columns_per_chunk=2500000 \
    --truncate_when_G_index_map_mismatch=true \
    --pefs_col_offsets_non_cumulative=false

