R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/wino1/wino_heldout_comps001.py

"""

import dataclasses
from importlib import reload
import os
import time

from colorama import Fore, Back, Style
import matplotlib.pyplot as plt
import numpy as np
import scipy.sparse as sps
import seaborn as sns
import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.models import transformer_model_vars as tmv
from em.tools.nmf import nmf_common
from em.tools.nmf import nmf_transform
from em.util import flat_pack
from em.util import hf_util
from em.util.color_util import cu

from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf


rocket_cmap = sns.color_palette("rocket", as_cmap=True)

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/winogrange1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

PRETRAINED_MODEL = 'bert-base-uncased'
SEQUENCE_LENGTH = 50
EVAL_BATCH_SIZE = 128

MODEL = "bert_base_mnli_to_winogrande_custom_8_epochs_01"
PER_EXAMPLES_FISHERS = f"{MODEL}.winogrande_heldout.no_embeddings.sparse_dynamic_raw.32k.32k.h5"
DECOMP_FILENAME = f"nmf_decomp.per_sub_block.10k.16k.256.{PER_EXAMPLES_FISHERS}"

FROM_PT = False

N_DECOMPS = 25

###############################################################################

tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL)

container = am.load_pef_nmf_analysis_container(
    pef_filepath=os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    nmf_filepath=os.path.join(PER_EXAMPLES_FISHERS_DIR, DECOMP_FILENAME),
    n_nmfs=N_DECOMPS,
    tokenizer=tokenizer,
    shift_labels=True,
)

# Do this kinda hack to get labels correct. Having shift_labels=True
# and then doing this gets the string labels and the integer labels
# properly matched.
container.labels = container.pef.labels
container.examples = container._make_nli_examples()


container.nmfs.force_load_all()

# reload(am); container.__class__ = am.PefNmfAnalysisContainer

###############################################################################

subset_names = am.make_per_sub_block_subset_names(N_DECOMPS - 1)
subset_names.append('Pooler')

############################################


'''

Coefficient fractor: 0.300   Fraction threshold: 0.500   P-value threshold: 0.0100
    Top examples fraction: 0.176
    Top examples accuracy: 0.478
    Remaining examples accuracy: 0.887

'''
selection_parameters = ncf.SelectionParameters(
    coeff_factor=0.3,
    frac_threshold=0.5,
    p_value_threshold=0.01,
)
incorrect_indicator = container.get_incorrect_prediction_indicator()

ac_fisher = ncf.get_apparently_tuned_fisher(container, incorrect_indicator, selection_parameters)

component_indices_per_subset = [
    list(sorted(c.component_index for c in ssi.correct_component_infos))
    for ssi in ac_fisher.subset_infos
]

example_indices_per_component_per_subset = [
    {
        c.component_index: c.get_all_relevant_example_indices(container)
        for c in ssi.correct_component_infos
    }
    for ssi in ac_fisher.subset_infos
]

############################################
COMPONENTS_LATEX_FILE_START = container.COMPONENTS_LATEX_FILE_START

start1, start2 = COMPONENTS_LATEX_FILE_START.split(R'\begin{document}')
start1 += '\n' + R'\begin{document}' + '\n'

middle = R"""
\paragraph{Selection parameters:}
\begin{itemize}
""" + ("\n".join([
    R"\item Indicator: incorrect predictions",
    R"\item Coefficient factor: " + f'{selection_parameters.coeff_factor:.3f}',
    R"\item Fraction threshold: " + f'{selection_parameters.frac_threshold:.3f}',
    R"\item P-value threshold: " + f'{selection_parameters.p_value_threshold:.4f}',
])) + R"""
\end{itemize}

"""


FILENAME = "winogrande_heldout_rank256_incorrect_components"

with open(f'/fruitbasket/users/m/tmp/{FILENAME}.tex', 'w') as f:
    f.write(start1)
    f.write(middle)
    f.write(start2)
    f.write(container.make_latex_string_for_some_components_and_examples(
        nmf_names=subset_names,
        example_indices_per_component_per_subset=example_indices_per_component_per_subset,
    ))
    f.write(container.COMPONENTS_LATEX_FILE_END)


R"""


FILENAME="winogrande_heldout_rank256_incorrect_components"

rsync -ra -e ssh \
    "m@banana.cs.unc.edu:/fruitbasket/users/m/tmp/$FILENAME.tex" \
    "$HOME/Downloads/$FILENAME.tex"

xelatex -interaction=batchmode -output-directory=/tmp ~/Downloads/$FILENAME.tex
mv /tmp/$FILENAME.pdf ~/Downloads


"""
