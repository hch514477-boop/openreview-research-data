R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i local_scripts/selective_transfer1/st_dev001.py

"""
from importlib import reload
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.models import transformer_model_vars as tmv
from em.tools.nmf import nmf_common
from em.util import flat_pack
from em.util import hf_util

from em.analysis import bert_nmf_analysis as bna
from em.experimental import selective_ablation1

###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/math_datasets_dev1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models1')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers0')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers0')

###############################################################################

TASK = 'math_dataset/original_true_false'
SEQUENCE_LENGTH = 128

MODEL = "og_tf__bert_small__100k_steps"
FROM_PT = False

PRETRAINED_MODEL = "prajjwal1/bert-small"

FISHER = "og_tf__bert_small__100k_steps.dense.32k.h5"
PER_EXAMPLES_FISHERS = "og_tf__bert_small__100k_steps.no_embeddings.sparse_dynamic_raw.32k.32k.h5"
DECOMP = 'nmf_decomp.8k.4k.128.og_tf__bert_small__100k_steps.no_embeddings.sparse_dynamic_raw.32k.32k.h5'

N_EXAMPLES = 8 * 1024
START_FISHER_INDEX, END_FISHER_INDEX = (0, 4096)

###############################################################################

###############################################################################
# TODO: In proper code, I can probably multithread/multiprocess this to do all these
# loads below in parallel.
#############################

tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL)

# print('Starting to load fisher.')
# start = time.time()
# dense_fisher = diagonal.DiagonalFisher.load(os.path.join(FISHERS_DIR, FISHER))
# print('Load saved fishertime: ', time.time() - start)


print('Starting to load saved NMF decomposition.')
start = time.time()
decomp = nmf_common.NmfDecomposition.load(os.path.join(PER_EXAMPLES_FISHERS_DIR, DECOMP))
decomp.normalize_components_to_unit_norm()
print('Load saved NMF decomposition time: ', time.time() - start)


print('Starting to load saved per-example Fishers.')
start = time.time()
pe_fishers_data = per_example.PerExampleFlatFishers.load(
    os.path.join(PER_EXAMPLES_FISHERS_DIR, PER_EXAMPLES_FISHERS),
    n_examples=N_EXAMPLES,
    start_fisher_index=START_FISHER_INDEX,
    end_fisher_index=END_FISHER_INDEX,
)
print('Load saved per-example Fishers time: ', time.time() - start)

###############################################################################

# We did not compute per-example Fishers for the embeddings, so ignore them.
embeddings_filter = tmv.VariableFilter(
    merge_embeddings=False,
)

finetuned_model = TFAutoModelForSequenceClassification.from_pretrained(
    os.path.join(MODELS_DIR, MODEL), from_pt=FROM_PT
)

finetuned_vars = hf_util.get_mergeable_variables(finetuned_model)
# fishers = dense_fisher.fishers

# finetuned_vars, fishers = embeddings_filter.filter_parallel_lists(finetuned_vars, fishers)
finetuned_vars = embeddings_filter.filter_parallel_lists(finetuned_vars)

flat_packer = flat_pack.FlatPacker([v.shape for v in finetuned_vars])
assert flat_packer.flat_size == decomp.H.shape[1]

#######################################

# This should be applied after the embeddings filter.
pooler_filter = tmv.VariableFilter(
    merge_pooler=False,
)
merge_finetuned_vars = pooler_filter.filter_parallel_lists(finetuned_vars)


#######################################

pretrained_model = TFAutoModelForSequenceClassification.from_pretrained(
    PRETRAINED_MODEL, from_pt=True
)

pretrained_vars = hf_util.get_mergeable_variables(pretrained_model)
pretrained_vars = embeddings_filter.filter_parallel_lists(pretrained_vars)

merge_pretrained_vars = pooler_filter.filter_parallel_lists(pretrained_vars)


###############################################################################

def make_output_model():
    output_model = TFAutoModelForSequenceClassification.from_pretrained(
        PRETRAINED_MODEL, from_pt=True, num_labels=2
    )
    #
    # Set the embeddings, pooler, and classification head from the finetuned model.
    output_model.bert.embeddings.set_weights(finetuned_model.bert.embeddings.get_weights())
    output_model.bert.pooler.set_weights(finetuned_model.bert.pooler.get_weights())
    output_model.classifier.set_weights(finetuned_model.classifier.get_weights())
    #
    output_variables = hf_util.get_mergeable_variables(output_model)
    output_variables = embeddings_filter.filter_parallel_lists(output_variables)
    output_variables = pooler_filter.filter_parallel_lists(output_variables)
    #
    output_model.compile(
        metrics=[
            tf.keras.metrics.SparseCategoricalAccuracy(),
            tf.keras.metrics.SparseCategoricalCrossentropy(from_logits=True),
        ]
    )
    return output_model, output_variables


output_model, output_variables = make_output_model()


###############################################################################
# COMPONENT = 14
# COMPONENT = 63
# COMPONENT = 29
# COMPONENT = 25
COMPONENT = 23
# COMPONENT = 34
#######################################

h_comp = decomp.H[COMPONENT]

component_fishers = flat_packer.decode_tf(h_comp)
_, component_fishers = pooler_filter.filter_parallel_lists(finetuned_vars, component_fishers)


pretrained_acting_fishers = [tf.ones_like(f) for f in component_fishers]


###############################################################################
EVAL_COMPONENT_N_EXAMPLES = 16
EVAL_BATCH_SIZE = 512
#######################################

eval_ds_comp = selective_ablation1.make_dataset_for_top_component_examples(
    W=decomp.W,
    component=COMPONENT,
    n_examples=EVAL_COMPONENT_N_EXAMPLES,
    tokenizer=tokenizer,
    pe_fishers_data=pe_fishers_data,
)
eval_ds_comp = eval_ds_comp.batch(EVAL_BATCH_SIZE)


###############################################################################
GRID_SIZE = 50
#######################################

coefficients_set = merging.create_pairwise_grid_coeffs(GRID_SIZE)
# coefficients_set = merging.create_pairwise_grid_coeffs(1_000_000)[-GRID_SIZE:]

_gen = selective_ablation1.generate_merged_for_coeffs_set(
    output_variables=output_variables,
    variables_to_merge=[merge_pretrained_vars, merge_finetuned_vars],
    fishers=[pretrained_acting_fishers, component_fishers],
    coefficients_set=coefficients_set,
    fisher_floor=1e-12,
    normalize_fishers=True,
)

for coefficients in _gen:
    _, comp_acc, comp_loss = output_model.evaluate(eval_ds_comp, verbose=0)
    print('Coefficients:', coefficients)
    print('Comp accuracy:', comp_acc)
    print('Comp loss:', comp_loss)
    print()


# Pooler has 262_656 parameters.
