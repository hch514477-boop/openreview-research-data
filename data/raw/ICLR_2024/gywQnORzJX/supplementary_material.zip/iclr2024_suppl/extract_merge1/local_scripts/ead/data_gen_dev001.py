R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i local_scripts/ead/data_gen_dev001.py

"""
import collections
from importlib import reload
import itertools
import os
import time
from typing import Sequence

import numpy as np
import matplotlib.pyplot as plt

import tensorflow as tf
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer

from em.datasets.antiderivative import antiderivative_ds
from em.fishers import per_example
from em.tools.nmf import nmf_common
from em.util.color_util import cu
from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf
from em.projects.ead import ead_misc1 as eadm
from em.util import vat_da_faak_vpn

###################################################################################

import sympy as sp
from sympy.parsing import mathematica
from sympy.parsing.sympy_parser import parse_expr
from em.datasets.antiderivative import sympy_util as sp_util

###################################################################################


R"""
# Mathematica inputs

RootSum[...]

Integrate[[x^6−2*x^3+7908*x^2−1]/[x^4−2*x+7908],x]



FullSimplify[Integrate[x + Sqrt[3402 - x^3], x]]

"""

# ROOTSUM_TEXT = 'RootSum[Function[Plus[7908, Times[-2, Slot[1]], Power[Slot[1], 4]]], Function[Times[Log[Plus[x, Times[-1, Slot[1]]]], Power[Plus[-1, Times[2, Power[Slot[1], 3]]], -1]]]]'
ROOTSUM_TEXT = 'x^3/3 - RootSum[7908 - 2 #1 + #1^4 & , Log[x - #1]/(-1 + 2 #1^3) & ]/2'

# print(sp_util.is_elementary(mathematica.mathematica('Cot[x]')))

# rs_expr = mathematica.mathematica(ROOTSUM_TEXT)
# print(rs_expr)


# RootSum
# Function
# Slot[1]


additional_translations = {
    'RootSum[x,y]': '(y)',
}
parser = mathematica.MathematicaParser(additional_translations)
rs_expr_str = parser.parse(ROOTSUM_TEXT.replace('#1', 'r').replace('&', ' '))

print(rs_expr_str)
print(sp.sympify(rs_expr_str))


# TODO: Maybe add entropy of p(y|x) (or just put [p1, p2]) to each example predictions when generating pdfs.

tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')

inputs = tokenizer.encode_plus(
    'Maybe add entropy of p(y|x) (or just put [p1, p2]) to each example predictions when generating pdfs.',
    add_special_tokens=True,
    max_length=8,
    return_token_type_ids=True,
    truncation=True,
)
print(inputs)