R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python -i local_scripts/m_npeff/wrong_heuristics/expansion_debug001.py

"""
from importlib import reload
import os

import matplotlib.pyplot as plt
import seaborn as sns

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer
from em.fishers import per_example

from em.tools.nmf import lrm_npeff
from em.projects.m_npeff import snli_context
from em.projects.m_npeff import latex_generation

from em.util.color_util import cu
from em.projects.pi import qqp_components_context as QCC

###############################################################################

"""
cp /fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/test_mnpeff_002.expansion_002.h5 /playpen/users/m/project_data/m_npeff1/per_example_fishers

"""

# NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/"
NMF_DIR = "/playpen/users/m/project_data/m_npeff1/per_example_fishers"
NMF_NAME = "test_mnpeff_002.expansion_002.h5"
# NMF_NAME = "test_mnpeff_002.expansion_002.coeffs_fit001.h5"
NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)


# Use this only to get the predictions and example token ids without having to
# evaluate the model.
PEFS_FOR_PREDICTIONS_DIR = "/fruitbasket/users/m/project_data/extract_merge1/pi1/per_example_fishers/"
# PEFS_FOR_PREDICTIONS_NAME = "feather_berts_0.snli_train.all_vars.skip50000.250000ex.131072.h5"
PEFS_FOR_PREDICTIONS_NAME = "feather_berts_0.snli_train.all_vars.50000ex.65536.h5"
PEFS_FOR_PREDICTIONS_PATH = os.path.join(PEFS_FOR_PREDICTIONS_DIR, PEFS_FOR_PREDICTIONS_NAME)

TOKENIZER = 'bert-base-uncased'

###############################################################################

nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=True)
W = nmf.W
G = nmf.G

W_e = W[:, :32]
print(np.max(W_e))
print(np.mean(W_e))

# plt.plot(G[0]); plt.show()
# plt.plot(G[32]); plt.show()


print(np.max(G))
print(np.min(G))
print(np.mean(G))

for i in range(32):
    plt.plot(W[:, i])

plt.show()


###############################################################################
# nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=False)
# W = nmf.W

# print(np.max(W))
# print(np.mean(W))
###############################################################################

# plt.imshow(W.T); plt.show()


# ctx = snli_context.SnliContext(
#     # split='train_skip_50k',
#     split='train',
#     tokenizer=AutoTokenizer.from_pretrained(TOKENIZER),
#     nmf=nmf,
# )

# ctx.n_examples = 50_000

# # eval_ctx = ctx.create_eval_ctx_from_pefs_file(PEFS_FOR_PREDICTIONS_PATH)
# pef = per_example.PerExampleFlatFishers.load(
#     os.path.expanduser(PEFS_FOR_PREDICTIONS_PATH),
#     n_examples=None,
#     # This leads to the Fishers not being loaded, which ends up being much faster.
#     start_fisher_index=0,
#     end_fisher_index=0,
# )
# eval_ctx = QCC.EvaluationContext2.create_from_pefs(
#     pef=pef,
#     tokenizer=ctx.tokenizer,
#     special_processing='HF_MNLI',
# )

# # reload(latex_generation)
# lg = latex_generation.TopExamplesLatexGenerator(
#     snli_ctx=ctx,
#     predicted_logits=eval_ctx.og_logits,
#     n_top_examples=16,
# )

# latex_str = lg.generate_all_components_latex()
# # print(latex_str)

# # filename = 'train_skip_50k.top16.256comps.32comps_from_wrongs.002.tex'

# with open(os.path.join('/fruitbasket/users/m/tmp', filename), 'w') as f:
#     f.write(latex_str)


# print(cu.hlg(filename))


# # Component 251 looks very interesting

# R"""

# make_pdf() {
#     local filename=$1

#     rsync -ra -e ssh \
#         "m@mango.cs.unc.edu:/fruitbasket/users/m/tmp/${filename}.tex" \
#         "$HOME/Downloads/${filename}.tex"

#     xelatex -interaction=batchmode -output-directory=/tmp ~/Downloads/${filename}.tex
#     mv /tmp/${filename}.pdf ~/Desktop/projects_data/extract_merge1/ll/pdfs
# }

# make_pdf train_skip_50k.top16.256comps.32comps_from_wrongs.002


# """
