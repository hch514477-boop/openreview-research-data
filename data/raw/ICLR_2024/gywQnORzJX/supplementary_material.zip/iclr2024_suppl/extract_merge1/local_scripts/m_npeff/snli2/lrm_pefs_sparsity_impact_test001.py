R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=2 python -i local_scripts/m_npeff/snli2/lrm_pefs_sparsity_impact_test001.py

"""

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em import datasets as em_datasets
from em.fishers import lrm_pefs
from em.analysis.sparsity_impact import sp_lrm

tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
model = TFAutoModelForSequenceClassification.from_pretrained("connectivity/feather_berts_0", from_pt=True)
variables = model.trainable_variables

n_values_per_example = 65536
n_examples = 100

ds = em_datasets.load(
    'snli/default',
    split='train',
    tokenizer=tokenizer,
    sequence_length=128,
)
ds = ds.batch(1)

fisher_computer = lrm_pefs.SparseLrmPefComputer(
    model=model, variables=variables, n_values_per_example=n_values_per_example)

ic = sp_lrm.ImpactComputer(fisher_computer=fisher_computer, n_examples=n_examples)

norm_dists = ic.run(ds)

