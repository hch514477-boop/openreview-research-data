R"""




cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=2 python -i local_scripts/m_npeff/lrm_npeff_snli_perturbations002.py

"""

from importlib import reload
import os

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em.fishers import diagonal
from em.tools.nmf import lrm_npeff
from em.util import flat_pack

from em.projects.m_npeff import perturbation_finder
from em.projects.m_npeff import snli_context
from em.projects.pi import qqp_components_context as QCC


###############################################################################

FISHER_DIR = "/fruitbasket/users/m/project_data/extract_merge1/pi1/fishers/"
FISHER_NAME = "feather_berts_0.mnli_snli_train.all_vars.50000ex.h5"
FISHER_PATH = os.path.join(FISHER_DIR, FISHER_NAME)

NMF_DIR = "/fruitbasket/users/m/project_data/extract_merge1/m_npeff1/per_example_fishers/"
NMF_NAME = "test_mnpeff_002.h5"
NMF_PATH = os.path.join(NMF_DIR, NMF_NAME)

MODEL = "connectivity/feather_berts_0"
TOKENIZER = 'bert-base-uncased'

###############################################################################

og_model = TFAutoModelForSequenceClassification.from_pretrained(MODEL, from_pt=True)

fisher = diagonal.DiagonalFisher.load(FISHER_PATH)
flat_fisher = fisher.as_flat_fisher().numpy()
flat_fisher /= np.sqrt(np.sum(flat_fisher**2))

nmf = lrm_npeff.LrmNpeffDecomposition.load(NMF_PATH, read_G=True)
nmf.normalize_components_to_unit_norm()

ctx = snli_context.SnliContext(
    split='train',
    tokenizer=AutoTokenizer.from_pretrained(TOKENIZER),
    nmf=nmf,
)

###############################################################################

N_TOTAL_EXAMPLES = 2048
reload(snli_context); ctx.__class__ = snli_context.SnliContext
eval_ctx = ctx.create_eval_ctx(og_model)

model = TFAutoModelForSequenceClassification.from_pretrained(MODEL, from_pt=True)


def run(component_index: int, delta=0.01, min_fisher_value=1e-6, f_factor=1.0, multiplier=1.0, max_offset=1e9):
    g = nmf.get_full_g(component_index)
    #
    # reload(perturbation_finder)
    pf = perturbation_finder.PerturbationFinder(f=f_factor * flat_fisher, g=g)
    #
    z = pf.solve(delta=delta, min_fisher_value=min_fisher_value)
    # z[flat_fisher < min_fisher_value] = 0
    z = np.minimum(max_offset, np.maximum(-max_offset, z))
    #
    packer = flat_pack.FlatPacker([v.shape for v in model.trainable_variables])
    offsets = packer.decode_tf(tf.cast(z, tf.float32))
    #
    # TODO: Both +/- offset would work here. Right now, just doing plus.
    for ogv, v, offset in zip(og_model.trainable_variables, model.trainable_variables, offsets):
        v.assign(ogv + multiplier * offset)


def eval(component_index: int, n_top_examples: int = 128, n_total_examples=N_TOTAL_EXAMPLES):
    top_inds = np.argsort(-nmf.W[:, component_index])[:n_top_examples]
    top_results = eval_ctx.evaluate(model, top_inds)
    total_results = eval_ctx.evaluate(model, np.arange(n_total_examples))
    #
    print('Top:', top_results.kl())
    print('Total:', total_results.kl())
    print('Ratio:', top_results.kl() / total_results.kl())
    #
    return top_results, total_results


# TOOD: Probably need better perturbation algorithm. Probably do the principled version
# with some constraints/regularizers.

# component_index = 6
# run(component_index, min_fisher_value=1e-6, f_factor=1e2, delta=0.01)
# _ = eval(component_index, n_top_examples=128)

for i in range(0, 32):
    print('Component', i)
    run(i, min_fisher_value=1e-7, f_factor=1, delta=0.001, multiplier=1.0)
    _ = eval(i, n_top_examples=128)
    run(i, min_fisher_value=1e-7, f_factor=1, delta=0.001, multiplier=-1.0)
    _ = eval(i, n_top_examples=128)
    print('')

