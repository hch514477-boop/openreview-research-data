R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i local_scripts/soc/soc_cifar_dev001.py



CUDA_VISIBLE_DEVICES=0 python -i local_scripts/soc/soc_cifar_dev001.py


"""
import collections
import dataclasses
import os
from importlib import reload
import itertools
import time
from typing import Any, List, Sequence

import h5py
import matplotlib.pyplot as plt
import numpy as np
from transformers import TFAutoModelForSequenceClassification, AutoTokenizer
import tensorflow as tf
import tensorflow_probability as tfp

from em.datasets import glue
from em.evaluation import evaluation
from em.fishers import diagonal
from em.fishers import per_example
from em.fishers import sparse_diagonal
from em.merging import merging
from em.models.generative import vae
# from em.models.generative import soc
from em.util import hf_util
from em.util import vat_da_faak_vpn

from local_scripts.soc import soc_dev_common as sdc


tfd = tfp.distributions


###############################################################################
###############################################################################

TRAIN_BATCH_SIZE = 256

#######################################

(train_images, train_labels), (test_images, test_labels) = tf.keras.datasets.cifar10.load_data()
train_images, test_images = train_images / 255.0, test_images / 255.0

data_format = 'channels_last'
# data_format = 'channels_first'

if data_format == 'channels_first':
    train_images = np.transpose(train_images, [0, 3, 1, 2])
    test_images = np.transpose(test_images, [0, 3, 1, 2])

r = {'data_format': data_format}

model = tf.keras.models.Sequential([
# model = sdc.HfLogitsSequential([
    tf.keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=train_images.shape[1:], **r),
    tf.keras.layers.MaxPooling2D((2, 2), **r),
    tf.keras.layers.Conv2D(64, (3, 3), activation='relu', **r),
    tf.keras.layers.MaxPooling2D((2, 2), **r),
    tf.keras.layers.Conv2D(64, (3, 3), activation='relu', **r),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(10),
])
# print(model.summary())
model.compile(optimizer=tf.keras.optimizers.Adam(),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])

tr_ds = tf.data.Dataset.zip((
    tf.data.Dataset.from_tensor_slices(train_images),
    tf.data.Dataset.from_tensor_slices(train_labels),
))
tr_ds = tr_ds.repeat().shuffle(1000).batch(TRAIN_BATCH_SIZE)

history = model.fit(tr_ds, epochs=6, steps_per_epoch=1024,
                    validation_data=(test_images, test_labels))

###############################################################################
###############################################################################

PE_BATCH_SIZE = 256

#######################################

pe_ds = tf.data.Dataset.from_tensor_slices(train_images)
pe_ds = pe_ds.repeat().shuffle(1000).batch(PE_BATCH_SIZE)

# model = sdc.hack_call_to_be_like_hf(model)
setattr(model, 'num_labels', 10)


def something(n_iters):
    gen = per_example.stream_per_example_diagonal_fishers(
        model,
        dataset=pe_ds,
        variables=model.trainable_variables,
        unbatch=False,
        expectation_wrt_logits=False,
    )
    times = []
    for batch_fishers in itertools.islice(gen, n_iters):
        times.append(time.time())
    return np.array(times)


n_iters = 100
times = something(n_iters)
print(np.diff(times))
print(np.diff(times).mean())
