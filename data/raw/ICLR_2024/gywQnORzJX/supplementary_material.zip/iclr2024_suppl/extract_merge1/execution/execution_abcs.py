"""Execution related abstract base classes."""
import abc
import dataclasses
from typing import Any, Optional, Sequence


@dataclasses.dataclass
class ExecutionEnv(abc.ABC):
    """ABC to be extended to interact with an execution environments.

    Example of an "execution environment" include local execution,
    longleaf, and lab GPUs.
    """

    env_config: Any
    run_config: Optional[Any] = None

    @abc.abstractmethod
    def copy_to_env(self, localpath: str, dstpath: str):
        """Copies a local folder to the execution environment.

        Args:
            localpath: the path to the local folder/file to copy over.
            dstpath: the destination folder/file to copy to.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def copy_from_env(self, envpath: str, localpath: str):
        """Copies from the remote execution environment to local machine.

        Args:
            envpath: the path to the folder/file on the environment to copy over.
            localpath: the destination folder/file on the local machine to copy to.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def run_command(self, cmd: str):
        """Run the command on the execution environment.

        Args:
            cmd: the command to run. Will typically be a shell command.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def launch_experiment(self, script_config, args_config):
        raise NotImplementedError


@dataclasses.dataclass
class ExecutableScript(abc.ABC):
    """ABC to be extended to enable interaction with a particular script."""

    @abc.abstractmethod
    def make_run_command(self, args_config, env_config, **kwargs) -> str:
        """Returns the shell command to run this script.

        Args:
            args_config: instance of ScriptArgs, configuration of the arguments
                for this script.
            env_config: configuration for the environment
            **kwargs: various, possibly environment specific, arguments relevant
                to running this script.
        Returns:
            The shell command to run this script with the given args.
        """
        raise NotImplementedError
