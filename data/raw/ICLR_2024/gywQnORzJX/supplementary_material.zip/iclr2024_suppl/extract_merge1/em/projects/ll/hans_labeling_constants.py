"""Constants for HANS labeling.

See:
    https://github.com/tommccoy1/hans/blob/master/templates.py
    https://github.com/tommccoy1/hans/blob/master/corpus_generator.py

"""
from typing import Optional, Tuple

####################################################################################
####################################################################################


nouns_sg = [
    "professor",
    "student",
    "president",
    "judge",
    "senator",
    "secretary",
    "doctor",
    "lawyer",
    "scientist",
    "banker",
    "tourist",
    "manager",
    "artist",
    "author",
    "actor",
    "athlete",
]
nouns_pl = [
    "professors",
    "students",
    "presidents",
    "judges",
    "senators",
    "secretaries",
    "doctors",
    "lawyers",
    "scientists",
    "bankers",
    "tourists",
    "managers",
    "artists",
    "authors",
    "actors",
    "athletes",
]
nouns = list(set(nouns_sg + nouns_pl))

transitive_verbs = [
    "recommended",
    "called",
    "helped",
    "supported",
    "contacted",
    "believed",
    "avoided",
    "advised",
    "saw",
    "stopped",
    "introduced",
    "mentioned",
    "encouraged",
    "thanked",
    "recognized",
    "admired",
]
passive_verbs = [
    "recommended",
    "helped",
    "supported",
    "contacted",
    "believed",
    "avoided",
    "advised",
    "stopped",
    "introduced",
    "mentioned",
    "encouraged",
    "thanked",
    "recognized",
    "admired",
]
intransitive_verbs = [
    "slept",
    "danced",
    "ran",
    "shouted",
    "resigned",
    "waited",
    "arrived",
    "performed",
]
verbs = list(set(transitive_verbs + intransitive_verbs))

preps = [
    "near",
    "behind",
    "by",
    "in front of",
    "next to",
]

rels = [
    "who",
    "that",
]

advs = [
    "quickly",
    "slowly",
    "happily",
    "easily",
    "quietly",
    "thoughtfully",
]


####################################################################################
####################################################################################

# Lexical Overlap: Simple sentence
lex_simple_templates = [
    (
        1.0,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, ".")],
            [3, 4, 2, 0, 1, 5],
            "temp1",
            ["(ROOT (S (NP (DT The) (", "nn,1", " ", 1, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn,4", " ", 4, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn,4", " ", 4, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn,1", " ", 1, "))) (. .)))"],
        )
    )
]

# Lexical Overlap: Preposition on subject
lex_prep_templates = [
    (
        1.0 / 6,
        (
            [(0, "the"), (1, nouns), (2, preps), (3, "the"), (4, nouns), (5, transitive_verbs), (6, "the"), (7, nouns), (8, ".")],
            [3, 4, 5, 0, 1, 8],
            "temp2",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "ppp, 2, 4", ") (VP (VBD ", 5, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ), 
    (
        1.0 / 6,
        (
            [(0, "the"), (1, nouns), (2, preps), (3, "the"), (4, nouns), (5, transitive_verbs), (6, "the"), (7, nouns), (8, ".")],
            [6, 7, 5, 0, 1, 8],
            "temp3",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "ppp, 2, 4", ") (VP (VBD ", 5, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 7", " ", 7, ")) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ), 
    (
        1.0 / 6,
        (
            [(0, "the"), (1, nouns), (2, preps), (3, "the"), (4, nouns), (5, transitive_verbs), (6, "the"), (7, nouns), (8, ".")],
            [6, 7, 5, 3, 4, 8],
            "temp4",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "ppp, 2, 4", ") (VP (VBD ", 5, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 7", " ", 7, ")) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 4", " ", 4, "))) (. .)))"]
        )
    ), 
    (
        1.0 / 6,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, preps), (6, "the"), (7, nouns), (8, ".")],
            [3, 4, 2, 0, 1, 8],
            "temp5",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "ppp, 5, 7", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ), 
    (
        1.0 / 6,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, preps), (6, "the"), (7, nouns), (8, ".")],
            [3, 4, 2, 6, 7, 8],
            "temp6",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "ppp, 5, 7", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"]
        )
    ), 
    (
        1.0 / 6,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, preps), (6, "the"), (7, nouns), (8, ".")],
            [6, 7, 2, 0, 1, 8],
            "temp7",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "ppp, 5, 7", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 7", " ", 7, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
]

# Lexical Overlap: Relative clause on subject
lex_rc_templates = [
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, rels), (3, "the"), (4, nouns), (5, transitive_verbs), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [3, 4, 6, 0, 1, 9],
            "temp8",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "prc, 2, 5", ") (VP (VBD ", 6, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 6, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, rels), (3, "the"), (4, nouns), (5, transitive_verbs), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [7, 8, 6, 0, 1, 9],
            "temp9",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "prc, 2, 5", ") (VP (VBD ", 6, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 8", " ", 8, ")) (VP (VBD ", 6, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, rels), (3, "the"), (4, nouns), (5, transitive_verbs), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [7, 8, 6, 3, 4, 9],
            "temp10",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "prc, 2, 5", ") (VP (VBD ", 6, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 8", " ", 8, ")) (VP (VBD ", 6, ") (NP (DT the) (", "nn, 4", " ", 4, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, rels), (3, transitive_verbs), (4, "the"), (5, nouns), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [4, 5, 6, 0, 1, 9],
            "temp11",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "prc, 2, 5", ") (VP (VBD ", 6, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 5", " ", 5, ")) (VP (VBD ", 6, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, rels), (3, transitive_verbs), (4, "the"), (5, nouns), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [7, 8, 6, 0, 1, 9],
            "temp12",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "prc, 2, 5", ") (VP (VBD ", 6, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 8", " ", 8, ")) (VP (VBD ", 6, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, rels), (3, transitive_verbs), (4, "the"), (5, nouns), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [7, 8, 6, 4, 5, 9],
            "temp13",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "prc, 2, 5", ") (VP (VBD ", 6, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 8", " ", 8, ")) (VP (VBD ", 6, ") (NP (DT the) (", "nn, 5", " ", 5, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, rels), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [3, 4, 2, 0, 1, 9],
            "temp14",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "prc, 5, 8", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, rels), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [3, 4, 2, 0, 7, 8, 9],
            "temp15",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "prc, 5, 8", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, rels), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [7, 8, 2, 0, 1, 9],
            "temp16",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "prc, 5, 8", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 8", " ", 8, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, rels), (6, "the"), (7, nouns), (8, transitive_verbs), (9, ".")],
            [3, 4, 2, 0, 1, 9],
            "temp17",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "prc, 5, 8", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, rels), (6, "the"), (7, nouns), (8, transitive_verbs), (9, ".")],
            [3, 4, 2, 6, 7, 9],
            "temp18",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "prc, 5, 8", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"]
        )
    ),
    (
        1.0 / 12,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, rels), (6, "the"), (7, nouns), (8, transitive_verbs), (9, ".")],
            [6, 7, 2, 0, 1, 9],
            "temp19",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "prc, 5, 8", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 7", " ", 7, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
]

# Lexical Overlap: Passive incorrect
lex_pass_templates = [
    (
        0.5,
        (
            [(0, "the"), (1, nouns_sg), (2, "was"), (3, passive_verbs), (4, "by"), (5, "the"), (6, nouns), (7, ".")],
            [0, 1, 3, 5, 6, 7],
            "temp20",
            ["(ROOT (S (NP (DT The) (NN ", 1, ")) (VP (VBD was) (VP (VBN ", 3, ") (PP (IN by) (NP (DT the) (", "nn, 6", " ", 6, "))))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 3, ") (NP (DT the) (", "nn, 6", " ", 6, "))) (. .)))"]
        )
    ),
    (
        0.5,
        (
            [(0, "the"), (1, nouns_pl), (2, "were"), (3, passive_verbs), (4, "by"), (5, "the"), (6, nouns), (7, ".")],
            [0, 1, 3, 5, 6, 7],
            "temp21",
            ["(ROOT (S (NP (DT The) (NNS ", 1, ")) (VP (VBD were) (VP (VBN ", 3, ") (PP (IN by) (NP (DT the) (", "nn, 6", " ", 6, "))))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 3, ") (NP (DT the) (", "nn, 6", " ", 6, "))) (. .)))"]
        )
    ),
]

# Lexical Overlap: Conjunctions
lex_conj_templates = [
    (
        0.25, (
            [(0, "the"), (1, nouns), (2, "and"), (3, "the"), (4, nouns), (5, transitive_verbs), (6, "the"), (7, nouns), (8, ".")],
            [0, 1, 5, 3, 4, 8],
            "temp22",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) (CC and) (NP (DT the) (", "nn, 4", " ", 4, "))) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 4", " ", 4, "))) (. .)))"]
        )
    ),
    (
        0.25, (
            [(0, "the"), (1, nouns), (2, "and"), (3, "the"), (4, nouns), (5, transitive_verbs), (6, "the"), (7, nouns), (8, ".")],
            [3, 4, 5, 0, 1, 8],
            "temp23",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) (CC and) (NP (DT the) (", "nn, 4", " ", 4, "))) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        0.25, (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, "and"), (6, "the"), (7, nouns), (8, ".")],
            [3, 4, 2, 6, 7, 8],
            "temp24",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) (CC and) (NP (DT the) (", "nn, 7", " ", 7, ")))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"]
        )
    ),
    (
        0.25, (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, "and"), (6, "the"), (7, nouns), (8, ".")],
            [6, 7, 2, 3, 4, 8],
            "temp25",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) (CC and) (NP (DT the) (", "nn, 7", " ", 7, ")))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 7", " ", 7, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 4", " ", 4, "))) (. .)))"]
        )
    )
]


# Lexical Overlap: Relative clause
lex_rc_ent_templates = [
    (
        0.25,
        (
            [(0, "the"), (1, nouns), (2, rels), (3, "the"), (4, nouns), (5, transitive_verbs), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [3, 4, 5, 0, 1, 9],
            "temp26",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "prc, 2, 5", ") (VP (VBD ", 6, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        0.25,
        (
            [(0, "the"), (1, nouns), (2, rels), (3, transitive_verbs), (4, "the"), (5, nouns), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [0, 1, 3, 4, 5, 9],
            "temp27",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "prc, 2, 5", ") (VP (VBD ", 6, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 3, ") (NP (DT the) (", "nn, 5", " ", 5, "))) (. .)))"]
        )
    ),
    (
        0.25,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, rels), (6, transitive_verbs), (7, "the"), (8, nouns), (9, ".")],
            [3, 4, 6, 7, 8, 9],
            "temp28",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "prc, 5, 8", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 4", " ", 4, ")) (VP (VBD ", 6, ") (NP (DT the) (", "nn, 8", " ", 8, "))) (. .)))"]
        )
    ),
    (
        0.25,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, rels), (6, "the"), (7, nouns), (8, transitive_verbs), (9, ".")],
            [6, 7, 8, 3, 4, 9],
            "temp29",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) ", "prc, 5, 8", ")) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 7", " ", 7, ")) (VP (VBD ", 8, ") (NP (DT the) (", "nn, 4", " ", 4, "))) (. .)))"]
        )
    ),
]

# Lexical Overlap: Across PP
lex_cross_pp_ent_templates = [
    (
        1.0,
        (
            [(0, "the"), (1, nouns), (2, preps), (3, "the"), (4, nouns), (5, transitive_verbs), (6, "the"), (7, nouns), (8, ".")],
            [0, 1, 5, 6, 7, 8],
            "temp30",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "ppp, 2, 4", ") (VP (VBD ", 5, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"]
        )
    )
]

# Lexical Overlap: Across relative clause
lex_cross_rc_ent_templates = [
    (
        1.0,
        (
            [(0, "the"), (1, nouns), (2, "RC"), (3, transitive_verbs), (4, "the"), (5, nouns), (6, ".")],
            [0, 1, 3, 4, 5, 6],
            "temp31",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) ", "prc, 2, 2", ") (VP (VBD ", 3, ") (NP (DT the) (", "nn, 5", " ", 5, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 3, ") (NP (DT the) (", "nn, 5", " ", 5, "))) (. .)))"]
        )
    )
]

# Lexical Overlap: Conjunctions
lex_ent_conj_templates = [
    (
        0.5,
        (
            [(0, "the"), (1, nouns), (2, "and"), (3, "the"), (4, nouns), (5, transitive_verbs), (6, "the"), (7, nouns), (8, ".")],
            [0, 1, 5, 6, 7, 8],
            "temp32",
            ["(ROOT (S (NP (NP (DT The) (", "nn, 1", " ", 1, ")) (CC and) (NP (DT the) (", "nn, 4", " ", 4, "))) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 5, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"]
        )
    ),
    (
        0.5,
        (
            [(0, "the"), (1, nouns), (2, transitive_verbs), (3, "the"), (4, nouns), (5, "and"), (6, "the"), (7, nouns), (8, ".")],
            [0, 1, 2, 6, 7, 8],
            "temp33",
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (NP (DT the) (", "nn, 4", " ", 4, ")) (CC and) (NP (DT the) (", "nn, 7", " ", 7, ")))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 1", " ", 1, ")) (VP (VBD ", 2, ") (NP (DT the) (", "nn, 7", " ", 7, "))) (. .)))"]
        )
    ),
]

# Lexical Overlap: Passive
lex_ent_pass_templates = [
    (
        0.5,
        (
            [(0, "the"), (1, nouns_sg), (2, "was"), (3, passive_verbs), (4, "by"), (5, "the"), (6, nouns), (7, ".")],
            [5, 6, 3, 0, 1, 7],
            "temp35",
            ["(ROOT (S (NP (DT The) (NN ", 1, ")) (VP (VBD was) (VP (VBN ", 3, ") (PP (IN by) (NP (DT the) (", "nn, 6", " ", 6, "))))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 6", " ", 6, ")) (VP (VBD ", 3, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
    (
        0.5,
        (
            [(0, "the"), (1, nouns_pl), (2, "were"), (3, passive_verbs), (4, "by"), (5, "the"), (6, nouns), (7, ".")],
            [5, 6, 3, 0, 1, 7],
            "temp36",
            ["(ROOT (S (NP (DT The) (NNS ", 1, ")) (VP (VBD were) (VP (VBN ", 3, ") (PP (IN by) (NP (DT the) (", "nn, 6", " ", 6, "))))) (. .)))"],
            ["(ROOT (S (NP (DT The) (", "nn, 6", " ", 6, ")) (VP (VBD ", 3, ") (NP (DT the) (", "nn, 1", " ", 1, "))) (. .)))"]
        )
    ),
]


####################################################################################
####################################################################################

template_list = [
    # Non-entailing templates.
    ("lexical_overlap", "ln_subject/object_swap", "non-entailment", lex_simple_templates),
    ("lexical_overlap", "ln_preposition", "non-entailment", lex_prep_templates),
    ("lexical_overlap", "ln_relative_clause", "non-entailment", lex_rc_templates),
    ("lexical_overlap", "ln_passive", "non-entailment", lex_pass_templates),
    ("lexical_overlap", "ln_conjunction", "non-entailment", lex_conj_templates),
    # Entailing templates.
    ("lexical_overlap", "le_relative_clause", "entailment", lex_rc_ent_templates),
    ("lexical_overlap", "le_around_prepositional_phrase", "entailment", lex_cross_pp_ent_templates),
    ("lexical_overlap", "le_around_relative_clause", "entailment", lex_cross_rc_ent_templates),
    ("lexical_overlap", "le_conjunction", "entailment", lex_ent_conj_templates),
    ("lexical_overlap", "le_passive", "entailment", lex_ent_pass_templates),
]


####################################################################################
####################################################################################


SUBCASES = tuple(t[1] for t in template_list)
SUBCASES_NE = tuple(t[1] for t in template_list if t[2] == 'non-entailment')
SUBCASES_YE = tuple(t[1] for t in template_list if t[2] == 'entailment')

TEMPLATES_BY_NAME = {
    template[1][2]: template[1]
    for t in template_list for template in t[3]
}

TEMPLATE_TO_LABEL = {
    template[1][2]: t[2]
    for t in template_list for template in t[3]
}

TEMPLATES = tuple(TEMPLATE_TO_LABEL.keys())
TEMPLATES_NE = tuple(k for k, v in TEMPLATE_TO_LABEL.items() if v == 'non-entailment')
TEMPLATES_YE = tuple(k for k, v in TEMPLATE_TO_LABEL.items() if v == 'entailment')


####################################################################################

def get_subcases(label_only: Optional[str] = None) -> Tuple[str, ...]:
    if label_only is None:
        return SUBCASES
    elif label_only in (True, 1, 'ne', 'non-entailment'):
        return SUBCASES_NE
    elif label_only in (False, 'ye', 'entailment'):
        return SUBCASES_YE
    else:
        raise ValueError(label_only)


def get_templates(label_only: Optional[str] = None) -> Tuple[str, ...]:
    if label_only is None:
        return TEMPLATES
    elif label_only in (True, 1, 'ne', 'non-entailment'):
        return TEMPLATES_NE
    elif label_only in (False, 'ye', 'entailment'):
        return TEMPLATES_YE
    else:
        raise ValueError(label_only)
