R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=3 python -i em/projects/pi/exps/mains/snli_tuned_ablations_03.py
"""
import dataclasses
from importlib import reload
import random
import os
from typing import Tuple

import matplotlib.pyplot as plt
import seaborn as sns

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.tools.nmf import nmf_common
from em.util import hf_util

from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf

from em.projects.pi import binary_ablation_experiment as BAE
from em.projects.pi import qqp_components_context as QCC
from em.projects.pi import qqp_merging_context as QMC
from em.projects.pi import scitail_ablations

from em.projects.pi.exps import ablation_exp_util

##########################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/pi1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

##########################################################################

TOKENIZER = 'bert-base-uncased'
tokenizer = AutoTokenizer.from_pretrained(TOKENIZER)

##########################################################################

MODEL_NUMBER = 0

MODEL = f"connectivity/feather_berts_{MODEL_NUMBER}"

PEF_FILENAME = f"feather_berts_{MODEL_NUMBER}.snli_train.all_vars.50000ex.65536.h5"
# NMF_FILENAME = f"spH.nmf_decomp2.c{512}_1250Iters_{65536}pe_mvpp{10}_{50000}ex.{PEF_FILENAME}"
NMF_FILENAME = f"refit_w.spH.nmf_decomp2.c{512}_1250Iters_{65536}pe_mvpp{10}_{50000}ex.{PEF_FILENAME}"

FISHER_FILENAME = f"feather_berts_{MODEL_NUMBER}.mnli_snli_train.all_vars.{50000}ex.h5"

##########################################################################

hacc = QCC.QqpComponentContext(
    model_name_pattern=MODEL,
    pef_filepath_pattern=os.path.join(PER_EXAMPLES_FISHERS_DIR, PEF_FILENAME),
    nmf_filepath_pattern=os.path.join(PER_EXAMPLES_FISHERS_DIR, NMF_FILENAME),
    tokenizer=tokenizer,
    special_processing='HF_MNLI',
)
mc = hacc.make_model_context('a')

exp = ablation_exp_util.Experiment1(
    mc=mc,
    retaining_fisher=diagonal.DiagonalFisher.load(os.path.join(FISHERS_DIR, FISHER_FILENAME)).fishers,
)

##########################################################################

eval_ctx = mc.get_evaluation_context()

##########################################################################

# COMP_INDEX = 7
# COMP_INDEX = 354
# COMP_INDEX = 117

# COMP_INDEX = 216
# COMP_INDEX = 136
# COMP_INDEX = 474
# COMP_INDEX = 42
# COMP_INDEX = 409
# COMP_INDEX = 240
# COMP_INDEX = 333
# COMP_INDEX = 378
# COMP_INDEX = 32
# COMP_INDEX = 5
# COMP_INDEX = 131
# COMP_INDEX = 412
COMP_INDEX = 222

# N_EVAL = 1024
N_EVAL = 2 * 1024
# N_EVAL = 8 * 1024

evaluation_example_inds = exp.random_example_indices(N_EVAL)

sign_guide = [tf.random.normal(v.shape) for v in exp.retaining_variables]

##########################################################################


def moving_average(a, n=3) :
    ret = np.cumsum(a, dtype=float)
    ret[n:] = ret[n:] - ret[:-n]
    return ret[n - 1:] / n


def kl_fn(model):
    kl = eval_ctx.evaluate(model, evaluation_example_inds).kl()
    print(kl)
    return kl


reload(ablation_exp_util)

targeter = ablation_exp_util.KlRangeTargeter(
    exp=exp,
    sign_guide=sign_guide,
    kl_fn=kl_fn,
    # kl_range=[.001, .01],
    # kl_range=[.025, .075],
    # kl_range=[.075, .175],
    kl_range=[.15, .25],
    delta_mag_range=[1e-5, 3],
)

kl_model = targeter.search(COMP_INDEX, max_iters=25)


#


real_evaluation_example_inds = exp.random_example_indices(16 * 1024)

eval_results = eval_ctx.evaluate(kl_model, real_evaluation_example_inds)
inds_by_kl = eval_results.indices_ordered_by_kl()


coeffs = []
kls = []
for _ind in inds_by_kl:
    kl = eval_results.kl_for_examples([_ind])
    ind = real_evaluation_example_inds[_ind]
    #
    kls.append(kl)
    coeffs.append(exp.W[ind, COMP_INDEX])
    # coeffs.append(exp.W[ind, 352])

coeffs = np.array(coeffs)
kls = np.array(kls)

# inds = np.argsort(coeffs)
# kls = kls[inds]
# coeffs = coeffs[inds]

# plot_kls = moving_average(kls, 768)

# plt.plot(coeffs[768 - 1:], plot_kls, )
# plt.show()


plt.plot(coeffs, kls, '.')
plt.show()


# n_bins = 10
# max_coeff = coeffs.max()
# inds_by_bins = []
# mean_coeffs = []
# for i in range(n_bins):
#     bin_min_coeff = i * max_coeff / n_bins
#     bin_max_coeff = (i + 1) * max_coeff / n_bins
#     mean_coeffs.append((bin_max_coeff + bin_min_coeff) / 2)
#     inds_by_bins.append(np.nonzero((bin_min_coeff <= coeffs) & (coeffs <= bin_max_coeff))[0])

# mean_kls = []
# for inds in inds_by_bins:
#     mean_kls.append(kls[inds].mean())


# plt.plot(mean_coeffs, mean_kls)
# plt.show()



# TODO: Something with bin min width.
n_bins = 8
# n_bins = 128
sorted_inds = np.argsort(coeffs)
mean_coeffs = []
mean_kls = []
for i in range(n_bins):
    assert len(sorted_inds) % n_bins == 0, "TODO: Support this"
    chunk_size = len(sorted_inds) // n_bins
    inds = sorted_inds[i * chunk_size : (i + 1) * chunk_size]
    mean_kls.append(kls[inds].mean())
    mean_coeffs.append(coeffs[inds].mean())


plt.plot(mean_coeffs, mean_kls)
plt.show()




# Fit the coeffs of the data used to learn the data to the NMF and
# see if the tunings/ablations are sharper.
