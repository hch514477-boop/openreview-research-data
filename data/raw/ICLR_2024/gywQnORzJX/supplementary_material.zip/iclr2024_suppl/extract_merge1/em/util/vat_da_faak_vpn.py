"""Fixes issue with HuggingFace hanging/taking forever when using a VPN.

The issue is that socket.getaddrinfo returns IPv6 addresses in addition
to IPv4 addresses when using the VPN. Without the VPN, it returns just
IPv4. The https request hangs when we connect to the HuggingFace IPv6
address, so this code makes sure that socket.getaddrinfo returns only
IPv4 addresses.

Import this file before calling only code, and it should allow HuggingFace
to be used while using a VPN. If disabling IPv6 addresses leads to
issues with other libraries, then the best solution would be to create
a context manager that disables IPv6 addresses only when in context.
"""

import socket


def _getaddrinfo_ipv4_only(*args, **kwargs):
    # AddressFamily.AF_INET means IPv4.
    return [
        item
        for item in _og_getaddrinfo(*args, **kwargs)
        if item[0] == socket.AddressFamily.AF_INET
    ]


_og_getaddrinfo = socket.getaddrinfo
socket.getaddrinfo = _getaddrinfo_ipv4_only
