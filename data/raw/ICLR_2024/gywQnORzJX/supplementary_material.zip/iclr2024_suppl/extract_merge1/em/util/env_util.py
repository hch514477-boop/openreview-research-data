"""Utilities related to the execution environment."""
import os


def on_fruit() -> bool:
    return os.path.exists('/fruitbasket')
