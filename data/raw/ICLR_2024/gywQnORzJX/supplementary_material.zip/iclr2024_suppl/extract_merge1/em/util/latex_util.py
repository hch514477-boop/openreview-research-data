"""Utilities for when I am writing out LaTeX."""
from typing import Optional


def escape(s: str) -> str:
    # Escape characters with special meaning in LaTeX.
    s = s.replace('{', R'TEMPBACKSLASHFNDSSKFNSDKNG{')
    s = s.replace('}', R'TEMPBACKSLASHFNDSSKFNSDKNG}')

    s = s.replace('\\', R'\textbackslash{}')
    s = s.replace('%', R'\%{}')
    s = s.replace('$', R'\${}')
    s = s.replace('_', R'\_{}')
    s = s.replace('^', R'\^{}')

    # Annoying unicode stuff.
    s = s.replace('“', R'"')
    s = s.replace('’', R"'")
    s = s.replace('–', R"-")

    # Finish up doing this hack.
    s = s.replace('TEMPBACKSLASHFNDSSKFNSDKNG', '\\')

    return s


def rpad_curly(s: str, length: int, s_length: Optional[int] = None):
    # Does not take into account characters in the PDF that
    # are written with multiple characters in the LaTeX (e.g.
    # escape sequences, curly brackets). Use s_length to handle this.
    len_s = s_length if s_length is not None else len(s)
    n_to_add = max(0, length - len_s)
    return s + (n_to_add * ' {}')
