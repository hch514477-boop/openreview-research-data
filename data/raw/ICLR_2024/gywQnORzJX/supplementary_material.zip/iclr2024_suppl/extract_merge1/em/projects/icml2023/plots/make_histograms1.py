R"""Make histograms of log2 ratios


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1

python3 em/projects/icml2023/plots/make_histograms1.py


"""
import os

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from em.projects.icml2023.data import ratios


def plot(values, x_type: str, filename: str, color: str = 'green'):
    values = np.log2(values)
    n_bins = 20
    plt.rcParams["figure.figsize"] = (6, 2.5)

    fig, ax = plt.subplots()

    # plt.title(title)
    ax.hist(
        values,
        n_bins,
        color=color,
        alpha=0.7,
    )
    ax.set_xlabel(f'Log_2 {x_type} Ratio')
    ax.set_ylabel('Count')
    fig.tight_layout()

    filename = f'{filename}.pdf'
    filepath = os.path.join(SAVE_DIR, filename)

    # plt.show()
    fig.savefig(filepath)
    plt.close(fig)


SAVE_DIR = os.path.expanduser('~/Desktop/projects_data/extract_merge1/paper1_imgs/histograms')


# NLP
plot(ratios.NLP['H']['top_top'], 'KL', 'nlp_H_top_top')
plot(ratios.NLP['H']['rand_rand'], 'KL', 'nlp_H_rand_rand')
plot(ratios.NLP['H']['rand_top'], 'KL', 'nlp_H_rand_top')

plot(ratios.NLP['ex']['top'], 'KL', 'nlp_ex_top')
plot(ratios.NLP['ex']['rand'], 'KL', 'nlp_ex_rand')

plot(ratios.NLP['norm'], 'PEF Norm', 'nlp_norm', 'purple')


# Vision
plot(ratios.VISION['H']['top_top'], 'KL', 'vision_H_top_top')
plot(ratios.VISION['H']['rand_rand'], 'KL', 'vision_H_rand_rand')
plot(ratios.VISION['H']['rand_top'], 'KL', 'vision_H_rand_top')

plot(ratios.VISION['norm'], 'PEF Norm', 'vision_norm', 'purple')
