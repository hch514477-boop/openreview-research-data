"""Stuff dealing with generation of examples."""
