"""Utilities for the run_guided_kl_ablations.py script."""
from em.projects.pi.exps import guided_ablations


ABLATION_EXP_TYPES = ('component_examples', 'component_examples_H',
                      'random_examples', 'random_examples_H')

SUPPORTED_IMAGE_EXP_TYPES = ('component_examples_H', 'random_examples_H')


# For now, these just mirror what I did for the SNLI experiments.
OutputForAblator = guided_ablations.OutputForAblator
OutputForComponent = guided_ablations.OutputForComponent
