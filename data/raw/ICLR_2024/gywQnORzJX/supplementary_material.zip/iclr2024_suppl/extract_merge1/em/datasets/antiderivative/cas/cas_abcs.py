"""Abstract base classes and iterfaces for CASes."""
import abc
from typing import Optional, Union

from ..misc_util import timeout, TimeoutError


class CasAbc(abc.ABC):

    def has_elementary_antiderivative(
            self, expr, d_variable, seconds: Optional[float] = None) -> Union[bool, None]:
        f = self._has_elementary_antiderivative
        if seconds is not None:
            f = timeout(seconds)(f)
        try:
            return f(expr, d_variable)

        except TimeoutError:
            return None

    @abc.abstractmethod
    def _has_elementary_antiderivative(self, expr, d_variable) -> Union[bool, None]:
        # Has the option of returning a None if it cannot tell. It is up
        # to the user to do with they will with that information.
        raise NotImplementedError
