"""Patterns for generating expressions that (probably) don't have elementary antiderivates."""
import sympy as sp


ASDF = [
    'exp(Rational(NotLinear, x))',
    'exp(x) / Poly(NotConstant, x)',
    # exp(exp(x)) stuff
    '(Poly(x) + exp(x)) / (Poly(x) + exp(x))',  # Unless the numerator poly is derivative of denom poly.
    #
    'log(x)*exp(x)',
    'exp(x)/log(x)',
    'log(x)/exp(x)',
    #
    'exp(sqrt(log(x)))',
    #
    'exp(sin(x))',
    'exp(cos(x))',
    'exp(tan(x))',
    #
    'exp(asin(log(x)))',
    'exp(acos(log(x)))',
    'exp(atan(log(x)))',
    #
    'exp(atan(x))',
]
