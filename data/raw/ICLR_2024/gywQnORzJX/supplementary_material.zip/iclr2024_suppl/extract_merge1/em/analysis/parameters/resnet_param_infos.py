"""Parameter informations for ResNets."""
import dataclasses

