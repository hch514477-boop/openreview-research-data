"""Stuff about getting extra information about a sympy expression."""
import dataclasses
from typing import Optional

import sympy as sp

from . import function_types
from . import matching

# Think about "appearance" (ie the string literal) vs the abstract expression itself.
# Within in reason though, (ie no non-trivial simplifications of expressions).

# # I think most of these can be considered "abstract".
# expr.is_algebraic_expr(x)
# expr.is_constant(x)
# expr.is_polynomial(x)
# expr.is_rational_function(x)

###################################################################################


@dataclasses.dataclass
class Metadata:

    transcendence_level: Optional[str] = None

    contains_nan_like: Optional[bool] = None

    has_repeated_number: Optional[bool] = None

    ##################################################

    @property
    def is_constant(self):
        return self.transcendence_level and self.transcendence_level == 'constant'
    
    @property
    def is_polynomial(self):
        return self.transcendence_level and self.transcendence_level in ('constant', 'polynomial')

    @property
    def is_rational(self):
        return self.transcendence_level and self.transcendence_level in ('constant', 'polynomial', 'rational')

    @property
    def is_algebraic(self):
        return self.transcendence_level and self.transcendence_level in ('constant', 'polynomial', 'rational', 'algebraic')

    ##################################################

    @property
    def is_strictly_constant(self):
        return self.transcendence_level and self.transcendence_level == 'constant'
    
    @property
    def is_strictly_polynomial(self):
        return self.transcendence_level and self.transcendence_level == 'polynomial'

    @property
    def is_strictly_rational(self):
        return self.transcendence_level and self.transcendence_level == 'rational'

    @property
    def is_strictly_algebraic(self):
        return self.transcendence_level and self.transcendence_level == 'algebraic'

    @property
    def is_strictly_transcendental(self):
        return self.transcendence_level and self.transcendence_level == 'transcendental'

###################################################################################


# NOTE: IDK if there is a better term for this.
# 
# Ordered in increasing level of generality. If i <= j,
# then all members of TRANSCENDENCE_CLASSES[i] are members of
# TRANSCENDENCE_CLASSES[j]. Thus functions deemed transcedental
# can contain algebraic operations like rational-valued exponents.
TRANSCENDENCE_LEVELS = (
    'constant',
    'polynomial',
    'rational',
    'algebraic',
    'transcendental',
)


def get_transcendence_level(expr: sp.Expr, x: sp.Symbol) -> str:
    if expr.is_constant(x):
        return 'constant'
    elif expr.is_polynomial(x):
        return 'polynomial'
    elif expr.is_rational_function(x):
        return 'rational'
    elif expr.is_algebraic_expr(x):
        return 'algebraic'
    else:
        return 'transcendental'


######################################################

def contains_nan_like(expr: sp.Expr) -> bool:
    return expr.has(sp.oo, -sp.oo, sp.zoo, sp.nan)

######################################################


def has_repeated_number(expr: sp.Expr, min_value: int = 10):
    # Given our generation technique, this usually indicates that some
    # factorization has been expanded.
    numbers = set()
    for node in sp.preorder_traversal(expr):
        if not isinstance(node, sp.Number) or abs(node) < min_value:
            continue
        value = abs(node)
        if value in numbers:
            return True
        numbers.add(value)
    return False


######################################################

# repeated "biggish" number. (indicates factoring)
# term shared by numerator/denomiator.
# stuff like f(inv_f(...))

# exp-like, log-like
# exp-like(log-like(...)) [& vice versa]
# exp-like(exp-like(...))

# Most specific statistically signifcant fraction matched?

# trancental constants
# rational fn with trancendtal constants
# algebraic contatins
# algebraic & trancendtal constants

# direct/indirect power of fn
# x^a fn(x^b)

# Unrelated, but show cumulative fraction of fisher mass by layer?
