"""Context for decomposition of PAWS components."""
import dataclasses
import itertools
import os
import re
from typing import Optional

import numpy as np
import tensorflow as tf
from transformers import PreTrainedTokenizer

from em import datasets as em_datasets
from em.fishers import per_example
from em.tools.nmf import lrm_npeff

from em.projects.pi import qqp_components_context as QCC


###############################################################################

@dataclasses.dataclass
class PawsExample:
    # TODO: Add more info.
    index: int

    sentence1: str
    sentence2: str

    label: int


@dataclasses.dataclass
class PawsContext:
    """Context for LRM-NPEFF decomposition over PAWS examples."""
    split: str

    tokenizer: PreTrainedTokenizer

    nmf: lrm_npeff.LrmNpeffDecomposition

    # If we are not using the examples, then this is faster.
    load_examples: bool = True
