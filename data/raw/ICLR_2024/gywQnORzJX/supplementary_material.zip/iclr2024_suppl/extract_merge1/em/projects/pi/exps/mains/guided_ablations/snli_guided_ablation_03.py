R"""
cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python -i em/projects/pi/exps/mains/guided_ablations/snli_guided_ablation_03.py
"""

import dataclasses
from importlib import reload
import random
import os
from typing import Sequence, Tuple

from em.util import vat_da_faak_vpn

import matplotlib.pyplot as plt
import seaborn as sns

import numpy as np
from sklearn.feature_selection import mutual_info_regression
from scipy import stats

import tensorflow as tf
from tqdm import tqdm
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em import datasets as em_datasets
from em.evaluation import tf_metrics
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.tools.nmf import nmf_common
from em.util import hf_util
from em.util import sparse_util

from em.perturbations import examples_context
from em.perturbations import h_to_fishers
from em.perturbations import kl_targeter
from em.perturbations import mm_perturbations
from em.perturbations import perturbation_exp_util as pe_util

from em.projects.pi.exps import ablation_exp_util
from em.projects.pi.exps import coeff_kl_relationship_util

from em.projects.pi.exps import guided_ablations
from em.util.color_util import cu

OutputForAblator = guided_ablations.OutputForAblator
OutputForComponent = guided_ablations.OutputForComponent
KlSelectivityInfo = guided_ablations.KlSelectivityInfo

##########################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/pi1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

##########################################################################

RESULTS_DIR = f'{EXPS_DIR}/guided_kl_ablations/attempt01_03'

##########################################################################


def geometric_mean_ratios(infos: Sequence[KlSelectivityInfo]):
    return stats.gmean([info.ratio() for info in infos])


def do_it(results_dir, k: int):
    rows = []
    #
    for filename in os.listdir(results_dir):
        print(filename)
        filepath = os.path.join(results_dir, filename)
        results = OutputForComponent.load(filepath)
        #
        # 
        comp_H_kl_ratio = geometric_mean_ratios(results.get_component_H_kl_selectivities())
        top_ex_dsf_kl_ratio = geometric_mean_ratios(results.get_component_top_fisher_kl_selectivities())
        # 
        rows.append([
            results.component_index,
            #
            comp_H_kl_ratio,
            top_ex_dsf_kl_ratio,
        ])
    return list(sorted(rows, key=lambda r: r[0]))

##########################################################################


# "
# "
# # TODO: Need to do things where I filter out the runs where the KL search did not work.
# "
# "


rows = do_it(RESULTS_DIR, k=128)

for r in rows:
    print(', '.join(str(c) for c in r))
