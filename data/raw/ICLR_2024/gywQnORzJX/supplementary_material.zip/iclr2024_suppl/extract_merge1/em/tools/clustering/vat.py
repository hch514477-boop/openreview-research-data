"""Visual assessment of tendency (VAT).

Tool permuting the rows/columns of a dissimilarity matrix
(e.g. 1 - [cos sim matrix]) to reveal structure.


This is pretty much copy-pasted from the `pyclustertend` package. Annoyingly,
they don't let you operate directly on the dissimilarity matrix and
only operate on the dataset.

Links:
    https://www.researchgate.net/publication/3950332_VAT_A_tool_for_visual_assessment_of_cluster_tendency

Paper with general information about matrix reordering:
    https://bib.dbvis.de/uploadedFiles/MatrixReorderingSTAR.pdf
"""
import numpy as np


def vat_reorder_dissimilarity_matrix(X: np.ndarray):
    """Reorders the dissimilarity matrix according to VAT.

    Args:
        X: dissimilarity matrix, should be a square symmetric matrix.
    """

    # Step 1 :

    observation_path = []

    matrix_of_pairwise_distance = X
    list_of_int = np.zeros(matrix_of_pairwise_distance.shape[0], dtype="int")

    index_of_maximum_value = np.argmax(matrix_of_pairwise_distance)

    column_index_of_maximum_value = index_of_maximum_value // matrix_of_pairwise_distance.shape[1]

    list_of_int[0] = column_index_of_maximum_value
    observation_path.append(column_index_of_maximum_value)

    K = np.linspace(0, matrix_of_pairwise_distance.shape[0] - 1, matrix_of_pairwise_distance.shape[0], dtype="int")
    J = np.delete(K, column_index_of_maximum_value)

    # Step 2 :

    for r in range(1, matrix_of_pairwise_distance.shape[0]):

        p, q = (-1, -1)

        mini = np.max(matrix_of_pairwise_distance)

        for candidate_p in observation_path:
            for candidate_j in J:
                if matrix_of_pairwise_distance[candidate_p, candidate_j] < mini:
                    p = candidate_p
                    q = candidate_j
                    mini = matrix_of_pairwise_distance[p, q]

        list_of_int[r] = q
        observation_path.append(q)

        ind_q = np.where(np.array(J) == q)[0][0]
        J = np.delete(J, ind_q)

    # Step 3

    ordered_matrix = np.zeros(matrix_of_pairwise_distance.shape)

    for column_index_of_maximum_value in range(ordered_matrix.shape[0]):
        for j in range(ordered_matrix.shape[1]):
            ordered_matrix[column_index_of_maximum_value, j] = matrix_of_pairwise_distance[
                list_of_int[column_index_of_maximum_value], list_of_int[j]]

    # Step 4 :

    # I think list_of_int is the permutation.
    return ordered_matrix, list_of_int


def ivat_reorder_dissimilarity_matrix(X):
    """Reorders the dissimilarity matrix according to iVAT.

    Looks like the returned matrix might not just be a reordering of the input matrix.

    Args:
        X: dissimilarity matrix, should be a square symmetric matrix.
    """

    ordered_matrix, _ = vat_reorder_dissimilarity_matrix(X)
    re_ordered_matrix = np.zeros((ordered_matrix.shape[0], ordered_matrix.shape[0]))

    for r in range(1, ordered_matrix.shape[0]):
        # Step 1 : find j for which D[r,j] is minimum and j in [1:r-1]

        j = np.argmin(ordered_matrix[r, 0:r])

        # Step 2 :

        re_ordered_matrix[r, j] = ordered_matrix[r, j]

        # Step 3 : pour c : 1,r-1 avec c !=j
        c_tab = np.array(range(0, r))
        c_tab = c_tab[c_tab != j]

        for c in c_tab:
            re_ordered_matrix[r, c] = max(ordered_matrix[r, j], re_ordered_matrix[j, c])
            re_ordered_matrix[c, r] = re_ordered_matrix[r, c]

    return re_ordered_matrix
