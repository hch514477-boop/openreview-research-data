"""Utilities for stuff vaguely related to plotting."""
from typing import Optional

import numpy as np


def bin_data(x: np.ndarray, n_bins: int, bin_style: str):
    assert bin_style in ('width', 'contents')

    if bin_style == 'contents':
        inds = np.argsort(x)
