R"""Script to set up and convert the default pretrained weights to something we use.


Run the following to download the pretrained weights:
    wget ftp://ftp.cs.huji.ac.il/users/nadavb/protein_bert/epoch_92400_sample_23500000.pkl


python3 -i em/models/protein_bert/scripts/set_up_default_pretrained_weights.py

"""
import pickle

# from em.models.protein_bert import pb_models
from em.models.protein_bert import pb_checkpoint
from em.models.protein_bert import pb_weights_loading

###############################################################################

filepath = '/tmp/epoch_92400_sample_23500000.pkl'

with open(filepath, 'rb') as f:
    n_annotations, model_weights, optimizer_weights = pickle.load(f)
    del n_annotations, optimizer_weights

# model_weights is list of np.ndarrays
###############################################################################

outpath = '~/Desktop/projects_data/extract_merge1/pb/weights/default_protein_bert_body.h5'

ckpt = pb_checkpoint.CheckpointData(
    body_config=pb_weights_loading.DEFAULT_BODY_CONFIG,
    body_weights=model_weights,
)
ckpt.save(outpath)
