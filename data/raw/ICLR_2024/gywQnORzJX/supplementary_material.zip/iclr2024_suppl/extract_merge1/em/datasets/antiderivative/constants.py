"""Constants."""
import sympy as sp


ELEMENTARY_SP_OPERATORS = {
    # Elementary functions
    sp.Add: 'add',
    sp.Mul: 'mul',
    sp.Pow: 'pow',
    sp.exp: 'exp',
    sp.log: 'ln',
    sp.Abs: 'abs',
    sp.sign: 'sign',

    # Trigonometric Functions
    sp.sin: 'sin',
    sp.cos: 'cos',
    sp.tan: 'tan',
    sp.cot: 'cot',
    sp.sec: 'sec',
    sp.csc: 'csc',

    # Trigonometric Inverses
    sp.asin: 'asin',
    sp.acos: 'acos',
    sp.atan: 'atan',
    sp.acot: 'acot',
    sp.asec: 'asec',
    sp.acsc: 'acsc',

    # Hyperbolic Functions
    sp.sinh: 'sinh',
    sp.cosh: 'cosh',
    sp.tanh: 'tanh',
    sp.coth: 'coth',
    sp.sech: 'sech',
    sp.csch: 'csch',

    # Hyperbolic Inverses
    sp.asinh: 'asinh',
    sp.acosh: 'acosh',
    sp.atanh: 'atanh',
    sp.acoth: 'acoth',
    sp.asech: 'asech',
    sp.acsch: 'acsch',
}


SYMPY_OPERATORS = {
    **ELEMENTARY_SP_OPERATORS,
    # # Derivative
    # sp.Derivative: 'derivative',
}


# Map from operator to arity.
OPERATOR_ARITIES = {
    # Elementary functions
    'add': 2,
    'sub': 2,
    'mul': 2,
    'div': 2,
    'pow': 2,
    'rac': 2,
    'inv': 1,
    'pow2': 1,
    'pow3': 1,
    'pow4': 1,
    'pow5': 1,
    'sqrt': 1,
    'exp': 1,
    'ln': 1,
    'abs': 1,
    'sign': 1,

    # Trigonometric Functions
    'sin': 1,
    'cos': 1,
    'tan': 1,
    'cot': 1,
    'sec': 1,
    'csc': 1,

    # Trigonometric Inverses
    'asin': 1,
    'acos': 1,
    'atan': 1,
    'acot': 1,
    'asec': 1,
    'acsc': 1,

    # Hyperbolic Functions
    'sinh': 1,
    'cosh': 1,
    'tanh': 1,
    'coth': 1,
    'sech': 1,
    'csch': 1,

    # Hyperbolic Inverses
    'asinh': 1,
    'acosh': 1,
    'atanh': 1,
    'acoth': 1,
    'asech': 1,
    'acsch': 1,

    # # Derivative
    # 'derivative': 2,

    # # custom functions
    # 'f': 1,
    # 'g': 2,
    # 'h': 3,
}

SUPPORTED_OPERATORS = frozenset(OPERATOR_ARITIES.keys())


DEFAULT_OPERATOR_WEIGHTS = {
    'add': 10,
    'sub': 3,
    'mul': 10,
    'div': 5,
    'sqrt': 4,
    'pow2': 4,
    'pow3': 2,
    'pow4': 1,
    'pow5': 1,
    'ln': 4,
    'exp': 4,
    'sin': 4,
    'cos': 4,
    'tan': 4,
    'asin': 1,
    'acos': 1,
    'atan': 1,
    'sinh': 1,
    'cosh': 1,
    'tanh': 1,
    'asinh': 1,
    'acosh': 1,
    'atanh': 1,
}


ALL_SYMPY_REWRITE_FUNCTIONS = ('expand', 'factor', 'expand_log', 'logcombine', 'powsimp', 'simplify')


INTEGRAL_FUNCS = frozenset({sp.erf, sp.erfc, sp.erfi, sp.erfinv, sp.erfcinv, sp.expint, sp.Ei, sp.li, sp.Li, sp.Si, sp.Ci, sp.Shi, sp.Chi, sp.fresnelc, sp.fresnels})
