"""Main class for doing perturbations."""
import dataclasses

import numpy as np

from em.fishers import per_example
from em.tools.nmf import nmf_common


###############################################################################

@dataclasses.dataclass
class Perturber:
    # pef: per_example.PerExampleFlatFishers
    nmf: nmf_common.SparseNmfDecomposition

    def __post_init__(self):
        pass
