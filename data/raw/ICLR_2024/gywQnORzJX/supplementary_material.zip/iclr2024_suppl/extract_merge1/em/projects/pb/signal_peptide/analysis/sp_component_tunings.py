"""Analysis code for quantifying component tunings."""
import numpy as np
import tensorflow as tf

from ..contexts import sp_npeff_context

SpExample = sp_npeff_context.SpExample
NpeffContext = sp_npeff_context.NpeffContext

##########################################################################


def get_component_tuned_for_positive_predictions(
    ctx: NpeffContext,
    n_top_examples: int,
    min_positive_top_examples: int,
) -> np.ndarray:
    assert min_positive_top_examples <= n_top_examples

    tuned_indices = []
    for component_index in range(ctx.n_components):
        top_examples = ctx.get_top_examples(component_index, n_top_examples)
        n_positive = sum(ex.prediction != 0 for ex in top_examples)
        if n_positive >= min_positive_top_examples:
            tuned_indices.append(component_index)

    return np.array(tuned_indices, dtype=np.int32)
