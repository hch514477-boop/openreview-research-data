"""Class representing an example."""
from typing import Mapping

import sympy as sp
from sympy.parsing.sympy_parser import parse_expr

from em.datasets.antiderivative import expression_metadata as emd


class Example:

    @classmethod
    def from_str(cls, expr_str: str, local_dict: Mapping[str, sp.Variable]):
        expr = parse_expr(expr_str, evaluate=True, local_dict=local_dict)
        return cls(expr)

    def __init__(self, expr: sp.Expr, x: sp.Variable):
        if isinstance(expr, str):
            expr = parse_expr(expr, evaluate=True, local_dict={x.name: x})
        assert isinstance(expr, sp.expr)

        self.expr = expr
        self.x = x

    def get_transcendence_level(self) -> str:
        # See emd.TRANSCENDENCE_LEVELS for possible return values.
        return emd.get_transcendence_level(self.expr, self.x)

    def contains_nan_like(self) -> bool:
        return emd.contains_nan_like(self.expr)
