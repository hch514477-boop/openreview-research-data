R"""Interface to the pyDNMFk library.

https://github.com/lanl/pyDNMFk


/fruitbasket/users/m/other_code/pyDNMFk
"""

# # Use "mpirun -n 4 python -m code.py" to run this example
# from pyDNMFk.runner import pyDNMFk_Runner
# import numpy as np

# runner = pyDNMFk_Runner(itr=100, init='nnsvd', verbose=True, 
#                         norm='fro', method='mu', precision=np.float32,
#                         checkpoint=False, sill_thr=0.6)

# # results = runner.run(grid=[4,1], fpath='/fruitbasket/users/m/other_code/pyDNMFk/data/', fname='wtsi', 
# #                      ftype='mat', results_path='/fruitbasket/users/m/tmp/',
# #                      k_range=[1,3], step_k=1)

# results = runner.run(grid=[1,1], fpath='/fruitbasket/users/m/other_code/pyDNMFk/data/', fname='wtsi', 
#                      ftype='mat', results_path='/fruitbasket/users/m/tmp/',
#                      k_range=[1,3], step_k=1)
# W = results["W"]
# H = results["H"]

'''Imports block'''

import sys
import pyDNMFk.config as config
config.init(0)
from pyDNMFk.pyDNMFk import *
from pyDNMFk.data_io import *
from pyDNMFk.dist_comm import *
from scipy.io import loadmat
from mpi4py import MPI
comm = MPI.COMM_WORLD
args = parse()


'''parameters initialization block'''


# Data Read here
args.fpath = '/fruitbasket/users/m/other_code/pyDNMFk/data/'
args.fname = 'wtsi'
args.ftype = 'mat'
args.precision = np.float32

#Distributed Comm config block
p_r, p_c = 96, 21

#NMF config block
args.norm = 'kl'
args.method = 'mu'
args.init = 'nnsvd'
args.itr = 5000
args.verbose = True

# #Cluster config block
# args.start_k = 1
# args.end_k = 1
# args.sill_thr = 0.9

args.k = 4

#Data Write
args.results_path = '/fruitbasket/users/m/tmp/'


'''Parameters prep block'''


comms = MPI_comm(comm, p_r, p_c)
comm1 = comms.comm
rank = comm.rank
size = comm.size
args.size, args.rank, args.comm, args.p_r, args.p_c = size, rank, comms, p_r, p_c
args.row_comm, args.col_comm, args.comm1 = comms.cart_1d_row(), comms.cart_1d_column(), comm1
A_ij = data_read(args).read().astype(args.precision)

nopt = PyNMF(A_ij, factors=None, params=args).fit()
print('Estimated k with NMFk is ',nopt)