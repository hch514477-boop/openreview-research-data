"""Code for loading pretrained weights.

Environment variables:
    PROTEIN_BERT_MODELS_DIR: Directory to save pretrained weights to.

"""
import os

import tensorflow as tf

from . import pb_vocab
from . import pb_models

###############################################################################

# DEFAULT_PROTEIN_BERT_MODELS_DIR = '~/.protein_bert_models'
# DEFAULT_LOCAL_MODEL_DUMP_FILE_NAME = 'epoch_92400_sample_23500000.pkl'

# DEFAULT_REMOTE_MODEL_DUMP_URL = 'ftp://ftp.cs.huji.ac.il/users/nadavb/protein_bert/epoch_92400_sample_23500000.pkl'

###############################################################################

_DEFAULT_BODY_CONFIG_KWARGS = {
    'vocab_size': pb_vocab.DEFAULT_TOKENIZER.vocab_size,
    'd_hidden_seq': 128,
    'd_hidden_global': 512,
    'n_blocks': 6,
    'n_heads': 4,
    'd_key': 64,
    'conv_kernel_size': 9,
    'wide_conv_dilation_rate': 5,
    'activation': 'gelu',
}

DEFAULT_BODY_CONFIG = pb_models.BodyConfig(**_DEFAULT_BODY_CONFIG_KWARGS)

###############################################################################

# _KNOWN_MODEL_NAMES = {
#     'pretrained': DEFAULT_REMOTE_MODEL_DUMP_URL
# }
