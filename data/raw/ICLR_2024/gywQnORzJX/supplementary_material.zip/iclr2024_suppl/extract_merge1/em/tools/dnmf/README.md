# Interface to pyDNMFk

This directory contains documentation and code for setting up and interacting
with the [pyDNMFk](https://github.com/lanl/pyDNMFk) library.

## Installation

Here is what I did on the Raffel server.

### Open-MPI

We will need to build and install CUDA-aware OpenMPI.
https://github.com/openucx/ucx/wiki/OpenMPI-and-OpenSHMEM-installation-with-UCX
https://www.open-mpi.org/faq/?category=buildcuda
https://www.open-mpi.org/faq/?category=runcuda

#### Installing gdrcopy

```bash
OTHER_CODE_DIR=/fruitbasket/users/m/other_code
CUDA_DIR=/usr/local/cuda
GDRCOPY_DIR=/usr/local/gdrcopy

cd $OTHER_CODE_DIR
git clone https://github.com/NVIDIA/gdrcopy.git
cd $OTHER_CODE_DIR/gdrcopy

# sudo apt install check libsubunit0 libsubunit-dev

sudo make prefix=$GDRCOPY_DIR CUDA=$CUDA_DIR all install
sudo ./insmod.sh
```

#### Installing UCX
```bash
OTHER_CODE_DIR=/fruitbasket/users/m/other_code
UCX_DIR=/usr/local/openucx
GDRCOPY_DIR=/usr/local/gdrcopy

cd $OTHER_CODE_DIR
git clone https://github.com/openucx/ucx.git ucx
cd $OTHER_CODE_DIR/ucx

./autogen.sh
./contrib/configure-release --prefix=$UCX_DIR --with-gdrcopy=$GDRCOPY_DIR
make -j8
sudo make install
```

#### Installing OpenMPI
```bash
OTHER_CODE_DIR=/fruitbasket/users/m/other_code
CUDA_DIR=/usr/local/cuda
GDRCOPY_DIR=/usr/local/gdrcopy
UCX_DIR=/usr/local/openucx

MPI_DIR=/fruitbasket/users/m/openmpi

cd $OTHER_CODE_DIR
wget https://download.open-mpi.org/release/open-mpi/v4.1/openmpi-4.1.4.tar.bz2
tar -xf openmpi-4.1.4.tar.bz2
rm openmpi-4.1.4.tar.bz2
cd $OTHER_CODE_DIR/openmpi-4.1.4

./configure  --prefix=$MPI_DIR --with-cuda=$CUDA_DIR --with-ucx=$UCX_DIR
# ./configure --with-cuda # --with-ucx=$UCX_DIR
sudo make -j8 install
# sudo make -j8
# sudo make install

# /usr/local/lib/openmpi
# export LD_LIBRARY_PATH=/usr/local/lib/openmpi:$LD_LIBRARY_PATH

```


Check for cuda support.
```bash
MPI_DIR=/fruitbasket/users/m/openmpi

# ompi_info --parsable --all | grep mpi_built_with_cuda_support:value
$MPI_DIR/bin/ompi_info --parsable --all | grep mpi_built_with_cuda_support:value
```

<!-- # Interface to pyDNMFk

This directory contains documentation and code for setting up and interacting
with the [pyDNMFk](https://github.com/lanl/pyDNMFk) library.

## Installation

Here is what I did on the Raffel server.

### Single environment

```bash
# This is where I placed the code.
cd /fruitbasket/users/m/other_code

# This is from the pyDNMFk installation instructions.
git clone https://github.com/lanl/pyDNMFk.git
cd pyDNMFk
conda create --name pyDNMFk python=3.7.1 openmpi mpi4py
source activate pyDNMFk
python setup.py install
```

### Building and writing to channel

I am unfamiliar with conda, but I think this lets me use the pyDNMFk
library directly from other conda environments. We build it and write
to a channel on the file system.

The following assumes that I have the environment already set up as in
the "Single environment" section.

```bash
DNMF_DIR=/fruitbasket/users/m/other_code/pyDNMFk
CONDA_CHANNEL=/fruitbasket/users/m/conda_channel

cd $DNMF_DIR
source activate pyDNMFk
python setup.py build -c file:/$CONDA_CHANNEL

```

## Modification of pyDNMFk code

This is mostly a paste-bin of commands that I use.

### Open local code for editting
```bash
subl "$HOME/Desktop/other_code/pyDNMFk"
```

### Move local code to Raffel servers.
```bash
rsync -ra -e ssh \
    --exclude "*/__pycache__" \
    --exclude "*/.git" \
    "$HOME/Desktop/other_code/pyDNMFk/" \
    "m@banana.cs.unc.edu:/fruitbasket/users/m/other_code/pyDNMFk/"
``` -->

# Pytorch-NMF stuff

TODO: Move this documentation to the proper place.


<!-- ### Open local code for editting -->

<!-- I needed to change the `|=` operator to its constituent operations. -->
<!-- 
```bash
subl "$HOME/Desktop/other_code/pytorch-NMF"
```

### Move local code to Raffel servers.
```bash
rsync -ra -e ssh \
    --exclude "*/__pycache__" \
    --exclude "*/.git" \
    "$HOME/Desktop/other_code/pytorch-NMF/" \
    "m@banana.cs.unc.edu:/fruitbasket/users/m/other_code/pytorch-NMF/"
```

### Install on Raffel server
```bash
pip install /fruitbasket/users/m/other_code/pytorch-NMF
```
 -->


```bash
# pip install torch==1.6.0 --extra-index-url https://download.pytorch.org/whl/cu114
pip install --upgrade torch==1.11.0+cu113 -f https://download.pytorch.org/whl/torch_stable.html

```