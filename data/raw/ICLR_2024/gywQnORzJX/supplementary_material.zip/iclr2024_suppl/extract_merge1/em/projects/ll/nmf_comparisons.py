"""Code for comparing the components extracted by two different methods."""
from em.fishers import per_example
from em.tools.nmf import nmf_common


def parameter_space_cosine_similarities(nmf1, nmf2):
    H1 = nmf1.get_full_sparse_H()
    H2 = nmf2.get_full_sparse_H()
