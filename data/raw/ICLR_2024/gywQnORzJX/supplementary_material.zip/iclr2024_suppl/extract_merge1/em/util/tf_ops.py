# """Some ops implemented in tensorflow."""
# import tensorflow as tf


# # def quickselect(l, k, pivot_fn):
# #     """
# #     Select the kth element in l (0 based)
# #     :param l: List of numerics
# #     :param k: Index
# #     :param pivot_fn: Function to choose a pivot, defaults to random.choice
# #     :return: The kth element of l
# #     """
# #     if len(l) == 1:
# #         assert k == 0
# #         return l[0]

# #     pivot = pivot_fn(l)

# #     lows = [el for el in l if el < pivot]
# #     highs = [el for el in l if el > pivot]
# #     pivots = [el for el in l if el == pivot]

# #     if k < len(lows):
# #         return quickselect(lows, k, pivot_fn)
# #     elif k < len(lows) + len(pivots):
# #         # We got lucky and guessed the median
# #         return pivots[0]
# #     else:
# #         return quickselect(highs, k - len(lows) - len(pivots), pivot_fn)


# @tf.function
# def quick_select(x, k, mask: tf.Variable):
#     # For now, we assume that x only has a single dimension.
#     mask.assign(tf.zeros_like(mask))

#     # mask-based approach
#     pass


# def top_k__quick_select():
#     pass