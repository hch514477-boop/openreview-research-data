"""Misc common tools and stuff for experimenting with Winograd stuff."""
import dataclasses
from typing import List, Optional, Sequence

import numpy as np

from em.projects.anli import anli_misc1 as am
from em.projects.anli import nli_example

# typedefs
NliExample = nli_example.NliExample
