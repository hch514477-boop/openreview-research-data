R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=0 python -i em/projects/neurips2023/compute_baseline_snli_acc.py



"""
import json
import os

import tensorflow as tf

from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em import datasets as em_datasets
from em.models import em_models


model = em_models.from_pretrained("connectivity/feather_berts_0", from_pt=True)
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")

ds = em_datasets.load(
    "snli/default",
    split="train_skip_50k",
    tokenizer=tokenizer,
    sequence_length=128,
)

ds = ds.map(lambda x, y: (x, (y + 1) % 3))

ds = ds.take(10000).batch(64)

model.compile(
    loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
    metrics=[tf.keras.metrics.SparseCategoricalAccuracy()],
)

_, acc = model.evaluate(ds)
print(f"Acc: {acc}")


# n_total_examples=10000
# train_skip_50k

"""

q = [0.794, 0.7876, 0.7767, 0.7849, 0.7863, 0.7777, 0.7942, 0.7824, 0.7779, 0.781, 0.7632, 0.7933, 0.7827, 0.7712, 0.7834, 0.743, 0.7816, 0.7802, 0.7866, 0.7865, 0.7649, 0.7885, 0.786, 0.7655, 0.7661, 0.7789, 0.7902, 0.7886, 0.7844, 0.78, 0.7945, 0.7942, 0.7852, 0.7777, 0.7854, 0.7666, 0.7757, 0.7873, 0.7847, 0.7742, 0.7805, 0.773, 0.7876, 0.7608, 0.7847, 0.7751, 0.7764, 0.7926 ]
"""