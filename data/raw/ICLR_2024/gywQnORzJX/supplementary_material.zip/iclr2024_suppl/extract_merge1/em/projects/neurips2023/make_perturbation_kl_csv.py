R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


python3 -i em/projects/neurips2023/make_perturbation_kl_csv.py



"""
import json
import os

from em.projects.m_npeff import perturbations

###############################################################################

JSON_DIR = os.path.expanduser("~/Desktop/projects_data/extract_merge1/neurips2023/perturbation_kl_jsons")


# JSON_NAME = "snli3og_lrm_npeff/kl_perturbations.feather_berts_0.train.50000ex.65536.mnpeff.512comps.001.fit_to_train_skip_50k.json"
# JSON_NAME = "snli3og_lrm_npeff/kl_perturbations.feather_berts_0.train.50000ex.65536.mnpeff.512comps.001.wrongs_only.expansion_001.no_full_joint.fit_to_train_skip_50k.json"

# JSON_NAME = "qqp_lrm_npeff2/kl_perturbations.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.json"
JSON_NAME = "qqp_lrm_npeff2/kl_perturbations.no_semiorth.bert_base_qqp_50k_holdout_4_epochs_01_epoch9.heldout_from_train.mnpeff.256comps.001.coeffs_fit_to_validation001.json"

# JSON_NAME = "imagenet2_lrm_npeff/kl_perturbations.resnet50_imagenet.train.20000ex.65536.mpc3e-3.mnpeff.512comps.001.fit_to_validation.001.json"
###############################################################################


output = perturbations.PmPerturbationExperimentOutput.load(os.path.join(JSON_DIR, JSON_NAME))

print(output.make_kl_ratios_csv_str())
