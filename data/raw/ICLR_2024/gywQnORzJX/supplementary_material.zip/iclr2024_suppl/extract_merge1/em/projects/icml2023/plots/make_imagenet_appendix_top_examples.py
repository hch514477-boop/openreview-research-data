R"""Makes the top example stuff to include in paper.


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python -i em/projects/icml2023/plots/make_imagenet_appendix_top_examples.py


rsync -ra -e ssh \
    "m@banana.cs.unc.edu:/fruitbasket/users/m/tmp/imagenet_appendix/" \
    "$HOME//Desktop/projects_data/extract_merge1/paper1_imgs/imagenet_appendix/"


"""
import os

import dataclasses
from importlib import reload

from typing import List, Optional, Sequence

import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns

import tensorflow as tf

from em import datasets as em_datasets
from em.datasets.imagenet import imagenet_x

from em.models import em_models

from em.fishers import per_example
from em.tools.nmf import nmf_common

from em.projects.imagenet import imagenet_components_context as imagenet_cc

ImageNetCC = imagenet_cc.ImageNetCC


###############################################################################

EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/imagenet1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

IMAGE_SIZE = 224

##########################################################################

OG_PEF_FILENAME = "resnet50_imagenet.imagenet_train.all_vars.20000ex.nvpe131072.mpc3e-3.h5"
OG_NMF_FILENAME = f"spH.nmf_decomp.c{512}_{2500}Iters_{65536}pe_mvpp{6}_{20000}ex.{OG_PEF_FILENAME}"

PEF_FILENAME = "resnet50_imagenet.imagenet_validation.all_vars.30000ex.nvpe131072.mpc3e-3.h5"
NMF_FILENAME = f"fit_w.{65536}vpe.{OG_NMF_FILENAME}"
SPLIT = "validation"


##########################################################################

OUT_DIR = '/fruitbasket/users/m/tmp/imagenet_appendix'

##########################################################################


def make_image(cc: ImageNetCC, component_index: int, n_cols: int, n_rows: int, extension: str = 'png'):
    Q = IMAGE_SIZE
    #
    ret = np.zeros([n_rows * Q, n_cols * Q, 3], dtype=np.float64)
    #
    imgs = cc.get_top_examples(component_index, n_cols * n_rows)
    for i, image in enumerate(imgs):
        col = i % n_cols
        row = i // n_cols
        ret[row * Q : (row + 1) * Q, col * Q : (col + 1) * Q, :] = image.image
    #
    filepath = os.path.join(OUT_DIR, f'comp{component_index}.{extension}')
    plt.imsave(filepath, ret)


##########################################################################

cc = ImageNetCC(
    pef_filepath=os.path.join(PER_EXAMPLES_FISHERS_DIR, PEF_FILENAME),
    nmf_filepath=os.path.join(PER_EXAMPLES_FISHERS_DIR, NMF_FILENAME),
    ds_split=SPLIT,
)


COMPONENT_INDICES = [
    36, 218,
    35, 29,
    53, 81,
    171, 271, 276,
]


GRID_KWARGS = {'n_cols': 8, 'n_rows': 4}
for component_index in COMPONENT_INDICES:
    # make_image(cc, component_index, **GRID_KWARGS)
    make_image(cc, component_index, extension='jpg', **GRID_KWARGS)
