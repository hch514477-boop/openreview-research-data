"""Misc util for this."""
import errno
import functools
import math
import os
import signal
import threading
import time

# import wrapt_timeout_decorator


class TimeoutError(BaseException):
    pass


# class InterruptableThread(threading.Thread):
#     def __init__(self, func, *args, **kwargs):
#         threading.Thread.__init__(self)
#         self._func = func
#         self._args = args
#         self._kwargs = kwargs
#         self._result = None

#     def run(self):
#         self._result = self._func(*self._args, **self._kwargs)

#     @property
#     def result(self):
#         return self._result


# class timeout(object):
#     def __init__(self, sec=10):
#         self._sec = sec

#     def __call__(self, f):
#         def wrapped_f(*args, **kwargs):
#             it = InterruptableThread(f, *args, **kwargs)
#             it.start()
#             it.join(self._sec)
#             if not it.is_alive():
#                 return it.result
#             raise TimeoutError('execution expired')
#         return wrapped_f

# timeout = functools.partial(wrapt_timeout_decorator.timeout, timeout_exception=TimeoutError, use_signals=False)


# NOTE: THIS IS VERY BUGGY WHEN USING MULTIPROCESSING.
def timeout(seconds=10, error_message=os.strerror(errno.ETIME)):

    def decorator(func):

        def _handle_timeout(repeat_id, signum, frame):
            signal.signal(signal.SIGALRM, functools.partial(_handle_timeout, repeat_id + 1))
            signal.alarm(seconds)
            raise TimeoutError(error_message)

        def wrapper(*args, **kwargs):
            old_signal = signal.signal(signal.SIGALRM, functools.partial(_handle_timeout, 0))
            old_time_left = signal.alarm(seconds)
            assert type(old_time_left) is int and old_time_left >= 0
            if 0 < old_time_left < seconds:  # do not exceed previous timer
                signal.alarm(old_time_left)
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
            finally:
                if old_time_left == 0:
                    signal.alarm(0)
                else:
                    sub = time.time() - start_time
                    signal.signal(signal.SIGALRM, old_signal)
                    signal.alarm(max(0, math.ceil(old_time_left - sub)))
            return result

        return functools.wraps(func)(wrapper)

    return decorator
