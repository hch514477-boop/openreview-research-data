R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=3 python -i em/projects/pi/exps/mains/scitail_generalizing_ablate_01.py
"""
import dataclasses
from importlib import reload
import random
import os

import matplotlib.pyplot as plt
import seaborn as sns

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.tools.nmf import nmf_common
from em.util import hf_util

from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf

from em.projects.pi import binary_ablation_experiment as BAE
from em.projects.pi import qqp_components_context as QCC
from em.projects.pi import qqp_merging_context as QMC
from em.projects.pi import scitail_ablations

from em.projects.pi.exps import ablation_exp_util


EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/pi1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

###############################################################################

MODEL = "textattack/bert-base-uncased-RTE"

PEF_FILENAME = "bert_base_rte.sci_tail_train.all_vars.all_ex.65536.h5"
NMF_FILENAME = f"spH.nmf_decomp.c{1024}_2kIters_{65536}pe_mvpp{8}.{PEF_FILENAME}"

FISHER_FILENAME = "bert_base_rte.scit_tail_final_train.all_vars.all_ex.h5"

##########################################################################

TOKENIZER = 'bert-base-uncased'
tokenizer = AutoTokenizer.from_pretrained(TOKENIZER)

##########################################################################


hacc = QCC.QqpComponentContext(
    model_name_pattern=MODEL,
    pef_filepath_pattern=os.path.join(PER_EXAMPLES_FISHERS_DIR, PEF_FILENAME),
    nmf_filepath_pattern=os.path.join(PER_EXAMPLES_FISHERS_DIR, NMF_FILENAME),
    tokenizer=tokenizer,
)
mc = hacc.make_model_context('a')

exp = ablation_exp_util.Experiment1(
    mc=mc,
    retaining_fisher=diagonal.DiagonalFisher.load(os.path.join(FISHERS_DIR, FISHER_FILENAME)).fishers,
)

##########################################################################

ordered_comps = exp.get_components_order_by_coeff_magnitude(12)

##########################################################################

gen_eval_ctx = scitail_ablations.get_scitail_eval_ctx(mc, split='validation')
eval_ctx = mc.get_evaluation_context()


def print_evaluations(coefficients):
    gen_eval_results = gen_eval_ctx.evaluate(exp.output_model)
    sub_eval_results = eval_ctx.evaluate(exp.output_model, top_example_inds)
    #
    print(coefficients)
    print(f'  {gen_eval_results.kl()}, {gen_eval_results.acc():.4f}, {gen_eval_results.loss()}')
    print(f'  {sub_eval_results.kl()}, {sub_eval_results.acc()}')
    print('')


##########################################################################

# The comments are just for using the dummy ablating fishers.

# COMP_INDEX = 81
# COMP_INDEX = 73
# COMP_INDEX = 887  # y
# COMP_INDEX = 1008  # n
# COMP_INDEX = 423  # n
# COMP_INDEX = 968  # Y, even adds a few percentage to acc, works for both validation and test sets
# COMP_INDEX = 952  # Y, even adds a few percentage to acc, works for both validation and test sets
# COMP_INDEX = 423  # n
# COMP_INDEX = 530  # maybe, needs to compute gradients only on the incorrectly predicted examples though.
# COMP_INDEX = 774  # maybe, needs to compute gradients only on the incorrectly predicted examples though.
# COMP_INDEX = 147  # n, probably
# COMP_INDEX = 876  # n, probably
# COMP_INDEX = 292  # n, probably
# COMP_INDEX = 720  # Y, although it looks like you can increase acc only if you compute gradients only on the incorrectly predicted examples

# VERY GOOD RESULTS: 
# COMP_INDEX = 968, delta = -6e-1, dummy_ablating_fisher, N_SG = 128, gradient = exp.compute_loss_gradient(top_example_inds, exp.W[top_example_inds, COMP_INDEX])
# The above works also for COMP_INDEX = 952

# N_SG = 12
# N_SG = 16
# N_SG = 32
# N_SG = 64
N_SG = 128
# N_SG = 256
# N_SG = 512
# N_SG = 11

# delta = -1e1
# delta = -5e0
delta = -6e-1
# delta = -2e-1  # ##
# delta = -6e-2
# delta = -8e-3
# delta = -3e-3


# top_example_inds = exp.get_top_example_indices(COMP_INDEX)[:N_SG]
# top_example_inds = exp.remove_correct_example_indices(exp.get_top_example_indices(COMP_INDEX)[:N_SG])
# top_example_inds = exp.get_top_incorrect_example_indices(COMP_INDEX)[:N_SG]
#
# top_example_inds = exp.random_example_indices_by_correctness(N_SG // 2, N_SG // 2)
top_example_inds = exp.random_example_indices_by_correctness(2 * N_SG // 3, N_SG // 3)
# top_example_inds = exp.random_example_indices_by_correctness(0, N_SG)
# top_example_inds = exp.random_example_indices(N_SG)


gradient = exp.compute_loss_gradient(top_example_inds)
# gradient = exp.compute_loss_gradient(top_example_inds, exp.W[top_example_inds, COMP_INDEX])
# gradient = exp.compute_loss_gradient(top_example_inds, exp.W[top_example_inds, COMP_INDEX], normalize_by_example=True)
#
gradient = exp.l2_normalize(gradient)


ablating_variables = exp.apply_gradient(gradient, delta)
# ablating_variables = exp.apply_sign_guide(gradient, delta)


# ablating_fisher = mc.make_fisher_for_components([COMP_INDEX])
# ablating_fisher = exp.compute_fisher(top_example_inds)
ablating_fisher = exp.get_dummy_ablating_fisher()


#######################################

# print(exp.W[top_example_inds, COMP_INDEX])


gen = exp.stream_merge(
    ablating_variables=ablating_variables,
    ablating_fisher=ablating_fisher,
    coefficients=21,
)
for coefficients in gen:
    print_evaluations(coefficients)


#


#


##########################################################################

"""
 81 looks like it significantly improves the generalization performance! Only for n_SG = 12

 Sort by average coeff of top-k examples (k=12), look at ablating those components first.


- Try to make fisher-aware gradient following ablation strategy.
- Try only using incorrectly labeled examples in the sign guide, perhaps taking into
  account the logits to make this a more continuous criteria.
- Need to experiment with various values of delta and N_SG.
- Try to have W coeffs weigh the examples when computing the sign guide.
- Baseline of random examples, probably set the fraction of correct predictions.
- Maybe see which generalizing set examples change the most.

"""
