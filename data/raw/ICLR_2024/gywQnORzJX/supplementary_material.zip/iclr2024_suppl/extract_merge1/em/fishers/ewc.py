"""Elastic-weight consolidation style stuff."""
from . import regularizers

EwcLoss = regularizers.EwcLoss
