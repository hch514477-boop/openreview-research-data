"""General sum of components model code."""
import tensorflow as tf
