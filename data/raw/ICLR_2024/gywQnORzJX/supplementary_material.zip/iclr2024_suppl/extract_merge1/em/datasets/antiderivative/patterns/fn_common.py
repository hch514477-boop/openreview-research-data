"""Common function-related stuff."""
import sympy as sp


###############################################################################


# Technically limited to less than a billion, but should
# be OK for our purposes.
ONE_OR_MORE_ARGS = range(1, 1_000_000_000)


###############################################################################
# Various options for the placeholder functions restricting what they can
# or cannot represent.
###############################################################################


class Option(sp.Symbol):
    def __new__(cls, name, **assumptions):
        return super().__new__(cls.aliases[0], **assumptions)


class NotConstant(Option):
    aliases = ('NotConstant',)


class NotLinear(Option):
    aliases = ('NotLinear',)


class MinDegree(sp.Function):
    aliases = ('MinDegree',)
    # This argument is an integer that is the minimum degree.
    nargs = (1,)


###############################################################################
# Placeholder functions.
#
# These represent types of functions that can be put in an expression. Their
# syntax when calling is Fn([options...], argument?).
###############################################################################


class Polynomial(sp.Function):
    aliases = ('Polynomial', 'Poly')
    nargs = ONE_OR_MORE_ARGS


class Rational(sp.Function):
    aliases = ('Rational',)
    nargs = ONE_OR_MORE_ARGS
