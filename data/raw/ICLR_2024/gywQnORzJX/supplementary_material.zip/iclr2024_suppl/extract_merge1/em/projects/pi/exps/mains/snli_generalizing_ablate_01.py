R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=3 python -i em/projects/pi/exps/mains/snli_generalizing_ablate_01.py
"""
import dataclasses
from importlib import reload
import random
import os

import matplotlib.pyplot as plt
import seaborn as sns

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.tools.nmf import nmf_common
from em.util import hf_util

from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf

from em.projects.pi import binary_ablation_experiment as BAE
from em.projects.pi import qqp_components_context as QCC
from em.projects.pi import qqp_merging_context as QMC
from em.projects.pi import scitail_ablations

from em.projects.pi.exps import ablation_exp_util


EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/pi1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

##########################################################################

TOKENIZER = 'bert-base-uncased'
tokenizer = AutoTokenizer.from_pretrained(TOKENIZER)

##########################################################################

MODEL_NUMBER = 0

MODEL = f"connectivity/feather_berts_{MODEL_NUMBER}"

# PEF_FILENAME = f"feather_berts_{MODEL_NUMBER}.mnli_train.all_vars.100000ex.131072.h5"
# NMF_FILENAME = f"spH.nmf_decomp.c{1024}_1250Iters_{65536}pe_mvpp{16}_{50000}ex.{PEF_FILENAME}"

PEF_FILENAME = f"feather_berts_{MODEL_NUMBER}.snli_train.all_vars.50000ex.65536.h5"
NMF_FILENAME = f"spH.nmf_decomp.c{512}_1250Iters_{65536}pe_mvpp{10}_{50000}ex.{PEF_FILENAME}"

FISHER_FILENAME = f"feather_berts_{MODEL_NUMBER}.mnli_snli_train.all_vars.{50000}ex.h5"

##########################################################################

hacc = QCC.QqpComponentContext(
    model_name_pattern=MODEL,
    pef_filepath_pattern=os.path.join(PER_EXAMPLES_FISHERS_DIR, PEF_FILENAME),
    nmf_filepath_pattern=os.path.join(PER_EXAMPLES_FISHERS_DIR, NMF_FILENAME),
    tokenizer=tokenizer,
    special_processing='HF_MNLI',
)
mc = hacc.make_model_context('a')

exp = ablation_exp_util.Experiment1(
    mc=mc,
    retaining_fisher=diagonal.DiagonalFisher.load(os.path.join(FISHERS_DIR, FISHER_FILENAME)).fishers,
)

##########################################################################

ordered_comps = exp.get_components_order_by_coeff_magnitude(12)

##########################################################################
# N_EVAL = 2048
N_EVAL = 1024

gen_eval_ctx = exp.create_eval_ctx('snli/default', sequence_length=96, n_examples=N_EVAL)
# gen_eval_ctx = exp.create_eval_ctx('snli/default', sequence_length=96, n_examples=4096)
eval_ctx = mc.get_evaluation_context()


def print_evaluations(coefficients):
    gen_eval_results = gen_eval_ctx.evaluate(exp.output_model)
    sub_eval_results = eval_ctx.evaluate(exp.output_model, top_example_inds)
    #
    print(coefficients)
    print(f'  {gen_eval_results.kl()}, {gen_eval_results.acc():.4f}, {gen_eval_results.loss()}')
    print(f'  {sub_eval_results.kl()}, {sub_eval_results.acc()}')
    print('')


##########################################################################

# COMP_INDEX = 435
# COMP_INDEX = 28
# COMP_INDEX = 91  # hard maybe
# COMP_INDEX = 489
# COMP_INDEX = 244
# COMP_INDEX = 442
# COMP_INDEX = 252
# COMP_INDEX = 235
# COMP_INDEX = 412
# COMP_INDEX = 182
# COMP_INDEX = 195
# COMP_INDEX = 386  # hard maybe
# COMP_INDEX = 205  # hard maybe
# COMP_INDEX = 320
# COMP_INDEX = 290  # soft maybe
# COMP_INDEX = 452  # very soft maybe
# COMP_INDEX = 198
# COMP_INDEX = 32
# COMP_INDEX = 424  # hard maybe
# COMP_INDEX = 156
# COMP_INDEX = 484
# COMP_INDEX = 142
# COMP_INDEX = 61
# COMP_INDEX = 240  # maybe
# COMP_INDEX = 344  # hard maybe
# COMP_INDEX = 100  # soft maybe
# COMP_INDEX = 65  # very soft maybe
# COMP_INDEX = 171
# COMP_INDEX = 27  # hard maybe
# COMP_INDEX = 5
# COMP_INDEX = 464  # hard maybe
# COMP_INDEX = 357  # hard maybe
# COMP_INDEX = 93  # hard maybe
# COMP_INDEX = 215  # maybe
# COMP_INDEX = 150
# COMP_INDEX = 217  # maybe
# COMP_INDEX = 390
# COMP_INDEX = 218
# COMP_INDEX = 204  # Based on tuning, looks to be an "bad heuristic" component; maybe with positive delta and N_SG=128
# COMP_INDEX = 483  # hard maybe
COMP_INDEX = 136  # hard maybe, also possibly "interpretable" component

# N_SG = 12
# N_SG = 16
# N_SG = 32
# N_SG = 64
N_SG = 128
# N_SG = 256
# N_SG = 512
# N_SG = 1024

# delta = -1e1
# delta = -5e0
# delta = -6e-1
delta = -2e-1  # ##
# delta = -6e-2
# delta = -8e-3
# delta = -3e-3


top_example_inds = exp.get_top_example_indices(COMP_INDEX)[:N_SG]
# top_example_inds = exp.remove_correct_example_indices(exp.get_top_example_indices(COMP_INDEX)[:N_SG])
# top_example_inds = exp.get_top_incorrect_example_indices(COMP_INDEX)[:N_SG]
#
# top_example_inds = exp.random_example_indices_by_correctness(N_SG // 2, N_SG // 2)
# top_example_inds = exp.random_example_indices_by_correctness(2 * N_SG // 3, N_SG // 3)
# top_example_inds = exp.random_example_indices_by_correctness(0, N_SG)
# top_example_inds = exp.random_example_indices(N_SG)


# gradient = exp.compute_loss_gradient(top_example_inds)
gradient = exp.compute_loss_gradient(top_example_inds, exp.W[top_example_inds, COMP_INDEX])
# gradient = exp.compute_loss_gradient(top_example_inds, exp.W[top_example_inds, COMP_INDEX], normalize_by_example=True)
#
gradient = exp.l2_normalize(gradient)


ablating_variables = exp.apply_gradient(gradient, delta)
# ablating_variables = exp.apply_sign_guide(gradient, delta)


# ablating_fisher = mc.make_fisher_for_components([COMP_INDEX])
# ablating_fisher = exp.compute_fisher(top_example_inds)
# ablating_fisher = exp.compute_fisher(top_example_inds, exp.W[top_example_inds, COMP_INDEX])
# ablating_fisher = exp.compute_fisher(top_example_inds, exp.W[top_example_inds, COMP_INDEX], normalize_by_example=True)
ablating_fisher = exp.get_dummy_ablating_fisher()


#######################################

# print(exp.W[top_example_inds, COMP_INDEX])


gen = exp.stream_merge(
    ablating_variables=ablating_variables,
    ablating_fisher=ablating_fisher,
    coefficients=21,
)
for coefficients in gen:
    print_evaluations(coefficients)


#


#

# OG: .8115 [val1024], .8047 [val4096]
# Best of 5 random tries [N_SG=128]: .8311 [val1024], .8145 [val4096]

# 91: .8262, .8130
# 386: .8223, .8130
