"""Tools for mechanistic analysis of components for the simple divisibility dataset."""
import dataclasses

import numpy as np
import tensorflow as tf


@dataclasses.dataclass
class ComponentSelectivityQuery:
    pass


"""
Types of tuning:
- last digit same
- last digit even/odd
- last digit 0 or 5

- last n digits the same

- Predictions all true/false
- Predictions mixed.

- Divisor (or divisor belonging to set)

- Look at divisibility rules for cetain divisors from https://en.wikipedia.org/wiki/Divisibility_rule



# Rules (yes vs no) vs patterns

Selection options:


"""

###############################################################################


def _get_digit(n: int, k: int) -> int:
    # kth from back.
    return (n // 10**k) % 10**(k + 1)


def _get_last_digit(n: int) -> int:
    return n % 10


###############################################################################

def last_digit_even(dividend: int) -> bool:
    return not (dividend % 2)


###############################################################################


def get_possible_yes_rules_for_2(dividend: int):
    if last_digit_even(dividend):
        return ['yes:divisor2:last_digit_even']
    else:
        return []


def get_possible_no_rules_for_2(dividend: int):
    if not last_digit_even(dividend):
        return ['no:divisor2:last_digit_odd']
    else:
        return []


############################################

def get_possible_yes_rules_for_4(dividend: int):
    last_digit = _get_digit(dividend, k=0)
    tens_digit = _get_digit(dividend, k=1)
    if tens_digit % 2:
        if last_digit in (2, 6):
            pass
    else:
        if last_digit in (0, 4, 8):
            pass

    # last_two_digits_divisible_by_4 = not ((tens_digit * 10 + last_digit) % 4)


def get_possible_no_rules_for_4(dividend: int):
    if not last_digit_even(dividend):
        return ['no:divisor4:last_digit_odd']



############################################

def get_possible_rules_for_example(divisor: int, dividend: int):
    pass

###############################################################################



def get_components_by_selectivity(query: ComponentSelectivityQuery):
    pass
