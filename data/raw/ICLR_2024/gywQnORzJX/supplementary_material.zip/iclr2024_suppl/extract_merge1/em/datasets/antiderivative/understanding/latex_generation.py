R"""Script to contain things used for generating latex to understand the antiderivative problem better.


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES= python -i em/datasets/antiderivative/understanding/latex_generation.py


"""
import os

import sympy as sp

from wolframclient.evaluation import parallel_evaluate

###############################################################################

MAX_EVALUATORS = 8
WOLFRAM_KERNEL = os.path.expanduser('~/.local/bin/WolframKernel')

###############################################################################


TRIG_FNS = ('Sin', 'Cos', 'Tan')
HYPE_FNS = ('Sinh', 'Cosh', 'Tanh')

INV_TRIG_FNS = ('ArcSin', 'ArcCos', 'ArcTan')
INV_HYPE_FNS = ('ArcSinh', 'ArcCosh', 'ArcTanh')

###############################################################################


def wolf_eval(wolf_exprs):
    return parallel_evaluate(
        wolf_exprs,
        WOLFRAM_KERNEL,
        max_evaluators=MAX_EVALUATORS,
    )


def join_align_lr_sides(lhss, rhss):
    assert len(lhss) == len(rhss)
    return ' \\\\ \n'.join([
        f'{lhs} &= {rhs}'
        for lhs, rhs in zip(lhss, rhss)
    ])


###############################################################################


def th_inv_th():
    wolf_exprs = []
    lhss = []
    for outer in TRIG_FNS + HYPE_FNS:
        for inner in INV_TRIG_FNS + INV_HYPE_FNS:
            lhss.append(f'\\{outer.lower()}(\\{inner.lower()}(x))')
            expr = f'ToString[TeXForm[FullSimplify[TrigToExp[{outer}[{inner}[x]]]]]]'
            wolf_exprs.append(expr)
    wolfram_results = wolf_eval(wolf_exprs)
    return lhss, wolfram_results


def inv_th_th():
    wolf_exprs = []
    lhss = []
    for outer in INV_TRIG_FNS + INV_HYPE_FNS:
        for inner in TRIG_FNS + HYPE_FNS:
            lhss.append(f'\\{outer.lower()}(\\{inner.lower()}(x))')
            expr = f'ToString[TeXForm[FullSimplify[TrigToExp[{outer}[{inner}[x]]]]]]'
            wolf_exprs.append(expr)
    wolfram_results = wolf_eval(wolf_exprs)
    return lhss, wolfram_results


######################################################


def inv_as_logs():
    wolf_exprs = []
    lhss = []
    for fn in INV_TRIG_FNS + INV_HYPE_FNS:
        lhss.append(f'\\{fn.lower()}(x)')
        # expr = f'ToString[TeXForm[FullSimplify[TrigToExp[{fn}[x]]]]]'
        expr = f'ToString[TeXForm[TrigToExp[{fn}[x]]]]'
        wolf_exprs.append(expr)
    wolfram_results = wolf_eval(wolf_exprs)
    return lhss, wolfram_results


###############################################################################


def generate_for_align(fn):
    lhss, wolfram_results = fn()
    output = join_align_lr_sides(lhss, wolfram_results)
    print(output)


###############################################################################

# generate_for_align(th_inv_th)
# lhss, wolfram_results = inv_th_th()

generate_for_align(inv_as_logs)
