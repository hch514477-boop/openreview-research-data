# Antiderivative dataset

A lot of the initial code and logic comes from [Deep Learning for Symbolic Mathematics](https://github.com/facebookresearch/SymbolicMathematics).
