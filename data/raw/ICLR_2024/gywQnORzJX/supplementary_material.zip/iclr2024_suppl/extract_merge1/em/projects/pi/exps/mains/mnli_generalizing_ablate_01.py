R"""


cd ~/Desktop/projects/extract_merge1
export PYTHONPATH=$PYTHONPATH:~/Desktop/projects/extract_merge1


CUDA_VISIBLE_DEVICES=3 python -i em/projects/pi/exps/mains/mnli_generalizing_ablate_01.py
"""
import dataclasses
from importlib import reload
import random
import os

import matplotlib.pyplot as plt
import seaborn as sns

import numpy as np
import tensorflow as tf
from transformers import AutoTokenizer, TFAutoModelForSequenceClassification

from em import datasets as em_datasets
from em.fishers import diagonal
from em.fishers import per_example
from em.merging import merging
from em.tools.nmf import nmf_common
from em.util import hf_util

from em.projects.anli import anli_misc1 as am
from em.projects.wino import nmf_components_fisher as ncf

from em.projects.pi import binary_ablation_experiment as BAE
from em.projects.pi import qqp_components_context as QCC
from em.projects.pi import qqp_merging_context as QMC
from em.projects.pi import scitail_ablations

from em.projects.pi.exps import ablation_exp_util


EXPS_DIR = '/fruitbasket/users/m/project_data/extract_merge1/pi1'
MODELS_DIR = os.path.join(EXPS_DIR, 'models')
FISHERS_DIR = os.path.join(EXPS_DIR, 'fishers')
PER_EXAMPLES_FISHERS_DIR = os.path.join(EXPS_DIR, 'per_example_fishers')

##########################################################################

TOKENIZER = 'bert-base-uncased'
tokenizer = AutoTokenizer.from_pretrained(TOKENIZER)

##########################################################################

MODEL_NUMBER = 0

MODEL = f"connectivity/feather_berts_{MODEL_NUMBER}"

PEF_FILENAME = f"feather_berts_{MODEL_NUMBER}.mnli_train.all_vars.100000ex.131072.h5"
NMF_FILENAME = f"spH.nmf_decomp.c{1024}_1250Iters_{65536}pe_mvpp{16}_{50000}ex.{PEF_FILENAME}"

FISHER_FILENAME = f"feather_berts_{MODEL_NUMBER}.mnli_train.all_vars.{100000}ex.h5"

##########################################################################

hacc = QCC.QqpComponentContext(
    model_name_pattern=MODEL,
    pef_filepath_pattern=os.path.join(PER_EXAMPLES_FISHERS_DIR, PEF_FILENAME),
    nmf_filepath_pattern=os.path.join(PER_EXAMPLES_FISHERS_DIR, NMF_FILENAME),
    tokenizer=tokenizer,
    special_processing='HF_MNLI',
)
mc = hacc.make_model_context('a')

exp = ablation_exp_util.Experiment1(
    mc=mc,
    retaining_fisher=diagonal.DiagonalFisher.load(os.path.join(FISHERS_DIR, FISHER_FILENAME)).fishers,
)

##########################################################################

ordered_comps = exp.get_components_order_by_coeff_magnitude(12)

##########################################################################
# N_EVAL = 2048
N_EVAL = 1024

gen_eval_ctx = exp.create_eval_ctx('glue/mnli', sequence_length=128, n_examples=N_EVAL)
# gen_eval_ctx = exp.create_eval_ctx('glue/mnli-mm', sequence_length=128, n_examples=N_EVAL)
# gen_eval_ctx = exp.create_eval_ctx('snli/default', sequence_length=128, n_examples=N_EVAL)
eval_ctx = mc.get_evaluation_context()


def print_evaluations(coefficients):
    gen_eval_results = gen_eval_ctx.evaluate(exp.output_model)
    sub_eval_results = eval_ctx.evaluate(exp.output_model, top_example_inds)
    #
    print(coefficients)
    print(f'  {gen_eval_results.kl()}, {gen_eval_results.acc():.4f}, {gen_eval_results.loss()}')
    print(f'  {sub_eval_results.kl()}, {sub_eval_results.acc()}')
    print('')


##########################################################################
# TODO: Since this is from train set, maybe focus on ablating components that have correct predictions.

# COMP_INDEX = 327
# COMP_INDEX = 245  # maybe, seems to lack generalizability; best so far with N_SG = 64, delta = -6e-1
# COMP_INDEX = 113


# Ablations with positive deltas:
# COMP_INDEX = 20  # maybe?
# COMP_INDEX = 430
# COMP_INDEX = 405  # maybe?
# COMP_INDEX = 571
# COMP_INDEX = 995
# COMP_INDEX = 113
# COMP_INDEX = 316
# COMP_INDEX = 844  # looks maybe promising
# COMP_INDEX = 936  # maybe?
# COMP_INDEX = 610
# COMP_INDEX = 591  # maybe?
# COMP_INDEX = 438
# COMP_INDEX = 81
# COMP_INDEX = 493  # looks maybe promising
# COMP_INDEX = 497



# NOTES ON MAYBE GOOD COMPONENTS
# 844 looks maybe something with N_SG=4, delta=2e-1, exp.compute_fisher(top_example_inds, exp.W[top_example_inds, COMP_INDEX], normalize_by_example=True)
# 493 with N_SG=32,64,128,256, delta=2e-1, exp.compute_fisher(top_example_inds, exp.W[top_example_inds, COMP_INDEX], normalize_by_example=True)

# Components with large coeffs and some wrong preds maybe seem to contain good comps for ablation.

# N_SG = 4
# N_SG = 5
# N_SG = 6
# N_SG = 8
# N_SG = 12
# N_SG = 16
# N_SG = 32
# N_SG = 64
N_SG = 128
# N_SG = 256
# N_SG = 512
# N_SG = 11

# # delta = -1e1
# # delta = -5e0
# # delta = -6e-1
# delta = -2e-1  # ##
# # delta = -6e-2
# # delta = -8e-3
# # delta = -3e-3

# delta = 6e-1
delta = 2e-1
# delta = 6e-2


# TODO: Maybe label/prediction/label-prediction-pair aware filtering of the top example inds.
# TODO: Try changing the number of examples between computing the gradient and the fisher.

# top_example_inds = exp.get_top_example_indices(COMP_INDEX)[:N_SG]
# top_example_inds = exp.remove_correct_example_indices(exp.get_top_example_indices(COMP_INDEX)[:N_SG])
# top_example_inds = exp.get_top_incorrect_example_indices(COMP_INDEX)[:N_SG]
#
# top_example_inds = exp.random_example_indices_by_correctness(N_SG // 2, N_SG // 2)
# top_example_inds = exp.random_example_indices_by_correctness(0, N_SG)
top_example_inds = exp.random_example_indices(N_SG)


gradient = exp.compute_loss_gradient(top_example_inds)
# gradient = exp.compute_loss_gradient(top_example_inds, exp.W[top_example_inds, COMP_INDEX])
# gradient = exp.compute_loss_gradient(top_example_inds, exp.W[top_example_inds, COMP_INDEX], normalize_by_example=True)
#
gradient = exp.l2_normalize(gradient)


ablating_variables = exp.apply_gradient(gradient, delta)
# ablating_variables = exp.apply_sign_guide(gradient, delta)


# ablating_fisher = mc.make_fisher_for_components([COMP_INDEX])
ablating_fisher = exp.compute_fisher(top_example_inds)
# ablating_fisher = exp.compute_fisher(top_example_inds, exp.W[top_example_inds, COMP_INDEX])
# ablating_fisher = exp.compute_fisher(top_example_inds, exp.W[top_example_inds, COMP_INDEX], normalize_by_example=True)
# ablating_fisher = exp.get_dummy_ablating_fisher()


#######################################

# print(exp.W[top_example_inds, COMP_INDEX])


gen = exp.stream_merge(
    ablating_variables=ablating_variables,
    ablating_fisher=ablating_fisher,
    coefficients=21,
)
for coefficients in gen:
    print_evaluations(coefficients)


#


#
