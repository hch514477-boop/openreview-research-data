"""Utilities for some stuff dealing with flags."""


class _GlobalState:
    pass



def DEFINE(flag_type, *args, **kwargs):
    pass