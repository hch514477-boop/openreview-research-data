"""Stuff related to parsing and subsequent modification of HANS examples."""
from typing import Any, Dict

from . import hans_labeling_constants as hlc


ADSJHKKAS = {
    'temp1': [3, 1, 2, 0, 4, 5],
    #
    'temp2': [3, 1, 5, 0, 7, 8],
    'temp3': [6, 1, 5, 0, 7, 8],
    'temp4': [6, 1, 5, 3, 7, 8],
    'temp5': [3, 1, 2, 0, 4, 8],
    'temp6': [3, 1, 2, 0, 4, 8],
    'temp7': [3, 1, 2, 0, 4, 8],
    #
    'temp8': [3, 1, 6, 0, 8, 9],
    'temp9': [3, 1, 6, 0, 8, 9],
    'temp10': [3, 1, 6, 0, 8, 9],
    'temp11': [4, 1, 6, 0, 8, 9],
    'temp12': [4, 1, 6, 0, 8, 9],
    'temp13': [4, 1, 6, 0, 8, 9],
    'temp14': [3, 1, 2, 0, 4, 9],
    'temp15': [3, 1, 2, 0, 4, 9],
    'temp16': [3, 1, 2, 0, 4, 9],
    'temp17': [3, 1, 2, 0, 4, 9],
    'temp18': [3, 1, 2, 0, 4, 9],
    'temp19': [3, 1, 2, 0, 4, 9],
    #
    'temp20': [0, 6, 3, 5, 1, 7],
    'temp21': [0, 6, 3, 5, 1, 7],
    #
    'temp22': [0, 1, 5, 3, 7, 8],
    'temp23': [0, 4, 5, 3, 7, 8],
    'temp24': [3, 1, 2, 6, 7, 8],
    'temp25': [6, 1, 2, 3, 4, 8],
}

_MULTIWORD_PREPS = {
    "in front of": '__IN_FRONT_OF__',
    "next to": '__NEXT_TO__',
}


def _preprocess_premise(s: str) -> str:
    for k, v in _MULTIWORD_PREPS.items():
        s = s.replace(k, v)
    return s


def _postprocess_hypothesis(s: str) -> str:
    for k, v in _MULTIWORD_PREPS.items():
        s = s.replace(v, k)
    return s


def get_flipped_label_hypothesis(template_name, premise) -> str:
    template = hlc.TEMPLATES_BY_NAME[template_name]

    # Note: preps can be multi-word
    premise_words = _preprocess_premise(premise).lower().split(' ')
    premise_template = template[0]
    assert len(premise_template) == len(premise_words)

    context = {}
    for (idx, pattern), w in zip(premise_template, premise_words):
        if isinstance(pattern, str):
            assert w == pattern
        context[idx] = w

    hypothesis_order = ADSJHKKAS[template_name]
    hypothesis = ' '.join([context[i] for i in hypothesis_order])
    hypothesis = _postprocess_hypothesis(hypothesis)
    hypothesis = hypothesis[0].upper() + hypothesis[1:]
    return hypothesis


def get_flipped_label_hypothesis_for_example(ex: Dict[str, Any]) -> str:
    label = ex['label']
    assert label == 1, 'TODO: Support entailing examples.'
    return get_flipped_label_hypothesis(ex['template', ex['premise']])
