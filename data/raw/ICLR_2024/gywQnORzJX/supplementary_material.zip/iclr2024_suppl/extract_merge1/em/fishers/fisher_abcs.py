"""Abstract base classes and interfaces for Fishers."""
import abc
import os


class FisherAbc(abc.ABC):
    """Class that all Fisher implementations should extend.
    
    This class is focused on the Fisher representation itself, not
    really with computing it.
    """

    @abc.abstractmethod
    def _save(self, filepath: str, **optional_kwargs):
        raise NotImplementedError

    # @classmethod
    # @abc.abstractmethod
    # def _load(cls, filepath: str, **optional_kwargs):
    #     raise NotImplementedError

    def save(self, filepath: str, **optional_kwargs):
        filepath = os.path.expanduser(filepath)
        return self._save(filepath, **optional_kwargs)

    @classmethod
    def load(cls, filepath: str, **optional_kwargs):
        filepath = os.path.expanduser(filepath)
        return cls._load(filepath, **optional_kwargs)
