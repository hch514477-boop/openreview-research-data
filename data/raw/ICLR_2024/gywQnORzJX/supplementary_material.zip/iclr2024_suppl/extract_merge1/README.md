# Extract and Merge


## Some notes for developers (mostly me)

#### Move code to banana server
```bash
sh ~/Desktop/projects/extract_merge1/local_scripts/move_code_to_fruit.sh
```

#### Enter banana
```bash
ssh -X m@banana.cs.unc.edu
```


#### Start up on banana
```bash
VIRTUALENV_NAME=extract_merge1

CODE_DIR=/fruitbasket/users/m/project_code/extract_merge1
DATA_DIR=/fruitbasket/users/m/project_data/extract_merge1

cd $CODE_DIR
workon $VIRTUALENV_NAME
export PYTHONPATH="$PYTHONPATH:$CODE_DIR",
export TFDS_DATA_DIR=/fruitbasket/datasets/tensorflow_datasets


# Script for installing requirements, don't need to do every time.
pip install -r requirements.txt

```


#### Tmux stuff
See https://www.cs.swarthmore.edu/newhelp/longtmux.html.

```bash
tmux ls
tmux attach -t (session number)
```
