from typing import Callable, Sequence, Tuple

import jax.numpy as jnp
from flax import linen as nn

from common import MLP


class ValueCritic(nn.Module):
    hidden_dims: Sequence[int]
    reward_dim: int

    @nn.compact
    def __call__(self, observations: jnp.ndarray) -> jnp.ndarray:
        critic = MLP((*self.hidden_dims, self.reward_dim))(observations)
        return critic


class Critic(nn.Module):
    hidden_dims: Sequence[int]
    reward_dim: int
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu

    @nn.compact
    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> jnp.ndarray:
        inputs = jnp.concatenate([observations, actions], -1)
        critic = MLP((*self.hidden_dims, self.reward_dim),
                     activations=self.activations)(inputs)
        return critic


class DoubleCritic(nn.Module):
    hidden_dims: Sequence[int]
    reward_dim: int

    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu

    @nn.compact
    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
        critic1 = Critic(self.hidden_dims, self.reward_dim,
                         activations=self.activations)(observations, actions)
        critic2 = Critic(self.hidden_dims, self.reward_dim,
                         activations=self.activations)(observations, actions)
        return critic1, critic2
