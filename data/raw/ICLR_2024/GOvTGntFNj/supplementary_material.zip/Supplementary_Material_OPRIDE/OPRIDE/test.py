import jax

rng = jax.random.PRNGKey(1)