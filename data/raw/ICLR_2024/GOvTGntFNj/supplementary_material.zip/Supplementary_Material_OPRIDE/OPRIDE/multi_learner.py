"""Implementations of algorithms for continuous control."""

from typing import Optional, Sequence, Tuple

import jax
import jax.numpy as jnp
import numpy as np
import optax

import multi_policy
import multi_value_net
from multi_actor import update as awr_update_actor
from common import Batch, InfoDict, Model, PRNGKey
from multi_critic import update_q, update_v
import pickle
import os


def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_map(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)


@jax.jit
def _update_jit(
        rng: PRNGKey, actor: Model, critic: Model, value: Model,
        target_critic: Model, batch: Batch, reward_dim: int, discount: float, tau: float,
        expectile: float, temperature: float, ensemble_number, delta
) -> Tuple[PRNGKey, Model, Model, Model, Model, Model, InfoDict]:
    new_value, value_info = update_v(target_critic, value, batch, expectile)
    key, rng = jax.random.split(rng)
    new_actor, actor_info = awr_update_actor(key, actor, target_critic,
                                             new_value, batch, reward_dim, temperature)

    new_critic, critic_info = update_q(critic, new_value, batch, reward_dim, discount, ensemble_number, delta)
    
    new_target_critic = target_update(new_critic, target_critic, tau)

    return rng, new_actor, new_critic, new_value, new_target_critic, {
        **critic_info,
        **value_info,
        **actor_info
    }


class Learner(object):
    def __init__(self,
                 seed: int,
                 reward_dim: int,
                 observations: jnp.ndarray,
                 actions: jnp.ndarray,
                 actor_lr: float = 3e-4,
                 value_lr: float = 3e-4,
                 critic_lr: float = 3e-4,
                 hidden_dims: Sequence[int] = (256, 256),
                 discount: float = 0.99,
                 tau: float = 0.005,
                 expectile: float = 0.8,
                 temperature: float = 0.1,
                 dropout_rate: Optional[float] = None,
                 max_steps: Optional[int] = None,
                 opt_decay_schedule: str = "cosine"):
        """
        An implementation of the version of Soft-Actor-Critic described in https://arxiv.org/abs/1801.01290
        """

        self.expectile = expectile
        self.tau = tau
        self.discount = discount
        self.temperature = temperature
        self.reward_dim = reward_dim
        rng = jax.random.PRNGKey(seed)
        rng, actor_key, critic_key, value_key = jax.random.split(rng, 4)

        action_dim = actions.shape[-1]
        actor_def = multi_policy.NormalTanhPolicy(hidden_dims,
                                                  action_dim,
                                                  1,
                                                  log_std_scale=1e-3,
                                                  log_std_min=-5.0,
                                                  dropout_rate=dropout_rate,
                                                  state_dependent_std=False,
                                                  tanh_squash_distribution=False)

        if opt_decay_schedule == "cosine":
            schedule_fn = optax.cosine_decay_schedule(-actor_lr, max_steps)
            optimiser = optax.chain(optax.scale_by_adam(),
                                    optax.scale_by_schedule(schedule_fn))
        else:
            optimiser = optax.adam(learning_rate=actor_lr)

        actor = Model.create(actor_def,
                             inputs=[actor_key, observations],
                             tx=optimiser)

        critic_def = multi_value_net.DoubleCritic(hidden_dims, reward_dim)
        critic = Model.create(critic_def,
                              inputs=[critic_key, observations, actions],
                              tx=optax.adam(learning_rate=critic_lr))

        value_def = multi_value_net.ValueCritic(hidden_dims, reward_dim)
        value = Model.create(value_def,
                             inputs=[value_key, observations],
                             tx=optax.adam(learning_rate=value_lr))

        target_critic = Model.create(
            critic_def, inputs=[critic_key, observations, actions])

        self.actor = actor
        self.critic = critic
        self.value = value
        self.target_critic = target_critic
        self.rng = rng

    def sample_actions(self,
                       observations: np.ndarray,
                       temperature: float = 1.0,
                       all_actions=False) -> jnp.ndarray:
        rng, actions = multi_policy.sample_actions(self.rng, self.actor.apply_fn,
                                                   self.actor.params, observations,
                                                   temperature)
        self.rng = rng

        actions = np.asarray(actions)
        actions = np.clip(actions, -1, 1).squeeze(axis=0)
        if all_actions:
            return actions
        else:
            return actions[0, :]

    def save(self, save_dir):
        with open(os.path.join(save_dir, "actor.pkl"), "wb") as f:
            pickle.dump(self.actor.params, f)
        with open(os.path.join(save_dir, "critic.pkl"), "wb") as f:
            pickle.dump(self.critic.params, f)

    def update(self, batch: Batch, ensemble_number, delta) -> InfoDict:
        new_rng, new_actor, new_critic, new_value, new_target_critic, info = _update_jit(
            self.rng, self.actor, self.critic, self.value, self.target_critic,
            batch, self.reward_dim, self.discount, self.tau, self.expectile, self.temperature, ensemble_number, delta)

        self.rng = new_rng
        self.actor = new_actor
        self.critic = new_critic
        self.value = new_value
        self.target_critic = new_target_critic

        return info
