python3 submission_runner.py \
	--framework=jax \
	--data_dir=/path/to/data/imagenet/jax \
	--imagenet_v2_data_dir=/path/to/data/imagenet \
	--experiment_dir=/path/to/algorithmic-efficiency\
	--experiment_name=resnet_clip0.01 \
	--workload=imagenet_resnet \
	--submission_path=algorithmic_efficiency/spec.py \
	--tuning_search_space=algorithmic_efficiency/adamk.json
