This ZIP contains the following:
1. theorem_expansion.py (Source code for theorem expansion)
1. theorem_verification.py (Source code for theorem verification)
1. propositional.mm (A sample Metamath database used in theorem_expansion.py)
1. datasets/ (All necessary data for theorem verification)
1. experiment/ (A sample experiment with predictions for theorem verification)


#############################################

To expand propositional.mm
```
python theorem_expansion.py
```
The main expansion code is in the function `verify_custom`

To extract and verify new theorems predicted by REFACTOR
```
python theorem_verification.py
```
The main extraction and verification code is in the function `analyze_predictions`