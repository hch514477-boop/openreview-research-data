#!/bin/sh
python inference.py --dataset="gsm8k" --model="gpt-3.5-turbo" --method="zero_shot_cot" --random_seed=99 --multipath=1 --temperature=0 --api_time_interval=0.5 --test_size=256 --shot=0 --flag="gpt"
