"""
utils for DiffPIR
"""
