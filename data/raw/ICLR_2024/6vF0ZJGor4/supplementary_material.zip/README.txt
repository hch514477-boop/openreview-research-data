To reproduce the result from the paper for Matrix Factiorization + ImplicitSLIM on MovieLens-20M, run this notebook:
mf+ImplicitSLIM.ipynb


To reproduce the result from the paper for RecVAE + ImplicitSLIM on MovieLens-20M, run
$ python RecVAE/run.py --dataset ml20m/ --latent-dim 400 --gamma 0.004 --n-epochs 150