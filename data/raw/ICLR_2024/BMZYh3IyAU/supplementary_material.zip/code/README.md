# Instructions

Create a *conda* environment with:

    conda create --name ICMLENV --file requirements.txt

Also install additional needed modules:

    pip install git+https://github.com/konstmish/opt_methods.git@716a0ed61c978ea1b8a2b8253a5a9646ff76aa4e

    pip install numba==0.56.4

    pip install jupyter==1.0.0

Results can now be replicated by specifiying parameters listed in each experiment.<br>
For example, for reproducing Figure 2 c) use:

    python .\main.py --c_downlink 0.0 --reg 0.003 --dataset w8a --n_workers 3000

You can also set *--it_max* to a lower value for quicker insight.