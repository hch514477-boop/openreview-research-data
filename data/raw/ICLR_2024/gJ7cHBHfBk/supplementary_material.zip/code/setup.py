from distutils.core import setup
from setuptools import find_packages

setup(
    name='gen-neg-toy',
    version='0.0.1',
    py_modules=["gen_neg_toy"],
    license='MIT License',
    install_requires=[
            'matplotlib',
            'numpy',
            'torch>=1.12.1',
            'torchvision>=0.13.0',
            'absl-py==1.4.0',
            'ml-collections==0.1.1',
            'wandb',
            'tqdm',
        ],
)
