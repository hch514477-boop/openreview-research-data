
## FruitBin

The dataset being accesible in a non anonimous link exemples of data are in the folder "data". 

Considering the substantial size of the dataset, users will have the option to selectively download specific data subsets based on their requirements, such as RGB, depth, and other features, allowing for more efficient and targeted data retrieval.

Detailed information regarding the dataset generation process can be accessed through the code folder "PickSim" for insights into the PickSim generation, the code folder "fruitbin" for access to the processing codes and procedures involved in creating FruitBin, as well as the scenarios designed for training purposes. These resources provide valuable documentation and code references for a better understanding of the dataset's origins and the steps taken to prepare it for various applications.

To facilitate the reproduction of the benchmark results, we have provided the folder codes PVnet and Densefusion along with detailed instructions on how to apply them to the FruitBin dataset. These resources will guide you through the implementation of pvnet and Densefusion on the FruitBin dataset, enabling you to replicate the benchmark and further explore the capabilities of the dataset.


