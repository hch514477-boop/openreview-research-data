import pandas as pd
import json



#print(df.to_string()) 


#df = pd.DataFrame([1,2,3])

#df.to_json('example.json')


#Category = "kiwi1"
#Category = "cherry1"
#Category = "crate"
#Category = "banana1"
#Category = "apricot"
#Category = "orange2"
#Category = "pear2"
#Category = "floor"
#Category = "peach1"
#Category = "lemon2"
#Category = "apple2"
#Category = "strawberry1"

#Category = 'banana1'
Category = 'pear2'
#Category = "orange2"
# Opening JSON file

  
# returns JSON object as 
# a dictionary
data = json.load(f)
  
# Iterating through the json
# list

id_category = 0

for i in data['categories']:
    print(i)
    if i['label'] == Category :
        print("Hello fruits")
        id_category = i['id']
        print(id_category)

id_instances = []

for i in data['objects']:
    print(i)
    if i['category_id'] == id_category :
        print("Hello fruits instance")
        id_instances.append(i['id'])
        print(i['id'])

print(id_instances)

# Closing file
f.close()



data2 = json.load(f2)

id_instances_good = []

for i in data2:
    print('i : ',i)
    print(i['id'])
    print(id_instances)

    if i['id'] in id_instances :
        print("Hello banana instance occ")
        if i['occlusion_value'] > 0.5 :
            id_instances_good.append(i['id'])
            print(i['id'])
            print(i['occlusion_value'])

print(id_instances_good)




# Closing file
f2.close()


