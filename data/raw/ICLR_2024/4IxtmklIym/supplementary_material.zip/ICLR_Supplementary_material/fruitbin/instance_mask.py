from matplotlib import pyplot as plt
import cv2
import json
from pathlib import Path



def instance(im, id):
    #im = im * 255
    im[im == id] = 255
    im[im < 255] = 0
    im = im / 255
    #plt.imshow(im, cmap='gray')
    #plt.show()
    return im


# def generate_instance_mask(data_name, Nb_camera, Nb_world,list_categories, occ_target):

#     for i in range(1, Nb_world + 1): # worlds
        
#         catergories_instance_array_id_to_cat, catergories_instance_array_cat_to_id = compute_categories_id(data_name, i)
        


#         for j in range(1, Nb_camera+1): # cameras
#             p = ((i-1)*Nb_camera) + j

#             catergories_occ_array = compute_id_good_occ(data_name, p, catergories_instance_array_id_to_cat, catergories_instance_array_cat_to_id, occ_target)


#             for categories in list_categories:

#                 if len(catergories_occ_array[categories]) == 1 :

#                     id = catergories_occ_array[categories][0]
#                     print("iddd : ",id)
#                     img = cv2.imread(f"{data_name}/Instance_Segmentation/{p}.png", cv2.IMREAD_UNCHANGED) # plt.imread(path)

#                     #print("img[817][308] : ", img[817][308])
#                     print("img[308][817] : ", img[308][817])


#                     instance_img = instance(img, id)
#                     print("instance_img[308][817] : ", instance_img[308][817])


#                     cv2.imwrite(f"{data_name}/Generated/Instance_Mask/{categories}/{p}.png", 255*instance_img)


