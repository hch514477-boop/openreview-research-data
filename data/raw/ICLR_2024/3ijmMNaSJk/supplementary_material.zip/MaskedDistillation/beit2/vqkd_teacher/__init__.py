from .dino import *
from .clip import *
from .deit import *
