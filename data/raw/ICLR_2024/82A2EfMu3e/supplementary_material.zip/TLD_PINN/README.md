# Transfer learning enhanced discrete physics-informed neural networks for evolutionary differential equation

## Requirement

All codes are written based on JAX. To install JAX, please check the GitHub repository of [JAX](https://github.com/google/jax#installation).

Also, some additional Python libraries are required. We provide a [``requirements.txt``](requirements.txt) file that can be used to install the libraries with pip: 

```bash
pip install -r requirements.txt
```



## TLD_PINN code

We provide relevant codes for all experiments, including the Crank Nicolson and Runge Kutta methods. The codes and running results are saved in .ipynb files and stored in different folders according to different equations(Reaction-Diffusion, Allen-Cahn, Kuramoto–Sivashinsky, Navier-Stokes).
