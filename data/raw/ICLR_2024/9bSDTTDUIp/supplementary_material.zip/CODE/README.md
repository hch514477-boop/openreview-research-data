
To run ERM++ for DomainNet, for the painting domain, a sample command is below:

```python main_erm.py -j 1 dummy  dummy --save_name painting --pretrained --dataset domainnet --training_data clipart infograph real quickdraw sketch --validation_data  painting --save-dir  --steps 60000  --lr 5e-5 --wd 0 --save-freq 1000 --sma --linear-steps 500 --sma-start-iter 600  --resample-batch-size --arch resnet_timm```


Packages used for the codebase are listed below

```conda list

_libgcc_mutex             0.1                 conda_forge    conda-forge
_openmp_mutex             4.5                       2_gnu    conda-forge
anyio                     3.6.2              pyhd8ed1ab_0    conda-forge
aom                       3.4.0                h27087fc_1    conda-forge
argon2-cffi               21.3.0             pyhd8ed1ab_0    conda-forge
argon2-cffi-bindings      21.2.0          py310h5764c6d_3    conda-forge
asttokens                 2.0.5                    pypi_0    pypi
attrs                     22.1.0             pyh71513ae_1    conda-forge
backcall                  0.2.0                    pypi_0    pypi
backports                 1.0                        py_2    conda-forge
backports-functools-lru-cache 1.6.4                    pypi_0    pypi
backports.functools_lru_cache 1.6.4              pyhd8ed1ab_0    conda-forge
beautifulsoup4            4.11.1             pyha770c72_0    conda-forge
black                     22.12.0                  pypi_0    pypi
blas                      1.0                         mkl
bleach                    5.0.1              pyhd8ed1ab_0    conda-forge
brotli                    1.0.9                h166bdaf_8    conda-forge
brotli-bin                1.0.9                h166bdaf_8    conda-forge
brotlipy                  0.7.0           py310h5764c6d_1004    conda-forge
bzip2                     1.0.8                h7f98852_4    conda-forge
ca-certificates           2022.12.7            ha878542_0    conda-forge
certifi                   2022.12.7          pyhd8ed1ab_0    conda-forge
cffi                      1.15.1          py310h255011f_0    conda-forge
charset-normalizer        2.1.0                    pypi_0    pypi
click                     8.1.3                    pypi_0    pypi
comm                      0.1.2              pyhd8ed1ab_0    conda-forge
contourpy                 1.0.6           py310hbf28c38_0    conda-forge
cryptography              37.0.1          py310h9ce1e76_0
cudatoolkit               11.3.1               h2bc3f7f_2
cycler                    0.11.0             pyhd8ed1ab_0    conda-forge
dbus                      1.13.18              hb2f20db_0
debugpy                   1.6.4           py310hd8f1fbe_0    conda-forge
decorator                 5.1.1                    pypi_0    pypi
defusedxml                0.7.1              pyhd8ed1ab_0    conda-forge
easydict                  1.9                      pypi_0    pypi
entrypoints               0.4                pyhd8ed1ab_0    conda-forge
executing                 0.9.1                    pypi_0    pypi
expat                     2.4.8                h27087fc_0    conda-forge
ffmpeg                    5.1.0           gpl_hb2553f0_100    conda-forge
filelock                  3.8.0                    pypi_0    pypi
flit-core                 3.8.0              pyhd8ed1ab_0    conda-forge
font-ttf-dejavu-sans-mono 2.37                 hab24e00_0    conda-forge
font-ttf-inconsolata      3.000                h77eed37_0    conda-forge
font-ttf-source-code-pro  2.038                h77eed37_0    conda-forge
font-ttf-ubuntu           0.83                 hab24e00_0    conda-forge
fontconfig                2.14.0               h8e229c2_0    conda-forge
fonts-conda-ecosystem     1                             0    conda-forge
fonts-conda-forge         1                             0    conda-forge
fonttools                 4.38.0          py310h5764c6d_1    conda-forge
freetype                  2.10.4               hca18f0e_2    conda-forge
gdown                     4.5.1                    pypi_0    pypi
gettext                   0.19.8.1          h73d1719_1008    conda-forge
giflib                    5.2.1                h36c2ea0_2    conda-forge
glib                      2.69.1               he621ea3_2
gmp                       6.2.1                h58526e2_0    conda-forge
gnutls                    3.7.6                hf3e180e_5    conda-forge
gst-plugins-base          1.14.0               h8213a91_2
gstreamer                 1.14.0               h28cd5cc_2
icu                       58.2              hf484d3e_1000    conda-forge
idna                      3.3                      pypi_0    pypi
importlib-metadata        5.2.0              pyha770c72_0    conda-forge
importlib_resources       5.10.1             pyhd8ed1ab_0    conda-forge
intel-openmp              2021.4.0          h06a4308_3561
ipykernel                 6.19.3             pyh210e3f2_0    conda-forge
ipython                   8.4.0           py310hff52083_0    conda-forge
ipython_genutils          0.2.0                      py_1    conda-forge
jedi                      0.18.1                   pypi_0    pypi
jinja2                    3.1.2              pyhd8ed1ab_1    conda-forge
joblib                    1.1.0                    pypi_0    pypi
jpeg                      9e                   h166bdaf_2    conda-forge
jsonschema                4.17.3             pyhd8ed1ab_0    conda-forge
jupyter_client            7.4.8              pyhd8ed1ab_0    conda-forge
jupyter_core              5.1.0           py310hff52083_0    conda-forge
jupyter_server            1.23.3             pyhd8ed1ab_0    conda-forge
jupyterlab_pygments       0.2.2              pyhd8ed1ab_0    conda-forge
keyutils                  1.6.1                h166bdaf_0    conda-forge
kiwisolver                1.4.4           py310hbf28c38_1    conda-forge
krb5                      1.19.3               h3790be6_0    conda-forge
lame                      3.100             h7f98852_1001    conda-forge
lcms2                     2.12                 hddcbb42_0    conda-forge
ld_impl_linux-64          2.36.1               hea4e1c9_2    conda-forge
lerc                      4.0.0                h27087fc_0    conda-forge
libblas                   3.9.0            12_linux64_mkl    conda-forge
libbrotlicommon           1.0.9                h166bdaf_8    conda-forge
libbrotlidec              1.0.9                h166bdaf_8    conda-forge
libbrotlienc              1.0.9                h166bdaf_8    conda-forge
libcblas                  3.9.0            12_linux64_mkl    conda-forge
libclang                  10.0.1          default_hb85057a_2
libdeflate                1.13                 h166bdaf_0    conda-forge
libdrm                    2.4.112              h166bdaf_0    conda-forge
libedit                   3.1.20191231         he28a2e2_2    conda-forge
libevent                  2.1.12               h8f2d780_0
libffi                    3.4.2                h7f98852_5    conda-forge
libgcc-ng                 12.1.0              h8d9b700_16    conda-forge
libgfortran-ng            12.1.0              h69a702a_16    conda-forge
libgfortran5              12.1.0              hdcd56e2_16    conda-forge
libgomp                   12.1.0              h8d9b700_16    conda-forge
libiconv                  1.16                 h516909a_0    conda-forge
libidn2                   2.3.3                h166bdaf_0    conda-forge
liblapack                 3.9.0            12_linux64_mkl    conda-forge
libllvm10                 10.0.1               he513fc3_3    conda-forge
libnsl                    2.0.0                h7f98852_0    conda-forge
libpciaccess              0.16                 h516909a_0    conda-forge
libpng                    1.6.37               h753d276_3    conda-forge
libpq                     12.9                 h16c4e8d_3
libsodium                 1.0.18               h36c2ea0_1    conda-forge
libsqlite                 3.40.0               h753d276_0    conda-forge
libstdcxx-ng              12.1.0              ha89aaad_16    conda-forge
libtasn1                  4.18.0               h166bdaf_1    conda-forge
libtiff                   4.4.0                h0e0dad5_3    conda-forge
libunistring              0.9.10               h7f98852_0    conda-forge
libuuid                   2.32.1            h7f98852_1000    conda-forge
libva                     2.15.0               h166bdaf_0    conda-forge
libvpx                    1.11.0               h9c3ff4c_3    conda-forge
libwebp                   1.2.4                h522a892_0    conda-forge
libwebp-base              1.2.4                h166bdaf_0    conda-forge
libxcb                    1.15                 h7f8727e_0
libxkbcommon              1.0.3                he3ba5ed_0    conda-forge
libxml2                   2.9.14               h74e7548_0
libxslt                   1.1.35               h4e12654_0
libzlib                   1.2.13               h166bdaf_4    conda-forge
littleutils               0.2.2                    pypi_0    pypi
lz4-c                     1.9.3                h9c3ff4c_1    conda-forge
markupsafe                2.1.1           py310h5764c6d_2    conda-forge
matplotlib                3.6.2           py310hff52083_0    conda-forge
matplotlib-base           3.6.2           py310h945d387_0
matplotlib-inline         0.1.3                    pypi_0    pypi
mistune                   2.0.4              pyhd8ed1ab_0    conda-forge
mkl                       2021.4.0           h06a4308_640
mkl-service               2.4.0           py310ha2c4b55_0    conda-forge
mkl_fft                   1.3.1           py310h2b4bcf5_1    conda-forge
mkl_random                1.2.2           py310h00e6091_0
munkres                   1.1.4              pyh9f0ad1d_0    conda-forge
mypy-extensions           0.4.3                    pypi_0    pypi
nbclassic                 0.4.8              pyhd8ed1ab_0    conda-forge
nbclient                  0.7.2              pyhd8ed1ab_0    conda-forge
nbconvert                 7.2.7              pyhd8ed1ab_0    conda-forge
nbconvert-core            7.2.7              pyhd8ed1ab_0    conda-forge
nbconvert-pandoc          7.2.7              pyhd8ed1ab_0    conda-forge
nbformat                  5.7.1              pyhd8ed1ab_0    conda-forge
ncurses                   6.3                  h27087fc_1    conda-forge
nest-asyncio              1.5.6              pyhd8ed1ab_0    conda-forge
nettle                    3.8.1                hc379101_1    conda-forge
notebook                  6.5.2              pyha770c72_1    conda-forge
notebook-shim             0.2.2              pyhd8ed1ab_0    conda-forge
nspr                      4.35                 h27087fc_0    conda-forge
nss                       3.82                 he02c5a1_0    conda-forge
numpy                     1.23.1          py310h1794996_0
numpy-base                1.23.1          py310hcba007f_0
ogb                       1.3.5                    pypi_0    pypi
opencv-python             4.6.0.66                 pypi_0    pypi
openh264                  2.2.0                h27087fc_2    conda-forge
openjpeg                  2.4.0                hb52868f_1    conda-forge
openssl                   1.1.1t               h0b41bf4_0    conda-forge
outdated                  0.2.2                    pypi_0    pypi
p11-kit                   0.24.1               hc5aa10d_0    conda-forge
packaging                 22.0               pyhd8ed1ab_0    conda-forge
pandas                    1.5.2                    pypi_0    pypi
pandoc                    2.19.2               ha770c72_0    conda-forge
pandocfilters             1.5.0              pyhd8ed1ab_0    conda-forge
parso                     0.8.3                    pypi_0    pypi
pathspec                  0.10.3                   pypi_0    pypi
patsy                     0.5.3              pyhd8ed1ab_0    conda-forge
pcre                      8.45                 h9c3ff4c_0    conda-forge
pexpect                   4.8.0                    pypi_0    pypi
pickleshare               0.7.5                    pypi_0    pypi
pillow                    9.3.0           py310hace64e9_1
pip                       22.2.2                   pypi_0    pypi
pkgutil-resolve-name      1.3.10             pyhd8ed1ab_0    conda-forge
platformdirs              2.6.0              pyhd8ed1ab_0    conda-forge
ply                       3.11                       py_1    conda-forge
prometheus_client         0.15.0             pyhd8ed1ab_0    conda-forge
prompt-toolkit            3.0.30                   pypi_0    pypi
psutil                    5.9.4           py310h5764c6d_0    conda-forge
ptflops                   0.6.9                    pypi_0    pypi
pthread-stubs             0.4               h36c2ea0_1001    conda-forge
ptyprocess                0.7.0                    pypi_0    pypi
pure-eval                 0.2.2                    pypi_0    pypi
pure_eval                 0.2.2              pyhd8ed1ab_0    conda-forge
pycls                     0.1.1                    pypi_0    pypi
pycparser                 2.21                     pypi_0    pypi
pygments                  2.12.0                   pypi_0    pypi
pyopenssl                 22.0.0                   pypi_0    pypi
pyparsing                 3.0.9              pyhd8ed1ab_0    conda-forge
pyqt                      5.15.7          py310h6a678d5_1
pyqt5-sip                 12.11.0                  pypi_0    pypi
pyrsistent                0.19.2          py310h5764c6d_0    conda-forge
pysocks                   1.7.1           py310hff52083_5    conda-forge
python                    3.10.8          h257c98d_0_cpython    conda-forge
python-dateutil           2.8.2              pyhd8ed1ab_0    conda-forge
python-fastjsonschema     2.16.2             pyhd8ed1ab_0    conda-forge
python_abi                3.10                    2_cp310    conda-forge
pytorch                   1.12.1          py3.10_cuda11.3_cudnn8.3.2_0    pytorch
pytorch-mutex             1.0                        cuda    pytorch
pytz                      2022.6                   pypi_0    pypi
pyyaml                    6.0                      pypi_0    pypi
pyzmq                     24.0.1          py310h330234f_1    conda-forge
qt-main                   5.15.2               h327a75a_7
qt-webengine              5.15.9               hd2b0992_4
qtwebkit                  5.212                h4eab89a_4
readline                  8.1.2                h0f457ee_0    conda-forge
requests                  2.28.1                   pypi_0    pypi
scikit-learn              1.1.2           py310h0c3af53_0    conda-forge
scipy                     1.9.0           py310hdfbd76f_0    conda-forge
seaborn                   0.12.2               hd8ed1ab_0    conda-forge
seaborn-base              0.12.2             pyhd8ed1ab_0    conda-forge
send2trash                1.8.0              pyhd8ed1ab_0    conda-forge
setuptools                64.0.2          py310hff52083_0    conda-forge
simplejson                3.17.6                   pypi_0    pypi
sip                       6.6.2           py310hd8f1fbe_0    conda-forge
six                       1.16.0                   pypi_0    pypi
sniffio                   1.3.0              pyhd8ed1ab_0    conda-forge
soupsieve                 2.3.2.post1        pyhd8ed1ab_0    conda-forge
sqlite                    3.39.2               h4ff8645_0    conda-forge
stack-data                0.3.0                    pypi_0    pypi
stack_data                0.3.0              pyhd8ed1ab_0    conda-forge
statsmodels               0.13.5          py310hde88566_2    conda-forge
svt-av1                   1.2.0                h27087fc_0    conda-forge
terminado                 0.17.1             pyh41d4057_0    conda-forge
threadpoolctl             3.1.0                    pypi_0    pypi
timm                      0.2.1                    pypi_0    pypi
tinycss2                  1.2.1              pyhd8ed1ab_0    conda-forge
tk                        8.6.12               h27826a3_0    conda-forge
toml                      0.10.2             pyhd8ed1ab_0    conda-forge
tomli                     2.0.1                    pypi_0    pypi
torchaudio                0.12.1              py310_cu113    pytorch
torchvision               0.13.1              py310_cu113    pytorch
tornado                   6.2             py310h5764c6d_1    conda-forge
tqdm                      4.64.0                   pypi_0    pypi
traitlets                 5.3.0                    pypi_0    pypi
typing-extensions         4.3.0                    pypi_0    pypi
typing_extensions         4.3.0              pyha770c72_0    conda-forge
tzdata                    2022b                h191b570_0    conda-forge
unicodedata2              15.0.0          py310h5764c6d_0    conda-forge
urllib3                   1.26.11                  pypi_0    pypi
wcwidth                   0.2.5                    pypi_0    pypi
webencodings              0.5.1                      py_1    conda-forge
websocket-client          1.4.2              pyhd8ed1ab_0    conda-forge
wheel                     0.37.1                   pypi_0    pypi
wilds                     2.0.0                    pypi_0    pypi
x264                      1!164.3095           h166bdaf_2    conda-forge
x265                      3.5                  h924138e_3    conda-forge
xorg-fixesproto           5.0               h7f98852_1002    conda-forge
xorg-kbproto              1.0.7             h7f98852_1002    conda-forge
xorg-libx11               1.7.2                h7f98852_0    conda-forge
xorg-libxau               1.0.9                h7f98852_0    conda-forge
xorg-libxdmcp             1.1.3                h7f98852_0    conda-forge
xorg-libxext              1.3.4                h7f98852_1    conda-forge
xorg-libxfixes            5.0.3             h7f98852_1004    conda-forge
xorg-xextproto            7.3.0             h7f98852_1002    conda-forge
xorg-xproto               7.0.31            h7f98852_1007    conda-forge
xz                        5.2.6                h166bdaf_0    conda-forge
yacs                      0.1.8                    pypi_0    pypi
zeromq                    4.3.4                h9c3ff4c_1    conda-forge
zipp                      3.11.0             pyhd8ed1ab_0    conda-forge
zlib                      1.2.13               h166bdaf_4    conda-forge
zstd                      1.5.2                h8a70e8d_4    conda-forge
```