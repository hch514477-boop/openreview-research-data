bash run_rust_beam.sh 1
bash run_rust_beam.sh 2
bash run_rust_beam.sh 4
bash run_rust_beam.sh 8



# bash run_rust_beam.sh 64
# bash run_rust_beam.sh 128




# bash run_rust_beam.sh 16