import json

import random

def generate_exapmes(data, n=1, i=1):

    

    len_ = len(data)

    idxs = random.sample(range(len_), n)
    e = []

    for id in idxs:

        e.append(data[id])

    new_data = {}
    new_data['original'] = e

    with open(str(n) + '/' + str(i), 'w') as f:
        json.dump(new_data, f)


if __name__ == "__main__":

    dataset = 'dataset.json' 

    with open(dataset, 'r') as f:
        # Load the contents of the file into a Python dictionary
        data = json.load(f)
    bs = [1, 2, 4, 8, 16, 32, 64, 128]
    for b in bs:
        for i in range(1, 21):
            print("processing batch size %d, sample %d" % (b, i))
            generate_exapmes(data, n=b, i=i)


