
python generate_multiple_examples_bytes.py --num_subwords 7000 --batch_size 1

python generate_multiple_examples_bytes.py --num_subwords 7000 --batch_size 2

python generate_multiple_examples_bytes.py --num_subwords 7000 --batch_size 4

python generate_multiple_examples_bytes.py --num_subwords 7000 --batch_size 8

# python generate_multiple_examples_bytes.py --num_subwords 500 --batch_size 64

# python generate_multiple_examples_bytes.py --num_subwords 500 --batch_size 128
