from rouge import Rouge

text1 = "Phishing protection blocked 90 percent of verified phishing websites in PC Magazine testing."
text2 = "Fig. 2. In the present experiment, the total number of neurons was divided into three sections, one in order to account for variability in neural activity and to minimize chance of bias. Mice were"


rouge = Rouge()
scores = rouge.get_scores(text1, text2)
print(scores)