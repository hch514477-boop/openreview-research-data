# ================================ aggre ====================================
# path=/home/mengjiao/Documents/workspace/2023S
# DATA_BIN=$path/data/iwslt14/data-bin/moses-bpe-iwslt$3.$1-$2

# custom_model=/home/mengjiao/Documents/workspace/2023S/byte_subword/byte_aggregate
# subword_bytes_file=/home/mengjiao/Documents/workspace/2023S/byte_subword/subword_byte_table.pt


# lr='5e-4'
# freq=8

# LOG_DIR=$path/byte_word/results/bpe_$1_$2_$3_$4_$lr/logs

# mkdir -p $LOG_DIR

# CUDA_VISIBLE_DEVICES=0 fairseq-train \
# $DATA_BIN \
# --save-dir checkpoints/bpe_$1_$2_$3_$4_$freq_${lr} \
# --tensorboard-logdir tensorboard/bpe_$1_$2_$3_$4_$lr_$freq \
# --arch byteword_transformer_iwslt_de_en \
# --share-all-embeddings \
# --user-dir $custom_model \
# --optimizer adam \
# --adam-betas '(0.9, 0.98)' \
# --clip-norm 0.0 \
# --lr $lr \
# --lr-scheduler inverse_sqrt \
# --warmup-updates 4000 \
# --label-smoothing 0.1 \
# --dropout $4 \
# --weight-decay 0.0 \
# --warmup-init-lr '1e-07' \
# --stop-min-lr '1e-09' \
# --criterion label_smoothed_cross_entropy \
# --max-tokens $5 \
# --max-epoch 300 \
# --fp16 \
# --no-epoch-checkpoints \
# --update-freq $freq \
# --bw-aggre 'avg' \
# --bw-layernum 2 \
# --bw-interdim 2048 \
# --bw-padding-idx 258 \
# --bw-byte-subword \
# --bw-std 1.0 \
# --bw-relu-dropout 0.2 \
# --bw-subword-bytes-file $subword_bytes_file \
# --keep-best-checkpoints 5 | tee -a $LOG_DIR/train_byte_aggre_$freq.out


# --stop-min-lr '1e-09' \
# --warmup-init-lr '1e-07' \


# ================================ args check ====================================

# path=/home/mengjiao/Documents/workspace/2023S
# DATA_BIN=$path/data/iwslt14/data-bin/moses-bpe-iwslt$3.$1-$2
# --max-update 50000 \

# custom_model=/home/mengjiao/Documents/workspace/2023S/byte_subword/byte_aggregate
# subword_bytes_file=/home/mengjiao/Documents/workspace/2023S/byte_subword/subword_byte_table.pt


# lr='5e-4'

# LOG_DIR=$path/byte_word/results/bpe_$1_$2_$3_$4_$lr/logs

# mkdir -p $LOG_DIR

# CUDA_VISIBLE_DEVICES=0 fairseq-train \
# $DATA_BIN \
# --help



# ===============================    origin   =====================================
# path=/home/mengjiao/Documents/workspace/2023S
DATA_BIN=data/data-bin/moses-bpe-iwslt$3.$1-$2

custom_model=byte_aggregate
subword_bytes_file=subword2bytes/subword_byte_table.pt
lr=$6
freq=$7
seed=$8
aggre=$9
interdim=${10}
bytenum=${11}

LOG_DIR=results/$aggre/$bytenum/$interdim/bpe_$1_$2_$3_$4_$lr/logs

mkdir -p $LOG_DIR

CUDA_VISIBLE_DEVICES=0 fairseq-train \
$DATA_BIN \
--save-dir checkpoints/$aggre/$bytenum/$interdim/$seed/bpe_$1_$2_$3_$4_$lr \
--tensorboard-logdir tensorboard/$aggre/$bytenum/$interdim/bpe_$1_$2_$3_$4_$lr_$freq/$seed \
--arch byteword_transformer_iwslt_de_en \
--share-all-embeddings \
--user-dir $custom_model \
--optimizer adam \
--adam-betas '(0.9, 0.98)' \
--clip-norm 0.0 \
--lr $lr \
--lr-scheduler inverse_sqrt \
--warmup-updates 4000 \
--stop-min-lr '1e-09' \
--warmup-init-lr '1e-07' \
--label-smoothing 0.1 \
--dropout $4 \
--weight-decay 0.0001 \
--criterion label_smoothed_cross_entropy \
--max-tokens $5 \
--max-epoch 100 \
--fp16 \
--seed $seed \
--no-epoch-checkpoints \
--update-freq $freq \
--bw-aggre 'avg' \
--bw-layernum 2 \
--bw-interdim $interdim \
--bw-padding-idx -1 \
--bw-byte-subword 1 \
--bw-std 1.0 \
--bw-relu-dropout 0.15 \
--bw-subword-bytes-file $subword_bytes_file \
--keep-best-checkpoints 5 | tee -a $LOG_DIR/train_byte_$aggre_$freq_$seed.out

# ========================== original translation ===============================

# path=/home/mengjiao/Documents/workspace/2023S
# DATA_BIN=$path/data/iwslt14/data-bin/moses-bpe-iwslt$3.$1-$2

# custom_model=/home/mengjiao/Documents/workspace/2023S/byte_subword/alone


# CUDA_VISIBLE_DEVICES=0 fairseq-train \
# $DATA_BIN \
# --save-dir checkpoints/bpe_$1_$2_$3_$4 \
# --tensorboard-logdir tensorboard/bpe_$1_$2_$3_$4 \
# --arch transformer_iwslt_de_en \
# --share-all-embeddings \
# --optimizer adam \
# --adam-betas '(0.9, 0.98)' \
# --clip-norm 0.0 \
# --lr 5e-4 \
# --lr-scheduler inverse_sqrt \
# --warmup-updates 4000 \
# --stop-min-lr '1e-09' \
# --warmup-init-lr '1e-07' \
# --label-smoothing 0.1 \
# --dropout $4 \
# --weight-decay 0.0001  \
# --criterion label_smoothed_cross_entropy \
# --max-tokens $5 \
# --max-update 50000 \
# --no-epoch-checkpoints \
# --update-freq 8 \
# --keep-best-checkpoints 5
