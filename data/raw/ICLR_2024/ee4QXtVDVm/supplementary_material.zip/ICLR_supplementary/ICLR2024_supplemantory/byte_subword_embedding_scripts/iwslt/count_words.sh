#!/usr/bin/env bash
# src1=$1
# src2=$2
# tgt=$3
lang_pairs=$1
year=$2
lang_pairs_dict="ar-en,de-en,fa-en,tr-en,zh-en"
# cd examples/translation/

# # lang_pairs="de-en,zh-en,en-de,en-zh"
# echo $lang_pairs

# IFS=',' read -ra l_pairs <<< $lang_pairs

# # echo $l_pairs

# # #Print the split string
# # for element in "${l_pairs[@]}"
# #     do
# #         echo $element
# #         IFS='-' read -r -a l_pair <<< $element
# #         for l in $${l_pair[@]}
# #             do
# #             echo $l
# #         done
# # done

# for element in "${l_pairs[@]}"
#     do
#         echo $element
#         IFS='-' read -r -a l_pair <<< $element
#         echo "======= Creating raw data for ${src1}-${tgt} ======="
#         bash create_iwslt_data_mt.sh ${l_pair[0]} ${l_pair[1]} $year
#         echo "======= Done creating raw data for ${l_pair[0]}-${l_pair[1]} ======="
#     done

# cd ../../


# for element in "${l_pairs[@]}"
#     do
#         echo $element
#         IFS='-' read -r -a l_pair <<< $element
#         echo "======= Creating raw data for ${src1}-${tgt} ======="
#         bash create_iwslt_data.sh ${l_pair[0]} ${l_pair[1]} $year
#         echo "======= Done creating raw data for ${l_pair[0]}-${l_pair[1]} ======="
#     done


python build_dict.py -lp ${lang_pairs_dict} -y $year
