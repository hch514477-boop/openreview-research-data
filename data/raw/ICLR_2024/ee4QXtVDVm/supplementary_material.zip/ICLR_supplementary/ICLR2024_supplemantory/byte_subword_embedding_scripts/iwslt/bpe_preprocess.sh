# path=/home/mengjiao/Documents/workspace/2023S

DATA_BIN=data

python fairseq/fairseq_cli/preprocess.py --source-lang $1 --target-lang $2 \
    --trainpref $DATA_BIN/iwslt$3.moses.bpe.$1-$2/train.$1-$2 \
    --validpref $DATA_BIN/iwslt$3.moses.bpe.$1-$2/valid.$1-$2 \
    --testpref $DATA_BIN//iwslt$3.moses.bpe.$1-$2/test.$1-$2 \
    --destdir $DATA_BIN/data-bin/moses-bpe-iwslt$3.$1-$2 \
    --workers 20 \
    --joined-dictionary