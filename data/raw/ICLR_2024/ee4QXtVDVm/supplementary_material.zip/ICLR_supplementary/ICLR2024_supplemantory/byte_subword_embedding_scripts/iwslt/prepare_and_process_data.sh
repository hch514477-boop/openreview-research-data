src=$1
tgt=$2
year=$3


# cd ..
cd data
echo "======= Creating raw data for ${src}-${tgt} ======="
bash create_iwslt_data.sh $src $tgt $year
echo "======= Done creating raw data for ${src}-${tgt} ======="


# echo "======= Creating BPE data for ${src}-${tgt} ======="
cd ..
bash byte_subword_embedding_scripts/iwslt/bpe_preprocess.sh $src $tgt $year
# echo "======= BPE data ready ======="