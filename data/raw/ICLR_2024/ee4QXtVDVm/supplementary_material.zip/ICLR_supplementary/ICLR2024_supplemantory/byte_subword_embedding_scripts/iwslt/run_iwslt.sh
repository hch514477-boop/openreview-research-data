

lr='5e-4'
freq=2
# seeds='5555,6666,7777,8888,9999'
seeds='5555'
aggre='concate_embedding'
interdim='2048'
bytenum='256_8'

IFS=',' read -ra my_list <<< "$seeds"  # split the string by comma

# for seed in "${my_list[@]}"
# do
#     echo $seed
# donessss


for seed in "${my_list[@]}"
do
    bash byte_subword_embedding_scripts/iwslt/train_bpe.sh de en 14 0.2 4000 $lr $freq $seed $aggre $interdim $bytenum

    # bash byte_subword_embedding_scripts/iwslt/evaluate.sh bpe de en 14 0.2 test $lr $freq $seed $aggre $interdim $bytenum
    # bash byte_subword_embedding_scripts/iwslt/score.sh bpe de en 14 0.2 test $lr $freq $seed $aggre $interdim $bytenum
done

# lr='5e-4'
# freq=2
# seed='5555'
# aggre='concate_onehot'
# interdim='512'
# bash byte_subword_embedding_scripts/iwslt/train_bpe.sh de en 14 0.2 4000 $lr $freq $seed $aggre $interdim

# bash byte_subword_embedding_scripts/iwslt/evaluate.sh bpe de en 14 0.2 test $lr $freq $seed $aggre $interdim
# bash byte_subword_embedding_scripts/iwslt/score.sh bpe de en 14 0.2 test $lr $freq $seed $aggre $interdim