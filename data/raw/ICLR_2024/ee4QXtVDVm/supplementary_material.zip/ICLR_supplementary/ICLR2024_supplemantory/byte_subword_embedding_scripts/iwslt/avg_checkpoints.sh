checkpoint_path=checkpoints

# if [ -d $checkpoint_path ] 
# then
#     echo "Directory exists." 
# else
#     echo "Error: Directory does not exists."
# fi
# ls $checkpoint_path/$1
# exit

python fairseq/scripts/average_checkpoints.py --all-loss-checkpoints --dir $checkpoint_path/$1 --output $checkpoint_path/$1/checkpoint_avg.pt
