# Create environment
1. conda create -n bse python==3.9 and activate
2. cd fairseq
3. pip install --editable ./
4. cd ..

# preprocess iwslt14 data
1. make directory data/orig (download de-en)
2. cd data
3. git clone https://github.com/moses-smt/mosesdecoder.git
   git clone https://github.com/rsennrich/subword-nmt.git
4. cd ..
5. bash byte_subword_embedding_scripts/iwslt/prepare_and_process_data.sh de en 14
6. bash byte_subword_embedding_scripts/iwslt/run_iwslt.sh