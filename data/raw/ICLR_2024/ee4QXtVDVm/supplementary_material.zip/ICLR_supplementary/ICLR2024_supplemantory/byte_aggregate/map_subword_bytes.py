import numpy as np
import torch
from torch.nn.utils.rnn import pad_sequence


dictionary_path = "/home/mengjiao/Documents/workspace/2023S/data/iwslt14/data-bin/moses-bpe-iwslt14.de-en"
dict_name = "dict.en.txt"

dict_file = dictionary_path + '/' + dict_name



# bos="<s>"
# pad="<pad>"
# eos="</s>"
# unk="<unk>"
result = []

for w in range(257, 261):
    word = torch.tensor([w])
    result.append(word)

with open(dict_file, encoding="utf-8") as input:
    for i, line in enumerate(input):
        # print("word and index is:", line)
        word_freq = line.split()
        word = word_freq[0]
        # print("word is:", word)
        word_encoding = list(map(str, word.strip().encode('utf-8')))
        w = [int(i) for i in word_encoding]
        word = torch.tensor(w)
        # print(str_);exit()
        result.append(word)



# <pad> is 258
# padding_idx = 258


# special_symbols = ["<s>", "<pad>", "</s>", "<unk>"]
# for i, sysmbol in enumerate(special_symbols):
#     if sysmbol == "<pad>":
#         word_encoding = ['257']
#     else:
#         word_encoding = list(map(str, sysmbol.strip().encode('utf-8')))
#     w = [int(i) for i in word_encoding]
#     word = torch.tensor(w)
#     # print(str_);exit()
    # result.append(word)
# special_symbols = ["<s>", "<pad>", "</s>", "<unk>"]
# for i, sysmbol in enumerate(special_symbols):
#     if sysmbol == "<pad>":
#         word_encoding = ['257']
#     else:
#         word_encoding = list(map(str, sysmbol.strip().encode('utf-8')))
#     w = [int(i) for i in word_encoding]
#     word = torch.tensor(w)
#     # print(str_);exit()
#     result.append(word)
# print(result[:10])
subword_byte_table = pad_sequence(result, batch_first=True, padding_value=258.0)
# print(subword_byte_table[1])
print(subword_byte_table.size())

# if os.path.isfile(subword_bytes_file):
#     subword_bytes_table = torch.load(subword_bytes_file)
# else:
#     print("please provide the subword to bytes table.")
#     exit()



torch.save(subword_byte_table, 'subword_byte_table.pt')