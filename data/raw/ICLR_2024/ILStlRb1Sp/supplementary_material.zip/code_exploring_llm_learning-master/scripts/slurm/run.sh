#!/bin/bash

# GPUS_PER_NODE=1
# MASTER_ADDR=$(scontrol show hostnames $SLURM_JOB_NODELIST | head -n 1)
# MASTER_PORT=9901
NODE_GPUS="${SLURM_STEP_GPUS:-$SLURM_JOB_GPUS}"

echo "Running on $HOSTNAME"
nvidia-smi
# top -bn 1

# srun --jobid $SLURM_JOBID bash -c \
#     "python3 -u ./scripts/run_docker.py \
#     --gpus=$NODE_GPUS \
#     --no-progressbar \
#     python3 -m torch.distributed.run \
#     --nproc_per_node $GPUS_PER_NODE \
#     --master_port $MASTER_PORT \
#     --nnodes $SLURM_NNODES \
#     --node_rank $SLURM_PROCID \
#     src/main.py $args"
#

# if [ "$1" = "devel" ]; then
#     docker_args="--type devel"
# elif [ "$1" = "runtime" ]; then
#     docker_args="--type runtime"
# else
#     echo "Unknown argument $1"
#     exit 1
# fi
# shift
args="$@"

command="python3 -u ./scripts/run_docker.py \
    --gpus=$NODE_GPUS \
    --no-progressbar \
    $args"
# $docker_args \
echo "Running $command"
bash -c "$command"

echo "Done"
