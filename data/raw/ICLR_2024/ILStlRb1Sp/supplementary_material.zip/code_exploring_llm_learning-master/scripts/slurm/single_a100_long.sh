#!/bin/bash
#
#SBATCH --partition=a100        # GPU partition to use
#SBATCH --gres gpu:1            # Number of GPUs per job
#SBATCH -c 12                   # Number of cores
#SBATCH -N 1                    # Ensure that all cores are on one machine
#SBATCH -t 1-00:00              # Maximum run-time in D-HH:MM
#SBATCH --mem=196G              # Memory pool for all cores (see also --mem-per-cpu)
#SBATCH -o logs/1a100_long_%j.out    # File to which STDOUT will be written
#SBATCH -e logs/1a100_long_%j.out    # File to which STDERR will be written

scripts/slurm/run.sh "$@"
