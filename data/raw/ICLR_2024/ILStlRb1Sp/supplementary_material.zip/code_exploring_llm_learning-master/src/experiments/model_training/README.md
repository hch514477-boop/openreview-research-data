# Model Training

We finetune models on different random string configurations and log their training loss and memorization behavior.
