# What performance can we achieve with different prefix lengths?

We want to test whether using prefixes that are much shorter than the full prefix (e.g. 5 tokens vs 100) is sufficient for predicting the target token correctly.
If this is the case, then it shows that models are primarily relying on local information in their recollection of tokens in a memorized string, i.e. on prefixes that are immediately preceding the target token.
