## DiffSound
### Requirements
- Pytorch 2.0 + torchaudio
- cuda 11.7
- pytorch-scatter
- fTetWild
- scipy, matplotlib, tqdm, numpy, meshio, pymesh, open3d
- configparser, datetime, yaml, plotly, ipywidgets, IPython

### Experiments
All experiments are located under the experiments directory.
To run one of the experiments, select a `.ini` configuration file from the `experiments/configs `directory as the command-line argument. For example:
`python mat_train.py experiments/configs/bowl_mat.ini`