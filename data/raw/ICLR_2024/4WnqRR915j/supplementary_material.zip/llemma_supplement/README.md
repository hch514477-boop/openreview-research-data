# Llemma Supplement

Supplementary materials for "Llemma: an Open Language Model For Mathematics".

The `pretraining` directory contain configuration files that completely specify the training hyperparameters of Llemma 7B and 34B (except distributed world size).

The `algebraic-stack` directory contains scripts for redownloading and refiltering the Algebraic Stack. 

The file `sample.jsonl` contains representative samples from the aggregated Proof-Pile-2. 
