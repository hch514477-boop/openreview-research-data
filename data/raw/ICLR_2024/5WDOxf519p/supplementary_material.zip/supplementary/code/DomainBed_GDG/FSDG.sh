for algo in "GDG" "ERM" "GVRT" "MIRO" "Fish" "IRM" "GroupDRO" "Mixup" "MLDG" "CORAL" "MMD" "DANN" "CDANN" "MTL" "SagNet" "ARM" "VREx" "RSC" "SD" "ANDMask" "SANDMask" "IGA" "SelfReg" "Fishr" "TRM" "IB_ERM" "IB_IRM" "CAD" "CondCAD" "Transfer" "CausIRL_CORAL" "CausIRL_MMD" "EQRM" "MDSDI"
do
    python3 -m domainbed.scripts.train \
            --data_dir=data \
            --algorithm $algo \
            --dataset $2 \
            --trial_seed $3 \
            --hparams_seed $4 \
            --test_env 0 \
            --output_dir=train_output/$2/$1/fs_${algo}_trial${3}_hparam${4}/test_env0 $5 &&
    
    python3 -m domainbed.scripts.train \
            --data_dir=data \
            --algorithm $algo \
            --dataset $2 \
            --trial_seed $3 \
            --hparams_seed $4 \
            --test_env 1 \
            --output_dir=train_output/$2/$1/fs_${algo}_trial${3}_hparam${4}/test_env1 $5 &&
    
    python3 -m domainbed.scripts.train \
            --data_dir=data \
            --algorithm $algo \
            --dataset $2 \
            --trial_seed $3 \
            --hparams_seed $4 \
            --test_env 2 \
            --output_dir=train_output/$2/$1/fs_${algo}_trial${3}_hparam${4}/test_env2 $5 &&
    
    python3 -m domainbed.scripts.train \
            --data_dir=data \
            --algorithm $algo \
            --dataset $2 \
            --trial_seed $3 \
            --hparams_seed $4 \
            --test_env 3 \
            --output_dir=train_output/$2/$1/fs_${algo}_trial${3}_hparam${4}/test_env3 $5 &&

    python3 -m domainbed.scripts.train \
            --data_dir=data \
            --algorithm $algo \
            --dataset $2 \
            --trial_seed $3 \
            --hparams_seed $4 \
            --test_env 4 \
            --output_dir=train_output/$2/$1/fs_${algo}_trial${3}_hparam${4}/test_env4 $5 &&

    python3 -m domainbed.scripts.train \
            --data_dir=data \
            --algorithm $algo \
            --dataset $2 \
            --trial_seed $3 \
            --hparams_seed $4 \
            --test_env 5 \
            --output_dir=train_output/$2/$1/fs_${algo}_trial${3}_hparam${4}/test_env5 $5
done