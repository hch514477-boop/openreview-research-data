python3 -m domainbed.scripts.train \
       --data_dir=data \
       --algorithm $1 \
       --dataset $2 \
       --test_env $3 \
       --hparams_seed $4 \
       --output_dir=train_output/$5/$2/$2$4_testenv$3

# ./train.sh GDG DomainNet 0 0 graph_lr100 && ./train.sh GDG DomainNet 1 0 graph_lr100 && ./train.sh GDG DomainNet 2 0 graph_lr100 && ./train.sh GDG DomainNet 3 0 graph_lr100 && ./train.sh GDG DomainNet 4 0 graph_lr100 && ./train.sh GDG DomainNet 5 0 graph_lr100 &&
# ./train.sh GDG DomainNet 0 1 graph_lr100 && ./train.sh GDG DomainNet 1 1 graph_lr100 && ./train.sh GDG DomainNet 2 1 graph_lr100 && ./train.sh GDG DomainNet 3 1 graph_lr100 && ./train.sh GDG DomainNet 4 1 graph_lr100 && ./train.sh GDG DomainNet 5 1 graph_lr100 &&
# ./train.sh GDG DomainNet 0 2 graph_lr100 && ./train.sh GDG DomainNet 1 2 graph_lr100 && ./train.sh GDG DomainNet 2 2 graph_lr100 && ./train.sh GDG DomainNet 3 2 graph_lr100 && ./train.sh GDG DomainNet 4 2 graph_lr100 && ./train.sh GDG DomainNet 5 2 graph_lr100

#./train.sh GDG OfficeHome 0 0 graph_lr100 && ./train.sh GDG OfficeHome 1 0 graph_lr100 && ./train.sh GDG OfficeHome 2 0 graph_lr100 && ./train.sh GDG OfficeHome 3 0 graph_lr100 &&
#./train.sh GDG OfficeHome 0 1 graph_lr100 && ./train.sh GDG OfficeHome 1 1 graph_lr100 && ./train.sh GDG OfficeHome 2 1 graph_lr100 && ./train.sh GDG OfficeHome 3 1 graph_lr100 &&
#./train.sh GDG OfficeHome 0 2 graph_lr100 && ./train.sh GDG OfficeHome 1 2 graph_lr100 && ./train.sh GDG OfficeHome 2 2 graph_lr100 && ./train.sh GDG OfficeHome 3 2 graph_lr100 &&
#./train.sh GDG TerraIncognita 0 0 graph_lr100 && ./train.sh GDG TerraIncognita 1 0 graph_lr100 && ./train.sh GDG TerraIncognita 2 0 graph_lr100 && ./train.sh GDG TerraIncognita 3 0 graph_lr100 &&
#./train.sh GDG TerraIncognita 0 1 graph_lr100 && ./train.sh GDG TerraIncognita 1 1 graph_lr100 && ./train.sh GDG TerraIncognita 2 1 graph_lr100 && ./train.sh GDG TerraIncognita 3 1 graph_lr100 &&
#./train.sh GDG TerraIncognita 0 2 graph_lr100 && ./train.sh GDG TerraIncognita 1 2 graph_lr100 && ./train.sh GDG TerraIncognita 2 2 graph_lr100 && ./train.sh GDG TerraIncognita 3 2 graph_lr100