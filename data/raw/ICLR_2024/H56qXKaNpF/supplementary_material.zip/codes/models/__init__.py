from .diffusion import GuideDiffusion


gen_list = {"guidediffusion": GuideDiffusion, 
            }

def get_model(opt):
    model = gen_list[opt["name"]](**opt["args"])
    model.init_weights()
    return model