This folder contains video samples (slowed down to 4fps for viewability) for methods in the paper.

Main methods to compare:

**DWM**

- `csgo_dwm_framestack_T=20_gen_real.avi`
- `drive_dwm_crossattention_T=20_gen_real.avi`

**IRIS**

- `csgo_IRIS_16token_gen_real.avi`
- `drive_IRIS_16token_gen_real.avi`

**DreamerV3**

- `csgo_dreamerv3_gen_real.avi`
- `drive_dreamerv3_gen_real.avi`

To identify other methods, see the extended results in Table 3.

Also included are `atari_breakout_dwm.mp4`, `atari_breakout_IRIS.mp4`, `atari_asterix_dwm.mp4`, `atari_asterix_IRIS.mp4`. These provide a short clip of IRIS and DWM modeling Breakout and Asterix, and relate to the Breakout/Asterix Figure in the paper.