#! /bin/sh

conda create -n dwm python=3.10
conda activate dwm
pip install -r requirements.txt
AutoROM -y