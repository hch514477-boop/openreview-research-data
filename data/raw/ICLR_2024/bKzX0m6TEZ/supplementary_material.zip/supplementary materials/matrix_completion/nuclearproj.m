function [A] = nuclearproj(X,delta)

[U,S,V] = svd(full(X), 'econ');
d = diag(S);


if (sum(d) > delta) 
    newd = simplexproj(d,delta);
	A = U * diag(newd) * V';
else
	A = X;
end
return;