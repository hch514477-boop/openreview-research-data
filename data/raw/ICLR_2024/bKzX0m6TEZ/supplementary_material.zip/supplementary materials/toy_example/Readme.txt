Toy Example:
This toy example presents a variation of the coreset problem in a two-dimensional space. 

Problem Description:
Given a target point x0 and a set of points {x1, x2, x3, x4} in a two-dimensional space.
The task is to find the point among the convex hull of the 4 given points {x1, x2, x3, x4} that is closest to the target point x0.
The proximity is measured under a linear map A, meaning the selected point should be the closest when transformed using the linear mapping.
Additionally, the selected point must lie within the convex hull formed by {x1, x2, x3, x4}.

* For more details see Section 5.1. and Appendix G of the paper. 

Implementation:
Run the script "toy_example.m".
MATLAB: Make sure you have MATLAB installed on your system.
CVX: This problem requires the CVX package for solving a convex optimization problem
      Installation:
      Download CVX: Visit the CVX website at CVX Website(https://cvxr.com/cvx/) and download the appropriate version of CVX.
      Install CVX: Follow the installation instructions provided on the CVX website to install the package correctly.

