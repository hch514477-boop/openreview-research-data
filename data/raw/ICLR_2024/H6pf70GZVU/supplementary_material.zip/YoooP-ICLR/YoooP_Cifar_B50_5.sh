python Run.py \
`# ==> execulator` \
--phase_train True \
--up2now_test False \
`# ==> Global setting` \
--sys_device_ids [2] \
--threads 16 \
--dataset_path '' \
--dataset 'CIFAR-100' \
`# ==> Preprocess setting` \
--resize_h_w [32,32] \
--rotate_prob 0.2 \
--mirror_type 'random' \
`# ==> train dataset setting` \
--init_class_number 50 \
--phase 5 \
--ids_per_batch 4 \
--ims_per_id 64 \
--init_ids_per_batch 32 \
--init_ims_per_id 8 \
`# ==> test setting` \
--test_batch_size 256 \
`# ==> train/test process setting` \
--resume False \
--model 'Resnet18' \
--steps_per_log 10 \
--epochs_per_val 2 \
--epochs_per_task 60 \
`# ==> lr setting` \
--base_lr 0.01 \
--decay_factor 0.1 \
--lr_decay_type 'staircase' \
--staircase_decay_at_epochs [20,40,60] \
`# -> lr_status set for f_new_parameters` \
--lr_satus 1.5 \
`# ==> loss setting` \
--backbone_feature_loss 'msaloss' \
--arcface_s 16 \
--arcface_m2 0.25 \
--backbone_local_loss 'KLloss' \
--backbone_local_loss_weight 6.0 \
`# ==> file setting` \
--exp_dir '' \
--train_path '' \
--test_path ''