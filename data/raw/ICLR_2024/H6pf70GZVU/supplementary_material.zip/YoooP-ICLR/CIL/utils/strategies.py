def get_lr_kwarg(**kwargs):
    # lr strategy setting
    if kwargs['lr_decay_type'] in ['staircase', 'warmup']:
        decay_at_epochs = kwargs['staircase_decay_at_epochs']
        factor = kwargs['decay_factor']
    elif kwargs['lr_decay_type'] == 'exp':
        decay_at_epochs = kwargs['exp_decay_at_epoch']
        factor = kwargs['decay_factor']
    elif kwargs['lr_decay_type'] == 'epochs':
        decay_at_epochs = kwargs['epoch_decay_steps']
        factor = kwargs['decay_factor']
    return decay_at_epochs, factor
