# Revisiting Non-separable Classification and its applications in Anomaly Detection

## Code Directory

Part of this submission includes code used to run the experiments in the main paper and appendix.


For linear binary classification experiments, we share our code for solving the XOR problem, general
linearly non-separable problems and linearly separable problems. 

For non-linear synthetic anomaly detection (AD) experiments, we share our code that uses shallow models, deep models with 2 hidden
layers and deep models with 3 hidden layers. 

For experiments on non-linear supervised AD with
NSL-KDD dataset, we share our code on shallow methods/baselines, binary classification, Negative
Sampling (NS) and Deep Semi-Supervised Anomaly Detection (SAD).
Note that you will first need to download the NSL-KDD dataset.