from setuptools import setup

setup(name='GEMINI',
      version='0.1',
      description='',
      author='',
      author_email='',
      license='MIT',
      package_dir={'': '2_code'},
      packages=['gpl'],
      zip_safe=False)
