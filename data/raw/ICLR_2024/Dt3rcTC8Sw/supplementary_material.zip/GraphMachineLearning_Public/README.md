# Enhancing Mutual Information Estimation in Self-Interpretable Graph Neural Networks
This is the implementation of GEMINI, a self-interpretable GNN framework with an enhanced mutual information estimator for graphs.


# Run
1. Install this repo
```
pip install -e .
```
2. run the main.py script
```
cd 3_pipeline/
python main.py dataset=spmotif_0.5 model=GIN train=true debug=false device='cuda:0'
```

# Datasets info
- Spurious-Motifs series datasets can be generated automatically.
- For other datasets, they can be downloaded online.
- - ogbg-molhiv: https://github.com/snap-stanford/ogb/blob/master/ogb/utils/features.py
- - mnist & mutag & Graph-SST2: https://github.com/Graph-COM/GSAT/tree/main/data
