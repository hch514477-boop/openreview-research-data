#!/bin/bash

name='shop_multi'
path_config='config_'$name'.yaml'
folder_base='./output/images'
folder_train=$folder_base'/3_6'
folder_out='./output'
python ../src/create_dataset.py \
    --name $name \
    --path_config $path_config \
    --folder_train $folder_train \
    --folder_out $folder_out \
    --multiview