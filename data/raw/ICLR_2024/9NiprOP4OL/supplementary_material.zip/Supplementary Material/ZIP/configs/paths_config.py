DATASET_PATHS = {
	'FFHQ': '/hdd1/datasets/celeba_hq/',
	'CelebA_HQ': '/data/Datasets/gc',
	'AFHQ': '/hdd1/datasets/afhq/',
	'LSUN':  '/hdd1/datasets/lsun/',
    'IMAGENET': '/hdd1/datasets/imagenet/',
	'CUSTOM': '/hdd1/custom/',
	'CelebA_HQ_Dialog': '/hdd1/datasets/img_align_celeba/',
	'MetFACE': '/hdd1/datasets/metfaces/',
}

MODEL_PATHS = {
	'AFHQ': "pretrained/afhq_dog_4m.pt",
	'FFHQ': "pretrained/ffhq_10m.pt",
	'ir_se50': 'pretrained/model_ir_se50.pth',
    'IMAGENET': "pretrained/512x512_diffusion.pt",
	'shape_predictor': "pretrained/shape_predictor_68_face_landmarks.dat.bz2",
	'MetFACE' : "pretrained/metface_p2.pt",
}
