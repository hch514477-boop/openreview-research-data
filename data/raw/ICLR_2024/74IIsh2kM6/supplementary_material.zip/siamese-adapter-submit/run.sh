export MASTER_ADDR=localhost
export MASTER_PORT=5888

python -B infer_s2s.py --config-dir ./conf/ --config-name s2s_decode.yaml \
 dataset.gen_subset=test common_eval.path=/siamese-adapter-submit/checkpoint/lrs2_checkpoint_base.pt \
 common_eval.results_path=/siamese-adapter-submit/result_path/ \
 override.modalities=['audio','video'] common.user_dir=/siamese-adapter-submit/ \
 generation.beam=50 \
 override.data=/siamese-adapter-submit/example_data/test_dir/ override.label_dir=/siamese-adapter-submit/example_data/test_dir/
