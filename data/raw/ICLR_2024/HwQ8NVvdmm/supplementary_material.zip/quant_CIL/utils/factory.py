from models.icarl import iCaRL
from models.lwf import LwF
from models.bic import BiC

def get_model(model_name, args):
  name = model_name.lower()
  if name == "icarl":
    return iCaRL(args)
  elif name == "bic":
    return BiC(args)
  elif name == "lwf":
    return LwF(args)
  else:
    assert 0