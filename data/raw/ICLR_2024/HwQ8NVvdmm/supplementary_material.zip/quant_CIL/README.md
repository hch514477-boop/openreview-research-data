# Quantized Class Incremental Learning

## Run Command

No quant baseline:
```python
python3 main.py -model icarl -p benchmark -seed 42467 --dataset="cifar100" --init_cls=2 --incre=2  --model_type="resnet32" --quantMethod="noq"
```

HDQT with CIL:
```python
python3 main.py -model icarl -p benchmark -seed 42467 --dataset="cifar100" --init_cls=2 --incre=2  --model_type="resnet32" --quantMethod="ours" --quantBits=4 --quantFWDWgt="int" --quantFWDAct="int" --quantBWDAct="stoch" --quantBWDWgt="int" --quantBWDGrad1="stoch" --quantBWDGrad2="stoch" --quantBlockSize=32
```

## Requirements

```
torch==2.0.1
pandas
scipy
tqdm
numpy
quadprog
POT
```


## Sources
- https://openreview.net/forum?id=yTbNYYcopd  luq
- https://openreview.net/forum?id=3HJOA-1hb0e fp134
- https://github.com/zhoudw-zdw/CIL_Survey 
