import os
import json

root_path = '/ina2018/train_val2018'

with open('categories.json', 'r') as f:
    meta_info = json.load(f)

should_saved_info = []
for mi in meta_info:
    should_saved_info.append(mi['name'])

with open('labels_name.txt', 'w') as f:
    f.write('\n'.join(should_saved_info))

