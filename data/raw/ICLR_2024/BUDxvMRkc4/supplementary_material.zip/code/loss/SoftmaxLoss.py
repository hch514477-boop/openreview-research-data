import torch.nn as nn

def create_loss(weights=None):
    print('Loading Softmax Loss.')
    return nn.CrossEntropyLoss(reduction='none', weight=weights)

