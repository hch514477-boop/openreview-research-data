# BALLAD
This is the official code repository for [*BLG: BALANCED LANGUAGE DISTRIBUTION AS GUIDANCE FOR ROBUST LONG-TAILED VISION CLASSIFICATION*]

## Requirements
* Python3
* Pytorch(1.7.1 recommended)
* clip
* yaml
* other necessary packages

## Datasets
* ImageNet_LT
* Places_LT
* iNaturalist2018

Download the [ImageNet_2014](http://image-net.org/index), [Places_365](http://places2.csail.mit.edu/download.html) and [iNaturalist2018](https://paperswithcode.com/sota/image-classification-on-inaturalist-2018)

Modify the data_root in [main.py](main.py) to refer to your own dataset path.

## Training

#### Phase A
```
python main.py --cfg ./config/ImageNet_LT/clip_A_rn50.yaml
```

#### Phase B
```
python main.py --cfg ./config/ImageNet_LT/clip_B_rn50.yaml
```

## Testing
```
python main.py --cfg ./config/ImageNet_LT/test.yaml --test
```
