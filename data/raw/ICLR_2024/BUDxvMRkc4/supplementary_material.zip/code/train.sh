#ViT-B/16
# CUDA_VISIBLE_DEVICES=1 python main.py --c ./config/Places_LT/clip_B_vit_base_16.yaml 
# CUDA_VISIBLE_DEVICES=1 python main.py --c ./config/ImageNet_LT/clip_B_vit_base.yaml 
# CUDA_VISIBLE_DEVICES=1 python main.py --c ./config/iNaturalist18/clip_A_vit_base_16.yaml
# CUDA_VISIBLE_DEVICES=1 python main.py --c ./config/iNaturalist18/clip_B_vit_base_16.yaml

#RN50
# CUDA_VISIBLE_DEVICES=0 python main.py --c ./config/iNaturalist18/clip_B_rn50.yaml 
# CUDA_VISIBLE_DEVICES=2 python main.py --c ./config/ImageNet_LT/clip_B_rn50.yaml
# CUDA_VISIBLE_DEVICES=4 python main.py --c ./config/ImageNet_LT/clip_B_vit_base.yaml
# CUDA_VISIBLE_DEVICES=0 python main.py --c ./config/Places_LT/clip_B_rn50.yaml

#test
# CUDA_VISIBLE_DEVICES=1 python main.py --c ./config/ImageNet_LT/test.yaml --test
# CUDA_VISIBLE_DEVICES=1 python main.py --c ./config/Places_LT/test.yaml --test