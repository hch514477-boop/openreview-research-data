#!/bin/bash
dataset_path=/local/home/stuff
path=/local/home/author/run-data/resnet50-imagenet
checkpoint_path=/local/home/author/run-data/resnet50_imagenet_ep-90_lr-0.1_bsz-256_mom-0.9_wdecay-0.0001_seed-0_2023-02-21_10-45-30_983469

width=50
weights=PRETRAINED
epoch=10

runtimestamp=`date +%s`

# start the computation
CUDA_VISIBLE_DEVICES="" pipenv run python code/resnet_upper_lip.py \
    --width $width --weights $weights --runtimestamp $runtimestamp --path $path \
    --checkpoint_path $checkpoint_path --checkpoint_epoch $epoch
