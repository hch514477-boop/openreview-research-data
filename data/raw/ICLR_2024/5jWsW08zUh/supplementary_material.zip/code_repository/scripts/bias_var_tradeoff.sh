#!/bin/bash
path=/local/home/author/run-data/mnist1d-mse
dataset_path=/local/home/author/run-data

runs=(
MNIST1D+LeakyOutput_FF_ReLU_16+MSE+SGD_0.001_Warmup20000Step25+alpha_0.0+seed_101+target_0.01+runtimestamp_1684051761/
MNIST1D+LeakyOutput_FF_ReLU_16+MSE+SGD_0.001_Warmup20000Step25+alpha_0.0+seed_27+target_0.01+runtimestamp_1684051761/
MNIST1D+LeakyOutput_FF_ReLU_16+MSE+SGD_0.001_Warmup20000Step25+alpha_0.0+seed_404+target_0.01+runtimestamp_1684051761/
MNIST1D+LeakyOutput_FF_ReLU_16+MSE+SGD_0.001_Warmup20000Step25+alpha_0.0+seed_42+target_0.01+runtimestamp_1683909146/
)

device=CPU

runtimestamp=`date +%s`

# start the computation
CUDA_VISIBLE_DEVICES="" pipenv run python code/bias_var_tradeoff.py \
    --path $path --dataset_path $dataset_path --runs ${runs[@]} --timestamp $runtimestamp \
    --batch_size 512 --device $device
