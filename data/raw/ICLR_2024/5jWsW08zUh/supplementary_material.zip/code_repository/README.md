## Requirements
- **Mandatory**: 
	- For package versioning [`pipenv`](https://pypi.org/project/pipenv/) is required (regardless of the installation).
- **Optional**: 
	- Python version specified in `.python-version` is controlled by [`pyenv`](https://github.com/pyenv/pyenv). Installing other python versions could be done using other methods.

## Running the code
Check the `scripts` directory, it contains bash scripts to train models and compute their Lipschitz bounds during training. Modify the variables in the script to change learning parameters (do not forget to change the paths to save results).

Results can be viewed using `tensorboard` or by parsing `.csv` files in the `${path}/runs/${run_name}` directory.
