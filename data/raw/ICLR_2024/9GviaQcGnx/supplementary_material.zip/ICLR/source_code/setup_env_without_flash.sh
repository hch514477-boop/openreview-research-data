#!/bin/bash -x


conda create --name cpr python=3.10 -y
conda activate cpr
pip install --upgrade pip setuptools wheel
pip install tqdm pyyaml pyaml numpy scipy pandas scikit-learn matplotlib
conda install pytorch torchvision torchaudio pytorch-cuda=11.7 -c pytorch -c nvidia -y
pip install triton==2.0.0.dev20221202 ninja
pip install tensorboard==2.13.0 transformers==4.30.2 datasets==2.13.1 pytorch-lightning==2.0.4 deepspeed==0.9.5
pip install nnunetv2==2.2