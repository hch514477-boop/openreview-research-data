#!/usr/bin/env python

import shutil
from distutils.core import setup
from setuptools import find_packages

setup(name='cpr',
      version="0.0.1",

      packages=find_packages(),

      dependency_links=[],
      )
