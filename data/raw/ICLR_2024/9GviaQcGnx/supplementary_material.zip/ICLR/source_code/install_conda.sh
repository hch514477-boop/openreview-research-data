#!/bin/bash -x




wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh -O miniconda_install.sh
bash miniconda_install.sh -b -u -p miniconda3
rm -rf miniconda_install.sh
miniconda3/bin/conda init bash
source miniconda3/bin/activate
