# PygHO

A library for high-order GNN based on torch_geometric.

## Installation
Install it locally
```
cd PygHO
pip install -e ./
```
`-e` enables modifying the library code dynamically and is optional. 

## reproduce

`reproduce.sh` provides the command needed for reproducing each model.

## Document

Open `build/html/index.html` in browser for the document.