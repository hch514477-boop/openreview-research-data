
import json
import sys
sys.path.append('../')
from templates import *
datasets=['imagenet','cifar10','cifar100','caltech101','cars196','dtd','eurosat','food101','oxford_flowers102','oxford_iiit_pet','resisc45','sun397','fgvc_aircraft']
# datasets=['imagenet']
for dataset in datasets:
    file_name="descriptors_{}.json".format(dataset)
    orgin_class_name=(ZEROSHOT_CLASS_NAMES[dataset])

    with open(file_name, 'r') as f:
        des=json.load(f)
        des_class_name=list(des.keys())
    assert(len(orgin_class_name)==len(des_class_name))
    for i in range(len(orgin_class_name)):
        res=(orgin_class_name[i]==des_class_name[i])
        # if res==False:
        #     print(dataset,orgin_class_name[i],'|',des_class_name[i])
        if des[des_class_name[i]]==[]:
            print(dataset,'|',des_class_name[i])