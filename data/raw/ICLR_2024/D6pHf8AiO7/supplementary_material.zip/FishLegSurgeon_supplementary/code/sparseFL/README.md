# SparseFL

This code is based on the SparseML GitHub repository. Please refer to the README_sparseML file for the original instructions.



