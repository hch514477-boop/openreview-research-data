from .accuracy import *

ACCURACY = {
    "mse": MSE_accuracy,
    "bernoulli": bernoulli_accuracy,
    "class": class_accuracy,
}
