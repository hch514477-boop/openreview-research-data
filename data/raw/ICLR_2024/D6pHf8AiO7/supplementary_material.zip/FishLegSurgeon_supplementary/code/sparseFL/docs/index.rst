..
    Copyright (c) 2021 - present / Neuralmagic, Inc. All Rights Reserved.
    
    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at
    
       http://www.apache.org/licenses/LICENSE-2.0
    
    Unless required by applicable law or agreed to in writing,
    software distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.

.. mdinclude:: ../README.md

.. toctree::
    :maxdepth: 3
    :caption: General

    source/installation
    source/code
    source/recipes
    source/onnx_export

.. toctree::
    :maxdepth: 2
    :caption: API

    api/sparseml

.. toctree::
    :maxdepth: 3
    :caption: Connect Online

    Bugs, Feature Requests <https://github.com/neuralmagic/sparseml/issues>
    Deep Sparse Community Slack <https://join.slack.com/t/discuss-neuralmagic/shared_invite/zt-q1a1cnvo-YBoICSIw3L1dmQpjBeDurQ>
    Neural Magic GitHub <https://github.com/neuralmagic>
    Neural Magic Docs <https://docs.neuralmagic.com>
