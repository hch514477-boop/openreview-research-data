#!/usr/bin/env python

from setuptools import setup, find_packages

setup(name='em_discrete',
      version='1.0',
      description='Python Modules for Discrete Episodic Memory',
      author='<redacted>',
      author_email='<redacted>',
      packages=['em_discrete']
      )
