#!/usr/bin/env python

from setuptools import setup, find_packages

setup(name='emt_tools',
      version='0.0.1',
      description='Python modules for the mechanistic interpretation of neural networks using the Episodic Memory '
                  'Theory',
      author='<redacted>',
      author_email='<redacted>',
      packages=['emt_tools']
      )
