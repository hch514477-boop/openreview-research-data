import numpy as np


data = np.load("SfBC//dataset/toy.npy", allow_pickle=True).item()
print(data)
