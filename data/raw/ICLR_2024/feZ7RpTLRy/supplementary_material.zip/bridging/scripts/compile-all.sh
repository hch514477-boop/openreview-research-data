#!/bin/sh

cd hyperrogue
make mymake
./mymake -O3 -rv
cd ..

cd hyperbolic-embedder
make
cd ..

cd poincare-embeddings
python setup.py build_ext --inplace
cd ..

cd hypviewer
g++ gentree.cpp -o gentree -I include/ src/HypGraph.cpp src/HypNode.cpp src/HypPoint.cpp src/HypTransform.cpp src/HypNodeArray.cpp src/HypLink.cpp src/HypGroupArray.cpp
cd ..

cd HyperbolicTiling_Learning
python setup.py build_ext --inplace
cd ..

cd mercator
g++ -O3 -std=c++11 -I include/ src/embeddingS1_unix.cpp -o mercator
cd ..
