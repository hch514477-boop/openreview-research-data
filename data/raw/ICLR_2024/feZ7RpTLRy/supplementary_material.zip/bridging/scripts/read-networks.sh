#!/bin/bash
# convert graph-orig.txt to graph.txt (used by BFKL) and graph.csv (used by Poincare and Lorentz)

g++ scripts/convert-graph.cpp -O3 -o bin/convert-graph
for x in astroph facebook condmat grqc hepph human1 yeast diseasome celegans
do echo converting $x
bin/convert-graph graphs/$x/graph-orig.txt graphs/$x/graph.txt graphs/$x/graph.csv
done
rm bin/convert-graph
g++ scripts/convert-graph-str.cpp -O3 -o bin/convert-graph-str
for x in mouse3 drosophila1
do echo converting $x
bin/convert-graph-str graphs/$x/graph-orig.txt graphs/$x/graph.txt graphs/$x/graph.csv
done
rm bin/convert-graph-str
