sh scripts/process.sh CL mesh
sh scripts/process.sh CL mammal
sh scripts/process.sh CL tetrapoda
sh scripts/process.sh CL noun
sh scripts/process.sh M mesh &
sh scripts/process.sh M mammal &
sh scripts/process.sh M tetrapoda &
sh scripts/process.sh M noun &
