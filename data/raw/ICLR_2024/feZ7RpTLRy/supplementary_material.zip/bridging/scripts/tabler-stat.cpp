#include <string>
#include <vector>
#include <iostream>
#include <map>

using namespace std;

vector<string> graphs;

map<string, map<string, double>> values;

int main(int argc, char ** argv) {

  string graph = "none";
  string s;

  while(getline(cin, s)) {
    int p = -1;
    for(int i=0; i<int(s.size()); i++) if(s[i] == '=') p = i;
    if(p == -1) continue;
    string cat = s.substr(0, p);
    string vals = s.substr(p+1);
    if(cat == "GRAPH") { graph = vals; graphs.push_back(graph); continue; }
    double vald = atof(vals.c_str());
    values[graph][cat] = vald;
    }

  printf("graph;ssize;stemp;sid;n;m;method;dim;discrete;mr;map;success;stretch;time;radius;name\n");
  for(auto g: graphs) {
    char head[100];
    auto& v = values[g];
    if(g.substr(0, 9) == "simulated") {
      int n, t, id;
      sscanf(g.c_str(), "simulated/%d-T%d/%d", &n, &t, &id);
      sprintf(head, "simulated;%d;%d;%d;%d;%d", n, t, id, int(v["n"]), int(v["m"]));
      }
    else if(g[2] == '/') {
      auto g1 = g.substr(3);
      sprintf(head, "%s;;;%c;%d;%d", g1.c_str(), g[1], int(v["n"]), int(v["m"]));
      }
    else {
      sprintf(head, "%s;;;0;%d;%d", g.c_str(), int(v["n"]), int(v["m"]));
      }
    printf("%s;lorentz;2;0;%.1f;%.6f;%.6f;%.2f;%d;%.2f;Lorentz2D\n",
      head, v["lorentz2_meanrank"], v["lorentz2_map"], v["lorentz2_greedy_success"], v["lorentz2_greedy_stretch"], int(v["lorentz2_time"]),
      v["lorentz2_au"]
      );
    printf("%s;lorentz;2;1;%.1f;%.6f;;;;;X\n",
      head, v["lorentz2_pre_meanrank"], v["lorentz2_pre_map"]);
    printf("%s;lorentz;2;2;%.1f;%.6f;;;;;X\n",
      head, v["lorentz2_post_meanrank"], v["lorentz2_post_map"]);
    printf("%s;lorentz;2;3;%.1f;%.6f;%.6f;%.6f;;;Lorentz2D+DHRG\n",
      head, v["lorentz2_ddhrg_meanrank"], v["lorentz2_ddhrg_map"], v["lorentz2_ddhrg_greedy_success"], v["lorentz2_ddhrg_greedy_stretch"]);
    printf("%s;bfkl;2;0;%.1f;%.6f;%.6f;%.2f;%d;%.2f;BFKL\n",
      head, v["bfkl_meanrank"], v["bfkl_map"], v["bfkl_greedy_success"], v["bfkl_greedy_stretch"], 
      v["bfkl_au"], int(v["bfkl_time"]));
    printf("%s;bfkl;2;1;%.1f;%.6f;;;;;X\n",
      head, v["bfkl_pre_meanrank"], v["bfkl_pre_map"]);
    printf("%s;bfkl;2;2;%.1f;%.6f;%.6f;%.2f;;;X\n",
      head, v["bfkl_post_meanrank"], v["bfkl_post_map"], v["dhrg_greedy_success"], v["dhrg_greedy_stretch"]);
    printf("%s;bfkl;2;3;%.1f;%.6f;%.6f;%.2f;;;BFKL+DHRG\n",
      head, v["bfkl_ddhrg_meanrank"], v["bfkl_ddhrg_map"], v["bfkl_ddhrg_greedy_success"], v["bfkl_ddhrg_greedy_stretch"]);
    printf("%s;poincare;2;0;%.1f;%.6f;%.6f;%.6f;%d;%.2f;Poincare2D\n",
      head, v["poincare2_meanrank"], v["poincare2_map"], v["poincare2_greedy_success"], v["poincare2_greedy_stretch"], int(v["poincare2_time"]), v["poincare2_au"]);
    printf("%s;poincare;3;0;%.1f;%.6f;%.6f;%.2f;%d;%.2f;Poincare3D\n",
      head, v["poincare3_meanrank"], v["poincare3_map"], v["poincare3_greedy_success"], v["poincare3_greedy_stretch"], int(v["poincare3_time"]), v["poincare3_au"]);
    printf("%s;poincare;5;0;%.1f;%.6f;;;;;X\n",
      head, v["poincare5_meanrank"], v["poincare5_map"]);
    printf("%s;euclidean;50;0;%.1f;%.6f;;;;;X\n",
      head, v["euclidean50_meanrank"], v["euclidean50_map"]);
    printf("%s;euclidean;200;0;%.1f;%.6f;;;;;X\n",
      head, v["euclidean200_meanrank"], v["euclidean200_map"]);      
    if(v["mfast_map"])
    printf("%s;mercatorfast;2;0;%.1f;%.6f;%.6f;%.2f;%d;%.2f;Mercator fast\n",
      head, v["mfast_meanrank"], v["mfast_map"], v["mfast_greedy_success"], v["mfast_greedy_stretch"], int(v["mercator_fast_time"]), v["mercator_fast_au"]);
    if(v["mfull_map"])
    printf("%s;mercatorfull;2;0;%.1f;%.6f;%.6f;%.2f;%d;%.2f;Mercator full\n",
      head, v["mfull_meanrank"], v["mfull_map"], v["mfull_greedy_success"], v["mfull_greedy_stretch"], int(v["mercator_full_time"]), v["mercator_full_au"]);
    if(v["norec_treerep_hr_map"])
    printf("%s;treerep_norec;1;0;%.1f;%.6f;%.6f;%.2f;;%.2f;X\n",
      head, v["norec_treerep_hr_meanrank"], v["norec_treerep_hr_map"], v["norec_treerep_hr_greedy_success"], v["norec_treerep_hr_greedy_stretch"], v["norec_treerep_tu"]);
    if(v["wrec_treerep_hr_map"])
    printf("%s;treerep_wrec;1;0;%.1f;%.6f;%.6f;%.2f;;%.2f;TreeRep\n",
      head, v["wrec_treerep_hr_meanrank"], v["wrec_treerep_hr_map"], v["wrec_treerep_hr_greedy_success"], v["wrec_treerep_hr_greedy_stretch"], v["wrec_treerep_tu"]);
    if(v["ltiling_map"])
    printf("%s;ltiling;1;0;%.1f;%.6f;%.6f;%.2f;;%.2f;LTiling\n",
      head, v["ltiling_meanrank"], v["ltiling_map"], v["ltiling_greedy_success"], v["ltiling_greedy_stretch"], v["ltiling_diam"]);
    }

  return 0;
  }
