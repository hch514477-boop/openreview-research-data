EXTRA=
if [ -f graphs/$1/notrans.txt ]
then EXTRA="-alt-edges ../graphs/$1/notrans.txt"
fi

DHRG="./hyper -c - -s - -fillmodel ffffffff -canvas i -stdgrid c0c0ffff -dftcolor c0ffc0ff -gridon -rvedge 808080ff -fore 0 -zoom .95 -wsh 9 -smart 20"
VIEW="-cview -run -rvlabelscale 0.5 -shot-1000 -shott 1 -svgshot ../view.svg"

cd hyperrogue
case $2 in
  lorentz2) $DHRG $EXTRA -graphv ../graphs/$1/lorentz2 -lab $VIEW ;;
  lorentz2d) $DHRG $EXTRA -eload ../graphs/$1/lorentz2 -dhrgview -lab $VIEW ;;
  bfkl) $DHRG $EXTRA -graphv ../graphs/$1/bfkl -lab $VIEW ;;
  bfkld) $DHRG $EXTRA -eload ../graphs/$1/bfkl -dhrgview -lab $VIEW ;;
  esac
cd ..
