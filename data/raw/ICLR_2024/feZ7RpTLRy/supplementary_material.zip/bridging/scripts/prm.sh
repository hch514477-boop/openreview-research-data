#!/bin/sh
#for x in human1 drosophila1 mouse3 grqc hepph condmat mammal acm
#do sh scripts/process.sh FGHIJK $x
#done
#sh scripts/process.sh afgh tetrapoda
#sh scripts/process.sh FGHI noun
#sh scripts/process.sh qrsuvwxz tetrapoda
#sh scripts/process.sh abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLM csphd
#sh scripts/process.sh abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLM yeast
sh scripts/process.sh abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLM diseasome
