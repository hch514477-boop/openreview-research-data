#!/bin/bash
g++ scripts/tabler-stat.cpp -o bin/tabler-stat
bash scripts/stats.sh rshnABC | bin/tabler-stat > tables/statistical-data.csv
