#!/bin/sh
g++ scripts/create-notrans.cpp -o bin/create-notrans

for x in noun mammal verb:
do bin/create-notrans < graphs/$1/graph.txt graphs/$1/notrans.txt
done
