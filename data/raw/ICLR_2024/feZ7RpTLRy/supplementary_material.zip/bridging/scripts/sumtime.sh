#!/bin/bash
echo real:
bash scripts/stats.sh r | grep lorentz2_time | sed s/lorentz2_time=// | awk '{ sum += $1 } END { print sum }'
echo simulated:
bash scripts/stats.sh s | grep lorentz2_time | sed s/lorentz2_time=// | awk '{ sum += $1 } END { print sum }'
