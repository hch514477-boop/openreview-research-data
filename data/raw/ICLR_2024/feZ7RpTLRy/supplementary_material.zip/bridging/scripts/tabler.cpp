#include <string>
#include <vector>
#include <iostream>
#include <map>

using namespace std;

vector<string> graphs;

map<string, map<string, double>> values;

void tableline(string title, const auto& f) {
  printf("%-30s ", title.c_str());
  for(auto g: graphs) printf(" &%7s", f(g).c_str());
  printf(" \\\\\n");
  }

string fmtf(string fmt, double val) {
  if(!val) return "";
  char buf[100];
  sprintf(buf, fmt.c_str(), val);
  return buf;
  }

string its(int val) {
  char buf[100];
  sprintf(buf, "%d", val);
  return buf;  
  }

string measures = "tmausr";

int mode = 0;

void gen(string s) {
  auto ex = [&] (char c) {
    bool incase = false;
    for(char d: s) if(c==d) return true; else if((c>>5) == (d>>5)) incase = true;
    if(!incase) return true;
    return false;
    };

  if(ex('n') && ex('N')) {
    tableline("nodes", [&] (string s) { return its(values[s]["n"]); });
    tableline("edges", [&] (string s) { return its(values[s]["m"]); });
    }

  if(ex('L')) {
    if(ex('t')) tableline("Lorentz 2D embed time [s]", [&] (string s) { return its(values[s]["lorentz2_time"]); });
    if(ex('t')) tableline("Lorentz 2D eval time [s]", [&] (string s) { return fmtf("%.2f", values[s]["lorentz2_eval_time"]); });
    if(ex('r')) tableline("Lorentz 2D radius AU", [&] (string s) { return fmtf("%.3f", values[s]["lorentz2_au"]); });
    if(ex('g')) tableline("Lorentz 2D radius grid", [&] (string s) { return its(values[s]["lorentz2_radius_pre_improve"]); });

    if(ex('m')) {
      tableline("MR Lorentz2D", [&] (string s) { return fmtf("%.1f", values[s]["lorentz2_meanrank"]); });
      tableline("dMR Lorentz2D", [&] (string s) { return fmtf("%.1f", values[s]["lorentz2_pre_meanrank"]); });
      tableline("MR Lorentz2D + DHRG", [&] (string s) { return fmtf("%.1f", values[s]["lorentz2_ddhrg_meanrank"]); });
      tableline("dMR Lorentz2D + DHRG", [&] (string s) { return fmtf("%.1f", values[s]["lorentz2_post_meanrank"]); });
      }

    if(ex('a')) {
      tableline("mAP Lorentz2D", [&] (string s) { return fmtf("%.3f", values[s]["lorentz2_map"]); });
      tableline("dmAP Lorentz2D", [&] (string s) { return fmtf("%.3f", values[s]["lorentz2_pre_map"]); });
      tableline("dmAP Lorentz2D + DHRG", [&] (string s) { return fmtf("%.3f", values[s]["lorentz2_post_map"]); });
      tableline("mAP Lorentz2D + DHRG", [&] (string s) { return fmtf("%.3f", values[s]["lorentz2_ddhrg_map"]); });
      }
    }

  if(ex('B')) {
    if(ex('r')) tableline("BFKL radius AU", [&] (string s) { return fmtf("%.3f", values[s]["bfkl_au"]); });
    if(ex('g')) tableline("BFKL radius grid", [&] (string s) { return its(values[s]["bfkl_radius_pre_improve"]); });
    if(ex('t')) {
      tableline("BFKL embed time [s]", [&] (string s) { return its(values[s]["bfkl_time"]); });
      tableline("DHRG improve time [s]", [&] (string s) { return its(values[s]["improve_time"]); });
      }

    if(ex('m')) {
      tableline("MR BFKL", [&] (string s) { return fmtf("%.1f", values[s]["bfkl_meanrank"]); });
      tableline("dMR BFKL", [&] (string s) { return fmtf("%.1f", values[s]["bfkl_pre_meanrank"]); });
      tableline("dMR BFKL + DHRG", [&] (string s) { return fmtf("%.1f", values[s]["bfkl_post_meanrank"]); });
      tableline("MR BFKL + DHRG", [&] (string s) { return fmtf("%.1f", values[s]["bfkl_ddhrg_meanrank"]); });
      }

    if(ex('a')) {
      tableline("mAP BFKL", [&] (string s) { return fmtf("%.3f", values[s]["bfkl_map"]); });
      tableline("dmAP BFKL", [&] (string s) { return fmtf("%.3f", values[s]["bfkl_pre_map"]); });
      tableline("dmAP BFKL + DHRG", [&] (string s) { return fmtf("%.3f", values[s]["bfkl_post_map"]); });
      tableline("mAP BFKL + DHRG", [&] (string s) { return fmtf("%.3f", values[s]["bfkl_ddhrg_map"]); });
      }

    if(ex('u') && mode != 2) {
      tableline("success BFKL", [&] (string s) { return fmtf("%.3f", values[s]["bfkl_greedy_success"]); });
      tableline("success BFKL + DHRG", [&] (string s) { return fmtf("%.3f", values[s]["dhrg_greedy_success"]); });
      tableline("success BFKL + DDHRG", [&] (string s) { return fmtf("%.3f", values[s]["bfkl_ddhrg_greedy_success"]); });
      tableline("success Lorentz2D", [&] (string s) { return fmtf("%.3f", values[s]["lorentz2_greedy_success"]); });
      tableline("success Lorentz2D + DD", [&] (string s) { return fmtf("%.3f", values[s]["lorentz2_ddhrg_greedy_success"]); });
      }

    if(ex('s') && mode != 2) {
      tableline("stretch BFKL", [&] (string s) { return fmtf("%.2f", values[s]["bfkl_greedy_stretch"]); });
      tableline("stretch BFKL + DHRG", [&] (string s) { return fmtf("%.2f", values[s]["dhrg_greedy_stretch"]); });
      tableline("stretch BFKL + DDHRG", [&] (string s) { return fmtf("%.2f", values[s]["bfkl_ddhrg_greedy_stretch"]); });
      tableline("stretch Lorentz2D", [&] (string s) { return fmtf("%.2f", values[s]["lorentz2_greedy_stretch"]); });
      tableline("stretch Lorentz2D + DD", [&] (string s) { return fmtf("%.2f", values[s]["lorentz2_ddhrg_greedy_stretch"]); });
      }
    }

  if(ex('S')) {
    if(ex('m')) tableline("MR landscape 200D", [&] (string s) { return fmtf("%.1f", values[s]["landscape200_meanrank"]); });
    if(ex('m')) tableline("MR landscape 50D", [&] (string s) { return fmtf("%.1f", values[s]["landscape50_meanrank"]); });
    if(ex('a')) tableline("mAP landscape 200D", [&] (string s) { return fmtf("%.3f", values[s]["landscape200_map"]); });
    if(ex('a')) tableline("mAP landscape 50D", [&] (string s) { return fmtf("%.3f", values[s]["landscape50_map"]); });
    }

  if(ex('P')) {
    if(ex('t')) {
      tableline("Poincare 2D embed time [s]", [&] (string s) { return its(values[s]["poincare2_time"]); });
      tableline("Poincare 3D embed time [s]", [&] (string s) { return its(values[s]["poincare3_time"]); });
      }

    if(ex('m')) {
      tableline("MR Poincare 2D", [&] (string s) { return fmtf("%.1f", values[s]["poincare2_meanrank"]); });
      tableline("MR Poincare 3D", [&] (string s) { return fmtf("%.1f", values[s]["poincare3_meanrank"]); });
      tableline("MR Poincare 5D", [&] (string s) { return fmtf("%.1f", values[s]["poincare5_meanrank"]); });
      }

    if(ex('a')) {
      tableline("mAP Poincare 2D", [&] (string s) { return fmtf("%.3f", values[s]["poincare2_map"]); });
      tableline("mAP Poincare 3D", [&] (string s) { return fmtf("%.3f", values[s]["poincare3_map"]); });
      tableline("mAP Poincare 5D", [&] (string s) { return fmtf("%.3f", values[s]["poincare5_map"]); });
      }

    if(ex('u') && mode != 2) {
      tableline("success Poincare2D", [&] (string s) { return fmtf("%.3f", values[s]["poincare2_greedy_success"]); });
      tableline("success Poincare3D", [&] (string s) { return fmtf("%.3f", values[s]["poincare3_greedy_success"]); });
      }

    if(ex('s') && mode != 2) {
      tableline("stretch Poincare2D", [&] (string s) { return fmtf("%.3f", values[s]["poincare2_greedy_stretch"]); });
      tableline("stretch Poincare3D", [&] (string s) { return fmtf("%.2f", values[s]["poincare3_greedy_stretch"]); });
      }
    }

  if(ex('E')) {
    if(ex('m')) {
      tableline("MR Euclidean50D", [&] (string s) { return fmtf("%.1f", values[s]["euclidean50_meanrank"]); });
      tableline("MR Euclidean200D", [&] (string s) { return fmtf("%.1f", values[s]["euclidean200_meanrank"]); });
      }
    if(ex('a')) {
      tableline("mAP Euclidean50D", [&] (string s) { return fmtf("%.3f", values[s]["euclidean50_map"]); });
      tableline("mAP Euclidean200D", [&] (string s) { return fmtf("%.3f", values[s]["euclidean200_map"]); });
      }
    }

  if(ex('H') && mode != 1) {
    if(ex('r')) tableline("HypViewer radius AU", [&] (string s) { return fmtf("%.3f", values[s]["hypviewer_au"]); });
    if(ex('r')) tableline("RogueViz radius AU", [&] (string s) { return fmtf("%.3f", values[s]["rogueviz_au"]); });
    if(ex('m')) tableline("MR HypViewer", [&] (string s) { return fmtf("%.1f", values[s]["hypviewer_meanrank"]); });
    if(ex('m')) tableline("MR RogueViz", [&] (string s) { return fmtf("%.1f", values[s]["rogueviz_meanrank"]); });
    if(ex('a')) tableline("mAP HypViewer", [&] (string s) { return fmtf("%.3f", values[s]["hypviewer_map"]); });
    if(ex('a')) tableline("mAP RogueViz", [&] (string s) { return fmtf("%.3f", values[s]["rogueviz_map"]); });
    }

  if(ex('M')) {
    if(ex('t')) {
      tableline("Mercator fast embed time [s]", [&] (string s) { return its(values[s]["mercator_fast_time"]); });
      tableline("Mercator full embed time [s]", [&] (string s) { return its(values[s]["mercator_full_time"]); });
      }
    if(ex('r')) {
      tableline("Mercator fast radius AU", [&] (string s) { return fmtf("%.3f", values[s]["mercator_fast_au"]); });
      tableline("Mercator full radius AU", [&] (string s) { return fmtf("%.3f", values[s]["mercator_full_au"]); });
      }
    if(ex('m')) {
      tableline("MR Mercator fast", [&] (string s) { return fmtf("%.1f", values[s]["mfast_meanrank"]); });
      tableline("MR Mercator full", [&] (string s) { return fmtf("%.1f", values[s]["mfull_meanrank"]); });
      }
    if(ex('a')) {
      tableline("mAP Mercator fast", [&] (string s) { return fmtf("%.3f", values[s]["mfast_map"]); });
      tableline("mAP Mercator full", [&] (string s) { return fmtf("%.3f", values[s]["mfull_map"]); });
      }
    if(ex('u') && mode != 2) {
      tableline("success Mercator fast", [&] (string s) { return fmtf("%.3f", values[s]["mfast_greedy_success"]); });
      tableline("success Mercator full", [&] (string s) { return fmtf("%.3f", values[s]["mfull_greedy_success"]); });
      }
    if(ex('s') && mode != 2) {
      tableline("stretch Mercator fast", [&] (string s) { return fmtf("%.2f", values[s]["mfast_greedy_stretch"]); });
      tableline("stretch Mercator full", [&] (string s) { return fmtf("%.2f", values[s]["mfull_greedy_stretch"]); });
      }
    }

  if(ex('T')) {
    if(ex('r')) {
      tableline("TreeRep diameter rec", [&] (string s) { return fmtf("%.3f", values[s]["wrec_treerep_tu"]); });
      tableline("TreeRep diameter norec", [&] (string s) { return fmtf("%.3f", values[s]["norec_treerep_tu"]); });
      }
    if(ex('m')) {
      tableline("MR TreeRep rec", [&] (string s) { return fmtf("%.3f", values[s]["wrec_treerep_hr_meanrank"]); });
      tableline("MR TreeRep norec", [&] (string s) { return fmtf("%.3f", values[s]["norec_treerep_hr_meanrank"]); });
      }
    if(ex('a')) {      
      tableline("mAP TreeRep rec orig", [&] (string s) { return fmtf("%.3f", values[s]["wrec_treerep_map"]); });
      tableline("mAP TreeRep norec orig", [&] (string s) { return fmtf("%.3f", values[s]["norec_treerep_map"]); });
      tableline("mAP TreeRep rec", [&] (string s) { return fmtf("%.3f", values[s]["wrec_treerep_hr_map"]); });
      tableline("mAP TreeRep norec", [&] (string s) { return fmtf("%.3f", values[s]["norec_treerep_hr_map"]); });
      }
    if(ex('u') && mode != 2) {
      tableline("success TreeRep rec", [&] (string s) { return fmtf("%.3f", values[s]["wrec_treerep_hr_greedy_success"]); });
      tableline("success TreeRep norec", [&] (string s) { return fmtf("%.3f", values[s]["norec_treerep_hr_greedy_success"]); });
      }
    if(ex('s') && mode != 2) {
      tableline("stretch TreeRep rec", [&] (string s) { return fmtf("%.3f", values[s]["wrec_treerep_hr_greedy_stretch"]); });
      tableline("stretch TreeRep norec", [&] (string s) { return fmtf("%.3f", values[s]["norec_treerep_hr_greedy_stretch"]); });
      }
    }

  if(ex('G')) {
    if(ex('t')) tableline("ltiling embed time [s]", [&] (string s) { return its(values[s]["ltiling_time"]); });
    if(ex('r')) tableline("ltiling radius", [&] (string s) { return fmtf("%.3f", values[s]["ltiling_diam"]/2); });
    if(ex('m')) tableline("MR ltiling", [&] (string s) { return fmtf("%.3f", values[s]["ltiling_meanrank"]); });
    if(ex('a')) tableline("mAP ltiling", [&] (string s) { return fmtf("%.3f", values[s]["ltiling_map"]); });
    if(mode != '2') {
      if(ex('u')) tableline("success ltiling", [&] (string s) { return fmtf("%.3f", values[s]["ltiling_greedy_success"]); });
      if(ex('s')) tableline("stretch ltiling", [&] (string s) { return fmtf("%.3f", values[s]["ltiling_greedy_stretch"]); });
      }
    }
  }

int main(int argc, char ** argv) {

  string graph = "none";
  string s;

  while(getline(cin, s)) {
    int p = -1;
    for(int i=0; i<int(s.size()); i++) if(s[i] == '=') p = i;
    if(p == -1) continue;
    string cat = s.substr(0, p);
    string vals = s.substr(p+1);
    if(cat == "GRAPH") { graph = vals; graphs.push_back(graph); continue; }
    double vald = atof(vals.c_str());
    values[graph][cat] = vald;
    }

  tableline("graph name", [&] (string s) { return s.substr(0, 6); });
  string argvs = argc > 1 ? argv[1] : "";

  string line = "";

  for(char ch: argvs) { if(ch == '1' || ch == '2') mode = ch - '0'; else if(ch == ',') gen(line), line = ""; else line += ch; }
  gen(line);

  return 0;
  }
