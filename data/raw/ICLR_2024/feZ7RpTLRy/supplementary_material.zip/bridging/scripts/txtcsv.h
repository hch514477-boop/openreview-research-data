FILE *txt, *csv;

inline void init() {
  txt = fopen("graph.txt", "wt");
  csv = fopen("graph.csv", "wt");
  fprintf(csv, "id1,id2,weight\n");
  }

inline void clos() {
  fclose(txt); fclose(csv);
  }

inline void edge(string who, string anc) {
  fprintf(csv, "%s,%s,1\n", who.c_str(), anc.c_str());
  fprintf(txt, "%s %s\n", who.c_str(), anc.c_str());
  }
