#!/bin/bash
# usage: bash process/sh [steps] [graph name]
# needs graphs/[graph name]/graph.txt and graphs/[graph name]/graph.csv

GRAPH=$2
IDIR=graphs/$GRAPH/
DIR=results/$GRAPH/
DHRG="hyperrogue/hyper -c - -fixx 42 -nogui -s -"

if [ -n "$SEED" ]
then DIR=results/repeated/$GRAPH$SEED/
fi
echo DIR is \'$DIR\', SEED is \'$SEED\'

function log {
  echo
  echo "######" $GRAPH " : " $1
  echo
  echo `TZ=Universal date` : $1 >> $DIR/log.txt
  }

mkdir -p $DIR

if [[ $1 == *a* ]]
then log "embed using BFKL"
hyperbolic-embedder/embedder -seed 123456$SEED -input $IDIR/graph.txt -embed $DIR/bfkl | tee $DIR/log-bfkl.txt
log "embed using BFKL: finished"
fi

if [[ $1 == *b* ]]
then log "embed using Lorentz 2D"
cd poincare-embeddings
python3 embed.py \
  -checkpoint ../$DIR/lorentz2.bin \
  -dset ../$IDIR/graph.csv \
  -epochs 1500 \
  -negs 50 \
  -burnin 20 \
  -dampening 0.75 \
  -ndproc 4 \
  -eval_each 100 \
  -fresh \
  -sparse \
  -burnin_multiplier 0.01 \
  -neg_multiplier 0.1 \
  -lr_type constant \
  -lr 0.5 -no-maxnorm \
  -train_threads 1 \
  -dampening 1.0 \
  -batchsize 50 \
  -gpu 0 \
  -manifold lorentz \
  -dim 2 | tee ../$DIR/log-lorentz2.txt
cd ..
log "embed using Lorentz 2D: finished"
fi

if [[ $1 == *c* ]]
then log "evaluate Lorentz 2D"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/lorentz2.bin.best -rank 1 | tee ../$DIR/log-lorentz2-evaluate.txt
cd ..
log "evaluate Lorentz 2D: finished"
fi

if [[ $1 == *d* ]]
then log "convert Lorentz 2D"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/lorentz2.bin.best -output ../$DIR/lorentz2-coordinates.txt | tee ../$DIR/log-lorentz2-convert.txt
cd ..
cp $DIR/bfkl-links.txt $DIR/lorentz2-links.txt
log "convert Lorentz 2D: finished"
fi

if [[ $1 == *e* ]]
then log "improve Lorentz 2D"
$DHRG -dhrg $DIR/lorentz2 -rdi $IDIR/graph.txt -discrete-rank -iterate 10 -discrete-rank -iterate 100 -discrete-rank -esave | tee $DIR/log-lorentz2-improve.txt
log "improve Lorentz 2D: finished"
fi

if [[ $1 == *f* ]]
then log "improve BFKL"
$DHRG -dhrg $DIR/bfkl -rdi $IDIR/graph.txt -discrete-rank -iterate 10 -discrete-rank -iterate 100 -discrete-rank -esave | tee $DIR/log-bfkl-improve.txt
log "improve BFKL: finished"
fi

if [[ $1 == *g* ]]
then log "landscape 200D"
$DHRG -eload $DIR/bfkl -rdi $IDIR/graph.txt -discrete-rank -landscape-rank 200 | tee $DIR/log-landscape-200.txt
log "landscape 200D: finished"
fi

if [[ $1 == *h* ]]
then log "landscape 50D"
$DHRG -eload $DIR/bfkl -rdi $IDIR/graph.txt -discrete-rank -landscape-rank 50 | tee $DIR/log-landscape-50.txt
log "landscape 50D: finished"
fi

if [[ $1 == *i* ]]
then log "evaluate bfkl cmap"
$DHRG -dhrg $DIR/bfkl -rdi $IDIR/graph.txt -map-rank | tee $DIR/log-bfkl-cmap.txt
log "evaluate bfkl cmap: finished"
fi

if [[ $1 == *j* ]]
then log "evaluate bfkl greedy"
$DHRG -dhrg $DIR/bfkl -rdi $IDIR/graph.txt -routing-hdist | tee $DIR/log-bfkl-greedy.txt
log "evaluate bfkl greedy: finished"
fi

if [[ $1 == *k* ]]
then log "evaluate lorentz2 greedy"
$DHRG -dhrg $DIR/lorentz2 -rdi $IDIR/graph.txt -routing-hdist | tee $DIR/log-lorentz2-greedy.txt
log "evaluate lorentz2 greedy: finished"
fi

if [[ $1 == *l* ]]
then log "evaluate dhrg greedy"
$DHRG -eload $DIR/bfkl -rdi $IDIR/graph.txt -routing-qdist | tee $DIR/log-dhrg-greedy.txt
log "evaluate dhrg greedy: finished"
fi

if [[ $1 == *m* ]]
then log "evaluate ddhrg bfkl cmap"
$DHRG -eload $DIR/bfkl -rdi $IDIR/graph.txt -cellcoords -map-rank | tee $DIR/log-ddhrg-bfkl-cmap.txt
log "evaluate bfkl cmap: finished"
fi

if [[ $1 == *n* ]]
then log "evaluate ddhrg lorentz2 cmap"
$DHRG -eload $DIR/lorentz2 -rdi $IDIR/graph.txt -cellcoords -map-rank | tee $DIR/log-ddhrg-lorentz2-cmap.txt
log "evaluate bfkl cmap: finished"
fi

if [[ $1 == *o* ]]
then log "evaluate ddhrg bfkl greedy"
$DHRG -eload $DIR/bfkl -rdi $IDIR/graph.txt -cellcoords -routing-hdist | tee $DIR/log-ddhrg-bfkl-greedy.txt
log "evaluate bfkl greedy: finished"
fi

if [[ $1 == *p* ]]
then log "evaluate ddhrg lorentz2 greedy"
$DHRG -eload $DIR/lorentz2 -rdi $IDIR/graph.txt -cellcoords -routing-hdist | tee $DIR/log-ddhrg-lorentz2-greedy.txt
log "evaluate bfkl greedy: finished"
fi

if [[ $1 == *q* ]]
then log "embed using Poincare 2D"
cd poincare-embeddings
python3 embed.py \
  -checkpoint ../$DIR/poincare2.bin \
  -dset ../$IDIR/graph.csv \
  -epochs 1500 \
  -negs 50 \
  -burnin 20 \
  -dampening 0.75 \
  -ndproc 4 \
  -eval_each 100 \
  -fresh \
  -sparse \
  -burnin_multiplier 0.01 \
  -neg_multiplier 0.1 \
  -lr_type constant \
  -lr 1 \
  -train_threads 1 \
  -dampening 1.0 \
  -batchsize 50 \
  -gpu 0 \
  -manifold poincare \
  -dim 2 | tee ../$DIR/log-poincare2.txt
cd ..
log "embed using Poincare 2D: finished"
fi

if [[ $1 == *r* ]]
then log "embed using Euclidean 50D"
cd poincare-embeddings
python3 embed.py \
  -checkpoint ../$DIR/euclidean50.bin \
  -dset ../$IDIR/graph.csv \
  -epochs 1500 \
  -negs 50 \
  -burnin 20 \
  -dampening 0.75 \
  -ndproc 4 \
  -eval_each 100 \
  -fresh \
  -sparse \
  -burnin_multiplier 0.01 \
  -neg_multiplier 0.1 \
  -lr_type constant \
  -lr 1 \
  -train_threads 1 \
  -dampening 1.0 \
  -batchsize 50 \
  -gpu 0 \
  -manifold euclidean \
  -dim 50 | tee ../$DIR/log-euclidean50.txt
cd ..
log "embed using Euclidean 50D: finished"
fi

if [[ $1 == *s* ]]
then log "embed using Euclidean 200D"
cd poincare-embeddings
python3 embed.py \
  -checkpoint ../$DIR/euclidean200.bin \
  -dset ../$IDIR/graph.csv \
  -epochs 1500 \
  -negs 50 \
  -burnin 20 \
  -dampening 0.75 \
  -ndproc 4 \
  -eval_each 100 \
  -fresh \
  -sparse \
  -burnin_multiplier 0.01 \
  -neg_multiplier 0.1 \
  -lr_type constant \
  -lr 1 \
  -train_threads 1 \
  -dampening 1.0 \
  -batchsize 50 \
  -gpu 0 \
  -manifold euclidean \
  -dim 200 | tee ../$DIR/log-euclidean200.txt
cd ..
log "embed using Euclidean 200D: finished"
fi

if [[ $1 == *t* ]]
then log "embed using Poincare 3D"
cd poincare-embeddings
python3 embed.py \
  -checkpoint ../$DIR/poincare3.bin \
  -dset ../$IDIR/graph.csv \
  -epochs 1500 \
  -negs 50 \
  -burnin 20 \
  -dampening 0.75 \
  -ndproc 4 \
  -eval_each 100 \
  -fresh \
  -sparse \
  -burnin_multiplier 0.01 \
  -neg_multiplier 0.1 \
  -lr_type constant \
  -lr 0.5 -no-maxnorm \
  -train_threads 1 \
  -dampening 1.0 \
  -batchsize 50 \
  -gpu 0 \
  -manifold poincare \
  -dim 3 | tee ../$DIR/log-poincare3.txt
cd ..
log "embed using Poincare 3D: finished"
fi

if [[ $1 == *u* ]]
then log "embed using Poincare 5D"
cd poincare-embeddings
python3 embed.py \
  -checkpoint ../$DIR/poincare5.bin \
  -dset ../$IDIR/graph.csv \
  -epochs 1500 \
  -negs 50 \
  -burnin 20 \
  -dampening 0.75 \
  -ndproc 4 \
  -eval_each 100 \
  -fresh \
  -sparse \
  -burnin_multiplier 0.01 \
  -neg_multiplier 0.1 \
  -lr_type constant \
  -lr 0.5 -no-maxnorm \
  -train_threads 1 \
  -dampening 1.0 \
  -batchsize 50 \
  -gpu 0 \
  -manifold poincare \
  -dim 5 | tee ../$DIR/log-poincare5.txt
cd ..
log "embed using Poincare 5D: finished"
fi

if [[ $1 == *v* ]]
then log "evaluate Poincare 2D"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/poincare2.bin.best -rank 1 | tee ../$DIR/log-poincare2-evaluate.txt
cd ..
log "evaluate Poincare 2D: finished"
fi

if [[ $1 == *w* ]]
then log "evaluate Euclidean 50D"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/euclidean50.bin.best -rank 1 | tee ../$DIR/log-euclidean50-evaluate.txt
cd ..
log "evaluate Euclidean 50D: finished"
fi

if [[ $1 == *x* ]]
then log "evaluate Euclidean 200D"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/euclidean200.bin.best -rank 1 | tee ../$DIR/log-euclidean200-evaluate.txt
cd ..
log "evaluate Euclidean 200D: finished"
fi

if [[ $1 == *y* ]]
then log "evaluate Poincare 3D"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/poincare3.bin.best -rank 1 | tee ../$DIR/log-poincare3-evaluate.txt
cd ..
log "evaluate Poincare 3D: finished"
fi

if [[ $1 == *z* ]]
then log "evaluate Poincare 5D"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/poincare5.bin.best -rank 1 | tee ../$DIR/log-poincare5-evaluate.txt
cd ..
log "evaluate Poincare 5D: finished"
fi

if [[ $1 == *A* ]]
then log "convert Poincare 3D"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/poincare3.bin.best -output3 ../$DIR/poincare3.txt | tee ../$DIR/log-poincare3-convert.txt
cd ..
log "convert Poincare 3D: finished"
fi

if [[ $1 == *B* ]]
then log "evaluate poincare3 greedy"
$DHRG -eload $DIR/lorentz2 -routing-poincare3 $DIR/poincare3.txt | tee $DIR/log-poincare3-greedy.txt
log "evaluate poincare3 greedy: finished"
fi

if [[ $1 == *C* ]]
then log "apply HypViewer"
hypviewer/gentree < $IDIR/graph.txt > $DIR/hypviewer.txt 2> $DIR/log-hypviewer.txt
log "apply HypViewer: finished"
fi

if [[ $1 == *D* ]]
then log "evaluate HypViewer"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/poincare3.bin.best -input3 ../$DIR/hypviewer.txt | tee ../$DIR/log-evaluate-hypviewer.txt
cd ..
log "evaluate HypViewer: finished"
fi

if [[ $1 == *E* ]]
then log "evaluate HypViewer using dhrg"
$DHRG -eload $DIR/lorentz2 -rdi $IDIR/graph.txt -map-poincare3 $DIR/hypviewer.txt | tee $DIR/log-hypviewer-evaluate.txt
log "evaluate HypViewer using dhrg: finished"
fi

if [[ $1 == *F* ]]
then log "embed using Mercator fast"
mercator/mercator -f -s 123456$SEED -o $DIR/mercator-fast $IDIR/graph.txt
scripts/mercator-to-bfkl < $DIR/mercator-fast.inf_coord > $DIR/mercator-fast-coordinates.txt
cp $DIR/bfkl-links.txt $DIR/mercator-fast-links.txt
log "embed using Mercator fast: finished"
fi

if [[ $1 == *G* ]]
then log "embed using Mercator full"
mercator/mercator -s 123456$SEED -o $DIR/mercator-full $IDIR/graph.txt
scripts/mercator-to-bfkl < $DIR/mercator-full.inf_coord > $DIR/mercator-full-coordinates.txt
cp $DIR/bfkl-links.txt $DIR/mercator-full-links.txt
log "embed using Mercator full: finished"
fi

if [[ $1 == *H* ]]
then log "evaluate Mercator fast mAP"
$DHRG -dhrg $DIR/mercator-fast -rdi $IDIR/graph.txt -map-rank | tee $DIR/log-mercator-fast-cmap.txt
log "evaluate Mercator fast mAP: finished"
fi

if [[ $1 == *I* ]]
then log "evaluate Mercator full mAP"
$DHRG -dhrg $DIR/mercator-full -rdi $IDIR/graph.txt -map-rank | tee $DIR/log-mercator-full-cmap.txt
log "evaluate Mercator fast mAP: finished"
fi

if [[ $1 == *J* ]]
then log "evaluate Mercator fast greedy"
$DHRG -dhrg $DIR/mercator-fast -rdi $IDIR/graph.txt -routing-hdist | tee $DIR/log-mercator-fast-greedy.txt
log "evaluate Mercator fast greedy: finished"
fi

if [[ $1 == *K* ]]
then log "evaluate Mercator full greedy"
$DHRG -dhrg $DIR/mercator-full -rdi $IDIR/graph.txt -routing-hdist | tee $DIR/log-mercator-full-greedy.txt
log "evaluate Mercator full greedy: finished"
fi

if [[ $1 == *L* ]]
then log "embed using RogueViz"
hypviewer/gentree < $IDIR/graph.txt > /dev/null
$DHRG -tree /tmp/treedata-tol.txt -write-in-dhrg-format $DIR/rogueviz-coordinates.txt | tee $DIR/log-rogueviz.txt
cp $DIR/bfkl-links.txt $DIR/rogueviz-links.txt
log "embed using RogueViz: finished"
fi

if [[ $1 == *M* ]]
then log "evaluate RogueViz mAP"
hypviewer/gentree < $IDIR/graph.txt > /dev/null
$DHRG -dhrg $DIR/rogueviz -rdi $IDIR/graph.txt -map-rank | tee $DIR/log-rogueviz-cmap.txt
log "evaluate RogueViz mAP: finished"
fi

if [[ $1 == *N* ]]
then log "embed using TreeRep and evaluate"
julia -t 8 TreeRep/experiment.jl $IDIR/graph.csv $DIR/treerep-edgelist.txt $DIR/treerep-norec.txt $DIR/treerep-wrec.txt | tee $DIR/log-treerep.txt
log "embed using TreeRep and evaluate: finished"
fi

if [[ $1 == *O* ]]
then log "evaluate TreeReps with other measures"
$DHRG -eload $DIR/lorentz2 -rdi $IDIR/graph.txt -eval-disttable $DIR/treerep-edgelist.txt $DIR/treerep-norec.txt -eval-disttable $DIR/treerep-edgelist.txt $DIR/treerep-wrec.txt | tee $DIR/log-treerep-eval.txt
log "evaluate TreeReps with other measures: finished"
fi

if [[ $1 == *P* ]]
then log "embed using LTiling_rsgd"
cd HyperbolicTiling_Learning
python3 embed.py \
  -dset ../$IDIR/graph.csv \
  -epochs 1000 \
  -negs 50 \
  -burnin 20 \
  -dampening 0.75 \
  -ndproc 4 \
  -eval_each 100 \
  -sparse \
  -burnin_multiplier 0.01 \
  -neg_multiplier 0.1 \
  -lr_type constant \
  -train_threads 2 \
  -dampening 1.0 \
  -batchsize 50 \
  -manifold LTiling_rsgd \
  -dim 2 \
  -com_n 1 \
  -lr 0.3 -no-maxnorm \
  -keys ../$DIR/ltiling-keys.txt \
  -disttable ../$DIR/ltiling-disttable.txt
cd ..
# epochs=1000, train_threads=2
log "embed using LTiling_rsgd: finished"
fi
#       -checkpoint ../$DIR/ltiling.bin \

if [[ $1 == *Q* ]]
then log "evaluate LTiling_rsgd using other measures"
$DHRG -eload $DIR/lorentz2 -rdi $IDIR/graph.txt -eval-disttable $DIR/ltiling-keys.txt $DIR/ltiling-disttable.txt | tee $DIR/log-ltiling-eval.txt
log "evaluate LTiling_rsgd using other measures: finished"
fi

if [[ $1 == *R* ]]
then log "convert Poincare 2D"
cd poincare-embeddings
python3 kx-evaluate.py ../$DIR/poincare2.bin.best -output3 ../$DIR/poincare2.txt | tee ../$DIR/log-poincare2-convert.txt
cd ..
log "convert Poincare 2D: finished"
fi

if [[ $1 == *S* ]]
then log "evaluate poincare2 greedy"
$DHRG -eload $DIR/lorentz2 -routing-poincare2 $DIR/poincare2.txt | tee $DIR/log-poincare2-greedy.txt
log "evaluate poincare2 greedy: finished"
fi

log "experiment complete"
