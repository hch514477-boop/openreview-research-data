#!/bin/sh
#g++ scripts/convert-graph-str.cpp -O3 -o bin/convert-graph-str
#for x in celegans
#do echo converting $x
#bin/convert-graph-str graphs/$x/graph-orig.txt graphs/$x/graph.txt graphs/$x/graph.csv
#done

#g++ scripts/convert-hierarchy.cpp -O3 -o bin/convert-hierarchy
#for x in csphd
#do echo converting $x
#bin/convert-hierarchy graphs/$x/graph-orig.txt graphs/$x/graph.txt graphs/$x/graph.csv
#done
#rm bin/convert-hierarchy

g++ scripts/convert-graph.cpp -O3 -o bin/convert-graph
for x in diseasome
do echo converting $x
bin/convert-graph graphs/$x/graph-orig.txt graphs/$x/graph.txt graphs/$x/graph.csv
done
rm bin/convert-graph
