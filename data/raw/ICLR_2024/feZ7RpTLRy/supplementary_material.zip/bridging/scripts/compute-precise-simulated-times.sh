#!/bin/bash

if [[ $1 == *r* ]]
then echo reembedding...
for x in graphs/simulated/*/*/graph.txt; do echo -n $x =; /usr/bin/time 2>&1 hyperbolic-embedder/embedder >/dev/null -seed 123456 -input $x -embed /tmp/result; done > tables/reembed-time.txt
fi

if [[ $1 == *p* ]]
then echo creating precise-times.csv
echo "graph;ssize;stemp;sid;bfkltime" > tables/precise-times.csv
cat tables/reembed-time.txt | grep -v inputs | sed s:graphs/:: | sed "s:user.*$::" | sed "s:/graph.txt =:;:" | sed "s:/:;:g" | sed "s:-T:;:" >> tables/precise-times.csv
fi
