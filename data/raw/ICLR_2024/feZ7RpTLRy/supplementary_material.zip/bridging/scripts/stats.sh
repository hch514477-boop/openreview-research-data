#!/bin/bash

function timer {
  start=`grep "$1" $DIR/log.txt | grep -v finished | tail -n 1 | sed "s- : .*--" | sed "s-universal--"`
  end=`grep "$1" $DIR/log.txt | grep finished | tail -n 1 | sed "s- : .*--" | sed "s-universal--"`
  echo $((`date "+%s" -d "$end"`-`date "+%s" -d "$start"`))
  }

function stat {

  IDIR=graphs/$1/
  DIR=results/$1/
  GRAPH=$1$2

  if [ ! -z $2 ]
  then
    DIR=results/repeated/$GRAPH/
    GRAPH=r$2/$1
  fi

  echo
  echo GRAPH=$GRAPH

  echo :: graph $GRAPH 1>&2

  echo n=`cat $DIR/log-bfkl-improve.txt | grep "Vertices by distance" | head -n 1 | sed "s-.*N = --" | sed "s-):--"`
  echo m=`wc -l $IDIR/graph.txt | sed "s- .*--"`

  echo bfkl_time=`timer "embed using BFKL"`
  echo lorentz2_time=`timer "embed using Lorentz"`
  echo improve_time=`timer "improve BFKL"`
  echo ltiling_time=`timer "embed using LTiling_rsgd"`
  echo mercator_fast_time=`timer "embed using Mercator fast"`
  echo mercator_full_time=`timer "embed using Mercator full"`
  echo poincare2_time=`timer "embed using Poincare 2D"`
  echo poincare3_time=`timer "embed using Poincare 3D"`

  echo bfkl_radius_pre_improve=`cat $DIR/log-bfkl-improve.txt | grep "Vertices by distance" -A 1 | head -n 2 | tail -n 1 | sed "s-.* --" | sed "s-:.*--"`
  echo bfkl_radius_post_improve=`cat $DIR/log-bfkl-improve.txt | grep "Vertices by distance" -A 1 | tail -n 2 | tail -n 1 | sed "s-.* --" | sed "s-:.*--"`
  echo lorentz2_radius_pre_improve=`cat $DIR/log-lorentz2-improve.txt | grep "Vertices by distance" -A 1 | head -n 2 | tail -n 1 | sed "s-.* --" | sed "s-:.*--"`
  echo lorentz2_radius_post_improve=`cat $DIR/log-lorentz2-improve.txt | grep "Vertices by distance" -A 1 | tail -n 2 | tail -n 1 | sed "s-.* --" | sed "s-:.*--"`

  echo bfkl_au=`cat $DIR/bfkl-coordinates.txt | tail -n +3 | cut -f 2 | sort -g | tail -n 1`
  echo lorentz2_au=`cat $DIR/lorentz2-coordinates.txt | tail -n +3 | cut -d " " -f 2 | sort -g | tail -n 1`
  echo rogueviz_au=`cat $DIR/rogueviz-coordinates.txt | tail -n +3 | cut -d " " -f 2 | sort -g | tail -n 1`
  echo poincare3_au=`cat $DIR/log-poincare3-greedy.txt | grep "maximum radius" | tail -n 1 | sed "s-.*maximum radius = --" | sed "s- .*--"`
  echo mercator_fast_au=`cat $DIR/mercator-fast-coordinates.txt | tail -n +3 | cut -d " " -f 2 | sort -g | tail -n 1`
  echo mercator_full_au=`cat $DIR/mercator-full-coordinates.txt | tail -n +3 | cut -d " " -f 2 | sort -g | tail -n 1`
  echo hypviewer_au=`cat $DIR/log-hypviewer.txt | grep radius | cut -d "=" -f 2`

  echo lorentz2_meanrank=`cat $DIR/log-lorentz2-evaluate.txt | grep rank | tail -n 1 | sed "s-Mean rank: --" | sed "s-, mAP.*--"`
  echo lorentz2_map=`cat $DIR/log-lorentz2-evaluate.txt | grep rank | tail -n 1 | sed "s-.*mAP rank: --" | sed "s-, time.*--"`
  echo lorentz2_eval_time=`cat $DIR/log-lorentz2-evaluate.txt | grep rank | tail -n 1 | sed "s-.*time: --"`
  #echo lorentz2_result=`cat $DIR/log-lorentz2-evaluate.txt | grep rank | tail -n 1`

  echo bfkl_pre_meanrank=`cat $DIR/log-bfkl-improve.txt | grep meanrank | head -n 1 | sed "s-.*meanrank = --" | sed "s- .*--"`
  echo bfkl_pre_map=`cat $DIR/log-bfkl-improve.txt | grep meanrank | head -n 1 | sed "s-.*MAP = --" | sed "s- .*--"`
  #echo bfkl_pre_improve=`cat $DIR/log-bfkl-improve.txt | grep meanrank | head -n 1`

  echo bfkl_post_meanrank=`cat $DIR/log-bfkl-improve.txt | grep meanrank | tail -n 1 | sed "s-.*meanrank = --" | sed "s- .*--"`
  echo bfkl_post_map=`cat $DIR/log-bfkl-improve.txt | grep meanrank | tail -n 1 | sed "s-.*MAP = --" | sed "s- .*--"`
  #echo bfkl_post_improve=`cat $DIR/log-bfkl-improve.txt | grep meanrank | tail -n 1`

  echo lorentz2_pre_meanrank=`cat $DIR/log-lorentz2-improve.txt | grep meanrank | head -n 1 | sed "s-.*meanrank = --" | sed "s- .*--"`
  echo lorentz2_pre_map=`cat $DIR/log-lorentz2-improve.txt | grep meanrank | head -n 1 | sed "s-.*MAP = --" | sed "s- .*--"`
  #echo lorentz2_pre_improve=`cat $DIR/log-lorentz2-improve.txt | grep meanrank | head -n 1`

  echo lorentz2_post_meanrank=`cat $DIR/log-lorentz2-improve.txt | grep meanrank | tail -n 1 | sed "s-.*meanrank = --" | sed "s- .*--"`
  echo lorentz2_post_map=`cat $DIR/log-lorentz2-improve.txt | grep meanrank | tail -n 1 | sed "s-.*MAP = --" | sed "s- .*--"`
  #echo lorentz2_post_improve=`cat $DIR/log-lorentz2-improve.txt | grep meanrank | tail -n 1`

  echo landscape200_meanrank=`cat $DIR/log-landscape-200.txt | grep MeanRank | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo landscape200_map=`cat $DIR/log-landscape-200.txt | grep MeanRank | sed "s-.*MAP = --" | sed "s- .*--"`
  #echo landscape199_meanrank=`cat $DIR/log-landscape-199b.txt | grep MeanRank | sed "s-.*MeanRank = --" | sed "s- .*--"`
  #echo landscape199_map=`cat $DIR/log-landscape-199b.txt | grep MeanRank | sed "s-.*MAP = --" | sed "s- .*--"`
  echo landscape50_meanrank=`cat $DIR/log-landscape-50.txt | grep MeanRank | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo landscape50_map=`cat $DIR/log-landscape-50.txt | grep MeanRank | sed "s-.*MAP = --" | sed "s- .*--"`

  echo poincare3_meanrank=`cat $DIR/log-poincare3-evaluate.txt | grep rank | tail -n 1 | sed "s-Mean rank: --" | sed "s-, mAP.*--"`
  echo poincare3_map=`cat $DIR/log-poincare3-evaluate.txt | grep rank | tail -n 1 | sed "s-.*mAP rank: --" | sed "s-, time.*--"`
  echo poincare5_meanrank=`cat $DIR/log-poincare5-evaluate.txt | grep rank | tail -n 1 | sed "s-Mean rank: --" | sed "s-, mAP.*--"`
  echo poincare5_map=`cat $DIR/log-poincare5-evaluate.txt | grep rank | tail -n 1 | sed "s-.*mAP rank: --" | sed "s-, time.*--"`
  echo poincare2_meanrank=`cat $DIR/log-poincare2-evaluate.txt | grep rank | tail -n 1 | sed "s-Mean rank: --" | sed "s-, mAP.*--"`
  echo poincare2_map=`cat $DIR/log-poincare2-evaluate.txt | grep rank | tail -n 1 | sed "s-.*mAP rank: --" | sed "s-, time.*--"`
  echo poincare5_meanrank=`cat $DIR/log-poincare5-evaluate.txt | grep rank | tail -n 1 | sed "s-Mean rank: --" | sed "s-, mAP.*--"`
  echo poincare5_map=`cat $DIR/log-poincare5-evaluate.txt | grep rank | tail -n 1 | sed "s-.*mAP rank: --" | sed "s-, time.*--"`
  echo euclidean50_meanrank=`cat $DIR/log-euclidean50-evaluate.txt | grep rank | tail -n 1 | sed "s-Mean rank: --" | sed "s-, mAP.*--"`
  echo euclidean50_map=`cat $DIR/log-euclidean50-evaluate.txt | grep rank | tail -n 1 | sed "s-.*mAP rank: --" | sed "s-, time.*--"`
  echo euclidean200_meanrank=`cat $DIR/log-euclidean200-evaluate.txt | grep rank | tail -n 1 | sed "s-Mean rank: --" | sed "s-, mAP.*--"`
  echo euclidean200_map=`cat $DIR/log-euclidean200-evaluate.txt | grep rank | tail -n 1 | sed "s-.*mAP rank: --" | sed "s-, time.*--"`

  echo bfkl_ddhrg_meanrank=`cat $DIR/log-ddhrg-bfkl-cmap.txt | grep MeanRank | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo bfkl_ddhrg_map=`cat $DIR/log-ddhrg-bfkl-cmap.txt | grep MeanRank | sed "s-.*MAP = --" | sed "s- .*--"`
  echo lorentz2_ddhrg_meanrank=`cat $DIR/log-ddhrg-lorentz2-cmap.txt | grep MeanRank | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo lorentz2_ddhrg_map=`cat $DIR/log-ddhrg-lorentz2-cmap.txt | grep MeanRank | sed "s-.*MAP = --" | sed "s- .*--"`

  echo bfkl_meanrank=`cat $DIR/log-bfkl-cmap.txt | grep MeanRank | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo bfkl_map=`cat $DIR/log-bfkl-cmap.txt | grep MeanRank | sed "s-.*MAP = --" | sed "s- .*--"`
  echo bfkl_greedy_success=`cat $DIR/log-bfkl-greedy.txt | grep "greedy routing:" | sed "s-.*success = --" | sed "s- .*--"`
  echo bfkl_greedy_stretch=`cat $DIR/log-bfkl-greedy.txt | grep "greedy routing:" | sed "s-.*stretch = --" | sed "s- .*--"`
  echo dhrg_greedy_success=`cat $DIR/log-dhrg-greedy.txt | grep "greedy routing:" | sed "s-.*success = --" | sed "s- .*--"`
  echo dhrg_greedy_stretch=`cat $DIR/log-dhrg-greedy.txt | grep "greedy routing:" | sed "s-.*stretch = --" | sed "s- .*--"`
  echo lorentz2_greedy_success=`cat $DIR/log-lorentz2-greedy.txt | grep "greedy routing:" | sed "s-.*success = --" | sed "s- .*--"`
  echo lorentz2_greedy_stretch=`cat $DIR/log-lorentz2-greedy.txt | grep "greedy routing:" | sed "s-.*stretch = --" | sed "s- .*--"`

  echo bfkl_ddhrg_greedy_success=`cat $DIR/log-ddhrg-bfkl-greedy.txt | grep "greedy routing:" | sed "s-.*success = --" | sed "s- .*--"`
  echo bfkl_ddhrg_greedy_stretch=`cat $DIR/log-ddhrg-bfkl-greedy.txt | grep "greedy routing:" | sed "s-.*stretch = --" | sed "s- .*--"`
  echo lorentz2_ddhrg_greedy_success=`cat $DIR/log-ddhrg-lorentz2-greedy.txt | grep "greedy routing:" | sed "s-.*success = --" | sed "s- .*--"`
  echo lorentz2_ddhrg_greedy_stretch=`cat $DIR/log-ddhrg-lorentz2-greedy.txt | grep "greedy routing:" | sed "s-.*stretch = --" | sed "s- .*--"`
  echo poincare3_greedy_success=`cat $DIR/log-poincare3-greedy.txt | grep "greedy routing:" | sed "s-.*success = --" | sed "s- .*--"`
  echo poincare3_greedy_stretch=`cat $DIR/log-poincare3-greedy.txt | grep "greedy routing:" | sed "s-.*stretch = --" | sed "s- .*--"`

  echo poincare2_au=`cat $DIR/log-poincare2-greedy.txt | grep "maximum radius" | tail -n 1 | sed "s-.*maximum radius = --" | sed "s- .*--"`
  echo poincare2_greedy_success=`cat $DIR/log-poincare2-greedy.txt | grep "greedy routing:" | sed "s-.*success = --" | sed "s- .*--"`
  echo poincare2_greedy_stretch=`cat $DIR/log-poincare2-greedy.txt | grep "greedy routing:" | sed "s-.*stretch = --" | sed "s- .*--"`

  echo : visualizations 1>&2

  echo hypviewer_meanrank=`cat $DIR/log-evaluate-hypviewer.txt | grep rank | tail -n 1 | sed "s-Mean rank: --" | sed "s-, mAP.*--"`
  echo hypviewer_map=`cat $DIR/log-evaluate-hypviewer.txt | grep rank | tail -n 1 | sed "s-.*mAP rank: --" | sed "s-, time.*--"`
  echo rogueviz_meanrank=`cat $DIR/log-rogueviz-cmap.txt | grep MeanRank | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo rogueviz_map=`cat $DIR/log-rogueviz-cmap.txt | grep MeanRank | sed "s-.*MAP = --" | sed "s- .*--"`

  echo : mercator 1>&2

  echo mfast_meanrank=`cat $DIR/log-mercator-fast-cmap.txt | grep MeanRank | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo mfast_map=`cat $DIR/log-mercator-fast-cmap.txt | grep MeanRank | sed "s-.*MAP = --" | sed "s- .*--"`
  echo mfull_meanrank=`cat $DIR/log-mercator-full-cmap.txt | grep MeanRank | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo mfull_map=`cat $DIR/log-mercator-full-cmap.txt | grep MeanRank | sed "s-.*MAP = --" | sed "s- .*--"`
  echo mfast_greedy_success=`cat $DIR/log-mercator-fast-greedy.txt | grep "greedy routing:" | sed "s-.*success = --" | sed "s- .*--"`
  echo mfast_greedy_stretch=`cat $DIR/log-mercator-fast-greedy.txt | grep "greedy routing:" | sed "s-.*stretch = --" | sed "s- .*--"`
  echo mfull_greedy_success=`cat $DIR/log-mercator-full-greedy.txt | grep "greedy routing:" | sed "s-.*success = --" | sed "s- .*--"`
  echo mfull_greedy_stretch=`cat $DIR/log-mercator-full-greedy.txt | grep "greedy routing:" | sed "s-.*stretch = --" | sed "s- .*--"`

  echo : treerep 1>&2

  echo wrec_treerep_map=`cat $DIR/log-treerep.txt | grep "wrec mAP" | sed "s-.* = --"`
  echo norec_treerep_map=`cat $DIR/log-treerep.txt | grep "norec mAP" | sed "s-.* = --"`

  echo norec_treerep_hr_meanrank=`cat $DIR/log-treerep-eval.txt | grep MeanRank | head -n 1 | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo norec_treerep_hr_map=`cat $DIR/log-treerep-eval.txt | grep MeanRank | head -n 1 | sed "s-.*MAP = --" | sed "s- .*--"`
  echo norec_treerep_hr_greedy_success=`cat $DIR/log-treerep-eval.txt | grep "greedy routing:" | head -n 1 | sed "s-.*success = --" | sed "s- .*--"`
  echo norec_treerep_hr_greedy_stretch=`cat $DIR/log-treerep-eval.txt | grep "greedy routing:" | head -n 1 | sed "s-.*stretch = --" | sed "s- .*--"`
  echo norec_treerep_tu=`cat $DIR/log-treerep-eval.txt | grep "maximum distance" | head -n 1 | sed "s-.*maximum distance = --" | sed "s- .*--"`

  echo wrec_treerep_hr_meanrank=`cat $DIR/log-treerep-eval.txt | grep MeanRank | tail -n 1 | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo wrec_treerep_hr_map=`cat $DIR/log-treerep-eval.txt | grep MeanRank | tail -n 1 | sed "s-.*MAP = --" | sed "s- .*--"`
  echo wrec_treerep_hr_greedy_success=`cat $DIR/log-treerep-eval.txt | grep "greedy routing:" | tail -n 1 | sed "s-.*success = --" | sed "s- .*--"`
  echo wrec_treerep_hr_greedy_stretch=`cat $DIR/log-treerep-eval.txt | grep "greedy routing:" | tail -n 1 | sed "s-.*stretch = --" | sed "s- .*--"`
  echo wrec_treerep_tu=`cat $DIR/log-treerep-eval.txt | grep "maximum distance" | tail -n 1 | sed "s-.*maximum distance = --" | sed "s- .*--"`

  echo ltiling_meanrank=`cat $DIR/log-ltiling-eval.txt | grep MeanRank | tail -n 1 | sed "s-.*MeanRank = --" | sed "s- .*--"`
  echo ltiling_map=`cat $DIR/log-ltiling-eval.txt | grep MeanRank | tail -n 1 | sed "s-.*MAP = --" | sed "s- .*--"`
  echo ltiling_greedy_success=`cat $DIR/log-ltiling-eval.txt | grep "greedy routing:" | tail -n 1 | sed "s-.*success = --" | sed "s- .*--"`
  echo ltiling_greedy_stretch=`cat $DIR/log-ltiling-eval.txt | grep "greedy routing:" | tail -n 1 | sed "s-.*stretch = --" | sed "s- .*--"`
  echo ltiling_diam=`cat $DIR/log-ltiling-eval.txt | grep "maximum distance" | tail -n 1 | sed "s-.*maximum distance = --" | sed "s- .*--"`

  echo : done 1>&2

  #echo landscape199=`cat $DIR/log-landscape-199b.txt | grep MeanRank`
  #echo landscape50=`cat $DIR/log-landscape-50.txt | grep MeanRank`
  #echo BFKL embed time: `grep "embed using BFKL" $DIR/log.txt`
  }

if [[ $1 == *h* ]]
then echo ::: real-world hierarchies 1>&2
  stat noun
  stat mammal
  stat verbf
  stat acm
  stat mesh
  stat tetrapoda
  stat csphd
fi

if [[ $1 == *r* ]]
then echo ::: real-world graphs 1>&2
  stat astroph
  stat condmat
  stat grqc
  stat hepph
  stat facebook
  stat yeast
  stat diseasome
  stat celegans
  stat human1
  stat drosophila1
  stat mouse3
fi

if [[ $1 == *s* ]]
then echo ::: including the simulations 1>&2
  for id in `seq -w 0 49`
  do stat simulated/500-T1/$id
  done
  for id in `seq -w 0 49`
  do stat simulated/1000-T1/$id
  done
  for id in `seq -w 0 49`
  do stat simulated/2000-T1/$id
  done
  for id in `seq -w 0 49`
  do stat simulated/500-T7/$id
  done
  for id in `seq -w 0 49`
  do stat simulated/1000-T7/$id
  done
  for id in `seq -w 0 49`
  do stat simulated/2000-T7/$id
  done
  for id in `seq -w 0 49`
  do stat simulated/500-T4/$id
  done
  for id in `seq -w 0 49`
  do stat simulated/1000-T4/$id
  done
  for id in `seq -w 0 49`
  do stat simulated/2000-T4/$id
  done
fi

if [[ $1 == *n* ]]
then echo ::: nouns-repeated 1>&2
  stat noun
  stat noun 1
  stat noun 2
  stat noun 3
  stat noun 4
fi

if [[ $1 == *A* ]]
then echo ::: repeated experiments A 1>&2
  stat grqc
  for i in 1 2 3 4
  do stat grqc $i
  done
  stat yeast
  for i in 1 2 3 4
  do stat yeast $i
  done
fi

if [[ $1 == *B* ]]
then echo ::: repeated experiments B 1>&2
  stat mouse3
  for i in 1 2 3 4
  do stat mouse3 $i
  done
  stat human1
  for i in 1 2 3 4
  do stat human1 $i
  done
fi

if [[ $1 == *C* ]]
then echo ::: repeated experiments C 1>&2
  stat drosophila1
  for i in 1 2 3 4
  do stat drosophila1 $i
  done
  stat celegans
  for i in 1 2 3 4
  do stat celegans $i
  done
fi

