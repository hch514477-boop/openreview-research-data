cp graphs/verb/graph.txt graphs/verbf/graph.txt
cp graphs/verb/graph.csv graphs/verbf/graph.csv
cat graphs/verb/graph.txt | tail +2 | tr " " "\n" | sort | uniq | sed "s/^\(.*\)$/\1 TOP/" >> graphs/verbf/graph.txt
cat graphs/verb/graph.txt | tail +2 | tr " " "\n" | sort | uniq | sed "s/^\(.*\)$/\1,TOP,1/" >> graphs/verbf/graph.csv

