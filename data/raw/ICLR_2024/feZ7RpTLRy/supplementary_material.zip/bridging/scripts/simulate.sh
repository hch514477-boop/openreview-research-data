# execute do-all.sh on simulated graphs

# embed with default temperature
function embed {
size=$1
id=$2
DIR=graphs/simulated/$size-T1/$id/
mkdir -p $DIR
hyperbolic-embedder/embedder --generate data/simg-$size-$proc$att -n $size -seed 42$id -embed $DIR/graph-orig
bin/convert-graph $DIR/graph-orig-links.txt $DIR/graph.txt $DIR/graph.csv
}

# embed with temperature 0.7
function embed7 {
size=$1
id=$2
DIR=graphs/simulated/$size-T7/$id/
mkdir -p $DIR
hyperbolic-embedder/embedder --generate data/simg-$size-$proc$att -n $size -T 0.7 -seed 42$id -embed $DIR/graph-orig
bin/convert-graph $DIR/graph-orig-links.txt $DIR/graph.txt $DIR/graph.csv
}

# embed with temperature 0.4
function embed4 {
size=$1
id=$2
DIR=graphs/simulated/$size-T4/$id/
mkdir -p $DIR
hyperbolic-embedder/embedder --generate data/simg-$size-$proc$att -n $size -T 0.4 -seed 42$id -embed $DIR/graph-orig
bin/convert-graph $DIR/graph-orig-links.txt $DIR/graph.txt $DIR/graph.csv
}

STEPS=abcdefghijklFGHIJK

for size in 500 1000 2000
do
for id in `seq -w 0 49`
do
echo iteration $size $id
embed $size $id
bash scripts/process.sh $STEPS simulated/$size-T1/$id/
done
done

for size in 500 1000 2000
do
for id in `seq -w 0 49`
do
echo iteration $size $id
embed7 $size $id
bash scripts/process.sh $STEPS simulated/$size-T7/$id/
done
done

for size in 500 1000 2000
do
for id in `seq -w 0 49`
do
echo iteration $size $id
embed4 $size $id
bash scripts/process.sh $STEPS simulated/$size-T4/$id/
done
done
