#!/bin/bash
g++ scripts/tabler.cpp -o bin/tabler -fconcepts

bash scripts/stats.sh r | bin/tabler "1n,t,r,g,a,m,u,s" > tables/real-world-network-table.tex

bash scripts/stats.sh h | bin/tabler "2n,t,r,g,a,m,u,s" > tables/real-world-hierarchy-table.tex

echo > tables/repeat-tables.tex
bash scripts/stats.sh n | bin/tabler "2n,t,r,g,a,m,u,s" >> tables/repeat-tables.tex

echo >> tables/repeat-tables.tex

bash scripts/stats.sh A | bin/tabler "1n,t,r,g,a,m,u,s" >> tables/repeat-tables.tex

echo >> tables/repeat-tables.tex

bash scripts/stats.sh B | bin/tabler "1n,t,r,g,a,m,u,s" >> tables/repeat-tables.tex

echo >> tables/repeat-tables.tex

bash scripts/stats.sh C | bin/tabler "1n,t,r,g,a,m,u,s" >> tables/repeat-tables.tex
