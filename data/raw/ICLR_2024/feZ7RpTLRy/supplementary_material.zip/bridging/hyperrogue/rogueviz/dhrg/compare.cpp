#include "../som/kohonen.h"

namespace dhrg {

/* build landscape embeddings and compute mAP for them */

using rogueviz::kohonen::kohvec;
using rogueviz::kohonen::columns;

int landscape_dim;

vector<kohvec> landscape_weights;

ld dist(const kohvec& a, const kohvec& b) {
  ld res = 0;
  for(int i=0; i<columns; i++) res += (a[i]-b[i]) * (a[i] - b[i]);
  return res;
  }

void landscape_build(int dim) {
  rogueviz::embeddings::init_landscape(columns = landscape_dim = dim);
  landscape_weights.resize(N);
  if(1) {
    progressbar pb(N, "compute landscape");
    for(int i=0; i<N; i++) {
      mycell *mc = vertices[i];
      cell *c = mc->ascell();
      landscape_weights[i] = rogueviz::embeddings::get_landscape_at(c);
      // println(hlog, i, ": ", landscape_weights[i]);
      pb++;
      }
    }
  println(hlog, "delta size = ", isize(rogueviz::embeddings::delta_at));
  }

void landscape_output(string shape, ld target_dist, string fname) {
  ld max_dist = 0;
  for(int i=0; i<N; i++) {
    ld tot = 0;
    for(int d=0; d<columns; d++) tot += pow(landscape_weights[i][d], 2);
    tot = sqrt(tot);
    max_dist = max(max_dist, tot);
    }
  println(hlog, "max_dist = ", max_dist, " to ", target_dist);
  fhstream f(fname, "w");
  for(int i=0; i<N; i++) {
    ld tot = 0;
    println(f, rogueviz::vdata[i].name);
    for(int d=0; d<columns; d++) {
      auto w = landscape_weights[i][d] * target_dist / max_dist;
      if(d) print(f, " ");
      print(f, w);
      tot += w * w;
      }
    if(shape == "euclid") println(f);
    else if(shape == "poincare") println(f);
    else if(shape == "lorentz") println(f, " ", sqrt(tot+1));
    else if(shape == "horosphere") {
      tot /= 2;
      ld shift = -asinh(target_dist)/2;
      println(f, " ", cosh(shift) * tot + sinh(shift) * (1+tot), " ", cosh(shift) * (1+tot) + sinh(shift) * tot);
      }
    }
  }

ld landscape_dist(int i, int j) {
  return dist(landscape_weights[i], landscape_weights[j]);
  } 

void rank_landscape(int dim) {
  landscape_build(dim);
  continuous_ranks(landscape_dist); 
  }

/* read Poincare embedding and compute ranks and routing measures */

void read_poincare(string fname) {
  fhstream g(fname, "rt");
  if(!g.f) {
    println(hlog, "Missing file: ", fname);
    exit(1);
    }
  println(hlog, "Reading Poincare3...");
  vertexcoords.resize(N);
  ld maxradius = 0;
  while(true) {
    int i = rogueviz::readLabel(g);
    if(i == -1) break;
    hyperpoint h;
    for(int i=0; i<GDIM; i++) h[i] = scan<ld>(g);
    auto h1 = perspective_to_space(h, 1);
    vertexcoords[i] = h1;
    maxradius = max(maxradius, hdist0(h1));
    }
  println(hlog, "maximum radius = ", maxradius);
  }

void rank_poincare3(string fname) {
  dynamicval<eGeometry> dg(geometry, gSpace534);
  read_poincare(fname);
  routing_by(vertex_dist);
  }

void routing_poincare3(string fname) {
  dynamicval<eGeometry> dg(geometry, gSpace534);
  read_poincare(fname);
  routing_by(vertex_dist);
  }

void routing_poincare2(string fname) {
  read_poincare(fname);
  routing_by(vertex_dist);
  }

void eval_disttable(string nodelist_fname, string disttable_fname) {
  vector<vector<ld>> disttable;
  fhstream g(nodelist_fname, "rt");
  vector<int> our_index;
  while(true) {
    int i = rogueviz::readLabel(g);
    if(i == -1) break;
    our_index.push_back(i);
    }
  println(hlog, "read ", isize(our_index), " node labels from ", nodelist_fname);
  if(isize(our_index) != N) { println(hlog, "wrong number of labels, ", N, " expected"); return; }

  ld maxdist = 0;

  disttable.resize(N);
  for(int i=0; i<N; i++) disttable[i].resize(N, 0);
  fhstream g1(disttable_fname, "rt");
  println(hlog, "reading distance table from ", disttable_fname);
  for(int i=0; i<N; i++)
  for(int j=0; j<i; j++) {
    ld dist = scan<ld>(g1);
    maxdist = max(dist, maxdist);
    disttable[our_index[i]][our_index[j]] = dist;
    disttable[our_index[j]][our_index[i]] = dist;
    }

  println(hlog, "maximum distance = ", maxdist);

  auto disttable_dist = [&] (int i, int j) { return disttable[i][j]; };
  routing_by(disttable_dist);
  continuous_ranks(disttable_dist);
  }

}
