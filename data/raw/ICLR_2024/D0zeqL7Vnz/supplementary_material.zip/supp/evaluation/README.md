## Setup

BigBench is included as a submodule. To download it follow the following steps after cloning this repo as usual:

```
git submodule init
git submodule update
```

Then create a conda environment and install all requirements:
```
conda create --name sketching python==3.8
conda activate sketching
pip3 install -r requirements.txt
```