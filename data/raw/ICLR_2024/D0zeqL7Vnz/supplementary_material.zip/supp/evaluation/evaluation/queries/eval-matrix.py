BEAM(dclib_decoder="argmax", max_length=1024, num_beams=3, openai_chunksize=32)
    "Transpose a matrix of shape (3,2). The result is a matrix of shape[var] Multiply the result with a matrix of shape (3,2). The result is a matrix of shape[var] Compute the hadamard product of the result with a matrix of shape (2,2). The result is a matrix of shape[var] Compute the kronecker product of the result with a matrix of shape (4,2). The result is a matrix of shape[var] The result is a matrix of shape[answer]."
FROM
    "openai/text-babbage-001"
WHERE
   not "\n" in var and STOPS_AT(var, ")") and STOPS_AT(answer, ")")