# Evaluation Suites

To download strategyqa, run:

```
mkdir -p strategyqa
cd strategyqa
wget https://storage.googleapis.com/ai2i/strategyqa/data/strategyqa_dataset.zip 
unzip -q strategyqa_dataset.zip
rm strategyqa_dataset.zip
```