BEAM(dclib_decoder="var", max_length=320, temperature=0.8, b=2, n=2)
    C0 = "bamboo"
    C1 = "memory"
    C2 = "lines"
    "What do the following have in common? 1) {C0} 2) {C1} 3) {C2}\n"
    "To answer this, first brief description of each concept:\n"
    "1) {C0}: [DESC]\n"
    "2) {C1}: [DESC]\n"
    "3) {C2}: [DESC]\n"
    "Judging from this I think the core difference is that [answer]"
    "[answer]"
FROM 
    "openai/text-curie-001"
WHERE
    not "\n" in DESC and STOPS_AT(DESC, ".") and answer in [
      "They all have leaves.",
      "They all are geometric.",
      "They all are straight.",
      "They all have segments.",
      "They all are living."
    ]