REPO_PATH=$(realpath $(dirname "${BASH_SOURCE[0]}"))
alias eval="PYTHONPATH=$REPO_PATH/evaluation python -m evaluation.evaluator \$*"
