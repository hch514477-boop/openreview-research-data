# Generative_Motion_Transfer

## Baseline Implementations
The baseline models are implemented in the subfolders (i.e. `./unpaired_motion`, `./diverse_stylize`, `./motion_puzzle`), built from their offical implementations public availbe on github. For more details, please refer to the official repositories [Aberman et al.](https://github.com/DeepMotionEditing/deep-motion-editing), [Park et al.](https://github.com/soomean/Diverse-Motion-Stylization), [Jang et al.](https://github.com/DK-Jang/motion_puzzle) and our supplementary document.

## Baseline Scripts
All training and testing scripts are documented in `./$baseline_path/eval_scripts.txt`. 