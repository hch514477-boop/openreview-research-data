
from options.base_options import BaseOptions
# import argparse

class TrainOptions(BaseOptions):
    def initialize(self):
        BaseOptions.initialize(self)
        self.parser.add_argument('--do_gan', action="store_true", help='models are saved here')
        self.parser.add_argument('--do_patch_gan', action="store_true", help='models are saved here')
        self.parser.add_argument('--do_cycle', action="store_true", help='models are saved here')
        self.parser.add_argument('--do_grid_sample', action="store_true", help='models are saved here')
        self.parser.add_argument('--do_patch_agg', action="store_true", help='models are saved here')

        self.parser.add_argument('--patch_min_scale', type=float, default=0.125, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--patch_max_scale', type=float, default=0.25, help='Dimension of hidden unit in GRU')

        # self.parser.add_argument('--dim_dis_hid', type=int, default=512, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--n_dis_down', type=int, default=4, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--patch_size', type=int, default=40, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--num_crops', type=int, default=8, help='Dimension of hidden unit in GRU')

        self.parser.add_argument('--adv_start_ep', type=int, default=0, help='Dimension of hidden unit in GRU')


        self.parser.add_argument('--lambda_sp_rec', type=float, default=1.0, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--lambda_gl_rec', type=float, default=1.0, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--lambda_gan', type=float, default=1.0, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--lambda_patch_gan', type=float, default=1.0, help='Dimension of hidden unit in GRU')

        self.parser.add_argument('--lambda_R1', type=float, default=10.0, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--lambda_patch_R1', type=float, default=10.0, help='Dimension of hidden unit in GRU')

        self.parser.add_argument('--lr', type=float, default=2e-4, help='Dimension of hidden unit in GRU')

        self.parser.add_argument('--R1_every_iter', type=int, default=16, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--log_every', type=int, default=10, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--save_latest', type=int, default=50, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--save_every_e', type=int, default=200, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--eval_every_e', type=int, default=100, help='Dimension of hidden unit in GRU')

        self.parser.add_argument('--is_continue', action="store_true", help='models are saved here')
        self.parser.add_argument('--feat_bias', type=float, default=5, help='Layers of GRU')

        self.parser.add_argument('--batch_size', type=int, default=32, help='Dimension of hidden unit in GRU')
        self.parser.add_argument('--max_epoch', type=int, default=30000, help='Dimension of hidden unit in GRU')

        self.is_train = True
