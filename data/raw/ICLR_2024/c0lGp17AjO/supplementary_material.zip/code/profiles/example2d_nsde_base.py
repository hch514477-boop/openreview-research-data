# Stores the parameters for the example2d_nsde_base profile
# Definition of the network see utils/sde_utils.py

batch_size, state_size, brownian_size = 200, 2, 2
hidden_size = 100
η = 0.0005
β = (0.9, 0.999)
weight_decay = 0.005
N_epoch = 2000
nsde_label = 'example2d_nsde_base'
checkpoint_freq = 100
