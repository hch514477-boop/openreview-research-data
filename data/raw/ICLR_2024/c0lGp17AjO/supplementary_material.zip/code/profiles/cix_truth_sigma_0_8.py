import torch
a, b, σ = 1, 5, 0.8
n_samples = 200
t_size = 41

ts = torch.linspace(0, 2, t_size)

torch.manual_seed(0)
u0 = torch.ones(n_samples, 1) * 2

truth_label = 'truth_sigma_0.8'
u_truth_savepath = 'data/cix_truth_sigma_0.8.pt'

