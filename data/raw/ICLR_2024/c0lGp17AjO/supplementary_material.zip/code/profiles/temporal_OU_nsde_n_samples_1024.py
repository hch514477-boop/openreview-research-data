# Stores the parameters for the cix_nsde_base profile
# Definition of the network see utils/sde_utils.py

batch_size, state_size, brownian_size = 1024, 1, 1
hidden_size = 32
η = 0.002
β = (0.9, 0.999)
weight_decay = 0.005
N_epoch = 2000
nsde_label = 'temporal_OU_nsde_base'
checkpoint_freq = 100
