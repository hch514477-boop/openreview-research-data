import torch

Mu = [
    [0.1,0.05] ,
    [0.05,0.2]
]
Sigma = [
    [0.2, -0.1], 
    [-0.1, 0.1]
]
n_samples = 200
t_size = 101

ts = torch.linspace(0, 2, t_size)

torch.manual_seed(0)
u0 = torch.ones(n_samples, 2) * torch.tensor([1, 0.5])

truth_label = 'truth_base'
u_truth_savepath = 'data/gbm_truth_base.pt'