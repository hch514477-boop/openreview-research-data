import os
import time
import math
import pickle
from contextlib import nullcontext

import numpy as np
import torch
import bounds.get_pac_bounds as get_bounds
import yaml


from model import GPTConfig, GPT
import loralib as lora
import datetime
import itertools
from projectors import create_intrinsic_model
import ast


out_dir = '[TODO]'

create_new_output_dir = True

eval_iters = 25
best_checkpoint_path = None
learning_rate = 2e-4
# wandb logging
wandb_log = False # disabled by default
wandb_project = 'owt'
wandb_run_name = 'gpt2' # 'run' + str(time.time())
# data
dataset = 'openwebtext'
gradient_accumulation_steps = 5 * 8 # used to simulate larger batch sizes
batch_size = 12 # if gradient_accumulation_steps > 1, this is the micro-batch size
block_size = 1024
# model
n_layer = 12
n_head = 12
n_embd = 768
dropout = 0.0 # for pretraining 0 is good, for finetuning try 0.1+
bias = False # do we use bias inside LayerNorm and Linear layers?
use_mergedlinear = False

# ===== LoRA Settings ===== #
# 0. Basics
use_lora=False # true if any LoRA layer is used
lora_alpha = 32
lora_dropout = 0.1

# 1. attention linear layer
attention_linear_use_lora = False
attention_linear_lora_r = 1

# 2. linear head
linear_head_lora_r = 1
linear_head_enable_lora = False

# 3. MLP
MLP_lora_r = 1
MLP_enable_lora = False

# 4. token embedding
token_embedding_lora_r = 1
token_embedding_enable_lora = False

# 5. positional embedding
positional_embedding_lora_r = 1
positional_embedding_enable_lora = False

## Quantization parameters 
intrinsic_dim=100000

## Bounds params
vocab_size = 50257
random_sampling_with_replacement = True
bound_samples = 10000
levels = 11
max_quant_iters = 0
data_size = 8823811

# DDP settings
backend = 'nccl' # 'nccl', 'gloo', etc.
# system
device = 'cuda' # examples: 'cpu', 'cuda', 'cuda:0', 'cuda:1' etc., or try 'mps' on macbooks
dtype = 'bfloat16' if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else 'float16' # 'float32', 'bfloat16', or 'float16', the latter will auto implement a GradScaler
# -----------------------------------------------------------------------------
config_keys = [k for k,v in globals().items() if not k.startswith('_') and isinstance(v, (int, float, bool, str, list))]
exec(open('configurator.py').read()) # overrides from command line or config file
config = {k: globals()[k] for k in config_keys} # will be useful for logging
# -----------------------------------------------------------------------------
ddp = 0
master_process = True
ddp_world_size = 1

config["linear_head_lora_r"] = attention_linear_lora_r
linear_head_lora_r = attention_linear_lora_r

### Change lora config here to train without lora if the rank for both attention and head = 0 

if attention_linear_lora_r == 0:
    attention_linear_use_lora = False
    config["attention_linear_use_lora"] = attention_linear_use_lora
    
if linear_head_lora_r == 0:
    linear_head_enable_lora = False
    config["linear_head_enable_lora"] = linear_head_enable_lora
    
if not (attention_linear_use_lora or linear_head_enable_lora or MLP_enable_lora or token_embedding_enable_lora or positional_embedding_enable_lora):
    use_lora = False 
    config["use_lora"] = use_lora
#####

wandb_run_name = "eval_id{}_lr{}_r{}_levels{}_qiters{}".format(config["intrinsic_dim"],
                                                               config["learning_rate"],
                                                               config["attention_linear_lora_r"],
                                                               config["levels"],
                                                               config["max_quant_iters"])
config["wandb_run_name"] = wandb_run_name

# ? creating new output directory
if create_new_output_dir:
    now = datetime.datetime.now()
    formatted_date = now.strftime('%Y-%m-%d')
    formatted_time = now.strftime('%H-%M')
    logging_directory = f'{formatted_date}/{formatted_time}'
    out_dir = os.path.join(out_dir,wandb_run_name, logging_directory)

os.makedirs(out_dir, exist_ok=True)
    
torch.manual_seed(137)
torch.backends.cuda.matmul.allow_tf32 = True # allow tf32 on matmul
torch.backends.cudnn.allow_tf32 = True # allow tf32 on cudnn
device_type = 'cuda' if 'cuda' in device else 'cpu' # for later use in torch.autocast
# note: float16 data type will automatically use a GradScaler
ptdtype = {'float32': torch.float32, 'bfloat16': torch.bfloat16, 'float16': torch.float16}[dtype]
ctx = nullcontext() if device_type == 'cpu' else torch.amp.autocast(device_type=device_type, dtype=ptdtype)

# poor man's data loader
dataset_dir = '[TODO]'


# poor man's data loader
data_dir = os.path.join(dataset_dir, dataset)
train_data = np.memmap(os.path.join(data_dir, 'train.bin'), dtype=np.uint16, mode='r')
val_data = np.memmap(os.path.join(data_dir, 'val.bin'), dtype=np.uint16, mode='r')

# helps estimate an arbitrarily accurate loss over either split using many batches
@torch.no_grad()
def estimate_loss():
    out = {}
    model.eval()
    for split in ['train', 'val']:
        losses = torch.zeros(eval_iters)
        for k in range(eval_iters):
            X, Y, ix = get_batch(split)
            
            if intrinsic_dim == 0:
                with ctx:
                    logits, loss = model(X, Y)
            else:
                logits, loss = model(X, Y)
            losses[k] = loss.item()
            
        out[split] = losses.mean()
    model.train()
    return out

def get_batch(split):
    data = train_data if split == 'train' else val_data
    ix = torch.randint(len(data) - block_size, (batch_size,))
    x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in ix])
    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    else:
        x, y = x.to(device), y.to(device)
    return x, y, ix

def get_batch_from_indices(split, lst_of_indices):
    data = train_data if split == 'train' else val_data
    x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in lst_of_indices])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in lst_of_indices])
    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    else:
        x, y = x.to(device), y.to(device)
    return x, y

def get_batch_sequential(split, ddp_world_size, curr_iter_i, batch_size, ddp_rank=0):
    data = train_data if split == 'train' else val_data
    ix = torch.arange((curr_iter_i*ddp_world_size+ddp_rank)*block_size*batch_size, (curr_iter_i*ddp_world_size+ddp_rank+1)*block_size*batch_size, block_size)
    x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in ix])
    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    else:
        x, y = x.to(device), y.to(device)
    return x, y, ix

def get_batch_random_with_replacement(split, batch_size):
    data = train_data if split == 'train' else val_data
    ix = torch.randint(len(data) - block_size, (batch_size,))
    x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in ix])
    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    else:
        x, y = x.to(device), y.to(device)
    return x, y, ix

# init these up here, can override if init_from='resume' (i.e. from a checkpoint)
iter_num = 0
best_val_loss = 1e9

# attempt to derive vocab_size from the dataset
meta_path = os.path.join(data_dir, 'meta.pkl')
meta_vocab_size = None
if os.path.exists(meta_path):
    with open(meta_path, 'rb') as f:
        meta = pickle.load(f)
    meta_vocab_size = meta['vocab_size']
    print(f"found vocab_size = {meta_vocab_size} (inside {meta_path})")
    
    
################ 3. Getting the model ###################

# model init
model_args = dict(n_layer=n_layer, n_head=n_head, n_embd=n_embd, block_size=block_size,
                  bias=bias, vocab_size=None, dropout=dropout,
                  use_lora=use_lora, lora_alpha=lora_alpha, lora_dropout=lora_dropout,
                  attention_linear_use_lora=attention_linear_use_lora, attention_linear_lora_r=attention_linear_lora_r, # attention_linear_enable_lora=attention_linear_enable_lora,
                  linear_head_lora_r=linear_head_lora_r, linear_head_enable_lora=linear_head_enable_lora,
                  MLP_lora_r = MLP_lora_r, MLP_enable_lora = MLP_enable_lora,
                  token_embedding_lora_r=token_embedding_lora_r, token_embedding_enable_lora=token_embedding_enable_lora,
                  positional_embedding_lora_r=positional_embedding_lora_r, positional_embedding_enable_lora=positional_embedding_enable_lora,
                  use_mergedlinear=use_mergedlinear,
                  ) # start with model_args from command line


print(f"loading best training checkpoint from {best_checkpoint_path} for pretraining bound metrics eval")

ckpt_name = f"quant_ckpt_levels{levels}_iters{max_quant_iters}.pt"

ckpt_path = os.path.join(best_checkpoint_path, ckpt_name)

print(f"THIS IS THE NEW QUANTIZATION CHECKPOINT PATH: {ckpt_path}")

checkpoint = torch.load(ckpt_path, map_location=device)
checkpoint_model_args = checkpoint['model_args']
# force these config attributes to be equal otherwise we can't even do eval after training
# the rest of the attributes (e.g. dropout) can stay as desired from command line
for k in ['n_layer', 'n_head', 'n_embd', 'block_size', 'bias', 'vocab_size', 'use_lora', 'lora_alpha', 'lora_dropout', 'attention_linear_use_lora', 'attention_linear_lora_r', 'linear_head_lora_r', 'linear_head_enable_lora', 'MLP_lora_r', 'MLP_enable_lora', 'token_embedding_lora_r', 'token_embedding_enable_lora', 'positional_embedding_lora_r', 'positional_embedding_enable_lora']:
    model_args[k] = checkpoint_model_args[k]

# create the model
gptconf = GPTConfig(**model_args)
model = GPT(gptconf)

if use_lora: 
    lora.mark_only_lora_as_trainable(model)

if intrinsic_dim > 0: 
        
    #### loading the random initialization of all the weights 

    init_ckpt_path = os.path.join(best_checkpoint_path, "forward_ckpt_at_random_initialization.pt")
    init_checkpoint = torch.load(init_ckpt_path, map_location=device)

    # fix the keys of the state dictionary :(
    # honestly no idea how checkpoints sometimes get this prefix, have to debug more
    unwanted_prefix = '_orig_mod.'
    for k,v in list(init_checkpoint.items()):
        if k.startswith(unwanted_prefix):
            init_checkpoint[k[len(unwanted_prefix):]] = init_checkpoint.pop(k)

    model.load_state_dict(init_checkpoint)
    
    #### creating the ID model and loading the subspace parameters + names + initparams 
    model = create_intrinsic_model(base_net=model,
                                   ckpt_path=None,
                                   intrinsic_mode="rdkronqr",
                                   intrinsic_dim=intrinsic_dim,
                                   seed=137,
                                   device=device,)

state_dict = checkpoint['raw_model']

# fix the keys of the state dictionary :(
# honestly no idea how checkpoints sometimes get this prefix, have to debug more
unwanted_prefix = '_orig_mod.'
for k,v in list(state_dict.items()):
    if k.startswith(unwanted_prefix):
        state_dict[k[len(unwanted_prefix):]] = state_dict.pop(k)
        
        
if intrinsic_dim > 0:
    if "subspace_params" in state_dict:
        model.load_state_dict(state_dict)
    else:
        tmp = {}
        tmp["subspace_params"] = state_dict["module.subspace_params"]
        model.load_state_dict(tmp)
    
    model.trainable_initparams = torch.load(os.path.join(best_checkpoint_path, "trainable_initparams.pt"), map_location=device)
    model.names = torch.load(os.path.join(best_checkpoint_path, "names.pt"))
else:
    model.load_state_dict(state_dict)

iter_num = checkpoint['iter_num']
best_val_loss = checkpoint['best_val_loss']

model.to(device)

if use_lora:
    if intrinsic_dim == 0:
        lora.mark_only_lora_as_trainable(model)
        

print("number of parameters: %.2fM" % (model.get_num_params()/1e6,))
print("number of trainable parameters: %.2f" % (model.get_num_params(only_trainable=True),))


print("\n# === final trainable parameters === #\n")
for n, p in model.named_parameters():
    if p.requires_grad:
        print(n)
print("\n# === final trainable parameters === #\n")



checkpoint = None # free up memory

################ 4. Defining some utils for later .. ###################

def sum_k_elements(row, k_th):
    return torch.sum(row[:k_th+1])


# helps estimate an arbitrarily accurate loss over either split using many batches
@torch.no_grad()
def compute_pretrain_bound_metrics(X, Y):
    if intrinsic_dim == 0:
        with ctx:
            logits, loss = model(X, Y)
    else:
        logits, loss = model(X, Y)
    
    # === for each token, log top-k indice, percentile, and log probability === #
    softmax_matrix = torch.nn.functional.softmax(logits.view(-1, logits.size(-1)),dim=-1)
    sorted_softmax_matrix, indices_softmax_matrix = torch.sort(softmax_matrix, dim=-1, descending=True)
    #torch.cumsum(sorted_softmax_matrix, dim=-1)
    
    # 1. top-k indices
    top_k_indices = torch.argmax((indices_softmax_matrix == Y.view(-1).unsqueeze(1)).long(),dim=-1)
    
    # 4. probabilities 
    selected_prob_scores = softmax_matrix[torch.arange(softmax_matrix.shape[0]), Y.view(-1)]
    
    
    # 3. percentile
    percentile_vec = torch.zeros((sorted_softmax_matrix.shape[0],), device=device)
    for i in range(sorted_softmax_matrix.shape[0]):
        percentile_vec[i] = sum_k_elements(sorted_softmax_matrix[i], top_k_indices[i])
        
    # 2. log probability
    selected_log_prob_scores = torch.log(selected_prob_scores)
    
            
    return loss.item(), top_k_indices, selected_log_prob_scores, percentile_vec, selected_prob_scores


# logging
if wandb_log and master_process:
    import wandb
    wandb.init(project=wandb_project, name=wandb_run_name, config=config)
    
    
################ 5. Beginning of the evaluation ###################

# clear file contents
with open(os.path.join(best_checkpoint_path, f'ix_levels{levels}_iters{max_quant_iters}.txt'), 'w') as file_ix:
    pass 
with open(os.path.join(best_checkpoint_path, f'loss_levels{levels}_iters{max_quant_iters}.txt'), 'w') as file_loss:
    pass 
with open(os.path.join(best_checkpoint_path, f'top_k_indices_levels{levels}_iters{max_quant_iters}.txt'), 'w') as file_top_k_indices:
    pass 
with open(os.path.join(best_checkpoint_path, f'selected_log_prob_scores_levels{levels}_iters{max_quant_iters}.txt'), 'w') as file_selected_log_prob_scores:
    pass 
with open(os.path.join(best_checkpoint_path, f'selected_prob_scores_levels{levels}_iters{max_quant_iters}.txt'), 'w') as file_selected_prob_scores:
    pass 
with open(os.path.join(best_checkpoint_path, f'percentile_vec_levels{levels}_iters{max_quant_iters}.txt'), 'w') as file_percentile_vec:
    pass 

alpha_array = [0.0001, 0.001, 0.005, 0.01, 0.05, 0.1, 0.25, 0.5]

with torch.no_grad():
    model.eval()

    len_train_data = len(train_data)

    curr_iter_i = 0
    
    metrics_dict = {}
    for k in range(1,10+1):
        metrics_dict[f'top_{k}_acc'] = 0
    metrics_dict[f'top_50_acc'] = 0
    metrics_dict[f'top_100_acc'] = 0
    
    for alpha in alpha_array:
        metrics_dict[f'bpd_alpha_{alpha}'] = 0
    metrics_dict["n_train"] = 0
    metrics_dict["curr_iter_i"] = 0

    while bound_samples > metrics_dict["n_train"]:
        if random_sampling_with_replacement:
            X, Y, ix = get_batch_random_with_replacement(split='train', batch_size=batch_size)
        else:
            X, Y, ix = get_batch_sequential(split='train', ddp_world_size=ddp_world_size, curr_iter_i=curr_iter_i, batch_size=batch_size)
#         print(f"ix / block_size ={ix/block_size} for curr_iter_i={curr_iter_i} and batch size={batch_size}")
        loss, top_k_indices, selected_log_prob_scores, percentile_vec, selected_prob_scores = compute_pretrain_bound_metrics(X, Y)
        
        # saving all of ix & loss & top-k & log_prob & percentile_vec
        with open(os.path.join(best_checkpoint_path, f'ix_levels{levels}_iters{max_quant_iters}.txt'), 'a') as file_ix:
            file_ix.write(str(ix.tolist()) + '\n') 
            
        with open(os.path.join(best_checkpoint_path, f'loss_levels{levels}_iters{max_quant_iters}.txt'), 'a') as file_loss:
            file_loss.write(str(loss) + '\n') 
            
        with open(os.path.join(best_checkpoint_path, f'top_k_indices_levels{levels}_iters{max_quant_iters}.txt'), 'a') as file_top_k_indices:
            file_top_k_indices.write(str(top_k_indices.tolist()) + '\n')  
            
        with open(os.path.join(best_checkpoint_path, f'selected_log_prob_scores_levels{levels}_iters{max_quant_iters}.txt'), 'a') as file_selected_log_prob_scores:
            file_selected_log_prob_scores.write(str(selected_log_prob_scores.tolist()) + '\n')  
            
        with open(os.path.join(best_checkpoint_path, f'selected_prob_scores_levels{levels}_iters{max_quant_iters}.txt'), 'a') as file_selected_prob_scores:
            file_selected_prob_scores.write(str(selected_prob_scores.tolist()) + '\n')  
            
        with open(os.path.join(best_checkpoint_path, f'percentile_vec_levels{levels}_iters{max_quant_iters}.txt'), 'a') as file_percentile_vec:
            file_percentile_vec.write(str(percentile_vec.tolist()) + '\n')  

        # compute local batch accuracy
        unique_indices, indices_counts = torch.unique(torch.tensor(top_k_indices),return_counts=True)

        assert len(top_k_indices) == batch_size * block_size

        ### getting the metrics 
        
        for k in range(1,10+1):            
            # sum of accuracy over batch size
            top_k_acc = (sum(indices_counts[0:k])/block_size).item() 
            metrics_dict[f'top_{k}_acc'] = (metrics_dict[f'top_{k}_acc'] * metrics_dict["n_train"] + top_k_acc) / (metrics_dict["n_train"] + batch_size)

                
        top_50_acc = (sum(indices_counts[0:50])/block_size).item()
        metrics_dict[f'top_50_acc'] = (metrics_dict[f'top_50_acc'] * metrics_dict["n_train"] + top_50_acc) / (metrics_dict["n_train"] + batch_size)

        top_100_acc = (sum(indices_counts[0:100])/block_size).item()
        metrics_dict[f'top_100_acc'] = (metrics_dict[f'top_100_acc'] * metrics_dict["n_train"] + top_100_acc) / (metrics_dict["n_train"] + batch_size)
        
        for alpha in alpha_array:          
            log_probs = [np.log2((1-alpha)*x.item() + alpha/vocab_size) for x in selected_prob_scores]
            bdp_alpha = - sum(log_probs)/block_size

            metrics_dict[f'bpd_alpha_{alpha}'] = float((metrics_dict[f'bpd_alpha_{alpha}'] * metrics_dict["n_train"] + bdp_alpha) / (metrics_dict["n_train"] + batch_size))

        # update batch size estimation
        metrics_dict["n_train"] += batch_size
        metrics_dict["curr_iter_i"] += 1 
        
        with open(os.path.join(best_checkpoint_path, f'metrics_levels{levels}_iters{max_quant_iters}.yml'), 'w') as f:
                        yaml.safe_dump(metrics_dict, f, indent=2)
                
        if wandb_log:
            wandb.log(metrics_dict)
            
        if curr_iter_i % 100 == 0:
            print("\n".join("{}\t{}".format(k, v) for k, v in metrics_dict.items()))

        curr_iter_i += 1
        
################ 6. Compute the bounds ###################

if intrinsic_dim == 0:
    if attention_linear_lora_r == 0:
        # no_lora_no_id
        misc_extra_bits = np.ceil(np.log2(2*3))
    else:
        # lora_no_id 
        misc_extra_bits = np.ceil(np.log2(2*2*3)) 
        
else:
    if attention_linear_lora_r == 0:
        ## no_lora_id
        misc_extra_bits = np.ceil(np.log2(2*6*3)) 
    else:
        ## lora_id
        misc_extra_bits = np.ceil(np.log2(4*6*2*3)) 
        
        
prefix_message_len = torch.load(os.path.join(best_checkpoint_path, f'quant_ckpt_levels{levels}_iters{max_quant_iters}.pt'))['prefix_message_len']
sample_size = metrics_dict["n_train"]

# def new_bound(train_error, div, data_size, sample_size, delta = 1, epsilon=0.05):
#     r = sample_size/(sample_size + data_size)
#     num = div - np.log(r * epsilon) - 1/r * np.log((1-r) * epsilon)
#     bound = train_error
#     bound += delta * np.sqrt(num / (2. * data_size))
#     return bound


def corrected_bound(train_error, div, data_size, sample_size, delta = 1, epsilon=0.05):
    r = sample_size/(sample_size + data_size)
    complexity = np.sqrt((div - np.log(r * epsilon))/(2*data_size)) +np.sqrt(-np.log((1-r) * epsilon)/(2*sample_size))
    bound = train_error
    return bound+delta*complexity

bounds_dict = {}
bounds_dict["prefix_message_len"] = float(prefix_message_len)

for k in metrics_dict.keys():
    if k != "n_train" and k != "curr_iter_i":
        if "acc" in k:
            train_error = 1. - metrics_dict[k] 
            
            divergence = (prefix_message_len + misc_extra_bits) * np.log(2)
            
            bounds_dict["acc_divergence"] = float(divergence)

            bounds_dict[f"bound_{k}"] = float(corrected_bound(train_error=train_error,
                                                  div=divergence,
                                                  data_size=data_size,
                                                  sample_size=sample_size,
                                                  delta=1.))
            
        else:
            misc_extra_bits += np.ceil(len(alpha_array))
            
            divergence = (prefix_message_len + misc_extra_bits) * np.log(2)
            
            bounds_dict["bpd_divergence"] = float(divergence)
            
            alpha = float(k.replace("bpd_alpha_", ""))
            
            delta = np.log2(1 + (1 - alpha) * vocab_size / alpha)
            
            train_error = metrics_dict[k]
            
            bounds_dict[f"bound_{k}"] = float(corrected_bound(train_error=train_error,
                                                  div=divergence,
                                                  data_size=data_size,
                                                  sample_size=sample_size,
                                                  delta=delta))
                        
print("\n".join("{}\t{}".format(k, v) for k, v in bounds_dict.items()))

if wandb_log:
    wandb.log(bounds_dict)
            
with open(os.path.join(best_checkpoint_path, f'bounds_levels{levels}_iters{max_quant_iters}.yml'), 'w') as f:
                        yaml.safe_dump(bounds_dict, f, indent=2)
        

        

