import os
import time
import math
import pickle
from contextlib import nullcontext

import numpy as np
import torch
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.distributed import init_process_group, destroy_process_group

from model import GPTConfig, GPT
import loralib as lora
import datetime
import itertools
from projectors import create_intrinsic_model
import bounds.quantize_fns as quantize
import bounds.get_pac_bounds as get_bounds

from torch.optim import SGD, Adam
from tqdm.auto import tqdm

import projectors

# -----------------------------------------------------------------------------
# default config values designed to train a gpt2 (124M) on OpenWebText
# I/O
out_dir = '[TODO]'

create_new_output_dir = True

eval_interval = 500
log_interval = 1
eval_iters = 200
eval_only = False # if True, script exits right after the first eval
always_save_checkpoint = True # if True, always save a checkpoint after each eval
init_from = 'scratch' # 'scratch' or 'resume' or 'gpt2*'
eval_metrics_after_training = False # if True, evaluate metrics for LLM pretraining bounds
best_checkpoint_path = None
# wandb logging
wandb_log = False # disabled by default
wandb_project = 'owt'
wandb_run_name = 'gpt2' # 'run' + str(time.time())
# data
dataset = 'openwebtext'
gradient_accumulation_steps = 5 * 8 # used to simulate larger batch sizes
batch_size = 12 # if gradient_accumulation_steps > 1, this is the micro-batch size
block_size = 1024
# model
n_layer = 12
n_head = 12
n_embd = 768
dropout = 0.0 # for pretraining 0 is good, for finetuning try 0.1+
bias = False # do we use bias inside LayerNorm and Linear layers?
use_mergedlinear = False
# adamw optimizer
learning_rate = 6e-4 # max learning rate
max_iters = 600000 # total number of training iterations
weight_decay = 1e-1
beta1 = 0.9
beta2 = 0.95
grad_clip = 1.0 # clip gradients at this value, or disable if == 0.0
correct_bias = False
adam_epislon = 1e-8
no_decay_bias = True
# learning rate decay settings
decay_lr = True # whether to decay the learning rate
warmup_iters = 2000 # how many steps to warm up for
lr_decay_iters = 600000 # should be ~= max_iters per Chinchilla
min_lr = 6e-5 # minimum learning rate, should be ~= learning_rate/10 per Chinchilla
# TODO: check lora setting

# ===== LoRA Settings ===== #
# 0. Basics
use_lora=False # true if any LoRA layer is used
lora_alpha = 32
lora_dropout = 0.1
# fan_in_fan_out=True
# merge_weights=False

# 1. attention linear layer
attention_linear_use_lora = False
attention_linear_lora_r = 1
# attention_linear_enable_lora=(True, False, True)

# 2. linear head
linear_head_lora_r = 1
linear_head_enable_lora = False

# 3. MLP
MLP_lora_r = 1
MLP_enable_lora = False

# 4. token embedding
token_embedding_lora_r = 1
token_embedding_enable_lora = False

# 5. positional embedding
positional_embedding_lora_r = 1
positional_embedding_enable_lora = False

intrinsic_dim=100000
levels = 17 ### Make sure this is odd so that zero is included
use_kmeans=False
max_quant_iters = 0
quant_lr=5e-5

################ 1. Getting the config ###################

# DDP settings
backend = 'nccl' # 'nccl', 'gloo', etc.
# system
device = 'cuda' # examples: 'cpu', 'cuda', 'cuda:0', 'cuda:1' etc., or try 'mps' on macbooks
dtype = 'bfloat16' if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else 'float16' # 'float32', 'bfloat16', or 'float16', the latter will auto implement a GradScaler
compile = True # use PyTorch 2.0 to compile the model to be faster
# -----------------------------------------------------------------------------
config_keys = [k for k,v in globals().items() if not k.startswith('_') and isinstance(v, (int, float, bool, str, list))]
exec(open('configurator.py').read()) # overrides from command line or config file
config = {k: globals()[k] for k in config_keys} # will be useful for logging

ddp = False
ddp_rank = 0
master_process = True
seed_offset = 0
ddp_world_size = 1
tokens_per_iter = gradient_accumulation_steps * ddp_world_size * batch_size * block_size
print(f"tokens per iteration will be: {tokens_per_iter:,}")

# ? creating new output directory
wandb_run_name = "proj_id{}_lr{}_r{}".format(config["intrinsic_dim"],
                                        config["learning_rate"],
                                        config["linear_head_lora_r"],
                                       )
config["wandb_run_name"] = wandb_run_name

### Change lora config here to train without lora if the rank for both attention and head = 0 

if attention_linear_lora_r == 0:
    attention_linear_use_lora = False
    config["attention_linear_use_lora"] = attention_linear_use_lora
    
if linear_head_lora_r == 0:
    linear_head_enable_lora = False
    config["linear_head_enable_lora"] = linear_head_enable_lora
    
if not (attention_linear_use_lora or linear_head_enable_lora or MLP_enable_lora or token_embedding_enable_lora or positional_embedding_enable_lora):
    use_lora = False 
    config["use_lora"] = use_lora
#####

# ? creating new output directory
if create_new_output_dir:
    now = datetime.datetime.now()
    formatted_date = now.strftime('%Y-%m-%d')
#     formatted_time = now.strftime('%H-%M-%S')
    formatted_time = now.strftime('%H-%M')
    logging_directory = f'{formatted_date}/{formatted_time}'
    out_dir = os.path.join(out_dir,wandb_run_name, logging_directory)
    
# logging
if wandb_log and master_process:
    import wandb
    wandb.init(project=wandb_project, name=wandb_run_name, config=config)

if master_process:
    os.makedirs(out_dir, exist_ok=True)
# torch.manual_seed(1337 + seed_offset)
torch.manual_seed(137)
torch.backends.cuda.matmul.allow_tf32 = True # allow tf32 on matmul
torch.backends.cudnn.allow_tf32 = True # allow tf32 on cudnn
device_type = 'cuda' if 'cuda' in device else 'cpu' # for later use in torch.autocast
# note: float16 data type will automatically use a GradScaler
ptdtype = {'float32': torch.float32, 'bfloat16': torch.bfloat16, 'float16': torch.float16}[dtype]
ctx = nullcontext() if device_type == 'cpu' else torch.amp.autocast(device_type=device_type, dtype=ptdtype)


################ 2. Getting the data ###################


# poor man's data loader
dataset_dir = '[TODO]'

# poor man's data loader
data_dir = os.path.join(dataset_dir, dataset)
train_data = np.memmap(os.path.join(data_dir, 'train.bin'), dtype=np.uint16, mode='r')
val_data = np.memmap(os.path.join(data_dir, 'val.bin'), dtype=np.uint16, mode='r')


def get_batch(split, ix=None):
    data = train_data if split == 'train' else val_data
    ix = torch.randint(len(data) - block_size, (batch_size,))
    x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in ix])
    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    else:
        x, y = x.to(device), y.to(device)
    return x, y, ix

# init these up here, can override if init_from='resume' (i.e. from a checkpoint)
iter_num = 0
best_val_loss = 1e9

# attempt to derive vocab_size from the dataset
meta_path = os.path.join(data_dir, 'meta.pkl')
meta_vocab_size = None
if os.path.exists(meta_path):
    with open(meta_path, 'rb') as f:
        meta = pickle.load(f)
    meta_vocab_size = meta['vocab_size']
    print(f"found vocab_size = {meta_vocab_size} (inside {meta_path})")
    
################ 3. Getting the model ###################

training_mode = None

if intrinsic_dim == 0:
    if attention_linear_lora_r == 0:
        training_mode = "no_lora_no_id"
    else:
        training_mode = "lora_no_id"
        
else:
    if attention_linear_lora_r == 0:
        training_mode = "no_lora_id"
    else:
        training_mode = "lora_id"
        
### Change lora config here to train without lora if the rank for both attention and head = 0 

if attention_linear_lora_r == 0:
    attention_linear_use_lora = False
    config["attention_linear_use_lora"] = attention_linear_use_lora
    
if linear_head_lora_r == 0:
    linear_head_enable_lora = False
    config["linear_head_enable_lora"] = linear_head_enable_lora
    
if not (attention_linear_use_lora or linear_head_enable_lora or MLP_enable_lora or token_embedding_enable_lora or positional_embedding_enable_lora):
    use_lora = False 
    config["use_lora"] = use_lora
#####



# model init
model_args = dict(n_layer=n_layer, n_head=n_head, n_embd=n_embd, block_size=block_size,
                  bias=bias, vocab_size=None, dropout=dropout,
                  use_lora=use_lora, lora_alpha=lora_alpha, lora_dropout=lora_dropout,
                  attention_linear_use_lora=attention_linear_use_lora, attention_linear_lora_r=attention_linear_lora_r, # attention_linear_enable_lora=attention_linear_enable_lora,
                  linear_head_lora_r=linear_head_lora_r, linear_head_enable_lora=linear_head_enable_lora,
                  MLP_lora_r = MLP_lora_r, MLP_enable_lora = MLP_enable_lora,
                  token_embedding_lora_r=token_embedding_lora_r, token_embedding_enable_lora=token_embedding_enable_lora,
                  positional_embedding_lora_r=positional_embedding_lora_r, positional_embedding_enable_lora=positional_embedding_enable_lora,
                  use_mergedlinear=use_mergedlinear,
                  ) # start with model_args from command line


            
print(f"loading best training checkpoint from {best_checkpoint_path} for pretraining bound metrics eval")

ckpt_path = os.path.join(best_checkpoint_path, "best_ckpt.pt")
checkpoint = torch.load(ckpt_path, map_location=device)
checkpoint_model_args = checkpoint['model_args']
# force these config attributes to be equal otherwise we can't even do eval after training
# the rest of the attributes (e.g. dropout) can stay as desired from command line
for k in ['n_layer', 'n_head', 'n_embd', 'block_size', 'bias', 'vocab_size', 'use_lora', 'lora_alpha', 'lora_dropout', 'attention_linear_use_lora', 'attention_linear_lora_r', 'linear_head_lora_r', 'linear_head_enable_lora', 'MLP_lora_r', 'MLP_enable_lora', 'token_embedding_lora_r', 'token_embedding_enable_lora', 'positional_embedding_lora_r', 'positional_embedding_enable_lora']:
    model_args[k] = checkpoint_model_args[k]

# create the model
gptconf = GPTConfig(**model_args)
model = GPT(gptconf)

if use_lora: 
    lora.mark_only_lora_as_trainable(model)

#### creating the ID model and loading the subspace parameters + names + initparams 

if intrinsic_dim > 0:
    
    #### loading the random initialization of all the weights 
    init_ckpt_path = os.path.join(best_checkpoint_path, "forward_ckpt_at_random_initialization.pt")
    init_checkpoint = torch.load(init_ckpt_path, map_location=device)

    # fix the keys of the state dictionary :(
    # honestly no idea how checkpoints sometimes get this prefix, have to debug more
    unwanted_prefix = '_orig_mod.'
    for k,v in list(init_checkpoint.items()):
        if k.startswith(unwanted_prefix):
            init_checkpoint[k[len(unwanted_prefix):]] = init_checkpoint.pop(k)

    model.load_state_dict(init_checkpoint)

    
    model = create_intrinsic_model(base_net=model,
                                   ckpt_path=None,
                                   intrinsic_mode="rdkronqr",
                                   intrinsic_dim=intrinsic_dim,
                                   seed=137,
                                   device=device,)

state_dict = checkpoint['raw_model']

# fix the keys of the state dictionary :(
# honestly no idea how checkpoints sometimes get this prefix, have to debug more
unwanted_prefix = '_orig_mod.'
for k,v in list(state_dict.items()):
    if k.startswith(unwanted_prefix):
        state_dict[k[len(unwanted_prefix):]] = state_dict.pop(k)
        
if intrinsic_dim > 0:
    if "subspace_params" in state_dict:
        model.load_state_dict(state_dict)
    else:
        tmp = {}
        tmp["subspace_params"] = weights["module.subspace_params"]
        model.load_state_dict(tmp)

    model.trainable_initparams = torch.load(os.path.join(best_checkpoint_path, "trainable_initparams.pt"), map_location=device)
    model.names = torch.load(os.path.join(best_checkpoint_path, "names.pt"))
    
else:
    model.load_state_dict(state_dict)


iter_num = checkpoint['iter_num']
best_val_loss = checkpoint['best_val_loss']

model.to(device)

# initialize a GradScaler. If enabled=False scaler is a no-op
scaler = torch.cuda.amp.GradScaler(enabled=(dtype == 'float16'))

optimizer = model.configure_optimizers(weight_decay, learning_rate, (beta1, beta2), device_type, correct_bias, adam_epislon, no_decay_bias)

checkpoint = None # free up memory


# wrap model into DDP container
if ddp:
    if use_lora:
        model = DDP(model, device_ids=[ddp_local_rank], find_unused_parameters=True)
    else:
        model = DDP(model, device_ids=[ddp_local_rank])

if use_lora:
    if intrinsic_dim == 0:
        lora.mark_only_lora_as_trainable(model)
if ddp:
    print("number of parameters: %.2fM" % (model.module.get_num_params()/1e6,))
    print("number of trainable parameters: %.2f" % (model.module.get_num_params(only_trainable=True),))
else:
    print("number of parameters: %.2fM" % (model.get_num_params()/1e6,))
    print("number of trainable parameters: %.2f" % (model.get_num_params(only_trainable=True),))


print("\n# === final trainable parameters === #\n")
for n, p in model.named_parameters():
    if p.requires_grad:
        print(n)
print("\n# === final trainable parameters === #\n")


################ 4. Defining some utils for later .. ###################

# helps estimate an arbitrarily accurate loss over either split using many batches
@torch.no_grad()
def estimate_loss():
    out = {}
    model.eval()
    for split in ['train', 'val']:
        losses = torch.zeros(eval_iters)
        for k in range(eval_iters):
            X, Y, ix = get_batch(split)
            
            if intrinsic_dim == 0:
                with ctx:
                    logits, loss = model(X, Y)
            else:
                logits, loss = model(X, Y)
            losses[k] = loss.item()
            
        out[split] = losses.mean()
    model.train()
    return out
    

################ [PENDING] 5. Evaluation of the model without the quantized weights ###################

eval_iters=50

losses = estimate_loss()

print("EVALUATING THE MODEL BEFORE QUANTIZATION")

print(f"step {iter_num}: train loss {losses['train']:.4f}, val loss {losses['val']:.4f}")


################ 6. Quantization ###################


if max_quant_iters > 0 and intrinsic_dim > 0:
    vector = model.subspace_params.cpu().data.numpy()
    cluster_fn = quantize.get_random_symbols_and_codebook
    if use_kmeans:
        cluster_fn = quantize.get_kmeans_symbols_and_codebook
    _, centroids = cluster_fn(vector, levels=levels, codebook_dtype=np.float16)
    centroids = torch.tensor(centroids, dtype=torch.float32)
    centroids = centroids.to(device)
    quantizer_fn = quantize.Quantize().apply
    qw = quantize.QuantizingWrapper(model, quantizer=quantizer_fn, centroids=centroids)
    optim = SGD(
        [qw.subspace_params, qw.centroids],
        lr = quant_lr, momentum=0.9)

    for e in tqdm(range(max_quant_iters)):
        qw.train()
        optim.zero_grad()
        X, Y, ix = get_batch('train')
        logits, loss = qw(X, Y)
        loss.backward()
        optim.step()
        if e % 10 == 0:
            metrics = {"iter": e, "ix": ix, "mini_loss": loss.detach().item()}
            print(metrics)
    quantized_vec = qw.quantizer(qw.subspace_params, qw.centroids)
    quantized_vec = quantized_vec.cpu().detach().numpy()
    vec = (qw.centroids.unsqueeze(-2) - qw.subspace_params.unsqueeze(-1))**2.0
    symbols = torch.min(vec, -1)[-1]
    symbols = symbols.cpu().detach().numpy()
    centroids = qw.centroids.cpu().detach().numpy()
    # centroids = centroids.astype(np.float16)
    probabilities = np.array([np.mean(symbols == i) for i in range(levels)])
    _, coded_symbols_size = quantize.do_arithmetic_encoding(symbols, probabilities,
                                                   qw.centroids.shape[0])
    message_len = quantize.get_message_len(
        coded_symbols_size=coded_symbols_size,
        codebook=centroids,
        max_count=len(symbols),
    )
else:
    if intrinsic_dim > 0:
        module = model.module if isinstance(model,
                                        torch.nn.parallel.DistributedDataParallel) else model
        vector = module.subspace_params.cpu().data.numpy()
        quantized_vec, message_len = quantize.quantize_vector(vector, levels=levels, use_kmeans=use_kmeans)
    else:
        aux = [(n, p) for n, p in model.named_parameters() if p.requires_grad]
        names, vector = zip(*aux)
        fvector = projectors.flatten(vector).cpu().data.numpy()
        quantized_vec, message_len = quantize.quantize_vector(fvector, levels=levels, use_kmeans=use_kmeans)
        ## free memory 
        fvector = None 
        

if intrinsic_dim > 0:
    module = model.module if ddp else model
    module.subspace_params.data = torch.tensor(quantized_vec).float().to(device)
else:
    unfquantized_vec = projectors.unflatten_like(torch.tensor(quantized_vec), vector)
    ## free memory  
    quantized_vec, vector = None, None
    for n, p in model.named_parameters():
        for name, quantp in zip(names, unfquantized_vec):
            if n == name:
                p.data = torch.tensor(quantp).float().to(device)
        
prefix_message_len = message_len + 2 * np.log2(message_len) if message_len > 0 else 0
    
################ 7. Evaluation of the model with the quantized weights ###################

losses = estimate_loss()

print("EVALUATING THE MODEL AFTER QUANTIZATION")

print(f"step {iter_num}: train loss {losses['train']:.4f}, val loss {losses['val']:.4f}")

# breakpoint()


################ 8. Saving everything for the bound computation ###################

raw_model = model.module if ddp else model # unwrap DDP container if needed

if use_lora:
    raw_model_state_dict = raw_model.state_dict()
    lora_state_dict = lora.lora_state_dict(model)
else:
    raw_model_state_dict = raw_model.state_dict()
    lora_state_dict = None

checkpoint = {
    'raw_model': raw_model_state_dict,
    'lora_model': lora_state_dict,
    'optimizer': None,
    'model_args': model_args,
    'iter_num': iter_num,
    'best_val_loss': None,
    'config': config,
    'prefix_message_len': prefix_message_len, 
}
print(f"saving checkpoint to {out_dir}")

torch.save(checkpoint, os.path.join(best_checkpoint_path, f'quant_ckpt_levels{levels}_iters{max_quant_iters}.pt'))
