"""
This training script can be run both on a single gpu in debug mode,
and also in a larger training run with distributed data parallel (ddp).

To run on a single GPU, example:
$ python train.py --batch_size=32 --compile=False

To run with DDP on 4 gpus on 1 node, example:
$ torchrun --standalone --nproc_per_node=4 train.py

To run with DDP on 4 gpus across 2 nodes, example:
- Run on the first (master) node with example IP 123.456.123.456:
$ torchrun --nproc_per_node=8 --nnodes=2 --node_rank=0 --master_addr=123.456.123.456 --master_port=1234 train.py
- Run on the worker node:
$ torchrun --nproc_per_node=8 --nnodes=2 --node_rank=1 --master_addr=123.456.123.456 --master_port=1234 train.py
(If your cluster does not have Infiniband interconnect prepend NCCL_IB_DISABLE=1)
"""

import os
import time
import math
import pickle
from contextlib import nullcontext

import numpy as np
import torch
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.distributed import init_process_group, destroy_process_group

from model import GPTConfig, GPT
import loralib as lora
import datetime
import itertools
from projectors import create_intrinsic_model

# -----------------------------------------------------------------------------
# default config values designed to train a gpt2 (124M) on OpenWebText
# I/O
out_dir = 'out'


create_new_output_dir = True

eval_interval = 500
log_interval = 1
eval_iters = 200
eval_only = False # if True, script exits right after the first eval
always_save_checkpoint = True # if True, always save a checkpoint after each eval
init_from = 'scratch' # 'scratch' or 'resume' or 'gpt2*'
eval_metrics_after_training = False # if True, evaluate metrics for LLM pretraining bounds
best_checkpoint_path = None
# wandb logging
wandb_log = False # disabled by default
wandb_project = 'owt'
wandb_run_name = 'gpt2' # 'run' + str(time.time())
# data
dataset = 'openwebtext'
gradient_accumulation_steps = 5 * 8 # used to simulate larger batch sizes
batch_size = 12 # if gradient_accumulation_steps > 1, this is the micro-batch size
block_size = 1024
# model
n_layer = 12
n_head = 12
n_embd = 768
dropout = 0.0 # for pretraining 0 is good, for finetuning try 0.1+
bias = False # do we use bias inside LayerNorm and Linear layers?
use_mergedlinear = False
# adamw optimizer
learning_rate = 6e-4 # max learning rate
max_iters = 600000 # total number of training iterations
weight_decay = 1e-1
beta1 = 0.9
beta2 = 0.95
grad_clip = 1.0 # clip gradients at this value, or disable if == 0.0
correct_bias = False
adam_epislon = 1e-8
no_decay_bias = True
# learning rate decay settings
decay_lr = True # whether to decay the learning rate
warmup_iters = 2000 # how many steps to warm up for
lr_decay_iters = 600000 # should be ~= max_iters per Chinchilla
min_lr = 6e-5 # minimum learning rate, should be ~= learning_rate/10 per Chinchilla
# TODO: check lora setting

# ===== LoRA Settings ===== #
# 0. Basics
use_lora=False # true if any LoRA layer is used
lora_alpha = 32
lora_dropout = 0.1
# fan_in_fan_out=True
# merge_weights=False

# 1. attention linear layer
attention_linear_use_lora = False
attention_linear_lora_r = 1
# attention_linear_enable_lora=(True, False, True)

# 2. linear head
linear_head_lora_r = 1
linear_head_enable_lora = False

# 3. MLP
MLP_lora_r = 1
MLP_enable_lora = False

# 4. token embedding
token_embedding_lora_r = 1
token_embedding_enable_lora = False

# 5. positional embedding
positional_embedding_lora_r = 1
positional_embedding_enable_lora = False

intrinsic_dim=100000

# sentence perturbation
perturb_word_order_window_size=0

# poor man's data loader
dataset_dir = '[TODO]'


# DDP settings
backend = 'nccl' # 'nccl', 'gloo', etc.
# system
device = 'cuda' # examples: 'cpu', 'cuda', 'cuda:0', 'cuda:1' etc., or try 'mps' on macbooks
dtype = 'bfloat16' if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else 'float16' # 'float32', 'bfloat16', or 'float16', the latter will auto implement a GradScaler
compile = True # use PyTorch 2.0 to compile the model to be faster
# -----------------------------------------------------------------------------
config_keys = [k for k,v in globals().items() if not k.startswith('_') and isinstance(v, (int, float, bool, str, list))]
exec(open('configurator.py').read()) # overrides from command line or config file
config = {k: globals()[k] for k in config_keys} # will be useful for logging
# -----------------------------------------------------------------------------
# various inits, derived attributes, I/O setup
ddp = int(os.environ.get('RANK', -1)) != -1 # is this a ddp run?
if ddp:
    init_process_group(backend=backend)
    ddp_rank = int(os.environ['RANK'])
    ddp_local_rank = int(os.environ['LOCAL_RANK'])
    ddp_world_size = int(os.environ['WORLD_SIZE'])
    device = f'cuda:{ddp_local_rank}'
    torch.cuda.set_device(device)
    master_process = ddp_rank == 0 # this process will do logging, checkpointing etc.
    seed_offset = ddp_rank # each process gets a different seed
    # world_size number of processes will be training simultaneously, so we can scale
    # down the desired gradient accumulation iterations per process proportionally
    assert gradient_accumulation_steps % ddp_world_size == 0
    gradient_accumulation_steps //= ddp_world_size
else:
    # if not ddp, we are running on a single gpu, and one process
    ddp_rank = 0
    master_process = True
    seed_offset = 0
    ddp_world_size = 1
tokens_per_iter = gradient_accumulation_steps * ddp_world_size * batch_size * block_size
print(f"tokens per iteration will be: {tokens_per_iter:,}")

# ? creating new output directory
wandb_run_name = "proj_id{}_lr{}_r{}_pertw{}".format(config["intrinsic_dim"],
                                                     config["learning_rate"],
                                                     config["linear_head_lora_r"],
                                                     config["perturb_word_order_window_size"],)
config["wandb_run_name"] = wandb_run_name


### Change lora config here to train without lora if the rank for both attention and head = 0 

if attention_linear_lora_r == 0:
    attention_linear_use_lora = False
    config["attention_linear_use_lora"] = attention_linear_use_lora
    
if linear_head_lora_r == 0:
    linear_head_enable_lora = False
    config["linear_head_enable_lora"] = linear_head_enable_lora
    
if not (attention_linear_use_lora or linear_head_enable_lora or MLP_enable_lora or token_embedding_enable_lora or positional_embedding_enable_lora):
    use_lora = False 
    config["use_lora"] = use_lora
#####

# logging
if wandb_log and master_process:
    import wandb
    wandb.init(project=wandb_project, name=wandb_run_name, config=config)

# ? creating new output directory
if create_new_output_dir:
    now = datetime.datetime.now()
    formatted_date = now.strftime('%Y-%m-%d')
#     formatted_time = now.strftime('%H-%M-%S')
    formatted_time = now.strftime('%H-%M')
    logging_directory = f'{formatted_date}/{formatted_time}'
    out_dir = os.path.join(out_dir,wandb_run_name, logging_directory)

if master_process:
    os.makedirs(out_dir, exist_ok=True)
    
       
torch.manual_seed(137)
# torch.manual_seed(1337 + seed_offset)
torch.backends.cuda.matmul.allow_tf32 = True # allow tf32 on matmul
torch.backends.cudnn.allow_tf32 = True # allow tf32 on cudnn
device_type = 'cuda' if 'cuda' in device else 'cpu' # for later use in torch.autocast
# note: float16 data type will automatically use a GradScaler
ptdtype = {'float32': torch.float32, 'bfloat16': torch.bfloat16, 'float16': torch.float16}[dtype]
ctx = nullcontext() if device_type == 'cpu' else torch.amp.autocast(device_type=device_type, dtype=ptdtype)


# poor man's data loader
data_dir = os.path.join(dataset_dir, dataset)
train_data = np.memmap(os.path.join(data_dir, 'train.bin'), dtype=np.uint16, mode='r')
val_data = np.memmap(os.path.join(data_dir, 'val.bin'), dtype=np.uint16, mode='r')

def get_batch(
        split, 
        perturb_word_order_window_size=0, # 10 or 1024
        perturb_word_repeat=False, 
        perturb_word_repeat_counts=10, 
        perturb_verb_tense=False
    ):
    data = train_data if split == 'train' else val_data
    ix = torch.randint(len(data) - block_size, (batch_size,))

    newx = torch.stack([torch.from_numpy((data[i:i+1+block_size]).astype(np.int64)) for i in ix])
    
    if perturb_word_order_window_size > 1:
        for i, batch_i in enumerate(newx):
            if perturb_word_order_window_size==1024:
                # 100% shuffling
                newx[i] = newx[i][torch.randperm(len(newx[i]))]
            elif perturb_word_order_window_size < 1024:
                # shuffling within window size of 10
                num_of_windows = block_size // perturb_word_order_window_size
                counter_i = 0
                while counter_i < num_of_windows:
                    sequence_segment = newx[i][counter_i*perturb_word_order_window_size:(counter_i+1)*perturb_word_order_window_size]
                    shuffled_indices = torch.randperm(perturb_word_order_window_size)
                    shuffled_sequence_segment = sequence_segment[shuffled_indices]
                    newx[i][counter_i*perturb_word_order_window_size:(counter_i+1)*perturb_word_order_window_size] = shuffled_sequence_segment
                    counter_i += 1
            
            else:
                raise ValueError
                
    x = newx[:,:-1]
    y = newx[:,1:]
    
    if perturb_word_repeat:
        raise NotImplementedError
        
    if perturb_verb_tense:
        raise NotImplementedError

    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    else:
        x, y = x.to(device), y.to(device)
    return x, y, ix

def get_batch_from_indices(split, lst_of_indices):
    data = train_data if split == 'train' else val_data
    x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in lst_of_indices])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in lst_of_indices])
    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    else:
        x, y = x.to(device), y.to(device)
    return x, y

def get_batch_sequential(split, ddp_rank, ddp_world_size, curr_iter_i, batch_size):
    data = train_data if split == 'train' else val_data
    ix = torch.arange((curr_iter_i*ddp_world_size+ddp_rank)*block_size*batch_size, (curr_iter_i*ddp_world_size+ddp_rank+1)*block_size*batch_size, block_size)
    x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in ix])
    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    else:
        x, y = x.to(device), y.to(device)
    return x, y, ix

iter_num = 0
best_val_loss = 1e9

# attempt to derive vocab_size from the dataset
meta_path = os.path.join(data_dir, 'meta.pkl')
meta_vocab_size = None
if os.path.exists(meta_path):
    with open(meta_path, 'rb') as f:
        meta = pickle.load(f)
    meta_vocab_size = meta['vocab_size']
    print(f"found vocab_size = {meta_vocab_size} (inside {meta_path})")

# model init
model_args = dict(n_layer=n_layer, n_head=n_head, n_embd=n_embd, block_size=block_size,
                  bias=bias, vocab_size=None, dropout=dropout,
                  use_lora=use_lora, lora_alpha=lora_alpha, lora_dropout=lora_dropout,
                  attention_linear_use_lora=attention_linear_use_lora, attention_linear_lora_r=attention_linear_lora_r, # attention_linear_enable_lora=attention_linear_enable_lora,
                  linear_head_lora_r=linear_head_lora_r, linear_head_enable_lora=linear_head_enable_lora,
                  MLP_lora_r = MLP_lora_r, MLP_enable_lora = MLP_enable_lora,
                  token_embedding_lora_r=token_embedding_lora_r, token_embedding_enable_lora=token_embedding_enable_lora,
                  positional_embedding_lora_r=positional_embedding_lora_r, positional_embedding_enable_lora=positional_embedding_enable_lora,
                  use_mergedlinear=use_mergedlinear,
                  ) # start with model_args from command line

if init_from == 'scratch':
    # init a new model from scratch
    print("Initializing a new model from scratch")
    # determine the vocab size we'll use for from-scratch training
    if meta_vocab_size is None:
        print("defaulting to vocab_size of GPT-2 to 50304 (50257 rounded up for efficiency)")
    model_args['vocab_size'] = meta_vocab_size if meta_vocab_size is not None else 50304
    gptconf = GPTConfig(**model_args)
    model = GPT(gptconf)
    
    if master_process:
        torch.save(model.state_dict(), os.path.join(out_dir, 'forward_ckpt_at_random_initialization.pt'))
    
    print("INTRINSIC DIM IS: ", intrinsic_dim)
    
    if block_size < model.config.block_size:
        model._forward_net[0].crop_block_size(block_size)
        model_args['block_size'] = block_size # so that the checkpoint will have the right value
    
    if intrinsic_dim > 0:
        
        if use_lora:
            lora.mark_only_lora_as_trainable(model)
    
        model = create_intrinsic_model(base_net=model,
                                          ckpt_path=None,
                                          intrinsic_mode="rdkronqr",
                                          intrinsic_dim=intrinsic_dim,
                                          seed=137,
                                          device=device,)
            
elif init_from == 'eval_after_training':
    if best_checkpoint_path == 'gpt2':
        print(f"Initializing from OpenAI GPT-2 weights for pretraining bound metrics eval: {init_from}")
        # initialize from OpenAI GPT-2 weights
        override_args = dict(dropout=dropout)
        model = GPT.from_pretrained(best_checkpoint_path, override_args, use_mergedlinear=use_mergedlinear)
        # read off the created config params, so we can store them into checkpoint correctly
        for k in ['n_layer', 'n_head', 'n_embd', 'block_size', 'bias', 'vocab_size']:
            model_args[k] = getattr(model.config, k)
    else:
        print(f"loading best training checkpoint from {best_checkpoint_path} for pretraining bound metrics eval")
        # ckpt_path = os.path.join(best_checkpoint_path, 'best_ckpt.pt')
        ckpt_path = os.path.join(best_checkpoint_path, ckpt_name)
        checkpoint = torch.load(ckpt_path, map_location=device)
        checkpoint_model_args = checkpoint['model_args']
        # force these config attributes to be equal otherwise we can't even do eval after training
        # the rest of the attributes (e.g. dropout) can stay as desired from command line
        for k in ['n_layer', 'n_head', 'n_embd', 'block_size', 'bias', 'vocab_size', 'use_lora', 'lora_alpha', 'lora_dropout', 'attention_linear_use_lora', 'attention_linear_lora_r', 'linear_head_lora_r', 'linear_head_enable_lora', 'MLP_lora_r', 'MLP_enable_lora', 'token_embedding_lora_r', 'token_embedding_enable_lora', 'positional_embedding_lora_r', 'positional_embedding_enable_lora']:
            model_args[k] = checkpoint_model_args[k]
        
        # create the model
        gptconf = GPTConfig(**model_args)
        model = GPT(gptconf)
        
        state_dict = checkpoint['raw_model']
        # fix the keys of the state dictionary :(
        # honestly no idea how checkpoints sometimes get this prefix, have to debug more
        unwanted_prefix = '_orig_mod.'
        for k,v in list(state_dict.items()):
            if k.startswith(unwanted_prefix):
                state_dict[k[len(unwanted_prefix):]] = state_dict.pop(k)

        model.load_state_dict(state_dict)
        iter_num = checkpoint['iter_num']
        best_val_loss = checkpoint['best_val_loss']
elif init_from == 'resume':
    print(f"Resuming training from {out_dir}")
    # resume training from a checkpoint.
    ckpt_path = os.path.join(out_dir, 'ckpt.pt')
    checkpoint = torch.load(ckpt_path, map_location=device)
    checkpoint_model_args = checkpoint['model_args']
    # force these config attributes to be equal otherwise we can't even resume training
    # the rest of the attributes (e.g. dropout) can stay as desired from command line
    for k in ['n_layer', 'n_head', 'n_embd', 'block_size', 'bias', 'vocab_size']:
        model_args[k] = checkpoint_model_args[k]
    # create the model
    gptconf = GPTConfig(**model_args)
    model = GPT(gptconf)
    state_dict = checkpoint['model']
    # fix the keys of the state dictionary :(
    # honestly no idea how checkpoints sometimes get this prefix, have to debug more
    unwanted_prefix = '_orig_mod.'
    for k,v in list(state_dict.items()):
        if k.startswith(unwanted_prefix):
            state_dict[k[len(unwanted_prefix):]] = state_dict.pop(k)
    model.load_state_dict(state_dict)
    iter_num = checkpoint['iter_num']
    best_val_loss = checkpoint['best_val_loss']
elif init_from.startswith('gpt2'):
    print(f"Initializing from OpenAI GPT-2 weights: {init_from}")
    # initialize from OpenAI GPT-2 weights
    override_args = dict(dropout=dropout)
    model = GPT.from_pretrained(init_from, override_args)
    # read off the created config params, so we can store them into checkpoint correctly
    for k in ['n_layer', 'n_head', 'n_embd', 'block_size', 'bias', 'vocab_size']:
        model_args[k] = getattr(model.config, k)
# crop down the model block size if desired, using model surgery

if intrinsic_dim == 0:
    if block_size < model.config.block_size:
        model._forward_net[0].crop_block_size(block_size)
        model_args['block_size'] = block_size # so that the checkpoint will have the right value

if master_process:
    if not eval_metrics_after_training:
        torch.save(model.state_dict(), os.path.join(out_dir, 'ckpt_at_random_initialization.pt'))
    if intrinsic_dim > 0:
        torch.save(model.trainable_initparams, os.path.join(out_dir, 'trainable_initparams.pt'))
        torch.save(model.names, os.path.join(out_dir, 'names.pt'))

model.to(device)

# initialize a GradScaler. If enabled=False scaler is a no-op
scaler = torch.cuda.amp.GradScaler(enabled=(dtype == 'float16'))


optimizer = model.configure_optimizers(weight_decay, learning_rate, (beta1, beta2), device_type, correct_bias, adam_epislon, no_decay_bias)

if init_from == 'resume':
    optimizer.load_state_dict(checkpoint['optimizer'])
checkpoint = None # free up memory

# compile the model
# TODO: check compatibility between torch.compile with LoRA. 
# Skip it for intrinsic dimensionality too 
if compile and (not use_lora) and intrinsic_dim == 0:
    print("compiling the model... (takes a ~minute)")
    unoptimized_model = model
    model = torch.compile(model) # requires PyTorch 2.0

# wrap model into DDP container
if ddp:
    if use_lora:
        model = DDP(model, device_ids=[ddp_local_rank], find_unused_parameters=True)
    else:
        model = DDP(model, device_ids=[ddp_local_rank])

if use_lora:
    if intrinsic_dim == 0:
        lora.mark_only_lora_as_trainable(model)

if ddp:
    total_num_params = int(model.module.get_num_params())
    total_lora_params = int(model.module.get_num_params(only_trainable=True))
    print("number of parameters: %.2fM" % (model.module.get_num_params()/1e6,))
    print("number of trainable parameters: %.2f" % (model.module.get_num_params(only_trainable=True),))
else:
    total_num_params = int(model.get_num_params())
    total_lora_params = int(model.get_num_params(only_trainable=True))
    print("number of parameters: %.2fM" % (model.get_num_params()/1e6,))
    print("number of trainable parameters: %.2f" % (model.get_num_params(only_trainable=True),))

print("\n# === final trainable parameters === #\n")
for n, p in model.named_parameters():
    if p.requires_grad:
        print(n)
print("\n# === final trainable parameters === #\n")

if wandb_log and master_process:
    wandb.log({"num_params": total_num_params, "num_lora_params": total_lora_params})

print("TOTAL NUMBER OF PARAMS: ", total_num_params)
print("TOTAL NUMBER OF LORA PARAMS: ", total_lora_params)

def sum_k_elements(row, k_th):
    return torch.sum(row[:k_th+1])

# helps estimate an arbitrarily accurate loss over either split using many batches
@torch.no_grad()
def estimate_loss():
    out = {}
    model.eval()
    for split in ['train', 'val']:
        losses = torch.zeros(eval_iters)
        for k in range(eval_iters):
            X, Y, ix = get_batch(split, perturb_word_order_window_size=perturb_word_order_window_size)
            if intrinsic_dim == 0:
                with ctx:
                    logits, loss = model(X, Y)
            else:
                logits, loss = model(X, Y)
            losses[k] = loss.item()
            
        out[split] = losses.mean()
    model.train()
    return out

# helps estimate an arbitrarily accurate loss over either split using many batches
@torch.no_grad()
def compute_pretrain_bound_metrics(X, Y):
    if intrinsic_dim == 0:
        with ctx:
            logits, loss = model(X, Y)
    else:
        logits, loss = model(X, Y)

    # === for each token, log top-k indice, percentile, and log probability === #
    softmax_matrix = torch.nn.functional.softmax(logits.view(-1, logits.size(-1)),dim=-1)
    sorted_softmax_matrix, indices_softmax_matrix = torch.sort(softmax_matrix, dim=-1, descending=True)
    #torch.cumsum(sorted_softmax_matrix, dim=-1)
    
    # 1. top-k indices
    top_k_indices = torch.argmax((indices_softmax_matrix == Y.view(-1).unsqueeze(1)).long(),dim=-1)
    
    # 2. log probability
    selected_log_prob_scores = torch.log(softmax_matrix[torch.arange(softmax_matrix.shape[0]), Y.view(-1)])
    
    # 3. percentile
    percentile_vec = torch.zeros((sorted_softmax_matrix.shape[0],), device=device)
    for i in range(sorted_softmax_matrix.shape[0]):
        percentile_vec[i] = sum_k_elements(sorted_softmax_matrix[i], top_k_indices[i])
            
    return loss.item(), top_k_indices, selected_log_prob_scores, percentile_vec

# learning rate decay scheduler (cosine with warmup)
def get_lr(it):
    # 1) linear warmup for warmup_iters steps
    if it < warmup_iters:
        return learning_rate * it / warmup_iters
    # 2) if it > lr_decay_iters, return min learning rate
    if it > lr_decay_iters:
        return min_lr
    # 3) in between, use cosine decay down to min learning rate
    decay_ratio = (it - warmup_iters) / (lr_decay_iters - warmup_iters)
    assert 0 <= decay_ratio <= 1
    coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio)) # coeff ranges 0..1
    return min_lr + coeff * (learning_rate - min_lr)




if eval_metrics_after_training:
    model.eval()

    if best_checkpoint_path=='gpt2':
        raise NotImplementedError("focus on the implementation for GPT pretraining with LoRA for now")
    else:
        len_train_data = len(train_data)
        curr_iter_i = 0
        while True:
            X, Y, ix = get_batch_sequential(split='train',ddp_rank=ddp_rank, ddp_world_size=ddp_world_size, curr_iter_i=curr_iter_i, batch_size=batch_size)
            print(f"ix / block_size ={ix/block_size} for curr_iter_i={curr_iter_i} and {batch_size}={batch_size} and ddp_rank={ddp_rank} and ddp_world_size={ddp_world_size}")
            loss, top_k_indices, selected_log_prob_scores, percentile_vec = compute_pretrain_bound_metrics(X, Y)

            # saving all of ix & loss & top-k & log_prob & percentile_vec
            with open(os.path.join(best_checkpoint_path, f'train_indices_{ddp_rank}_ix.txt'), 'a') as file_ix:
                file_ix.write(str(ix.tolist()) + '\n') 
            with open(os.path.join(best_checkpoint_path, f'train_indices_{ddp_rank}_loss.txt'), 'a') as file_loss:
                file_loss.write(str(loss) + '\n') 
            with open(os.path.join(best_checkpoint_path, f'train_indices_{ddp_rank}_top_k_indices.txt'), 'a') as file_top_k_indices:
                file_top_k_indices.write(str(top_k_indices.tolist()) + '\n')  
            with open(os.path.join(best_checkpoint_path, f'train_indices_{ddp_rank}_selected_log_prob_scores.txt'), 'a') as file_selected_log_prob_scores:
                file_selected_log_prob_scores.write(str(selected_log_prob_scores.tolist()) + '\n')  
            with open(os.path.join(best_checkpoint_path, f'train_indices_{ddp_rank}_percentile_vec.txt'), 'a') as file_percentile_vec:
                file_percentile_vec.write(str(percentile_vec.tolist()) + '\n')  

            # compute local batch accuracy
            unique_indices, indices_counts = torch.unique(torch.tensor(top_k_indices),return_counts=True)
            
            wandb_dict_top_k = {}
            for k in range(1,10+1):
                top_k_acc = (sum(indices_counts[0:k])/len(top_k_indices)).item()
                wandb_dict_top_k[f'top_{k}_ddp_rank{ddp_rank}'] = top_k_acc
                
                if curr_iter_i % 10 == 0:
                    print(f"+++++ at iter_num i = {curr_iter_i} +++++")
                    if best_checkpoint_path=='gpt2':
                        print(f"top-{k} accuracy = {top_k_acc} from a local batch of {len(top_k_indices)} tokens (batch_size * sequence length) for {best_checkpoint_path} from huggingface pretrained model\n")
                    else:
                        print(f"top-{k} accuracy = {top_k_acc} from a local batch of {len(top_k_indices)} tokens (batch_size * sequence length) for a model pretrained with {iter_num} iter_num\n")
            top_50_acc = (sum(indices_counts[0:50])/len(top_k_indices)).item()
            wandb_dict_top_k[f'top_50_ddp_rank{ddp_rank}'] = top_50_acc

            top_100_acc = (sum(indices_counts[0:100])/len(top_k_indices)).item()
            wandb_dict_top_k[f'top_100_ddp_rank{ddp_rank}'] = top_100_acc

            if curr_iter_i % 10 == 0:
                if best_checkpoint_path=='gpt2':
                    print(f"top-50 accuracy = {top_50_acc} from a local batch of {len(top_k_indices)} tokens (batch_size * sequence length) for {best_checkpoint_path} from huggingface pretrained model\n")
                    print(f"top-100 accuracy = {top_100_acc} from a local batch of {len(top_k_indices)} tokens (batch_size * sequence length) for {best_checkpoint_path} from huggingface pretrained model\n")
                else:
                    print(f"top-50 accuracy = {top_50_acc} from a local batch of {len(top_k_indices)} tokens (batch_size * sequence length) for a model pretrained with {iter_num} iter_num\n")
                    print(f"top-100 accuracy = {top_100_acc} from a local batch of {len(top_k_indices)} tokens (batch_size * sequence length) for a model pretrained with {iter_num} iter_num\n")
            
            if wandb_log and master_process:
                wandb.log(wandb_dict_top_k)

            curr_iter_i += 1

            if master_process:
                if len_train_data - (curr_iter_i * ddp_world_size * block_size * batch_size) < ddp_world_size * block_size * batch_size:
                    break

        if ddp:
            destroy_process_group()
else:    
    torch.manual_seed(1337 + seed_offset)
    # training loop
    X, Y, ix = get_batch('train', perturb_word_order_window_size=perturb_word_order_window_size) # fetch the very first batch
    print(f"using perturb_word_order_window_size={perturb_word_order_window_size}")
#     with open(os.path.join(out_dir, train_indices_file_path), 'a') as file:
#         file.write(str(ix.tolist()) + '\n')  # Add a newline character to separate lines

    t0 = time.time()
    local_iter_num = 0 # number of iterations in the lifetime of this process
    raw_model = model.module if ddp else model # unwrap DDP container if needed
    running_mfu = -1.0
    while True:

        # determine and set the learning rate for this iteration
        lr = get_lr(iter_num) if decay_lr else learning_rate
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr

        # evaluate the loss on train/val sets and write checkpoints
        if iter_num % eval_interval == 0 and master_process:
            losses = estimate_loss()
            print(f"step {iter_num}: train loss {losses['train']:.4f}, val loss {losses['val']:.4f}")
            if wandb_log:
                wandb.log({
                    "iter": iter_num,
                    "train/loss": losses['train'],
                    "val/loss": losses['val'],
                    "lr": lr,
                    "mfu": running_mfu*100, # convert to percentage
                })
            if losses['val'] < best_val_loss or always_save_checkpoint:
                if losses['val'] < best_val_loss:
                    _best_checkpoint = True
                else:
                    _best_checkpoint = False

                best_val_loss = losses['val']
                if iter_num > 0:
                    # LoRA and conventional training logic
                    if use_lora:
                        raw_model_state_dict = raw_model.state_dict()
                        lora_state_dict = lora.lora_state_dict(model)
                    else:
                        raw_model_state_dict = raw_model.state_dict()
                        lora_state_dict = None

                    checkpoint = {
                        'raw_model': raw_model_state_dict,
                        'lora_model': lora_state_dict,
                        'optimizer': optimizer.state_dict(),
                        'model_args': model_args,
                        'iter_num': iter_num,
                        'best_val_loss': best_val_loss,
                        'config': config,
                    }
                    print(f"saving checkpoint to {out_dir}")
                    
                    if _best_checkpoint:
                        torch.save(checkpoint, os.path.join(out_dir, f'best_ckpt.pt'))
                    else:
                        torch.save(checkpoint, os.path.join(out_dir, f'ckpt_{iter_num}.pt'))
        if iter_num == 0 and eval_only:
            break

        # forward backward update, with optional gradient accumulation to simulate larger batch size
        # and using the GradScaler if data type is float16
        for micro_step in range(gradient_accumulation_steps):
            if ddp:
                # in DDP training we only need to sync gradients at the last micro step.
                # the official way to do this is with model.no_sync() context manager, but
                # I really dislike that this bloats the code and forces us to repeat code
                # looking at the source of that context manager, it just toggles this variable
                model.require_backward_grad_sync = (micro_step == gradient_accumulation_steps - 1)
            if intrinsic_dim == 0:
                with ctx:
                    logits, loss = model(X, Y)
                    loss = loss / gradient_accumulation_steps # scale the loss to account for gradient accumulation
                # immediately async prefetch next batch while model is doing the forward pass on the GPU
            else:
                logits, loss = model(X, Y)
                loss = loss / gradient_accumulation_steps # scale the loss to account for gradient accumulation
                # immediately async prefetch next batch while model is doing the forward pass on the GPU
            X, Y, ix = get_batch('train', perturb_word_order_window_size=perturb_word_order_window_size)

#             # write to file
#             with open(os.path.join(out_dir, train_indices_file_path), 'a') as file:
#                 file.write(str(ix.tolist()) + '\n')  # Add a newline character to separate lines

            # TODO: Change this to LoRA
            # backward pass, with gradient scaling if training in fp16
            scaler.scale(loss).backward()
        # clip the gradient
        if grad_clip != 0.0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        # step the optimizer and scaler if training in fp16
        scaler.step(optimizer)
        scaler.update()
        # flush the gradients as soon as we can, no need for this memory anymore
        optimizer.zero_grad(set_to_none=True)

        # timing and logging
        t1 = time.time()
        dt = t1 - t0
        t0 = t1
        if iter_num % log_interval == 0 and master_process:
            # get loss as float. note: this is a CPU-GPU sync point
            # scale up to undo the division above, approximating the true total loss (exact would have been a sum)
            lossf = loss.item() * gradient_accumulation_steps
    #         if local_iter_num >= 5: # let the training loop settle a bit
    #             mfu = raw_model.estimate_mfu(batch_size * gradient_accumulation_steps, dt)
    #             running_mfu = mfu if running_mfu == -1.0 else 0.9*running_mfu + 0.1*mfu
    #         print(f"iter {iter_num}: loss {lossf:.4f}, time {dt*1000:.2f}ms, mfu {running_mfu*100:.2f}%")
            print(f"iter {iter_num}: loss {lossf:.4f}, time {dt*1000:.2f}ms")
        iter_num += 1
        local_iter_num += 1

        # termination conditions
        if iter_num > max_iters:
            break

    if ddp:
        destroy_process_group()
