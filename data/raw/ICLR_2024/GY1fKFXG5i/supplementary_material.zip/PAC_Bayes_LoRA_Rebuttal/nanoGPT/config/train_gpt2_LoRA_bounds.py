# config for training GPT-2 (124M) down to very nice loss of ~2.85 on 1 node of 8X A100 40GB
# launch as the following (e.g. in a screen session) and wait ~5 days:
# $ torchrun --standalone --nproc_per_node=8 train.py config/train_gpt2.py

wandb_log = True
wandb_project = 'perturb-train-perturb-eval'
# wandb_project = 'perturb-train-no-perturb-eval'
wandb_run_name='gpus8-r4-acc40-b8'

# these make the total batch size be ~0.5M
# 12 batch size * 1024 block size * 5 gradaccum * 8 GPUs = 491,520
batch_size = 6
block_size = 1024
gradient_accumulation_steps = 5 * 8

# data
dataset_dir = '[TODO]'

# +++++ Optimizer +++++ #
learning_rate = 2e-4 # ? based on https://github.com/microsoft/LoRA/tree/main/examples/NLG

# this makes total number of tokens be 300B
max_iters = 600000
lr_decay_iters = 600000

# eval stuff
eval_interval = 1000
eval_iters = 200 
log_interval = 10


# TODO: check lora parameters
# ===== LoRA Settings ===== #
# 0. Basics
use_lora=True # true if any LoRA layer is used

lora_alpha = 32
lora_dropout = 0.1
# enable_lora = (True, False, True)
# fan_in_fan_out=True
# merge_weights=False

# 1. attention linear layer
attention_linear_use_lora = True
attention_linear_lora_r = 4
# attention_linear_enable_lora=(True, False, True)

# 2. linear head
linear_head_lora_r = 4
linear_head_enable_lora = True


## Bounds hyperparams
random_sampling_with_replacement = True
vocab_size = 50257
bound_samples = 10002
levels = 11
max_quant_iters = 0
data_size = 8823811
use_kmeans=True

# sentence perturbation
perturb_word_order_window_size=0
apply_perturb_eval = 0

intrinsic_dim = 50000
best_checkpoint_path = "[TODO]"
