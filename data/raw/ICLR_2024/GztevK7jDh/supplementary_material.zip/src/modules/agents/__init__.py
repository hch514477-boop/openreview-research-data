REGISTRY = {}

from .rnn_agent import RNNAgent
from .vq_agent import VQAgent
REGISTRY["rnn"] = RNNAgent
REGISTRY["vq"] = VQAgent