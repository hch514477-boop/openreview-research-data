REGISTRY = {}

from .basic_controller import BasicMAC
from .vq_controller import VQMAC

REGISTRY["basic_mac"] = BasicMAC
REGISTRY["vq_mac"] = VQMAC