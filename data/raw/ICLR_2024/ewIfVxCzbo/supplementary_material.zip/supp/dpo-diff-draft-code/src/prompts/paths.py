import os

SUBSTITUTES_LIBRARY = f'/nfs/data/{os.getlogin()}/projects/crash/github/dpo-diff/data/substitutes_library.json'
SUBSTITUTES_TXT_LIBRARY = f'/nfs/data/{os.getlogin()}/projects/crash/github/dpo-diff/data/substitute.txt'
PROJECT_DIR = f'/nfs/data/{os.getlogin()}/projects/crash/github/dpo-diff'
DATA_DIR = f'/nfs/data/{os.getlogin()}/projects/crash/github/dpo-diff/data'
NEG_PROMPTS_LIBRARY = f'/nfs/data/{os.getlogin()}/projects/crash/github/dpo-diff/data/prompts-negative-filtered.txt'
NEG_PROMPTS_LIBRARY_V2 = f'/nfs/data/{os.getlogin()}/projects/crash/github/dpo-diff/data/prompts-negative-filtered-v2.txt'
MODEL_CACHE_DIR = f'/nfs/data/{os.getlogin()}/projects/crash/github/dpo-diff/cache'