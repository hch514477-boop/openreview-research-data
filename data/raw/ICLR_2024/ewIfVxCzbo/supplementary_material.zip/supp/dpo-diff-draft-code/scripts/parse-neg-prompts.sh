#!/bin/bash
#### maual attack - filter concepts
script_name=`basename "$0"`
id=${script_name%.*}
entry=${entry:-'src'}
seed=${seed:-2}
gpu=${gpu:-"auto"}
group=${group:-"attack-sd"}
tag=${tag:-"none"}
override=${override:-""}

#### dev
cls=${cls:-"vit-laion"}
stats=${stats:-"model"}
ipc=${ipc:-10}
version=${version:-"v1-4"}

prompt_id=${prompt_id:-0}

constraint=${constraint:-"bert_score_gpt2"}
thresh=${thresh:-0.0}

num_exps=${num_exps:-1}
max_epochs=${max_epochs:-10}

path=${path:-"substitutes-dev"}
reverse=${reverse:--1}
task=${task:-"attack"}


while [ $# -gt 0 ]; do
    if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
    fi
    shift
done
prompt_id_list=$(echo $prompt_id | tr ',' ' ')


cd ../
python ${entry}/parse_negative_prompts.py \
