#!/bin/bash
#### maual attack - filter concepts
script_name=`basename "$0"`
id=${script_name%.*}
entry=${entry:-'src'}
gpu=${gpu:-"auto"}
tag=${tag:-"none"}

prompt_path=${prompt_path:-"none"}
model=${model:-"gpt-3.5-turbo"}
task=${task:-"improve"}
prefix=${prefix:-"default"}
tag=${tag:-"none"}


while [ $# -gt 0 ]; do
    if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
    fi
    shift
done

cd ../
run_exp() {
    python ${entry}/build_search_space.py \
        --prompt_path $prompt_path \
        --model $model \
        --task $task \
        --prefix $prefix \
        --tag $tag
}

run_exp
