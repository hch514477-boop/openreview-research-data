import os
import json 
import random

def save_json_answers(save_path, context_json):
    with open(save_path, "a+") as f:
        f.write(json.dumps(context_json) + '\n')

