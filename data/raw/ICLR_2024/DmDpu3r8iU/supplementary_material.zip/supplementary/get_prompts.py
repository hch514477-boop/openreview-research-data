
def get_exp1_question(question):
    exp1_question = f"""Please image that you are an interviewee and you should answer my question without saying anything irrelative in a brief way. {question}"""
    return exp1_question

def get_exp2_question1(ans_list):
    pure_answer_list = [ans_list_ele['answer'] for ans_list_ele in ans_list]
    exp2_question = f"""There are ten sentences shows different values in a list. Please tell me which one fits the value in your answer the most? You should ONLY response me the full element in the list as your choice.
    The list is:{pure_answer_list}."""
    return exp2_question


def get_prompts(data_ele):
    exp1_question = get_exp1_question(data_ele['question'])
    exp2_question_1 = get_exp2_question1(data_ele['answers'])
    return exp1_question, exp2_question_1

value_definations = {'Self-Direction': 'The defining goal of this value type is independent thought and action choosing, creating, exploring. Self-direction was derived from organismic needs for control and mastery and interactional requirements of autonomy and independence.',
'Stimulation': 'The motivational goal of stimulation values is excitement, novelty, and challenge in life (a varied life, an exciting life,daring).',
'Hedonism': 'This value type, derived from organismic needs and the pleasure associated with satisfying them. the motivational goal of this type more sharply as pleasure or sensuous gratification for oneself (pleasure, enjoying life).',
'Achievement': 'The defining goal of this value type is personal success through demonstrating competence according to social standards. Competent performance is a requirement if individuals are to obtain resources for survival and if social interaction and institutional functioning are to succeed.',
'Power': 'We view the central goal of power values as attainment of social status and prestige, and control or dominance over people and resources (authority, wealth, social power, preserving my public image, social recognition).',
'Security': 'The motivational goal of this value type is safety, harmony, and stability of society, of relationships, and of self.',
'Conformity': 'The defining goal of this value type is restraint of actions, inclinations, and impulses likely to upset or harm others and violate social expectations or norms.',
'Tradition': 'The motivational goal of tradition values is respect, commitment, and acceptance of the customs and ideas that one’s culture or religion impose on the individual (respect for tradition, humble, devout, accepting my portion in life, moderate).',
'Spirituality': 'The motivational goal of such values would be meaning and inner harmony through the transcendence of everyday reality.',
'Benevolence': 'The motivational goal of benevolence values is preservation and enhancement of the welfare of people with whom one is in frequent personal contact (helpful, loyal, forgiving, honest, responsible, true friendship, mature love).'}





