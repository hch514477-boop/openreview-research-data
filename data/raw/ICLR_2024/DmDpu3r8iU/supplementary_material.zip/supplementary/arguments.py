import argparse
import os

parser = argparse.ArgumentParser(description='LLMs DCG Measurement.')
parser.add_argument('--LLM_model', default='gpt-3.5-turbo') 
parser.add_argument('--value_system_prior', default='non') 

args = parser.parse_args()




