Run the main.py file directly at the Linux terminal:

# Please install numpy ,pytorchand python>3.7 firstly

python main.py