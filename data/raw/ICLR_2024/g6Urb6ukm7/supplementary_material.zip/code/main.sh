
# Example for Classification
python -u main.py PEMS-SF UEA --loader UEA --connection 0.5 --repr-dims 320 --batch-size 8 --seed 42 --eval

# Example for Forecasting
python -u main.py ETTm1 forecast_multivar --loader forecast_csv --connection 0.5 --repr-dims 320 --batch-size 8 --seed 99 --eval