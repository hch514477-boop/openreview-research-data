
To run MM-GPVAE with MNIST dataset:

1) Make sure you download the full MNIST dataset from the internet. Once you have the dataset, put its PATH to the 'pth' variable in the DataGenerator.py.
2) Create a python environment with the packages listed below.
3) Generate the modified MNIST data using DataGenerator.py, and move the data to the same directory as the MMGPVAE notebook. (The DataGenerator.py creates a file with a default name that already matches with the file path in the dataloder of the MMGPVAE notebook. If you change the file name in the DataGenerator.py, you will have to change the path to the data in the MMGPVAE notebook.)
4) Run MMGPVAE.ipynb 


Packages used: 
- python 3.8.13
- torch 1.12.0
- numpy 1.23.1
- matplotlib 3.5.2
- scipy 1.9.0
- scikit-learn 1.1.1

Summary of directory contents:

MMGPVAE.ipynb: The entire MM-GPVAE code for the simulated example. This code will train the model and plot the results on testing data.
DataGenerator.py: This will apply the modifications to the MNIST digit to be used in the MMGPVAE.ipynb.
GP_fourier: You don't need to run anything in this folder, it is just a dependency for the MMGPVAE notebook.