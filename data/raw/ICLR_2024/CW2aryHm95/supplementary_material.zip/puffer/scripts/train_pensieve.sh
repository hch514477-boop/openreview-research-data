cd third_party/pensieve/multi_video_sim_training

python multi_agent_entropy.py

sudo shutdown -h now
