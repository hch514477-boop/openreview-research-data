#!/bin/bash

mkdir -p logs

echo "\n#### RL running ####\n" >> logs/progress.log
date >> logs/progress.log

# training
echo "train_reinfroce" >> logs/progress.log
python3.7 ./src/scripts/train/rlserver.py --type=train & 
RL_PID=$!
sleep 10
python3.7 ./src/media-server/offline_test.py -f --epochs 6
kill $RL_PID
sleep 60

# evaluation
echo "RL - find optinal weight" >> logs/progress.log
scripts/find_optimal_weight.sh 200 210

sudo shutdown -h now
