#!/bin/bash

rm -rf temp
mkdir temp
cp Dash/chunk6-* temp

declare -i time=0
for file in `ls temp`;
do
	mv "temp/$file" "temp/${time}.m4s"
	let "time+=180180"
done

cp Dash/init6.m4s temp/init.m4s

rm ~/ubuntu/media-181230/bbb/ready/426x240-24/* -rf
cp temp/* ~/ubuntu/media-181230/bbb/ready/426x240-24/
