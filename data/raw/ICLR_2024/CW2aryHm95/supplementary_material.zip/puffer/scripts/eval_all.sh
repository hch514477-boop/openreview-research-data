#!/bin/bash

influx -execute 'drop series from /.*/' -database="puffer"

python3.7 src/media-server/offline_test.py -t --yaml-settings settings/puffer.yml
python3.7 src/media-server/offline_test.py -t --yaml-settings settings/robust_mpc.yml
python3.7 src/media-server/offline_test.py -t --yaml-settings settings/mpc.yml
python3.7 src/media-server/offline_test.py -t --yaml-settings settings/bba.yml

python3.7 ./src/scripts/train/rlserver.py --type=inference &
RL_PID=$!
sleep 10
python3.7 ./src/media-server/offline_test.py -t
kill $RL_PID

sudo shutdown -h now
