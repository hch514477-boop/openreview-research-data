#include "random.hh"
#include "ws_client.hh"
#include <stdlib.h> 

Random::Random(const WebSocketClient &client, const std::string &abr_name, const YAML::Node &abr_config)
    : ABRAlgo(client, abr_name)
{
    srand(time(NULL));
}

void Random::video_chunk_acked(Chunk && c)
{
}

VideoFormat Random::select_video_format()
{
    const auto & channel = client_.channel();
    const auto & vformats = channel->vformats();
    int format = rand() % vformats.size();
    return vformats[format];
}