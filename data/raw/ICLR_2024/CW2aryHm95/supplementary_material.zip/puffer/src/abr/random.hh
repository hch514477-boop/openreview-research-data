#ifndef RANDOM_HH
#define RANDOM_HH

#include "abr_algo.hh"

class Random : public ABRAlgo
{
public:
    Random(const WebSocketClient &client, const std::string &abr_name, const YAML::Node &abr_config);
    void video_chunk_acked(Chunk &&c) override;
    VideoFormat select_video_format() override;
};

#endif /* RANDOM_HH */