from .exp3 import Exp3


class Exp3Boggart(Exp3):
    def __init__(self, config):
        super().__init__(config)
