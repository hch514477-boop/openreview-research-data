from .exp3 import Exp3
import pickle


class Exp3KMeans(Exp3):
    def __init__(self, config):
        Exp3.__init__(self, config)

        # abr_config = yaml_settings["experiments"][0]['fingerprint']['abr_config']
        # clusters_path = abr_config['kmeans_dir'] + "clusters.pkl"
        # mean_path = np.loadtxt(kmeans_path + "mean.txt")
        # std_path = np.loadtxt(kmeans_path + "std.txt")

        # with open(clusters_path, 'rb') as f:
        #     self._kmeans = pickle.load(f)
        # with open(mean_path, 'rb') as f:
        #     self._mean = pickle.load(f)
        # with open(std_path, 'rb') as f:
        #     self._std = pickle.load(f)

    # def predict(self, datapoint):
    #     context_idx = self._kmeans.predict(datapoint)
    #     context_idx = context_idx[0]
    #     arm = self._contexts[context_idx].predict()
    #     return arm
