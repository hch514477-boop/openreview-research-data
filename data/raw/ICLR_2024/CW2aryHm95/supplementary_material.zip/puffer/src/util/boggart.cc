#include "boggart.hh"

#include <assert.h>
#include <cmath>
#include <iostream>

Boggart::Boggart()
{
}

std::size_t Boggart::calc_inner_index(std::size_t max_conservative, 
                                          std::size_t max_risk,
                                          std::size_t dis_buffer)
{
  return (max_conservative) + dis_buffer; // buf_size_
}
