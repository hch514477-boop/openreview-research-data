#ifndef BOGGART_HH
#define BOGGART_HH

#include "exp3.hh"

#include <string>
#include <vector>
#include <fstream>

class Boggart
{
public:
  Boggart();
  std::size_t calc_inner_index(std::size_t max_conservative, 
                               std::size_t max_risk,
                               std::size_t dis_buffer);
};

#endif /* BOGGART_HH */
