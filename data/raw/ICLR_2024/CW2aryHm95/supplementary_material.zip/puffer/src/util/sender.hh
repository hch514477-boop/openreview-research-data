#ifndef SENDER_HH
#define SENDER_HH

#include <vector>
#include <string>
#include "json.hpp"

using json = nlohmann::json;

class Sender 
{
public:
  Sender(){};
  Sender(unsigned int port);
  json post(json data);
  void post(json data, std::string endpoint);
  void post(json data, std::string server_id, std::string endpoint);
private:
  int sock_;
  int client_fd_;
  unsigned int port_;
};

#endif /* SENDER_HH */
