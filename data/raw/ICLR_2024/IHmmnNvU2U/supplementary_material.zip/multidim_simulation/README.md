We recommend using a virtual environment. Once your virtual environment is created you can install the requirements using

```bash
pip install -r requirements.txt
```

Tested with Python 3.7.5.

To generate multidimensional simulated data from the manuscript, run

```bash
/bin/bash generate_figure.sh
```

This will generate results in a local `results` directory and ultimately plot the figure into `results/multidim_sim.pdf`.
