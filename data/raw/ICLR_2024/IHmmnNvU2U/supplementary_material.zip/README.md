You can find the source code associated with experiments presented in our manuscript.

The HCMNIST and HCMNIST-CS results can be produced by following the `README.md` in `CMNIST`.

Simulated experimental results can be recreated using `multidim_simulation` and `twodim_simulation`.

The DomainBed results were produced using the code in `DomainBed`.
