To start run 

## Step 1. Setup environment

Requires you have conda installed. This will create a new conda environment named `wri_iclr2023_cmnist`.

```
bash setup_env.sh
```

## Step 2. Download and unpack pretrained featurizers (autoencoders)

```
bash download_data.sh
```

## Step 3. Run experiments

To generate table 1

```
bash run_experiment.sh
```

To generate table 2

```
bash run_idealized.sh
```

