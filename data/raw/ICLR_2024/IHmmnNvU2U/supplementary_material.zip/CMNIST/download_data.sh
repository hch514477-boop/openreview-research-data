#!/bin/bash

# download autoencoder features
wget -O "CMNIST_features.tar.gz" "https://dl.dropboxusercontent.com/scl/fi/yhx7yh4ndzbvuwzn5t4fe/CMNIST_features.tar.gz?rlkey=awabfm1e8jp1otmfdfuan08vs&dl=0"
                                  
# unpack features
pushd DomainBed
tar -xzvf ../CMNIST_features.tar.gz
popd

rm CMNIST_features.tar.gz

