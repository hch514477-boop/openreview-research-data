We recommend using a virtual environment. Once your virtual environment is created you can install the requirements using

```bash
pip install -r requirements.txt
```

Tested with Python 3.8.0.

The script in this directory is independent of domainbed. To generate the parts of Figure 1 from the manuscript, run

```bash
python main.py
```

This will produce two .pdf files in the local directory containing the top and bottom half of figure 1.

