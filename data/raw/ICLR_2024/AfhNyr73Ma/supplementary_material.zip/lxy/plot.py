import pandas as pd
import matplotlib.pyplot as plt


test_path_sgd = r'test_loss_sgd.csv'
test_path_gd = r'test_loss_gd.csv'
test_path_svrg = r'test_loss_svrg.csv'

train_path_sgd = r'train_loss_sgd.csv'
train_path_gd = r'train_loss_gd.csv'
train_path_svrg = r'train_loss_svrg.csv'

gen_path_sgd = r'test_train_loss_sgd.csv'
gen_path_gd = r'test_train_loss_gd.csv'
gen_path_svrg = r'test_train_loss_svrg.csv'

test_sgd = pd.read_csv(test_path_sgd,header=None)
test_gd = pd.read_csv(test_path_gd,header=None)
test_svrg = pd.read_csv(test_path_svrg,header=None)

train_sgd = pd.read_csv(train_path_sgd,header=None)
train_gd = pd.read_csv(train_path_gd,header=None)
train_svrg = pd.read_csv(train_path_svrg,header=None)

gen_sgd = pd.read_csv(gen_path_sgd,header=None)
gen_gd = pd.read_csv(gen_path_gd,header=None)
gen_svrg = pd.read_csv(gen_path_svrg,header=None)

print(gen_sgd.iloc[-1])
print(gen_gd.iloc[-1])
print(gen_svrg.iloc[-1])

# plt.plot(test_sgd, label="Test loss: ZO-SGD")
# plt.plot(test_gd, label="Test loss: ZGD")
# plt.plot(test_svrg, label="Test loss: ZO-SVRG")

# plt.plot(train_sgd, label="Train loss: ZO-SGD")
# plt.plot(train_gd, label="Train loss: ZGD")
# plt.plot(train_svrg, label="Train loss: ZO-SVRG")

plt.plot(gen_sgd[2000:-1], label="Generalization error: ZO-SGD")
plt.plot(gen_svrg[2000:-1], label="Generalization error: ZO-SVRG")
plt.plot(gen_gd[2000:-1], label="Generalization error: GD")




plt.xlabel('Epoches')
plt.ylabel('|test loss - train loss|')
plt.legend()
plt.show()




