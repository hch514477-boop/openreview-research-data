nohup python -m SimpleSAC.conservative_sac_ori \
--env 'pen-expert-v0' \
--name 'pen-expert-v0' \
--device='cuda:0' \
--seed=1 \
--logging.online \
--logging.output_dir './iclr_output' &
nohup python -m SimpleSAC.conservative_sac_ori \
--env 'pen-human-v0' \
--name 'pen-human-v0' \
--device='cuda:0' \
--seed=1 \
--logging.online \
--logging.output_dir './iclr_output' &
nohup python -m SimpleSAC.conservative_sac_ori \
--env 'kitchen-complete-v0' \
--name 'kitchen-complete-v0' \
--device='cuda:1' \
--seed=1 \
--logging.online \
--logging.output_dir './iclr_output' &
nohup python -m SimpleSAC.conservative_sac_ori \
--env 'kitchen-partial-v0' \
--name 'kitchen-partial-v0' \
--device='cuda:1' \
--seed=1 \
--logging.online \
--logging.output_dir './iclr_output' &
nohup python -m SimpleSAC.conservative_sac_ori \
--env 'kitchen-mixed-v0' \
--name 'kitchen-mixed-v0' \
--device='cuda:1' \
--seed=1 \
--logging.online \
--logging.output_dir './iclr_output' &