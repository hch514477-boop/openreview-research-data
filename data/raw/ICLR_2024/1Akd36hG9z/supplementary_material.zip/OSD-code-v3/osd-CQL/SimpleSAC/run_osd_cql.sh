nohup python -m SimpleSAC.conservative_sac_main \
--env 'antmaze-medium-play-v0' \
--name 'medium-play-osd-alpha-0.1-fixbug-scale-quantile-seed1' \
--cql.osd_alpha=0.01 \
--device='cuda:3' \
--seed=1 \
--logging.online \
--logging.output_dir './rebuttal_output' &

nohup python -m SimpleSAC.conservative_sac_main \
--env 'antmaze-medium-diverse-v0' \
--name 'medium-diverse-osd-alpha-0.01-fixbug--scale-quantile-seed1' \
--cql.osd_alpha=0.01 \
--device='cuda:3' \
--seed=1 \
--logging.online \
--logging.output_dir './rebuttal_output' &

nohup python -m SimpleSAC.conservative_sac_main \
--env 'antmaze-umaze-diverse-v0' \
--name 'medium-umaze-osd-alpha-0.01-fixbug--scale-quantile-seed1' \
--cql.osd_alpha=0.01 \
--device='cuda:4' \
--seed=1 \
--logging.online \
--logging.output_dir './rebuttal_output' &



python -m SimpleSAC.conservative_sac_main \
--env 'antmaze-medium-play-v0' \
--name 'medium-play-osd-alpha-0.01-scale-quantile-seed1' \
--device='cuda:4' \
--seed=1 \
--logging.output_dir './rebuttal_output' 