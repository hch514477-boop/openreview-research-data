python mvn.py -f gamma_1.yml
python mvn.py -f gamma_2.yml
python mvn.py -f gamma_02.yml