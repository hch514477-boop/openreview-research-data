We didn't contribute the datasets referenced in the paper.

The datasets used in the BNN example were sourced from the following repositories:
- UCI Machine Learning Repository (https://archive.ics.uci.edu/)
- OpenML (https://www.openml.org/)