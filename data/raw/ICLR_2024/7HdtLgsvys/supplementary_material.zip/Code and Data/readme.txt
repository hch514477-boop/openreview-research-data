
 First, set the path of the MATLAB to the folder containing the matlab files.

#######################################################################################################################
Kernel Machine Experinments with MATLAB
########################################################################################################################
Instruction for regenerating the numerical results 
1.	To generate the Figure 2 (a) of the paper run ‘Exp1.m’.
2.	 To generate the Figure 2 (b) of the paper set ‘tau=0.9’ at line 9 of the Exp1.m
3.	To generate the Figures of (3), run the ‘Exp2.m’.  You can change the value of r   at line 15 to generate the different figures.
4.	To generate the numerical results in Table 1 of the paper, run the ‘Test1.m’ and ‘Test2.m’ Test1.m is for dataset A. Test2.m is for dataset B.




#######################################################################################################################
NN Experiment  with python (COLAB file)
########################################################################################################################
Instruction for regenerating the numerical results 
1.	To generate the Figure 6(a) run the cells of code ‘Test6_.ipynb’ one by one.
2.	To generate the Figure 6(b) change at 4th cell of the code ‘Test6_.ipynb’. Set the l =1. run the cells of code ‘Test6.ipynb’ one by one.  With l =1 , the code runs with QD loss function. With Set the l =2, it runs with proposed Tube loss function.


####################################################################################################################
LSTM Experiment with python (COLAB file)
#####################################################################################################################
Instruction for regenerating the LSTM time-series experiment
1. Open the 'Updated_CL_SWH.ipynb'.
2. The '42001h2021.txt' is provided. Upload it to google drive or set the path of the file at the 2nd line of 3rd cell of the code.
3. Run the Updated_CL_SWH.ipynb.  It will generate Figure 8 and relevant numerical results.