from .model import ModelSTAGIN
from .util.bold import process_dynamic_fc