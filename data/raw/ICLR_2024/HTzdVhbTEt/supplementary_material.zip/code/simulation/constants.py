class Cte:
    # fairness-types
    EOP = "EOP"
    QUAL = 'QUAL'
    QUALVAL = 'QUALVAL'
    DP = 'DP'

    SYNTH = 'SYNTH'
    FICO = 'FICO'

    ONEMED = 'ONEMED'
    ONESLOW = 'ONESLOW'
    ONEFAST = 'ONEFAST'
    DEFAULT = 'DEFAULT'
    RANDOM = 'RANDOM'
    RECOURSE = 'RECOURSE'
    DISCOURAGED = 'DISCOURAGED'


