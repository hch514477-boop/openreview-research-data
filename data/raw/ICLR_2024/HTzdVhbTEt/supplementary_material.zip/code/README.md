## Code to replicate experiments

### 1. Generate environment using `environment.yml` and activate it.
```
conda env create -f environment.yml
conda activate myenv
```

or install: `numpy, scipy, pandas, matplotlib, seaborn, jupyter`

### 2. Solve optimization problems by running commands provided in `solve_policies.txt`


### 3. Evaluate policies using notebooks in folder `notebooks/`
