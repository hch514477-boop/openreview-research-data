from .semisup import SemiSupervisedLearning
from .partial_label import PartialLabelLearning
from .noisy_label import NoisyLabelLearning
from .mixture import SemiSupervisedNoisyPartialLearning
# from .noisy_label_v2 import NoisyLabelLearning

name2alg = {
    'semisup': SemiSupervisedLearning,
    'partial_label': PartialLabelLearning,
    'noisy_label': NoisyLabelLearning,
    'mixture': SemiSupervisedNoisyPartialLearning
}