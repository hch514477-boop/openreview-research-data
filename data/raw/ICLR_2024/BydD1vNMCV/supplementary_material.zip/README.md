### UCI Data set
The following code run post stonet experiments on UCI repository. --dataset_name_id specifies data set, 0, 1, 2, 3 corresponds to "Wine", "Power Plant", "Protein", "Year" data set respectively.

```{python}
python sgd_post_stonet.py --dataset_name_id 0
python CI_post_stonet.py --dataset_name_id 0 --lasso 0.02 --nepoch 1001 --split_start 0 --split_end 1
python CI_compute.py --dataset_name_id 0 --lasso 0.02 --load_epoch 1000 --split_start 0 --split_end 1
```

### CIFAR10 Data set
Post StoNet for CIFAR10
```{python}
python cifar_run_resnet.py
python cifar_run_wide_resnet.py
python cifar_run_densenet.py
python cifar_stonet.py --data_name "CIFAR10_densenet"
python cifar_stonet.py --data_name "CIFAR10_resnet"
python cifar_stonet.py --data_name "CIFAR10_wr"
```
