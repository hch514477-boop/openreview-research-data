import numpy as np
import pandas as pd


def GetDataset(name, base_path):
    """ Load a dataset
    
    Parameters
    ----------
    name : string, dataset name
    base_path : string, e.g. "path/to/datasets/directory/"
    
    Returns
    -------
    X : features (nXp)
    y : labels (n)
    
	"""
    if name=="Wine":
        temp = pd.read_csv('{}{}/winequality-red.csv'.format(base_path, name), sep=';')
        temp = np.array(temp)
        X = temp[:, 0:11]
        y = temp[:, 11]
    if name=="CCPP":
        temp = pd.read_excel('{}{}/Folds5x2_pp.xlsx'.format(base_path, name))
        temp = np.array(temp)
        X = temp[:, :4]
        y = temp[:, 4]    
    if name=="Protein":
        temp = pd.read_csv('{}{}/CASP.csv'.format(base_path, name))
        temp = np.array(temp)
        X = temp[:, 1:10]
        y = temp[:, 0]
    if name=="Year":
        temp = pd.read_table('{}{}/YearPredictionMSD.txt'.format(base_path, name), header = None, sep = ',')
        temp = np.array(temp)
        X = temp[:, 1:]
        y = temp[:, 0]
    if name=="CoverType":
        temp = pd.read_csv('.{}{}/covtype.data'.format(base_path, name), sep=',', header=None)
        temp = np.array(temp)
        X = temp[:, 0:-1]
        y = temp[:, 54]     
  
    X = X.astype(np.float32)
    y = y.astype(np.float32)
    
    return X, y
        