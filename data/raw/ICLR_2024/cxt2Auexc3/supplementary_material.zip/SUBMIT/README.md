#  Supplementary Materials

## Benchmark

Our benchmark is in the folder `PersonalityEdit`.

## Baseline

### Serac and Mend

The code of `serac` and `mend` is in the folder `./baseline/SERAC_MEND`.

To run the baseline code, first modify the base model config in `./baseline/SERAC_MEND/config/model` , and the run the following command:

```bash
cd ./baseline/SERAC_MEND

# example for running mend in GPTJ-6B
bash run_6B_mend.sh
```

### IKE and Prompt

The code for `ike` and `prompt` is in `./baseline/IKE_PROMPT`, the script `generate.sh` is for text generation, and `run_metric.sh` is for computing the `ES` and `DD` metric.

## Evaluation

The code and prompt for gpt-4 evaluation can be found in `./eval`.

## Others

We will maintain the code and further update the dataset in the future.