export model="Llama-2-7b-chat-hf"
export method_type="ike"
export prefix="edit"

CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 python generate.py \
    --ckpt_dir /meta-llama/${model} \
    --output_dir ./output/generation/${model}/${method_type}/ \
    --method_type ${method_type} \
    --prefix ${prefix}

