export model="gptj"
export method_type="edit"

CUDA_VISIBLE_DEVICES=1 python run_metric.py \
    --ckpt_dir gpt-j-6B \
    --output_dir ./output/metric/${model}/${method_type}/ \
    --method_type ${method_type} \
    --prefix ${method_type}

