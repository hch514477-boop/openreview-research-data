CUDA_VISIBLE_DEVICES=5 python -m run \
    +alg=gtn \
    +experiment=per \
    +model=llama-2-7b \
    batch_size=1 \
    val_batch_size=1 \
    device=0 \
    device_map=[0] \
    max_iters=16000 \
    # generate_file=./output/llama-2-7b/mend.json \
    # original_generate_file=./output/llama-2-7b/mend_original.json \
    
