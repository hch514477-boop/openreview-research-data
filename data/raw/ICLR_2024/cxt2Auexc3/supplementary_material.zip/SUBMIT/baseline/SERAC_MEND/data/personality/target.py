import os,json,sys
from tqdm import tqdm
import random

per_list = [
    "extraversion",
    "agreeableness", 
    "neuroticism"
]
test = json.load(open("test.json", "r"))
new_test = []

for mention in tqdm(test):
    mention["target_per"] = random.choice(per_list)
    new_test.append(mention)
    
json.dump(new_test, open("new_test.json", "w"), indent=4, ensure_ascii=False)