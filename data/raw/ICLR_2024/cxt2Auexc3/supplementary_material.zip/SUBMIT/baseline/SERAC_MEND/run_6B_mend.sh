CUDA_VISIBLE_DEVICES=1 python -m run \
    +alg=gtn \
    +experiment=per \
    +model=GPTJ-6B \
    batch_size=1 \
    val_batch_size=1 \
    device=0 \
    device_map=[0] \
    max_iters=16000 \
    model.pt=./models/gpt-j-6B/gtn.pt \
    eval_only=True \
    generate=True \
    generate_file=./models/gpt-j-6B/mend.json \
    