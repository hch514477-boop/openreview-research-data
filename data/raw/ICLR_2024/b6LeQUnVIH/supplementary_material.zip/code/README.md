This code is only for demonstration purposes. 
We will clean up our code, upload the data, and make it executable before camera ready.
