## DEEP IWOCS

Install dependencies use python 3.9:
```
pip install requirements.txt
pip install requirements-dev.txt
```
Run the experiments:
```
./run_deep_iwocs_experiment.sh
```
