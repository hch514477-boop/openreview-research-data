Run the tabular experiment:
`python windy_walk.py`