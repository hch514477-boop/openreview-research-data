The repo for ``A Unified Framework for Reinforcement Learning under Policy and Dynamics Shifts``



For the tasks under stationary environments:

~~~
python main_stationary.py --env_name Hopper-v3
~~~



