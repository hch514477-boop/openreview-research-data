import React from 'react';

import Spin from "antd/es/spin";

const LoadingCard = (props) => {
    const {loading} = props

    if (loading) {
        return (<div style={{
            position: "absolute",
            top: 0,
            right: 0,
            zIndex: 1,
            width: "100%",
            height: "100%",
            backgroundColor: "white",
            borderRadius: 1,
            textAlign: "center",
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
        }}>
            <Spin size="medium"/>
        </div>)
    }
    return null
};

export default LoadingCard;
