export async function getSample(dataset, index) {
    const response = await fetch(`http://localhost:3000/api/samples?dataset=${dataset}&index=${index+1}`, {
        headers: {
            'Content-Type': 'application/json',
        }
    });
    return await response.json();
}

export async function getTrees(dataset) {
    const response = await fetch(`http://localhost:3000/api/trees?dataset=${dataset}`, {
        headers: {
            'Content-Type': 'application/json',
        }
    });
    return await response.json();
}

export async function getDatasets() {
    const response = await fetch('http://localhost:3000/api/datasets', {
        headers: {'Content-Type': 'application/json'}
    });
    return await response.json();
}
