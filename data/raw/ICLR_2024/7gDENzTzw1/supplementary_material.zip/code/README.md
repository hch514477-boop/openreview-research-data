We include pretrained PF-RNN and vanilla DQN model
## Train Diffusion Model
### First Generate Trajectory
```
python3 gen_atari_pic.py --config config/Pong_ours.json
python3 diffuion.py
```
## Train our model
### BP-DQN
```
python3 train.py --config config/Grid_continous_ours.json
```
### DP-DQN
```
python3 train_atari.py --config config/Pong_ours.json
```
