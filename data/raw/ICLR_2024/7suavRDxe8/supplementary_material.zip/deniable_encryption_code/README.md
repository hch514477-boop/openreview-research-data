Preliminary code release for `PLAUSIBLY DENIABLE ENCRYPTION WITH LARGE LANGUAGE MODELS`.

We provide an efficient C++ implementation to calculate Hufmann codes.

Requirements:
- C++ compiler with C++11 support

To comile the library
```
make
```

This will create a static library `libhuffman.so`.