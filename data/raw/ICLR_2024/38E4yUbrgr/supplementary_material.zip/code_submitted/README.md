## How to run the code?

1. Install necessary dependencies:

The version of python we used is 3.10
```
pip install -r requirements.txt
```
Then we need install trlx (Notice! We changed the trlx, so you must use the trlx in the same folder provided by us namely trlx_ours:
```
cd ./trlx_ours
pip install torch==2.0.0 --extra-index-url https://download.pytorch.org/whl/cu116 # for cuda
pip install -e .
```


2. Run the code

```
python SIRLC.py --ask_mode "standard_answer_reward" --is_chain_of_thought True --model_name google/flan-t5-large --bbh_set date_understanding
```

3. available arguments:
- --model_name: which model to load
- --ask_mode: how to ask for judgement
- --is_chain_of_thought: ask with chain of thought or not for judgement 
- --dataset_name: The Specific dataset name:[TruthfulQA, CommonQA, BIG-Bench-Hard/bbh, human_annotations]
- --llm_generate_mode: generate mode : （multinomial_sampling）
- --few_shot_cot how many few shot of cot to use(only for BigBench dataset)




