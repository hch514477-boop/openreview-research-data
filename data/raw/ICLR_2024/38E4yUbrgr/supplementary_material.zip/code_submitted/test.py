from chatgpt_api import gpt_agent
import time

bot = gpt_agent(api_key="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")
start_time = time.time()
print(bot.ask("""Tell me most possible next steps to reach 24. 
                For example, Input: 2 8 8 14 
                Possible next steps:
                2 + 8 = 10 (left: 8 10 14)
                8 / 2 = 4 (left: 4 8 14)
                14 + 2 = 16 (left: 8 8 16)
                2 * 8 = 16 (left: 8 14 16)

                
                Input:4 5 6 7 
                Output: (Give me four possible steps)
                
                Input:3 3 3 1
                Output: (Give me four possible steps)
                
                Input:2 3 4 1
                Output: (Give me four possible steps)
                
                Input:5 6 8 1
                Output: (Give me four possible steps)
                
                Input:9 7 8 1
                Output: (Give me four possible steps)"""))

print(time.time() - start_time)