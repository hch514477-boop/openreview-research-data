from setuptools import setup

setup(  name='variational_classifier',
        version='1.0',
        description='Variational Bayes Classifier',
        author='Anonymous',
        author_email='abc@xyz.com',
        packages=['src'],
    )