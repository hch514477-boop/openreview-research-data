The directory "platform" is a modified version from the official release of "Playstyle Distance"(https://paperswithcode.com/paper/an-unsupervised-video-game-playstyle-metric#code), which is our implementation for this paper (some RGSK implementations are not provided by that repo, we follow the torcs and atari implemetations to implement it.).

About collecting the dataset for diversity, we use the tool in google-dopamine. 
https://github.com/google/dopamine/blob/master/dopamine/utils/example_viz_lib.py