# Sparse-PGD: An Effective and Efficient Attack for $l_0$ Bounded Adversarial Perturbation

1. sparse_adversarial_training: training a robust model against sparse perturbations, check details in [sparse_adversarial_training/README.md](./sparse_adversarial_training/README.md)
2. sparse_autoattack: evaluate the robustness of models against sparse perturbations, check details in [sparse_autoattack/README.md](./sparse_autoattack/README.md)
