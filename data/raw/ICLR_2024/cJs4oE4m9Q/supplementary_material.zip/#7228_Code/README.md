## Deep Orthogonal Hypersphere Compression for Anomaly Detection


### Dependencies

- python 3.8, pytorch, torch-geometric, torch-sparse, numpy, scikit-learn

If you have installed above mentioned packages you can skip this step. Otherwise run:

    pip install -r requirements.txt

## Reproduce graph data results

To generate results

    python demo_DOHSC.py --DS MUTAG

or

    python demo_DO2HSC.py --DS MUTAG

## Reproduce tabular data results

To generate results

    python demo_tabular.py

For running tabular data, the dataset name needs to be revised in corresponding demo files. 

## Reproduce image data results

To generate results

    python demo_cifar10.py

For both non-graph datasets, the algorithm needs to be selected in corresponding demo files. 



