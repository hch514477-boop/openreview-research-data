#!/bin/bash

raw_dataset_dir=$1
data_dir=$2

for dataset in mnist cifar10 domainnet fmow amazon_review otto
do
  python build_datasets.py --gpu 0 --dataset $dataset --data-dir $data_dir --raw-dataset-dir $raw_dataset_dir
done
