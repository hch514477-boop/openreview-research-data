"""Import selective prediction methods."""

from methods.aspest import ASPEST
from methods.de import DE
from methods.sr import SR
