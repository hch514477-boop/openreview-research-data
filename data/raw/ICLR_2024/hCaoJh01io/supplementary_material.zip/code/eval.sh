#!/bin/bash


python ./src/eval.py --from_ckpt=$num_iter --task=TurnFaucet-v0 --gpu_idx=0

