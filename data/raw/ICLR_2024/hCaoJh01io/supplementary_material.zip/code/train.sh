#!/bin/bash

cd ../src && 

python train.py --model_name=PickCube-v0_model_llm_flava \
    --num_traj=500 --n_iters=200_000 \
    --context_length=60 --model_type=s+a+cot \
    --task=PickCube-v0 --key_state_coeff=0.1 \
    --key_state_loss=0 --key_states=abcdef \
    --init_lr=5e-4 --num_workers=20 --seed=0 \
    --modify_dataset=True --weight_decay=0 --IB=flava



