## Code Submission for ICLR 2024


We've developed our code using open-source implementations for various tasks, as below.


- **[bAbI task (TPR-RNN)](https://github.com/APodolskiy/TPR-RNN-Torch)** 

- **[Sort-of-CLEVR task](https://github.com/sarthmit/Compositional-Attention)** 

- **[WikiText-103 task](https://github.com/IDSIA/lmtool-fwp)** 


### Requirement
- Python 3.8
- PyTorch 1.13