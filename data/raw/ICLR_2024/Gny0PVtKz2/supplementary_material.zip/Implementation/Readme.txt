The contents of the released code can be accessed at https://anonymous.4open.science/r/ConvFormer-3383/, including:

- The source code of ConvFormer and its variants,
- The source code of SAR and its variants,
- The pretrained model for reproducing the results in Table 2, as well as corresponding anonymous log files.