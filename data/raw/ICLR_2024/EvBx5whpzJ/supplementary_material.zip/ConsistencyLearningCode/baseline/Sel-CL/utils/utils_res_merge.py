import pandas as pd
import os

# folders = ['exp4', 'exp6', 'exp11']
# base = './output/UNICON_experiment_2/SEEG/'

folders = ['exp1', 'exp2','exp3','exp4','exp5','exp6','exp7','exp8','exp9','exp10','exp11','exp12']
base = './output/UNICON_experiment_2/fNIRS_2/'

# folders = ['exp1', 'exp2','exp3','exp4','exp5','exp6']
# base = './output/UNICON_experiment_2/Sleep/'

# Create an empty dataframe to store the merged results
merged_df = pd.DataFrame()

noise_ratio = input() # 0 20 40
base = base + noise_ratio + '/'

# Loop through each directory and CSV file, and read only the second row into a new dataframe
for dirname in folders:
    print(dirname)
    if os.path.isdir(base + dirname):
        # filepath = os.path.join(base, dirname, 'plus', 'test_results.csv')
        filepath = os.path.join(base, dirname, 'test_results.csv')
        print(filepath)
        if os.path.isfile(filepath):
            df = pd.read_csv(filepath, skiprows=1, nrows=1, header=None) # skiprows=2, bestf1
            merged_df = pd.concat([merged_df, df], ignore_index=True)
        else:
            print('Illegal file path')
            exit(0)

# Write the merged dataframe to a new CSV file
merged_df.to_csv(base+'merged_results.csv', index=False)
