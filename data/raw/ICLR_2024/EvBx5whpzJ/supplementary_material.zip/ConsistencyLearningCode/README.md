# Con4m

Please generate the database first 
- pipeline/b_fNIRS_database_generate.py
- pipeline/b_Sleep_database_generate.py

Then run the main files
- Con4m
  - a_train.py
  - b_test.py
- baselines
  - baseline/Sel-CL/src/train_Sel-CL_*.py
  - baseline/Sel-CL/src/test_Sel-CL.py
  - baseline/sktime_model/model_main.py
  - baseline/SREA/src/*_single_experiment.py
  - baseline/SREA/src/*_test.py
  - baseline/Time-Series-Library/run.py
  - baseline/UNICON-Noisy-Label/train_blurred.py
  - baseline/UNICON-Noisy-Label/test_blurred.py
