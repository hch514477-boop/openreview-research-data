# Angle

We only provide the core model file in the review phase. 
To ensure reproducibility, all our experiments are run with a random seed of 42, and all results are the average of five runs.
We will publish our training code, training details, and pre-trained checkpoints after the review process.
