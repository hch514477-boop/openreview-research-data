# Supplementary material

This directory contains the source code used to perform the experiments described in the paper.

Execution instructions:
1. Install all dependencies in pyproject.toml
2. Execute the provided .sh script for each experiment.
    - Marble maze: planning_marble.sh
    - Password locomotion:
        - Run pre-train script: pretrain_rl.sh
        - Run experiment: planning_buttons.sh
    - Marble run: marble_drop.sh

The experiments were conducted using 32 cores.
