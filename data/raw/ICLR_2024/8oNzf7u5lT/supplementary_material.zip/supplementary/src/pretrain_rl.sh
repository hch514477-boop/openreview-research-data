# Run this script to pre-train the button-pushing policy
output_dir="planning_buttons_pretrain" ;

# Delete previous output
rm -r $output_dir
mkdir $output_dir ;

# Incrementally pre-train policy 10 times
for l in 1 2 3 4 5 6 7 8 9 10
do
	xvfb-run -a -s "-screen 0 1400x900x24" python examples/planning_buttons/pretrain_rl.py --timeout-h 1 --max-button-n 3 --worker-n 32 --output-dir $output_dir ;
done
