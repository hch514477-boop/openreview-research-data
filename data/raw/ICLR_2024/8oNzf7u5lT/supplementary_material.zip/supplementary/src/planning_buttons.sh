# Call this after pre-training
pretrain_dir="planning_buttons_pretrain" ;
output_dir="planning_buttons" ;

# Run experiment
xvfb-run -a -s "-screen 0 1400x900x24" python examples/planning_buttons/main.py --pretrained_dir $pretrain_dir ;
