# This script spawns a lot of sub-processes
# To use CTRl-C to kill all sub-processes run this script with
# (trap 'kill 0' SIGINT; bash planning_marble.sh)

output_dir="planning_marble" ;

# Perform experiments in parallel
i=0
current_workers=0
max_workers=64
len_repeat=5
for maze_len in 3 5 7 8 9
do
	for ((j=0; j<len_repeat; j++))
	do
		if [ "$current_workers" -ge "$max_workers" ];
		then
			wait
			current_workers=0
		fi
		i=$((i+1))
		current_workers=$(($current_workers+1))
		python examples/planning_marble/main.py --maze_len $maze_len --experiment_seed $i --output_dir $output_dir/"run_$i" &
	done
done

wait

# Merge results
python examples/merge.py --time_jsons $output_dir/**/results.json --quality_jsons $output_dir/**/quality_results.json --output_dir $output_dir/"combined"

# Plot merged results
python examples/plotting.py --time_results_json $output_dir/combined/time_results.json --quality_results_json $output_dir/combined/quality_results.json --output_dir $output_dir/combined_plots/
