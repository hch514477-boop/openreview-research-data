#### Steps
1. Generate the benign classifier on the clean dataset
```python
python naturalTrain.py
```
2. Generate the poisoned images
```python
python poisoned_data.py train=False,True clean=True,False -m
```
3. Train classifier on the poisoned dataset
```python
python PPT.py TRAIN.poison_rate=0.01 dataset_cfg=cifar10 ATTACK=PPT TRAIN.clean_label=False,True -m
```
4. check the attack success rate
```python
python transfer.py 
```
Classifier in "transfer.py" is the infected classifier, generator is the benign classifier trained on the clean dataset in step 1.


Note:
Don't forget to modify the pathway for dataset and checkpoint of models.
