#!/usr/bin/bash

# python IBA.py attack_cfg.poison_rate=0.1
# python IBA.py attack_cfg.poison_rate=0.2
# python IBA.py attack_cfg.poison_rate=0.3
# python IBA.py attack_cfg.poison_rate=0.4
# python IBA.py attack_cfg.poison_rate=0.5
# python IBA.py attack_cfg.poison_rate=0.6
# python IBA.py attack_cfg.poison_rate=0.7
# python IBA.py attack_cfg.poison_rate=0.8
# python IBA.py attack_cfg.poison_rate=0.9
# python IBA.py attack_cfg.poison_rate=1.0


# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.01 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.02 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.03 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.04 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.05 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.06 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.07 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.08 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.09 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.1 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=False


# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.1 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=True
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.2 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=True
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.3 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=True
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.4 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=True
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.5 dataset_cfg=svhn ATTACK=IBA TRAIN.clean_label=True


# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.01 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.02 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.03 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.04 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.05 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.06 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.07 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.08 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.09 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=0 python IBA3.py TRAIN.poison_rate=0.1 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=False



# CUDA_VISIBLE_DEVICES=2 python IBA3.py TRAIN.poison_rate=0.5 dataset_cfg=tinyIN ATTACK=TooBad TRAIN.clean_label=True
# CUDA_VISIBLE_DEVICES=2 python IBA3.py TRAIN.poison_rate=0.1 dataset_cfg=tinyIN ATTACK=MARKSMAN TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=2 python IBA3.py TRAIN.poison_rate=0.5 dataset_cfg=tinyIN ATTACK=MARKSMAN TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=2 python IBA3.py TRAIN.poison_rate=0.5 dataset_cfg=tinyIN ATTACK=TooBad TRAIN.clean_label=False
# CUDA_VISIBLE_DEVICES=2 python IBA3.py TRAIN.poison_rate=0.5 dataset_cfg=tinyIN ATTACK=WANET TRAIN.clean_label=False

# CUDA_VISIBLE_DEVICES=1 python IBA3.py TRAIN.poison_rate=0.5 dataset_cfg=tinyIN ATTACK=WANET TRAIN.clean_label=True
# CUDA_VISIBLE_DEVICES=1 python IBA3.py TRAIN.poison_rate=0.5 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=True
# CUDA_VISIBLE_DEVICES=1 python IBA3.py TRAIN.poison_rate=0.1 dataset_cfg=svhn ATTACK=TooBad TRAIN.clean_label=True
