### CODE FOR "ONLINE WEIGHT APPROXIMATION FOR CONTINUAL LEARNING," ICLR 2024 ###

- All the experiments have been run with Python 3.10.12 using PyTorch version
  2.0.1.

- All the necessary dependencies can be found in the attached file
  package-list.txt.

- All experiments described in the paper can be launched from the script
  ./code/run.py by changing the command lines defined there. or by running
  the individual files ./code/main_incremental.py and
  ./code/main_sequential.py. All parameters can be passed via the command
  line. By default, the script run.py will run the last command line in the
  list "commands"

- The script main_incremental.py will launch the experiments related to the
  setting described in section 4.1 (Incrementally Permuted Datasets).

- The script main_sequential.py will launch the experiments related to the
  setting described in section 4.2 (Class Incremental/Split Datasets).

- All the parameters used have been described in the main paper except for
  the fixed seeds, which are {3, 31, 314}.
