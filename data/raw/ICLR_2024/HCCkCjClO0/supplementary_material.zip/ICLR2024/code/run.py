import os

commands = [
            "python main_incremental.py --dataset 'mnist' --order 20 --batch_size 128 --epochs 10 --n_tasks 1 --n_perm_pix 100"
            " --wandb_project 'woa' --wandb_group 'mnist_images' --hippo true --replay false --seed 3",

            "python main_sequential.py --dataset 'cub200'"
            ]

commands = [commands[-1]]

for command in commands:
    print(command)
    os.system(command)

