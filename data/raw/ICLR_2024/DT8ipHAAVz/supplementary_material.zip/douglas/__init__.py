from ._tree import Douglas

__all__ = ["Douglas"]