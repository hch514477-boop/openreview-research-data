# Creation of the environment

```
conda create -n kauri python=3.9
```

# Basic requirements

A file `requirements.txt` is provided. Please be sure *not to change* the required versions of the packages.
The installer of ExShallow expects numpy to be already installed, hence the twofold `pip install`.

```
conda create -n kauri python=3.9
conda activate kauri
pip install -r requirements.txt
pip install ExShallow
```