from setuptools import setup, Extension
import numpy as np

module = Extension('_utils', sources=['_utils.pyx'])

setup(
    name='kauriutils',
    version='1.0',
    author='jetbrains',
    ext_modules=[module],
    include_dirs=[np.get_include()]
)
