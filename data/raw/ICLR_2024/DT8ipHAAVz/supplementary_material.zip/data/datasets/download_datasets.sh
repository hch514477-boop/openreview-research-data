#!/bin/bash

# Download the avila dataset
wget https://www.openml.org/data/download/22045581/dataset avila
mv dataset avila.arff

# breast cancer dataset
wget https://archive.ics.uci.edu/static/public/15/breast+cancer+wisconsin+original.zip
mv breast+cancer+wisconsin+original.zip breast_cancer.zip

# car evaluation dataset
wget https://archive.ics.uci.edu/static/public/19/car+evaluation.zip
mv car+evaluation.zip car_evaluation.zip

# Congressionl voting records dataset
wget https://archive.ics.uci.edu/static/public/105/congressional+voting+records.zip
mv congressional+voting+records.zip congressional_voting_records.zip

# Haberman's survival dataset
wget https://archive.ics.uci.edu/static/public/43/haberman+s+survival.zip
mv haberman+s+survival.zip haberman_survival.zip

# Mice protein expression dataset
wget https://archive.ics.uci.edu/static/public/342/mice+protein+expression.zip
mv mice+protein+expression.zip mice_protein_expression.zip

# Poker hand dataset
wget https://archive.ics.uci.edu/static/public/158/poker+hand.zip
mv poker+hand.zip poker_hand.zip

# Vowel dataset
wget https://www.openml.org/data/download/53550/vowel.arff
