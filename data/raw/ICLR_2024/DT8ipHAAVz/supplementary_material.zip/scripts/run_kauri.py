from cppkauri import Kauri

def run(args, X):
    model = Kauri(max_clusters=args.n_clusters, max_depth=args.max_depth, min_samples_split=args.min_samples_split,
          min_samples_leaf=args.min_samples_leaf, max_leaves=args.max_leaves, max_features=args.max_features,
          kernel=args.kernel, verbose=True)

    y_pred = model.fit_predict(X)

    return y_pred, model.tree_
