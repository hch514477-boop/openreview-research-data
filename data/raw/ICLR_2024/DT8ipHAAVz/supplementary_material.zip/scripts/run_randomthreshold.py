from ShallowTree.RandomThresholdTree import RandomThresholdTree
from sklearn.cluster import KMeans

def run(args, X):

    # create a tree that will partition the data into k clusters
    tree = RandomThresholdTree(args.n_clusters)

    # The kmeans call is contained in the fit call
    tree.fit(X)

    return tree.predict(X), tree.tree