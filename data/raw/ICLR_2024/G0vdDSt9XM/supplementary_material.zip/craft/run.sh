# CONFIG_NAMES=vqa_v2_config nohup nohup python run_baseline.py --eval_dataset vqa_v2 --model turbo >logs/vqa_v2.log 2>&1 &
CONFIG_NAMES=okvqa_config CUDA_VISIBLE_DEVICES=0 nohup python run_baseline.py --eval_dataset aokvqa --model turbo >logs/aokvqa.log 2>&1 &
CONFIG_NAMES=okvqa_config CUDA_VISIBLE_DEVICES=1 nohup python run_baseline.py --eval_dataset okvqa --model turbo >logs/okvqa.log 2>&1 &
CONFIG_NAMES=gqa_config CUDA_VISIBLE_DEVICES=2 nohup python run_baseline.py --eval_dataset gqa --model turbo >logs/gqa.log 2>&1 &
# CONFIG_NAMES=retrieval_vqa_v2_config CUDA_VISIBLE_DEVICES=3 nohup python run_baseline.py --eval_dataset vqa_v2 --model turbo --retrieval >logs/vqa_v2_retrieval.log 2>&1 &
CONFIG_NAMES=retrieval_okvqa_config CUDA_VISIBLE_DEVICES=4 nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval >logs/aokvqa_retrieval.log 2>&1 &
CONFIG_NAMES=retrieval_okvqa_config CUDA_VISIBLE_DEVICES=5 nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval >logs/okvqa_retrieval.log 2>&1 &
CONFIG_NAMES=retrieval_gqa_config CUDA_VISIBLE_DEVICES=6 nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval >logs/gqa_retrieval.log 2>&1 &


# backbone scaling
# CONFIG_NAMES=gpt4_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model gpt4 >logs/gpt4_aokvqa.log 2>&1 &
# CONFIG_NAMES=gpt4_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model gpt4 >logs/gpt4_okvqa.log 2>&1 &
# CONFIG_NAMES=gpt4_gqa_config nohup python run_baseline.py --eval_dataset gqa --model gpt4 >logs/gpt4_gqa.log 2>&1 &

# CONFIG_NAMES=gpt4_retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model gpt4 --retrieval >logs/gpt4_aokvqa_retrieval.log 2>&1 &
# CONFIG_NAMES=gpt4_retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model gpt4 --retrieval >logs/gpt4_okvqa_retrieval.log 2>&1 &
# CONFIG_NAMES=gpt4_retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model gpt4 --retrieval >logs/gpt4_gqa_retrieval.log 2>&1 &

# tool scaling law
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 1 >logs/aokvqa_retrieval_1.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 2 >logs/aokvqa_retrieval_2.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 3 >logs/aokvqa_retrieval_3.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 4 >logs/aokvqa_retrieval_4.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 5 >logs/aokvqa_retrieval_5.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 6 >logs/aokvqa_retrieval_6.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 7 >logs/aokvqa_retrieval_7.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 8 >logs/aokvqa_retrieval_8.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 9 >logs/aokvqa_retrieval_9.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --tool_epoch 10 >logs/aokvqa_retrieval_10.log 2>&1 &


# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 1 >logs/okvqa_retrieval_1.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 2 >logs/okvqa_retrieval_2.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 3 >logs/okvqa_retrieval_3.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 4 >logs/okvqa_retrieval_4.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 5 >logs/okvqa_retrieval_5.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 6 >logs/okvqa_retrieval_6.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 7 >logs/okvqa_retrieval_7.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 8 >logs/okvqa_retrieval_8.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 9 >logs/okvqa_retrieval_9.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --tool_epoch 10 >logs/okvqa_retrieval_10.log 2>&1 &


# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 1 >logs/gqa_retrieval_1.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 2 >logs/gqa_retrieval_2.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 3 >logs/gqa_retrieval_3.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 4 >logs/gqa_retrieval_4.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 5 >logs/gqa_retrieval_5.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 6 >logs/gqa_retrieval_6.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 7 >logs/gqa_retrieval_7.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 8 >logs/gqa_retrieval_8.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 9 >logs/gqa_retrieval_9.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --tool_epoch 10 >logs/gqa_retrieval_10.log 2>&1 &


# ablation
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --ablation query >logs/aokvqa_retrieval_no_query.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --ablation name >logs/aokvqa_retrieval_no_name.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset aokvqa --model turbo --retrieval --ablation docstring >logs/aokvqa_retrieval_no_docstring.log 2>&1 &

# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --ablation query >logs/okvqa_retrieval_no_query.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --ablation name >logs/okvqa_retrieval_no_name.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config nohup python run_baseline.py --eval_dataset okvqa --model turbo --retrieval --ablation docstring >logs/okvqa_retrieval_no_docstring.log 2>&1 &

# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --ablation query >logs/gqa_retrieval_no_query.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --ablation name >logs/gqa_retrieval_no_name.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config nohup python run_baseline.py --eval_dataset gqa --model turbo --retrieval --ablation docstring >logs/gqa_retrieval_no_docstring.log 2>&1 &



# CONFIG_NAMES=retrieval_okvqa_config python run_baseline_ablation.py --eval_dataset aokvqa --model turbo --retrieval --ablation abstraction >logs/aokvqa_retrieval_no_abstraction.log 2>&1 &
# CONFIG_NAMES=retrieval_okvqa_config python run_baseline_ablation.py --eval_dataset okvqa --model turbo --retrieval --ablation abstraction >logs/okvqa_retrieval_no_abstraction.log 2>&1 &
# CONFIG_NAMES=retrieval_gqa_config python run_baseline_ablation.py --eval_dataset gqa --model turbo --retrieval --ablation abstraction >logs/gqa_retrieval_no_abstraction.log 2>&1 &



# open domain
# CONFIG_NAMES=llava_config nohup python run_baseline.py --eval_dataset llava --model turbo >logs/llava.log 2>&1 &
# CONFIG_NAMES=retrieval_llava_config nohup python run_baseline.py --eval_dataset llava --model turbo --retrieval >logs/llava_retrieval.log 2>&1 &
