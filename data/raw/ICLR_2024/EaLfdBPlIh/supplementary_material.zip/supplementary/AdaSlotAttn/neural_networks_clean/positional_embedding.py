import torch
from torch import nn

class DummyPositionEmbed(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, inputs: torch.Tensor, positions: torch.Tensor):
        return inputs
