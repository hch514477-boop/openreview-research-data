# Code Base
[MultiBench](https://cmu-multicomp-lab.github.io/multibench/)

# Env Setup

```bash
conda env create -f env_config.yml
```

# Data Download
```bash
./download_datasets.sh [dataset]
```

# SM $^4$ Training
```bash
iclr24/mmoe_four_tasks.sh

iclr24/mmoe_three_tasks_with_pretrain.sh

iclr24/mmoe_two_task.sh
```