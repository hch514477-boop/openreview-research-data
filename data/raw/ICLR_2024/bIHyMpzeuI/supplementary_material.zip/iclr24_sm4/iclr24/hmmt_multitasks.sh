###
 # @Author: pengjie pengjieb@mail.ustc.edu.cn
 # @Date: 2022-05-25 22:56:25
 # @LastEditors: pengjie pengjieb@mail.ustc.edu.cn
 # @LastEditTime: 2022-09-09 17:38:51
 # @FilePath: /MultiBench/running_scripts/hmmt_multitasks.sh
 # @Description: 
 # 
 # Copyright (c) 2022 by pengjie pengjieb@mail.ustc.edu.cn, All Rights Reserved. 
### 
# cd ../
path_prefix=`pwd`


gpu_id=0
py_file=private_test_scripts/perceivers/fourmultitask.py
debug=1
if [ $debug -eq 1 ]; then
    max_epochs=1
    is_train=1
    seeds=123
else
    max_epochs=80
    is_train=1
    seeds='123 321 132'
fi

for seed in $seeds
do
    args="--model-path private_test_scripts/model/multitasks_four_task.pth --seed $seed --epochs $max_epochs --is-train $is_train --debug $debug"
    CUDA_VISIBLE_DEVICES=$gpu_id python -u $py_file ${args}
done

