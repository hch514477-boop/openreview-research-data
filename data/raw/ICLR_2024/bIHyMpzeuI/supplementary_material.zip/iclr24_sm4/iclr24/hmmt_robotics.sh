
# cd ../
path_prefix=`pwd`


gpu_id=0
py_file=private_test_scripts/perceivers/roboticstasks.py
debug=0
if [ $debug -eq 1 ]; then
    max_epochs=1
    is_train=0
    seeds=123
else
    max_epochs=100
    is_train=1
    seeds='123 321 132'
fi

for seed in $seeds
do
    args="--model-path private_test_scripts/model/robotics.pth --seed $seed --epochs $max_epochs --is-train $is_train"
    CUDA_VISIBLE_DEVICES=$gpu_id python -u $py_file ${args}
done

