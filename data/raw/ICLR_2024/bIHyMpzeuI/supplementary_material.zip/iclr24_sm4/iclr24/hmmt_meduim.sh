###
 # @Author: pengjie pengjieb@mail.ustc.edu.cn
 # @Date: 2022-05-25 22:56:25
 # @LastEditors: pengjie pengjieb@mail.ustc.edu.cn
 # @LastEditTime: 2022-09-28 18:44:39
 # @FilePath: /MultiBench/running_scripts/hmmt_meduim.sh
 # @Description: 
 # 
 # Copyright (c) 2022 by pengjie pengjieb@mail.ustc.edu.cn, All Rights Reserved. 
### 
# cd ../
path_prefix=`pwd`


gpu_id=1
py_file=private_test_scripts/perceivers/medium_tasks.py
debug=0
if [ $debug -eq 1 ]; then
    max_epochs=1
    is_train=0
    seeds=123
else
    max_epochs=100
    is_train=1
    seeds='123 321 132'
fi

for seed in $seeds
do
    args="--model-path private_test_scripts/model/medium.pth --seed $seed --epochs $max_epochs --is-train $is_train"
    CUDA_VISIBLE_DEVICES=$gpu_id python -u $py_file ${args}
done

python -m utils.fs_msg_bot $0