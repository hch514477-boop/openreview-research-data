from agents.control.alr import ALR
from agents.control.dqn import DQN
from agents.control.wql import WQL
