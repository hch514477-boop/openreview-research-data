
To run PiLaR DQN:
```
python compound_returns/run_control.py --agent ALR --defaults minatar --env MinAtar/Freeway-v1 --estimator ql-pilar-10 --cpu --verbose
```

To run the $n$-step DQN baseline:
```
python compound_returns/run_control.py --agent DQN --defaults minatar --env MinAtar/Freeway-v1 --estimator ql-nstep-10 --cpu --verbose
```

Change the $n$-step for either method by editing `n` in `--estimator ql-<name>-<n>`.

Note: `--vebose` must be included to see printable output.
Omit `--cpu` to enable GPU training.
